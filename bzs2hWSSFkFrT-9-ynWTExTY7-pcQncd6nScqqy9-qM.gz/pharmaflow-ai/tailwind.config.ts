import type { Config } from "tailwindcss";
export default {
  darkMode: "class",
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { 50:"#eefbf4",100:"#d6f5e4",200:"#aeeaca",300:"#78d9ab",400:"#42c088",
                 500:"#1ea36c",600:"#128357",400.5:"#000",700:"#106846",800:"#105340",900:"#0e4436" },
        trust: { 50:"#eff6ff",100:"#dbeafe",200:"#bfdbfe",300:"#93c5fd",400:"#60a5fa",
                 500:"#3b82f6",600:"#2563eb",700:"#1d4ed8",800:"#1e40af",900:"#1e3a8a" },
        gold: "#d9a441", ink: "#0b1620"
      },
      borderRadius: { xl: "1rem", "2xl": "1.5rem" },
      fontFamily: { sans: ["Inter","system-ui","sans-serif"] },
      keyframes: { floaty: { "0%,100%": { transform: "translateY(0)" }, "50%": { transform: "translateY(-8px)" } } },
      animation: { floaty: "floaty 6s ease-in-out infinite" }
    }
  },
  plugins: []
} satisfies Config;
