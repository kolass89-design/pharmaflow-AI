"use client";
import { useMemo, useState } from "react";
import { fcfa } from "@/lib/utils";

export default function RoiCalculator() {
  const [ventes, setVentes] = useState(120);
  const [panier, setPanier] = useState(4500);
  const [pertes, setPertes] = useState(8);

  const r = useMemo(() => {
    const caMensuel = ventes * panier * 26;
    const perteMensuelle = (caMensuel * pertes) / 100;
    const perteEvitee = perteMensuelle * 0.45;       // ruptures & péremptions évitées
    const tempsGagne = 2.25 * 26 * 1200;              // 2h15/j valorisées 1 200 FCFA/h
    const total = perteEvitee + tempsGagne;
    return { caMensuel, perteMensuelle, perteEvitee, tempsGagne, total, net: total - 39000 };
  }, [ventes, panier, pertes]);

  const Field = ({ label, value, set, min, max, step, suffix }: any) => (
    <label className="block">
      <span className="flex justify-between text-sm font-medium">
        {label} <span className="text-brand-600">{value.toLocaleString("fr-FR")}{suffix}</span>
      </span>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => set(Number(e.target.value))}
        className="mt-2 w-full accent-brand-600" />
    </label>
  );

  return (
    <div className="grid gap-8 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 lg:grid-cols-2 dark:border-white/10 dark:bg-white/5">
      <div className="space-y-6">
        <Field label="Ventes par jour" value={ventes} set={setVentes} min={20} max={600} step={5} suffix="" />
        <Field label="Panier moyen" value={panier} set={setPanier} min={800} max={20000} step={100} suffix=" FCFA" />
        <Field label="Pertes estimées (ruptures + péremptions)" value={pertes} set={setPertes} min={1} max={25} step={1} suffix=" %" />
        <p className="text-xs muted">
          Estimation indicative basée sur 26 jours d'ouverture, une réduction moyenne de 45 % des pertes
          observée chez nos officines pilotes et 2 h 15 de travail administratif économisées par jour.
        </p>
      </div>
      <div className="rounded-xl bg-gradient-to-br from-brand-600 to-trust-700 p-6 text-white">
        <p className="text-sm/6 opacity-80">Chiffre d'affaires mensuel estimé</p>
        <p className="text-2xl font-bold">{fcfa(r.caMensuel)}</p>
        <div className="my-5 h-px bg-white/20" />
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between"><dt className="opacity-80">Pertes actuelles</dt><dd>{fcfa(r.perteMensuelle)}</dd></div>
          <div className="flex justify-between"><dt className="opacity-80">Pertes évitées</dt><dd>{fcfa(r.perteEvitee)}</dd></div>
          <div className="flex justify-between"><dt className="opacity-80">Temps administratif valorisé</dt><dd>{fcfa(r.tempsGagne)}</dd></div>
        </dl>
        <div className="my-5 h-px bg-white/20" />
        <p className="text-sm opacity-80">Économies potentielles / mois</p>
        <p className="text-3xl font-extrabold text-gold">{fcfa(r.total)}</p>
        <p className="mt-2 text-xs opacity-80">Soit {fcfa(r.net)} net après abonnement Pro (39 000 FCFA/mois).</p>
      </div>
    </div>
  );
}
