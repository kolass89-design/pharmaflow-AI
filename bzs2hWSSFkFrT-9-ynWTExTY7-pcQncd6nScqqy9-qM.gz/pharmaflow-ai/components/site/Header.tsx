"use client";
import Link from "next/link";
import { useState } from "react";
import Logo from "./Logo";

const nav = [
  { href: "/", label: "Accueil" },
  { href: "/fonctionnalites", label: "Fonctionnalités" },
  { href: "/demo", label: "Démo" },
  { href: "/tarifs", label: "Tarifs" },
  { href: "/trouver-un-medicament", label: "Trouver un médicament" },
  { href: "/pharmacies-de-garde", label: "Pharmacies de garde" },
  { href: "/ressources", label: "Ressources" },
  { href: "/contact", label: "Contact" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/70 bg-white/85 backdrop-blur dark:border-white/10 dark:bg-ink/85">
      <div className="container-x flex h-16 items-center justify-between">
        <Link href="/" aria-label="PharmaFlow AI"><Logo /></Link>
        <nav className="hidden items-center gap-6 lg:flex">
          {nav.map(n => (
            <Link key={n.href} href={n.href} className="text-sm font-medium muted hover:text-brand-600">{n.label}</Link>
          ))}
        </nav>
        <div className="hidden items-center gap-3 lg:flex">
          <Link href="/demo" className="btn-ghost !py-2">Voir une démo</Link>
          <Link href="/inscription" className="btn-primary !py-2">Essai gratuit</Link>
        </div>
        <button onClick={() => setOpen(!open)} className="rounded-lg border border-slate-300 p-2 lg:hidden dark:border-white/15" aria-label="Menu">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
        </button>
      </div>
      {open && (
        <div className="border-t border-slate-200 bg-white px-4 pb-4 lg:hidden dark:border-white/10 dark:bg-ink">
          {nav.map(n => (
            <Link key={n.href} href={n.href} onClick={() => setOpen(false)} className="block py-3 text-sm font-medium border-b border-slate-100 dark:border-white/5">{n.label}</Link>
          ))}
          <div className="mt-4 flex gap-3">
            <Link href="/demo" className="btn-ghost flex-1">Démo</Link>
            <Link href="/inscription" className="btn-primary flex-1">Essai gratuit</Link>
          </div>
        </div>
      )}
    </header>
  );
}
