"use client";
import { useState } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { salesWeek, products, prescriptions, aiRecos, waThread } from "@/lib/mock";
import { fcfa } from "@/lib/utils";

const tabs = ["Tableau de bord", "Ventes", "Stock", "Ordonnances", "IA", "WhatsApp"] as const;
type Tab = (typeof tabs)[number];

export default function DashboardPreview() {
  const [tab, setTab] = useState<Tab>("Tableau de bord");
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-lg dark:border-white/10 dark:bg-white/5">
      <div className="flex items-center gap-2 border-b border-slate-200 bg-slate-50 px-4 py-3 dark:border-white/10 dark:bg-white/5">
        <span className="h-3 w-3 rounded-full bg-rose-400" />
        <span className="h-3 w-3 rounded-full bg-amber-400" />
        <span className="h-3 w-3 rounded-full bg-emerald-400" />
        <span className="ml-3 text-xs muted">Pharmacie Étoile — Cotonou</span>
      </div>
      <div className="flex gap-1 overflow-x-auto border-b border-slate-200 px-3 py-2 dark:border-white/10">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={
              "whitespace-nowrap rounded-lg px-3 py-2 text-xs font-semibold transition " +
              (tab === t ? "bg-brand-600 text-white" : "muted hover:bg-slate-100 dark:hover:bg-white/10")
            }
          >
            {t}
          </button>
        ))}
      </div>
      <div className="p-4 sm:p-6">
        {tab === "Tableau de bord" && <Overview />}
        {tab === "Ventes" && <Ventes />}
        {tab === "Stock" && <Stock />}
        {tab === "Ordonnances" && <Ordonnances />}
        {tab === "IA" && <IA />}
        {tab === "WhatsApp" && <Wa />}
      </div>
    </div>
  );
}

function Kpi({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-xl border border-slate-200 p-4 dark:border-white/10">
      <p className="text-xs muted">{label}</p>
      <p className="mt-1 text-xl font-bold">{value}</p>
      {hint && <p className="mt-1 text-xs text-brand-600">{hint}</p>}
    </div>
  );
}

function Overview() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Kpi label="CA du jour" value={fcfa(704900)} hint="+12,4 % vs hier" />
        <Kpi label="Ventes" value="143" hint="Panier moyen 4 930 FCFA" />
        <Kpi label="Ordonnances" value="41" />
        <Kpi label="Alertes stock" value="7" hint="3 critiques" />
      </div>
      <div className="h-56 rounded-xl border border-slate-200 p-3 dark:border-white/10">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={salesWeek}>
            <defs>
              <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1ea36c" stopOpacity={0.5} />
                <stop offset="100%" stopColor="#1ea36c" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="jour" tickLine={false} axisLine={false} fontSize={12} />
            <YAxis hide />
            <Tooltip formatter={(v: number) => fcfa(v)} />
            <Area type="monotone" dataKey="ventes" stroke="#128357" strokeWidth={2} fill="url(#g1)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function Ventes() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="h-56 rounded-xl border border-slate-200 p-3 dark:border-white/10">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={salesWeek}>
            <XAxis dataKey="jour" tickLine={false} axisLine={false} fontSize={12} />
            <YAxis hide />
            <Tooltip formatter={(v: number) => fcfa(v)} />
            <Bar dataKey="ventes" fill="#2563eb" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="rounded-xl border border-slate-200 p-4 text-sm dark:border-white/10">
        <p className="mb-3 font-semibold">Derniers tickets</p>
        <ul className="space-y-2 muted">
          <li className="flex justify-between"><span>TK-90211 · Espèces</span><span>{fcfa(7400)}</span></li>
          <li className="flex justify-between"><span>TK-90212 · MTN MoMo</span><span>{fcfa(2500)}</span></li>
          <li className="flex justify-between"><span>TK-90213 · Moov Money</span><span>{fcfa(15200)}</span></li>
          <li className="flex justify-between"><span>TK-90214 · Wave</span><span>{fcfa(3900)}</span></li>
          <li className="flex justify-between"><span>TK-90215 · Celtiis Cash</span><span>{fcfa(6100)}</span></li>
        </ul>
      </div>
    </div>
  );
}

function Stock() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="text-xs uppercase muted">
          <tr>
            <th className="py-2">Produit</th><th>Lot</th><th>Exp.</th><th>Stock</th><th>PV</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id} className="border-t border-slate-100 dark:border-white/5">
              <td className="py-2 pr-3 font-medium">{p.nom}</td>
              <td className="muted">{p.lot}</td>
              <td className="muted">{p.expiration}</td>
              <td>
                <span className={"rounded-full px-2 py-0.5 text-xs font-semibold " + (p.stock < p.seuil ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-700")}>
                  {p.stock}
                </span>
              </td>
              <td className="muted">{fcfa(p.vente)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Ordonnances() {
  return (
    <ul className="space-y-3 text-sm">
      {prescriptions.map((o) => (
        <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 dark:border-white/10">
          <span className="font-medium">{o.id} · {o.patient}</span>
          <span className="muted">{o.medecin} — {o.items} lignes</span>
          <span className="badge">{o.statut}</span>
        </li>
      ))}
    </ul>
  );
}

function IA() {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {aiRecos.map((r) => (
        <div key={r.titre} className="rounded-xl border border-slate-200 p-4 dark:border-white/10">
          <div className="flex items-center justify-between">
            <p className="font-semibold">{r.titre}</p>
            <span className="badge">{r.niveau}</span>
          </div>
          <p className="mt-2 text-sm muted">{r.detail}</p>
        </div>
      ))}
    </div>
  );
}

function Wa() {
  return (
    <div className="mx-auto max-w-md space-y-3">
      {waThread.map((m, i) => (
        <div key={i} className={"flex " + (m.from === "patient" ? "justify-start" : "justify-end")}>
          <p className={"max-w-[80%] rounded-2xl px-4 py-2 text-sm " + (m.from === "patient" ? "bg-slate-100 dark:bg-white/10" : "bg-brand-600 text-white")}>
            {m.text}
          </p>
        </div>
      ))}
    </div>
  );
}
