"use client";
import { useState } from "react";

type G = { pharmacie: string; ville: string; quartier: string; tel: string; periode: string };

export default function GuardsList({ rows }: { rows: G[] }) {
  const [ville, setVille] = useState("Toutes");
  const villes = ["Toutes", ...Array.from(new Set(rows.map(g => g.ville)))];
  const list = ville === "Toutes" ? rows : rows.filter(g => g.ville === ville);

  return (
    <>
      <div className="flex flex-wrap gap-2">
        {villes.map(v => (
          <button key={v} onClick={() => setVille(v)}
            className={"rounded-full px-4 py-2 text-sm font-semibold " + (ville === v ? "bg-brand-600 text-white" : "border border-slate-300 muted dark:border-white/15")}>
            {v}
          </button>
        ))}
      </div>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((g, i) => (
          <div key={i} className="card">
            <span className="badge">De garde</span>
            <h2 className="mt-3 font-semibold">{g.pharmacie}</h2>
            <p className="mt-1 text-sm muted">{g.quartier}{g.quartier && ", "}{g.ville}</p>
            <p className="mt-3 text-sm">{g.tel}</p>
            <p className="mt-1 text-xs muted">{g.periode}</p>
            <div className="mt-4 flex gap-2">
              <a href={`tel:${g.tel.replace(/\s/g, "")}`} className="btn-ghost !py-2 !text-xs">Appeler</a>
              <a href={`https://maps.google.com/?q=${encodeURIComponent(g.pharmacie + " " + g.ville)}`} target="_blank" rel="noopener" className="btn-primary !py-2 !text-xs">Itinéraire</a>
            </div>
          </div>
        ))}
        {!list.length && <p className="text-sm muted">Aucune pharmacie de garde publiée pour cette ville.</p>}
      </div>
      <p className="mt-8 text-xs muted">
        Informations fournies par les officines partenaires. Vérifiez par téléphone avant de vous déplacer.
      </p>
    </>
  );
}
