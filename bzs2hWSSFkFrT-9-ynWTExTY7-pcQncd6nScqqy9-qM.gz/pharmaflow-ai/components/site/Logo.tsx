export default function Logo({ className = "" }: { className?: string }) {
  return (
    <span className={"inline-flex items-center gap-2 " + className}>
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden>
        <rect width="32" height="32" rx="10" fill="url(#pf)" />
        <path d="M9 16h14M16 9v14" stroke="#fff" strokeWidth="3" strokeLinecap="round" />
        <path d="M6 22c4 3 8-3 12 0s6 1 8-1" stroke="#d9a441" strokeWidth="2" strokeLinecap="round" fill="none" opacity=".9"/>
        <defs><linearGradient id="pf" x1="0" y1="0" x2="32" y2="32">
          <stop stopColor="#128357" /><stop offset="1" stopColor="#2563eb" /></linearGradient></defs>
      </svg>
      <span className="text-lg font-bold tracking-tight">PharmaFlow<span className="text-brand-600"> AI</span></span>
    </span>
  );
}
