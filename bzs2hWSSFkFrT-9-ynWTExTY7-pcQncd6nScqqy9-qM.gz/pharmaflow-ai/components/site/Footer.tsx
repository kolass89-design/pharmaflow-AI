import Link from "next/link";
import Logo from "./Logo";

export default function Footer() {
  const col = (t: string, links: [string, string][]) => (
    <div>
      <h4 className="mb-3 text-sm font-semibold">{t}</h4>
      <ul className="space-y-2 text-sm muted">
        {links.map(([l, h]) => <li key={h}><Link href={h} className="hover:text-brand-600">{l}</Link></li>)}
      </ul>
    </div>
  );
  return (
    <footer className="border-t border-slate-200 bg-white dark:border-white/10 dark:bg-ink">
      <div className="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-6">
        <div className="lg:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm muted">
            Le logiciel de gestion d'officine pensé pour l'Afrique francophone : caisse, stock,
            ordonnances, IA et WhatsApp — même quand le réseau faiblit.
          </p>
          <p className="mt-4 text-sm muted">Cotonou · Lomé · Abidjan · Dakar · Niamey · Douala</p>
        </div>
        {col("Produit", [["Fonctionnalités","/fonctionnalites"],["Démo interactive","/demo"],["Tarifs","/tarifs"]])}
        {col("Espace patient", [["Trouver un médicament","/trouver-un-medicament"],["Suivre ma réservation","/ma-reservation"],["Pharmacies de garde","/pharmacies-de-garde"]])}
        {col("Ressources", [["Blog","/blog"],["Guides","/ressources"],["Contact","/contact"]])}
        {col("Légal", [["Mentions légales","/contact#mentions"],["Confidentialité","/contact#confidentialite"],["Conditions d'utilisation","/contact#cgu"],["Sécurité","/fonctionnalites#securite"]])}
      </div>
      <div className="border-t border-slate-200 py-6 dark:border-white/10">
        <div className="container-x flex flex-col gap-3 text-sm muted sm:flex-row sm:items-center sm:justify-between">
          <span>© {new Date().getFullYear()} PharmaFlow AI. Tous droits réservés.</span>
          <span className="flex gap-4">
            <a href="https://wa.me/22900000000" className="hover:text-brand-600">WhatsApp</a>
            <a href="mailto:bonjour@pharmaflow.ai" className="hover:text-brand-600">bonjour@pharmaflow.ai</a>
            <a href="#" className="hover:text-brand-600">LinkedIn</a>
          </span>
        </div>
      </div>
    </footer>
  );
}
