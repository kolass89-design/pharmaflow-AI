"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "./Shell";
import { FormulairePharmacie, FormulaireHoraires, InviterMembre, BasculeMembre } from "./SettingsForms";
import { fcfa } from "@/lib/utils";

const onglets = ["Pharmacie", "Utilisateurs & rôles", "Paiements", "Sécurité", "Abonnement"] as const;

type Props = {
  pharmacy: { name: string; city: string; district: string; country: string; licenseNo: string; phone: string; currency: string; openingHours: Record<string, string> };
  members: { id: string; nom: string; email: string; role: string; statut: string }[];
  audit: { date: string; qui: string; action: string; entite: string }[];
  subscription: { plan: string; status: string; amount: number; trialEndsAt: string | null } | null;
};

export default function SettingsView({ pharmacy, members, audit, subscription }: Props) {
  const [t, setT] = useState<(typeof onglets)[number]>("Pharmacie");
  const r = useRouter();
  const logout = async () => { await fetch("/api/auth/logout", { method: "POST" }); r.push("/connexion"); };

  return (
    <>
      <div className="flex flex-wrap gap-2">
        {onglets.map(o => (
          <button key={o} onClick={() => setT(o)}
            className={"rounded-xl px-4 py-2 text-sm font-semibold " + (t === o ? "bg-brand-600 text-white" : "border border-slate-300 muted dark:border-white/15")}>{o}</button>
        ))}
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {t === "Pharmacie" && <>
          <Card title="Identité">
            <FormulairePharmacie pharmacy={pharmacy} />
          </Card>
          <Card title="Horaires d'ouverture">
            <ul className="space-y-2 text-sm muted">
              {Object.entries(pharmacy.openingHours).map(([k, v]) => (
                <li key={k} className="flex justify-between border-b border-slate-100 pb-2 dark:border-white/5">
                  <span>{k.replace("_", " – ")}</span><span className="font-medium">{v}</span>
                </li>
              ))}
              {!Object.keys(pharmacy.openingHours).length && <li>Horaires non renseignés.</li>}
            </ul>
            <FormulaireHoraires horaires={pharmacy.openingHours} />
          </Card>
        </>}

        {t === "Utilisateurs & rôles" && <>
          <Card title={`Utilisateurs (${members.length})`} action={<InviterMembre />}>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="text-xs uppercase muted"><tr><th className="py-2">Nom</th><th>Rôle</th><th>Statut</th><th></th></tr></thead>
                <tbody>
                  {members.map(m => (
                    <tr key={m.email} className="border-t border-slate-100 dark:border-white/5">
                      <td className="py-2.5 font-medium">{m.nom}<span className="block text-xs muted">{m.email}</span></td>
                      <td className="muted">{m.role}</td>
                      <td><span className="badge">{m.statut}</span></td>
                      <td className="text-right">
                        <BasculeMembre id={m.id} actif={m.statut === "Actif"} nom={m.nom} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
          <Card title="Matrice de permissions">
            <ul className="space-y-2 text-sm muted">
              <li><strong>Titulaire</strong> — accès complet, gestion des utilisateurs et de l'abonnement.</li>
              <li><strong>Pharmacien</strong> — caisse, stock, ordonnances, patients, IA, WhatsApp.</li>
              <li><strong>Préparateur</strong> — vente, lecture stock, mouvements, lecture ordonnances.</li>
              <li><strong>Caissier</strong> — vente et clôture de caisse uniquement.</li>
              <li><strong>Comptable</strong> — comptabilité, rapports et fournisseurs en lecture.</li>
            </ul>
          </Card>
        </>}

        {t === "Paiements" && <>
          <Card title="Moyens acceptés en caisse">
            {["Espèces", "MTN MoMo", "Moov Money", "Celtiis Cash", "Orange Money", "Wave", "Carte bancaire"].map(p => (
              <label key={p} className="flex items-center gap-3 border-b border-slate-100 py-2.5 text-sm dark:border-white/5">
                <input type="checkbox" defaultChecked className="accent-brand-600" />{p}</label>
            ))}
          </Card>
          <Card title="Devise et facturation">
            <p className="text-sm">Devise principale : <strong>{pharmacy.currency}</strong></p>
            <p className="mt-4 text-sm muted">Les rapprochements Mobile Money sont importés chaque nuit via l'agrégateur configuré.</p>
          </Card>
        </>}

        {t === "Sécurité" && <>
          <Card title="Protection du compte">
            <ul className="space-y-3 text-sm">
              <li className="flex justify-between"><span>Hachage des mots de passe</span><span className="badge">scrypt</span></li>
              <li className="flex justify-between"><span>Expiration de session</span><span className="muted">8 heures</span></li>
              <li className="flex justify-between"><span>Cookie de session</span><span className="badge">httpOnly · signé</span></li>
              <li className="flex justify-between"><span>Journal d'audit</span><span className="badge">Actif</span></li>
              <li className="flex justify-between">
                <span>Authentification à deux facteurs</span>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600 dark:bg-white/10 dark:text-slate-400">
                  Non disponible
                </span>
              </li>
              <li className="flex justify-between">
                <span>Sauvegarde automatique</span>
                <span className="muted text-xs">Configurée par l'hébergeur</span>
              </li>
            </ul>
            <p className="mt-3 rounded-xl bg-slate-100 p-3 text-xs muted dark:bg-white/5">
              La double authentification et les sauvegardes planifiées relèvent de la
              configuration serveur. Demandez à votre prestataire de confirmer leur activation.
            </p>
            <div className="mt-4 flex gap-2">
              <a href="/api/stock/export" className="btn-ghost !py-2 !text-xs">Exporter le stock</a>
              <button onClick={logout} className="btn-ghost !py-2 !text-xs">Se déconnecter</button>
            </div>
          </Card>
          <Card title="Journal d'audit (10 dernières entrées)">
            <ul className="space-y-2 text-xs muted">
              {audit.map((a, i) => <li key={i}>{a.date} · {a.qui} · {a.action} {a.entite}</li>)}
              {!audit.length && <li>Aucune entrée.</li>}
            </ul>
          </Card>
        </>}

        {t === "Abonnement" && (
          subscription ? <>
            <Card title="Formule actuelle">
              <p className="text-2xl font-extrabold text-brand-600">{subscription.plan} — {fcfa(subscription.amount)} / mois</p>
              <p className="mt-2 text-sm muted">
                Statut : {subscription.status}
                {subscription.trialEndsAt && ` · essai jusqu'au ${subscription.trialEndsAt}`}
              </p>
              <p className="mt-4 rounded-xl bg-slate-100 p-3 text-xs muted dark:bg-white/5">
                Pour activer ou changer de formule, contactez-nous au +229 00 00 00 00.
                Le paiement en ligne sera disponible prochainement.
              </p>
              <a href="https://wa.me/22900000000" className="btn-primary mt-3 !py-2 !text-xs">Nous contacter</a>
            </Card>
            <Card title="Factures"><p className="text-sm muted">Aucune facture émise pendant la période d'essai.</p></Card>
          </> : <Card><p className="text-sm muted">Aucun abonnement associé.</p></Card>
        )}
      </div>
    </>
  );
}
