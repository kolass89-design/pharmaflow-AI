"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "@/components/site/Logo";
import SyncBadge from "./SyncBadge";
import RegisterSW from "./RegisterSW";

const nav = [
  { href: "/dashboard", label: "Accueil", icon: "🏠" },
  { href: "/dashboard/ventes", label: "Ventes / Caisse", icon: "🧾" },
  { href: "/dashboard/stock", label: "Stock", icon: "📦" },
  { href: "/dashboard/ordonnances", label: "Ordonnances", icon: "📄" },
  { href: "/dashboard/patients", label: "Patients", icon: "🧑‍⚕️" },
  { href: "/dashboard/fournisseurs", label: "Fournisseurs", icon: "🚚" },
  { href: "/dashboard/comptabilite", label: "Comptabilité", icon: "📊" },
  { href: "/dashboard/ia", label: "Intelligence AI", icon: "✨" },
  { href: "/dashboard/whatsapp", label: "WhatsApp", icon: "💬" },
  { href: "/dashboard/synchronisation", label: "Synchronisation", icon: "🔄" },
  { href: "/dashboard/parametres", label: "Paramètres", icon: "⚙️" },
];

export default function Shell({ title, subtitle, children }:
  { title: string; subtitle?: string; children: React.ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <div className="min-h-screen lg:flex">
      <RegisterSW />
      <aside className={"fixed inset-y-0 left-0 z-50 w-64 border-r border-slate-200 bg-white p-4 transition-transform lg:static lg:translate-x-0 dark:border-white/10 dark:bg-ink " + (open ? "translate-x-0" : "-translate-x-full")}>
        <Link href="/" className="block px-2 py-2"><Logo /></Link>
        <nav className="mt-6 space-y-1">
          {nav.map(n => {
            const active = path === n.href;
            return (
              <Link key={n.href} href={n.href} onClick={() => setOpen(false)}
                className={"flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition " +
                  (active ? "bg-brand-600 text-white" : "muted hover:bg-slate-100 dark:hover:bg-white/10")}>
                <span>{n.icon}</span>{n.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-6 rounded-xl bg-brand-50 p-3 text-xs dark:bg-brand-500/10">
          <p className="font-semibold text-brand-700 dark:text-brand-300">Essai Pro</p>
          <p className="mt-1 muted">11 jours restants</p>
          <Link href="/dashboard/parametres" className="mt-2 inline-block font-semibold text-brand-600">Activer l'abonnement →</Link>
        </div>
      </aside>

      <div className="flex-1">
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-slate-200 bg-white/90 px-4 backdrop-blur sm:px-6 dark:border-white/10 dark:bg-ink/90">
          <div className="flex items-center gap-3">
            <button onClick={() => setOpen(!open)} className="rounded-lg border border-slate-300 p-2 lg:hidden dark:border-white/15" aria-label="Menu">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
            <div>
              <h1 className="text-base font-bold sm:text-lg">{title}</h1>
              {subtitle && <p className="hidden text-xs muted sm:block">{subtitle}</p>}
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <span className="hidden sm:inline"><SyncBadge /></span>
            <button onClick={() => setDark(!dark)} className="rounded-lg border border-slate-300 p-2 text-sm dark:border-white/15" aria-label="Thème">
              {dark ? "☀️" : "🌙"}
            </button>
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 px-3 py-1.5 dark:border-white/10">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-600 text-xs font-bold text-white">LA</span>
              <span className="hidden text-xs sm:block"><strong>Dr. L. Ahouansou</strong><br /><span className="muted">Titulaire</span></span>
            </div>
          </div>
        </header>
        <main className="p-4 sm:p-6">{children}</main>
      </div>
      {open && <div onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-black/40 lg:hidden" />}
    </div>
  );
}

export function Card({ title, action, children, className = "" }:
  { title?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <section className={"rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5 " + className}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h2 className="font-semibold">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Kpi({ label, value, delta, tone = "brand" }:
  { label: string; value: string; delta?: string; tone?: "brand" | "rose" | "amber" | "trust" }) {
  const tones: Record<string, string> = {
    brand: "text-brand-600", rose: "text-rose-600", amber: "text-amber-600", trust: "text-trust-600",
  };
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
      <p className="text-xs muted">{label}</p>
      <p className={"mt-2 text-2xl font-extrabold " + tones[tone]}>{value}</p>
      {delta && <p className="mt-1 text-xs muted">{delta}</p>}
    </div>
  );
}
