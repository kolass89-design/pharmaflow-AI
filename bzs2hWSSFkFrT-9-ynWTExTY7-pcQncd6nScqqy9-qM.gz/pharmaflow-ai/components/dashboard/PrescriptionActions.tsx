"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

/** Changement de statut d'une ordonnance (servie, archivée). */
export default function PrescriptionActions({ id, statut }: { id: string; statut: string }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function changer(status: string) {
    setBusy(true);
    const res = await fetch(`/api/prescriptions/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }),
    });
    if (!res.ok) alert((await res.json()).error ?? "Action impossible.");
    setBusy(false);
    router.refresh();
  }

  if (statut === "ARCHIVED") return <span className="text-xs muted">Archivée</span>;

  return (
    <div className="flex gap-2">
      {statut !== "SERVED" && (
        <button onClick={() => changer("SERVED")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
          Marquer servie
        </button>
      )}
      {statut !== "PARTIAL" && statut !== "SERVED" && (
        <button onClick={() => changer("PARTIAL")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
          Partiellement servie
        </button>
      )}
      <button onClick={() => changer("ARCHIVED")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
        Archiver
      </button>
    </div>
  );
}
