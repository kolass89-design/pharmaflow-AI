"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "./Shell";
import { fcfa } from "@/lib/utils";
import { enqueue, cacheCatalog, readCatalog } from "@/lib/offline";
import { useOffline } from "./useOffline";

type P = { id: string; nom: string; dci: string; lot: string; expiration: string; stock: number; vente: number };
type Line = { p: P; qte: number };

const PAIEMENTS: [string, string][] = [
  ["CASH", "Espèces"], ["MTN_MOMO", "MTN MoMo"], ["MOOV_MONEY", "Moov Money"],
  ["CELTIIS_CASH", "Celtiis Cash"], ["ORANGE_MONEY", "Orange Money"], ["WAVE", "Wave"], ["CARD", "Carte"],
];

export default function Pos({ products }: { products: P[] }) {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [lines, setLines] = useState<Line[]>([]);
  const [remise, setRemise] = useState(0);
  const [method, setMethod] = useState("CASH");
  const [msg, setMsg] = useState<{ type: "ok" | "err" | "warn"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [catalogue, setCatalogue] = useState<P[]>(products);
  const { online, pending } = useOffline();

  // Le catalogue est répliqué localement : la caisse reste utilisable sans réseau.
  useEffect(() => {
    if (products.length) {
      setCatalogue(products);
      void cacheCatalog(products.map(p => ({
        id: p.id, nom: p.nom, dci: p.dci, lot: p.lot, expiration: p.expiration, stock: p.stock, vente: p.vente,
      })));
    } else {
      void readCatalog().then(c => { if (c.length) setCatalogue(c as P[]); });
    }
  }, [products]);

  const results = useMemo(
    () => catalogue.filter(p => (p.nom + p.dci).toLowerCase().includes(q.toLowerCase())).slice(0, 8),
    [q, catalogue]
  );
  const sousTotal = lines.reduce((s, l) => s + l.p.vente * l.qte, 0);
  const total = Math.max(0, sousTotal - Math.round((sousTotal * remise) / 100));

  const add = (p: P) => {
    setLines(ls => {
      const f = ls.find(l => l.p.id === p.id);
      if (f) return f.qte >= p.stock ? ls : ls.map(l => l.p.id === p.id ? { ...l, qte: l.qte + 1 } : l);
      return [...ls, { p, qte: 1 }];
    });
    setQ(""); setMsg(null);
  };
  const setQte = (id: string, n: number) =>
    setLines(ls => ls.flatMap(l => l.p.id === id ? (n <= 0 || n > l.p.stock ? (n <= 0 ? [] : [l]) : [{ ...l, qte: n }]) : [l]));

  async function encaisser() {
    if (!lines.length || busy) return;
    setBusy(true); setMsg(null);

    const payload = {
      items: lines.map(l => ({ productId: l.p.id, quantity: l.qte })),
      discountPercent: remise, method,
    };

    // Hors ligne : la vente part en file locale, le ticket est remis au patient.
    if (!navigator.onLine) {
      await enqueue("/api/sales", payload);
      setBusy(false);
      setMsg({ type: "warn", text: `Vente enregistrée hors ligne · ${fcfa(total)}. Elle sera synchronisée automatiquement au retour du réseau.` });
      setLines([]); setRemise(0);
      return;
    }

    try {
      const res = await fetch("/api/sales", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...payload, offlineUuid: crypto.randomUUID() }),
      });
      const data = await res.json();
      setBusy(false);
      if (!res.ok) { setMsg({ type: "err", text: data.error ?? "Erreur inconnue" }); return; }
      if (data.encaissementNonAutomatique) {
        setMsg({
          type: "warn",
          text: `Ticket ${data.sale.reference} · ${fcfa(data.sale.total)} enregistré. ${data.avertissement}`,
        });
      } else {
        setMsg({ type: "ok", text: `Vente enregistrée — ticket ${data.sale.reference} · ${fcfa(data.sale.total)}. Stock et comptabilité mis à jour.` });
      }
      setLines([]); setRemise(0);
      router.refresh();
    } catch {
      // Coupure pendant la requête : on bascule en file plutôt que de perdre la vente.
      await enqueue("/api/sales", payload);
      setBusy(false);
      setMsg({ type: "warn", text: `Réseau interrompu — vente mise en file locale · ${fcfa(total)}. Synchronisation automatique dès le retour.` });
      setLines([]); setRemise(0);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <Card title={online ? "Recherche produit" : "Recherche produit · mode hors ligne"} className="lg:col-span-3">
        {!online && (
          <p className="mb-3 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
            📴 Réseau indisponible. La caisse fonctionne normalement : les ventes sont conservées
            localement{pending > 0 && ` (${pending} en attente)`} et synchronisées au retour de la connexion.
          </p>
        )}
        <div className="flex gap-2">
          <input value={q} onChange={e => setQ(e.target.value)} autoFocus
            placeholder="Nom, DCI ou code-barres (douchette compatible)…"
            className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />

        </div>
        <ul className="mt-4 max-h-[420px] space-y-2 overflow-y-auto">
          {(q ? results : catalogue).map(p => (
            <li key={p.id}>
              <button onClick={() => add(p)}
                className="flex w-full items-center justify-between gap-3 rounded-xl border border-slate-200 px-4 py-3 text-left text-sm transition hover:border-brand-500 hover:bg-brand-50/50 dark:border-white/10 dark:hover:bg-white/10">
                <span>
                  <span className="font-medium">{p.nom}</span>
                  <span className="block text-xs muted">{p.dci} · lot {p.lot} · exp. {p.expiration} · stock {p.stock}</span>
                </span>
                <span className="shrink-0 font-semibold text-brand-600">{fcfa(p.vente)}</span>
              </button>
            </li>
          ))}
          {q && !results.length && <p className="py-4 text-center text-sm muted">Aucun produit trouvé.</p>}
        </ul>
      </Card>

      <Card title="Panier" className="lg:col-span-2">
        {!lines.length && <p className="text-sm muted">Panier vide. Cliquez sur un produit pour l'ajouter.</p>}
        <ul className="space-y-2">
          {lines.map(l => (
            <li key={l.p.id} className="rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
              <div className="flex justify-between gap-2">
                <span className="font-medium">{l.p.nom}</span>
                <span className="shrink-0">{fcfa(l.p.vente * l.qte)}</span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <button onClick={() => setQte(l.p.id, l.qte - 1)} className="h-7 w-7 rounded-lg border border-slate-300 dark:border-white/15">−</button>
                <span className="w-8 text-center">{l.qte}</span>
                <button onClick={() => setQte(l.p.id, l.qte + 1)} disabled={l.qte >= l.p.stock}
                  className="h-7 w-7 rounded-lg border border-slate-300 disabled:opacity-40 dark:border-white/15">+</button>
                <span className="text-xs muted">/ {l.p.stock}</span>
                <button onClick={() => setQte(l.p.id, 0)} className="ml-auto text-xs text-rose-600">Retirer</button>
              </div>
            </li>
          ))}
        </ul>

        <div className="mt-4 space-y-3 border-t border-slate-200 pt-4 text-sm dark:border-white/10">
          <label className="flex items-center justify-between gap-3">
            <span>Remise (%)</span>
            <input type="number" min={0} max={50} value={remise} onChange={e => setRemise(Number(e.target.value))}
              className="w-20 rounded-lg border border-slate-300 px-2 py-1 text-right dark:border-white/15 dark:bg-transparent" />
          </label>
          <label className="flex items-center justify-between gap-3">
            <span>Paiement</span>
            <select value={method} onChange={e => setMethod(e.target.value)}
              className="rounded-lg border border-slate-300 px-2 py-1 dark:border-white/15 dark:bg-transparent">
              {PAIEMENTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </label>
          <div className="flex justify-between muted"><span>Sous-total</span><span>{fcfa(sousTotal)}</span></div>
          <div className="flex justify-between text-lg font-bold"><span>Total</span><span className="text-brand-600">{fcfa(total)}</span></div>
          <button onClick={encaisser} disabled={!lines.length || busy} className="btn-primary w-full disabled:opacity-50">
            {busy ? "Enregistrement…" : "Encaisser"}
          </button>
          {msg && (
            <p className={"rounded-xl p-3 text-xs " + (
              msg.type === "ok" ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300"
              : msg.type === "warn" ? "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300"
              : "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300")}>
              {msg.type === "ok" ? "✅ " : msg.type === "warn" ? "📴 " : "⚠️ "}{msg.text}
            </p>
          )}
        </div>
      </Card>
    </div>
  );
}
