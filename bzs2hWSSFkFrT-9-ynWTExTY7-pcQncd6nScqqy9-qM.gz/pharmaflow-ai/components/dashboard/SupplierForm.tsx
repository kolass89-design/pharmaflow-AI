"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

export default function SupplierForm() {
  const [ouvert, setOuvert] = useState(false);
  const [erreur, setErreur] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function creer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErreur("");
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/suppliers", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErreur(d.error ?? "Erreur.");
    setOuvert(false); router.refresh();
  }

  return (
    <>
      <button onClick={() => setOuvert(true)} className="btn-primary !py-2 !text-xs">+ Fournisseur</button>
      <Modal open={ouvert} onClose={() => setOuvert(false)} title="Nouveau fournisseur">
        <form onSubmit={creer} className="space-y-4">
          {erreur && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{erreur}</p>}
          <Field label="Nom *"><input name="name" required minLength={2} placeholder="UBIPHARM" className={inputCls} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Pays">
              <select name="country" className={inputCls}>
                {[["BJ","Bénin"],["TG","Togo"],["CI","Côte d\'Ivoire"],["SN","Sénégal"],["NE","Niger"],["CM","Cameroun"],["OTHER","Autre"]]
                  .map(([v,l]) => <option key={v} value={v}>{l}</option>)}
              </select>
            </Field>
            <Field label="Délai de livraison (heures)">
              <input name="leadTimeHours" type="number" min="1" defaultValue={72} className={inputCls} />
            </Field>
            <Field label="Téléphone"><input name="phone" type="tel" placeholder="+229 …" className={inputCls} /></Field>
            <Field label="Email"><input name="email" type="email" placeholder="commandes@grossiste.bj" className={inputCls} /></Field>
          </div>
          <Field label="Contact"><input name="contact" placeholder="Nom du commercial" className={inputCls} /></Field>
          <button disabled={busy} className="btn-primary w-full disabled:opacity-50">
            {busy ? "Création…" : "Créer le fournisseur"}
          </button>
        </form>
      </Modal>
    </>
  );
}
