"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

/** Programmation d'un rappel de traitement pour un patient. */
export default function ReminderForm({ patientId, patientNom }: { patientId: string; patientNom: string }) {
  const [ouvert, setOuvert] = useState(false);
  const [erreur, setErreur] = useState("");
  const [avis, setAvis] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function creer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErreur(""); setAvis("");
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/reminders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...f, patientId }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErreur(d.error ?? "Erreur.");
    setAvis(d.avertissement ?? "");
    router.refresh();
    if (!d.avertissement) setOuvert(false);
  }

  return (
    <>
      <button onClick={() => setOuvert(true)} className="btn-ghost mt-3 !py-1.5 !text-xs">Ajouter un rappel</button>
      <Modal open={ouvert} onClose={() => { setOuvert(false); setAvis(""); }} title={`Rappel — ${patientNom}`}>
        <form onSubmit={creer} className="space-y-4">
          {erreur && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{erreur}</p>}
          {avis && (
            <div className="rounded-xl bg-amber-50 p-3 text-sm dark:bg-amber-500/10">
              <p className="text-amber-800 dark:text-amber-300">{avis}</p>
              <button type="button" onClick={() => { setOuvert(false); setAvis(""); }}
                className="btn-ghost mt-3 !py-1.5 !text-xs">Fermer</button>
            </div>
          )}
          <Field label="Libellé *" hint="Ce que le patient doit faire.">
            <input name="label" required minLength={3} placeholder="Amlodipine — 1 comprimé le matin" className={inputCls} />
          </Field>
          <Field label="Fréquence *">
            <select name="schedule" required className={inputCls}>
              <option value="Chaque jour 07:00">Chaque matin (7 h)</option>
              <option value="Chaque jour 20:00">Chaque soir (20 h)</option>
              <option value="Deux fois par jour">Matin et soir</option>
              <option value="Chaque semaine">Une fois par semaine</option>
              <option value="Renouvellement mensuel">Renouvellement mensuel</option>
            </select>
          </Field>
          <Field label="Canal">
            <select name="channel" className={inputCls}>
              <option value="WHATSAPP">WhatsApp</option>
              <option value="SMS">SMS</option>
            </select>
          </Field>
          <button disabled={busy} className="btn-primary w-full disabled:opacity-50">
            {busy ? "Enregistrement…" : "Programmer le rappel"}
          </button>
        </form>
      </Modal>
    </>
  );
}
