"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "./Shell";

type C = {
  id: string; phone: string; statut: string; heure: string; dernier: string;
  messages: { from: string; text: string }[];
};

const STATUTS: Record<string, string> = {
  BOT: "Bot", HUMAN_REQUIRED: "Humain requis", HUMAN: "Pharmacien", CLOSED: "Clôturée",
};

export default function ConversationsView({ convs }: { convs: C[] }) {
  const [sel, setSel] = useState<C | null>(convs[0] ?? null);
  const [message, setMessage] = useState("");
  const [avis, setAvis] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function repondre(e: React.FormEvent) {
    e.preventDefault();
    if (!sel || !message.trim() || busy) return;
    setBusy(true); setAvis("");
    const res = await fetch(`/api/conversations/${sel.id}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) { setAvis(d.error ?? "Erreur."); return; }
    setMessage("");
    setAvis(d.avertissement ?? "Message envoyé.");
    router.refresh();
  }

  async function changerStatut(status: string) {
    if (!sel) return;
    setBusy(true);
    await fetch(`/api/conversations/${sel.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }),
    });
    setBusy(false);
    router.refresh();
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Conversations">
        <ul className="space-y-2">
          {convs.map(c => (
            <li key={c.id}>
              <button onClick={() => setSel(c)}
                className={"w-full rounded-xl border p-3 text-left text-sm " + (sel?.id === c.id ? "border-brand-500 bg-brand-50/60 dark:bg-white/10" : "border-slate-200 dark:border-white/10")}>
                <div className="flex justify-between gap-2">
                  <span className="font-medium">{c.phone}</span>
                  <span className="shrink-0 text-xs muted">{c.heure}</span>
                </div>
                <p className="mt-1 truncate text-xs muted">{c.dernier}</p>
                <span className="badge mt-2">{STATUTS[c.statut] ?? c.statut}</span>
              </button>
            </li>
          ))}
          {!convs.length && <p className="text-sm muted">Aucune conversation.</p>}
        </ul>
      </Card>

      {sel ? (
        <Card title={`Conversation · ${sel.phone}`} className="lg:col-span-2">
          <div className="space-y-3">
            {sel.messages.map((m, i) => (
              <div key={i} className={"flex " + (m.from === "patient" ? "justify-start" : "justify-end")}>
                <p className={"max-w-[80%] rounded-2xl px-4 py-2 text-sm " + (m.from === "patient" ? "bg-slate-100 dark:bg-white/10" : "bg-brand-600 text-white")}>{m.text}</p>
              </div>
            ))}
          </div>
          <form onSubmit={repondre} className="mt-5 flex gap-2">
            <input value={message} onChange={e => setMessage(e.target.value)}
              placeholder="Répondre en tant que pharmacien…"
              className="flex-1 rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />
            <button disabled={busy || !message.trim()} className="btn-primary disabled:opacity-50">Envoyer</button>
          </form>
          {avis && <p className="mt-2 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">{avis}</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <button onClick={() => changerStatut("HUMAN")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
              Reprendre la main
            </button>
            <button onClick={() => changerStatut("BOT")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
              Rendre au bot
            </button>
            <button onClick={() => changerStatut("CLOSED")} disabled={busy} className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">
              Clôturer
            </button>
          </div>
        </Card>
      ) : <Card className="lg:col-span-2"><p className="text-sm muted">Sélectionnez une conversation.</p></Card>}
    </div>
  );
}
