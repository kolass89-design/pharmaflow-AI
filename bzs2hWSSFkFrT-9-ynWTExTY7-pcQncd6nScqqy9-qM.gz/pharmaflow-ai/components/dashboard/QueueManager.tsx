"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Kpi } from "./Shell";
import { useOffline } from "./useOffline";
import { listQueue, discard, retry, clearSent, exportQueue, isSupported, type QueuedOp } from "@/lib/offline";
import { fcfa } from "@/lib/utils";

const STATUTS: Record<QueuedOp["status"], { label: string; cls: string }> = {
  pending: { label: "En attente", cls: "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300" },
  sent: { label: "Synchronisée", cls: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300" },
  failed: { label: "Échec", cls: "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300" },
};

/** Résumé lisible d'une opération : le pharmacien doit reconnaître sa vente. */
function describe(op: QueuedOp): { titre: string; detail: string; montant: number | null } {
  const p = op.payload as any;
  if (op.endpoint === "/api/sales") {
    const items = Array.isArray(p?.items) ? p.items : [];
    const unites = items.reduce((t: number, i: any) => t + (i.quantity ?? 0), 0);
    return {
      titre: "Vente comptoir",
      detail: `${items.length} référence${items.length > 1 ? "s" : ""} · ${unites} unité${unites > 1 ? "s" : ""}` +
        (p?.method ? ` · ${p.method.replace(/_/g, " ").toLowerCase()}` : "") +
        (p?.discountPercent ? ` · remise ${p.discountPercent} %` : ""),
      montant: typeof p?.total === "number" ? p.total : null,
    };
  }
  return { titre: op.endpoint, detail: "Opération en file", montant: null };
}

const heure = (ts: number) =>
  new Intl.DateTimeFormat("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(ts);

export default function QueueManager() {
  const { online, syncing, sync } = useOffline();
  const [ops, setOps] = useState<QueuedOp[]>([]);
  const [pret, setPret] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const router = useRouter();

  const charger = useCallback(async () => {
    if (!isSupported()) { setPret(true); return; }
    setOps(await listQueue());
    setPret(true);
  }, []);

  useEffect(() => { void charger(); }, [charger]);
  useEffect(() => { if (!syncing) void charger(); }, [syncing, charger]);

  const enAttente = ops.filter(o => o.status === "pending");
  const echecs = ops.filter(o => o.status === "failed");
  const envoyees = ops.filter(o => o.status === "sent");

  async function lancerSync() {
    const r = await sync();
    await charger();
    if (r) {
      setMsg(`${r.envoyees} envoyée(s), ${r.doublons} déjà enregistrée(s), ${r.echecs} en échec.`);
      if (r.envoyees) router.refresh();
    }
  }

  async function relancer(uuid: string) { await retry(uuid); await charger(); void lancerSync(); }
  async function supprimer(uuid: string) { await discard(uuid); await charger(); }
  async function purger() { await clearSent(); await charger(); }

  async function telecharger() {
    const blob = new Blob([await exportQueue()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `file-pharmaflow-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (!pret) return <Card><p className="text-sm muted">Lecture de la file locale…</p></Card>;

  if (!isSupported()) {
    return (
      <Card title="Stockage local indisponible">
        <p className="text-sm muted">
          Ce navigateur ne prend pas en charge IndexedDB. Le mode hors ligne est désactivé :
          les ventes exigent une connexion. Utilisez Chrome, Firefox ou Safari à jour.
        </p>
      </Card>
    );
  }

  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="État du réseau" value={online ? "En ligne" : "Hors ligne"} tone={online ? "brand" : "amber"} />
        <Kpi label="En attente d'envoi" value={String(enAttente.length)} tone={enAttente.length ? "amber" : "brand"} />
        <Kpi label="En échec" value={String(echecs.length)} tone={echecs.length ? "rose" : "brand"} />
        <Kpi label="Synchronisées (24 h)" value={String(envoyees.length)} tone="trust" />
      </div>

      <Card className="mt-6" title="Synchronisation" action={
        <div className="flex flex-wrap gap-2">
          <button onClick={telecharger} className="btn-ghost !py-2 !text-xs">Exporter (JSON)</button>
          {envoyees.length > 0 && <button onClick={purger} className="btn-ghost !py-2 !text-xs">Purger l'historique</button>}
          <button onClick={lancerSync} disabled={!online || syncing || !enAttente.length}
            className="btn-primary !py-2 !text-xs disabled:opacity-50">
            {syncing ? "Synchronisation…" : "Synchroniser maintenant"}
          </button>
        </div>}>
        <p className="text-sm muted">
          {online
            ? "Les ventes réalisées hors connexion sont renvoyées automatiquement au retour du réseau, puis toutes les 30 secondes."
            : "Réseau indisponible. La caisse continue de fonctionner : les ventes sont conservées ici et partiront dès le rétablissement."}
        </p>
        {msg && <p className="mt-3 rounded-xl bg-brand-50 p-3 text-xs dark:bg-brand-500/10">{msg}</p>}
      </Card>

      {echecs.length > 0 && (
        <Card className="mt-6" title={`Opérations en échec (${echecs.length})`}>
          <p className="mb-4 rounded-xl bg-rose-50 p-3 text-xs text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
            Ces ventes ont été refusées par le serveur — le plus souvent parce que le stock avait déjà
            été écoulé entre-temps. Corrigez le stock puis relancez, ou supprimez après vérification.
            <strong> Aucune n'est comptabilisée tant qu'elle figure ici.</strong>
          </p>
          <ul className="space-y-3">
            {echecs.map(op => {
              const d = describe(op);
              return (
                <li key={op.uuid} className="rounded-xl border border-rose-200 p-4 text-sm dark:border-rose-500/30">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold">{d.titre}{d.montant !== null && ` · ${fcfa(d.montant)}`}</p>
                      <p className="mt-0.5 text-xs muted">{d.detail} · {heure(op.createdAt)}</p>
                    </div>
                    <span className={"rounded-full px-2.5 py-1 text-xs font-semibold " + STATUTS.failed.cls}>Échec</span>
                  </div>
                  {op.lastError && <p className="mt-2 rounded-lg bg-slate-100 p-2 text-xs muted dark:bg-white/5">{op.lastError}</p>}
                  <div className="mt-3 flex gap-2">
                    <button onClick={() => relancer(op.uuid)} className="btn-ghost !py-1.5 !text-xs">Réessayer</button>
                    <button onClick={() => supprimer(op.uuid)} className="btn-ghost !py-1.5 !text-xs !text-rose-600">Abandonner</button>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      )}

      <Card className="mt-6" title={`File locale (${ops.length})`}>
        {!ops.length ? (
          <p className="text-sm muted">Aucune opération en file. Toutes les ventes sont enregistrées sur le serveur.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-left text-sm">
              <thead className="text-xs uppercase muted">
                <tr><th className="py-2">Opération</th><th>Détail</th><th>Montant</th><th>Heure</th><th>État</th></tr>
              </thead>
              <tbody>
                {ops.map(op => {
                  const d = describe(op);
                  return (
                    <tr key={op.uuid} className="border-t border-slate-100 dark:border-white/5">
                      <td className="py-2.5 pr-3 font-medium">{d.titre}</td>
                      <td className="text-xs muted">{d.detail}</td>
                      <td>{d.montant !== null ? fcfa(d.montant) : "—"}</td>
                      <td className="text-xs muted">{heure(op.createdAt)}</td>
                      <td>
                        <span className={"rounded-full px-2.5 py-1 text-xs font-semibold " + STATUTS[op.status].cls}>
                          {STATUTS[op.status].label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <p className="mt-4 text-xs muted">
          🔒 Les opérations restent sur ce poste jusqu'à confirmation du serveur. Un identifiant unique
          par vente empêche tout doublon, même si la synchronisation est relancée plusieurs fois.
        </p>
      </Card>
    </>
  );
}
