"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card } from "./Shell";
import { fcfa } from "@/lib/utils";

type R = {
  id: string; reference: string; produit: string; quantite: number; total: number;
  client: string; source: string; statut: string; minutesRestantes: number;
};

const ETATS: Record<string, { texte: string; classe: string }> = {
  ACTIVE: { texte: "À préparer", classe: "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300" },
  COLLECTED: { texte: "Retirée", classe: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300" },
  EXPIRED: { texte: "Expirée", classe: "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-400" },
  CANCELLED: { texte: "Annulée", classe: "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300" },
};

export default function ReservationsPanel({ reservations }: { reservations: R[] }) {
  const [occupe, setOccupe] = useState<string | null>(null);
  const router = useRouter();
  const actives = reservations.filter(r => r.statut === "ACTIVE");

  async function traiter(id: string, status: "COLLECTED" | "CANCELLED") {
    setOccupe(id);
    await fetch(`/api/reservations/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }),
    });
    setOccupe(null);
    router.refresh();
  }

  return (
    <Card title={`Réservations patients${actives.length ? ` — ${actives.length} à préparer` : ""}`}>
      {!reservations.length ? (
        <p className="text-sm muted">
          Aucune réservation. Les demandes venant de l'espace patient et de WhatsApp apparaîtront ici.
        </p>
      ) : (
        <ul className="space-y-2">
          {reservations.map(r => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 p-3 text-sm dark:border-white/10">
              <div className="min-w-0">
                <p className="font-semibold tracking-wide">{r.reference}</p>
                <p className="text-xs muted">
                  {r.produit} × {r.quantite} · {fcfa(r.total)} · {r.client}
                  {r.source === "WEB" ? " · web" : " · WhatsApp"}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {r.statut === "ACTIVE" && (
                  <span className="text-xs muted">{r.minutesRestantes} min restantes</span>
                )}
                <span className={"rounded-full px-2.5 py-1 text-xs font-semibold " + (ETATS[r.statut]?.classe ?? "")}>
                  {ETATS[r.statut]?.texte ?? r.statut}
                </span>
                {r.statut === "ACTIVE" && (
                  <>
                    <button onClick={() => traiter(r.id, "COLLECTED")} disabled={occupe === r.id}
                      className="btn-primary !py-1.5 !text-xs disabled:opacity-50">Retirée</button>
                    <button onClick={() => traiter(r.id, "CANCELLED")} disabled={occupe === r.id}
                      className="btn-ghost !py-1.5 !text-xs disabled:opacity-50">Annuler</button>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
      <p className="mt-4 text-xs muted">
        Une réservation ne décrémente pas le stock : mettez le produit de côté, puis encaissez
        normalement en caisse lors du retrait.
      </p>
    </Card>
  );
}
