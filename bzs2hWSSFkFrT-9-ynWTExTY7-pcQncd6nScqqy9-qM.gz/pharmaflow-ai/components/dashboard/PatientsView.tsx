"use client";
import { useState } from "react";
import { Card } from "./Shell";
import PatientForm from "./PatientForm";
import ReminderForm from "./ReminderForm";
import { fcfa } from "@/lib/utils";

type P = {
  id: string; nom: string; ville: string; allergies: string; chroniques: string;
  dernier: string; ordonnances: number;
  achats: { date: string; total: number; libelle: string }[];
  rappels: { label: string; schedule: string; channel: string; actif: boolean }[];
};

export default function PatientsView({ patients }: { patients: P[] }) {
  const [q, setQ] = useState("");
  const [sel, setSel] = useState<P | null>(patients[0] ?? null);
  const list = patients.filter(p => p.nom.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Répertoire" action={<PatientForm />}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Rechercher un patient…"
          className="mb-3 w-full rounded-xl border border-slate-300 px-4 py-2.5 text-sm dark:border-white/15 dark:bg-transparent" />
        <ul className="space-y-2">
          {list.map(p => (
            <li key={p.id}>
              <button onClick={() => setSel(p)}
                className={"w-full rounded-xl border px-3 py-2.5 text-left text-sm " + (sel?.id === p.id ? "border-brand-500 bg-brand-50/60 dark:bg-white/10" : "border-slate-200 dark:border-white/10")}>
                <span className="font-medium">{p.nom}</span>
                <span className="block text-xs muted">{p.ville} · dernier passage {p.dernier}</span>
              </button>
            </li>
          ))}
          {!list.length && <p className="text-sm muted">Aucun patient trouvé.</p>}
        </ul>
      </Card>

      {sel ? (
        <Card title={`Fiche · ${sel.nom}`} className="lg:col-span-2">
          <dl className="grid gap-4 text-sm sm:grid-cols-2">
            <div><dt className="text-xs muted">Ville</dt><dd className="font-medium">{sel.ville}</dd></div>
            <div><dt className="text-xs muted">Ordonnances</dt><dd className="font-medium">{sel.ordonnances}</dd></div>
            <div><dt className="text-xs muted">Allergies connues</dt><dd className="font-medium text-rose-600">{sel.allergies}</dd></div>
            <div><dt className="text-xs muted">Pathologies chroniques</dt><dd className="font-medium">{sel.chroniques}</dd></div>
          </dl>
          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <div className="rounded-xl border border-slate-200 p-4 dark:border-white/10">
              <p className="text-sm font-semibold">Historique d'achats</p>
              <ul className="mt-2 space-y-1 text-xs muted">
                {sel.achats.map((a, i) => <li key={i}>{a.date} · {a.libelle} — {fcfa(a.total)}</li>)}
                {!sel.achats.length && <li>Aucun achat enregistré.</li>}
              </ul>
            </div>
            <div className="rounded-xl border border-slate-200 p-4 dark:border-white/10">
              <p className="text-sm font-semibold">Rappels de traitement</p>
              <ul className="mt-2 space-y-1 text-xs muted">
                {sel.rappels.map((r, i) => <li key={i}>{r.label} · {r.channel} · {r.actif ? "actif" : "inactif"}</li>)}
                {!sel.rappels.length && <li>Aucun rappel programmé.</li>}
              </ul>
              <ReminderForm patientId={sel.id} patientNom={sel.nom} />
            </div>
          </div>
          <p className="mt-4 rounded-xl bg-slate-100 p-3 text-xs muted dark:bg-white/5">
            🔒 Accès tracé : chaque consultation de dossier est horodatée dans le journal d'audit.
          </p>
        </Card>
      ) : <Card className="lg:col-span-2"><p className="text-sm muted">Aucun patient.</p></Card>}
    </div>
  );
}
