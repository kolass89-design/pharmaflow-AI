"use client";
import { useState } from "react";
import { Card } from "./Shell";
import { fcfa } from "@/lib/utils";

type Row = {
  id: string; nom: string; dci: string; lot: string; expiration: string;
  stock: number; seuil: number; achat: number; vente: number; marge: number;
  fournisseur: string; sousSeuil: boolean;
};

export default function StockTable({ rows, actions }: { rows: Row[]; actions?: React.ReactNode }) {
  const [q, setQ] = useState("");
  const [filtre, setFiltre] = useState<"tous" | "alerte" | "peremption">("tous");

  const limite = new Date(Date.now() + 90 * 864e5).toISOString().slice(0, 10);
  const list = rows.filter(r => {
    const okQ = (r.nom + r.dci + r.fournisseur).toLowerCase().includes(q.toLowerCase());
    const okF = filtre === "tous"
      || (filtre === "alerte" && r.sousSeuil)
      || (filtre === "peremption" && r.expiration !== "—" && r.expiration <= limite);
    return okQ && okF;
  });

  return (
    <Card title={`Inventaire (${list.length} références)`} action={actions}>
      <div className="flex flex-wrap gap-2">
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Rechercher un produit, une DCI, un fournisseur…"
          className="min-w-[200px] flex-1 rounded-xl border border-slate-300 px-4 py-2.5 text-sm dark:border-white/15 dark:bg-transparent" />
        {([["tous", "Tous"], ["alerte", "Sous seuil"], ["peremption", "Péremption < 90 j"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setFiltre(k)}
            className={"rounded-xl px-3 py-2 text-xs font-semibold " + (filtre === k ? "bg-brand-600 text-white" : "border border-slate-300 muted dark:border-white/15")}>
            {l}
          </button>
        ))}
      </div>
      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[860px] text-left text-sm">
          <thead className="text-xs uppercase muted">
            <tr><th className="py-2">Produit</th><th>Lot</th><th>Expiration</th><th>Stock</th><th>Seuil</th><th>PA</th><th>PV</th><th>Marge</th><th>Fournisseur</th></tr>
          </thead>
          <tbody>
            {list.map(r => (
              <tr key={r.id} className="border-t border-slate-100 dark:border-white/5">
                <td className="py-2.5 pr-3 font-medium">{r.nom}<span className="block text-xs muted">{r.dci}</span></td>
                <td className="muted">{r.lot}</td>
                <td className="muted">{r.expiration}</td>
                <td><span className={"rounded-full px-2 py-0.5 text-xs font-semibold " + (r.sousSeuil ? "bg-rose-50 text-rose-600" : "bg-emerald-50 text-emerald-700")}>{r.stock}</span></td>
                <td className="muted">{r.seuil}</td>
                <td className="muted">{fcfa(r.achat)}</td>
                <td>{fcfa(r.vente)}</td>
                <td className="font-semibold text-brand-600">{r.marge} %</td>
                <td className="muted">{r.fournisseur}</td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan={9} className="py-6 text-center muted">Aucun résultat.</td></tr>}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
