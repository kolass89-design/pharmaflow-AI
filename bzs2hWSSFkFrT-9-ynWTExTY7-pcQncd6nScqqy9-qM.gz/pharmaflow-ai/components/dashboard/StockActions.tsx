"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

type Supplier = { id: string; nom: string };
type Prod = { id: string; nom: string; stock: number };

export default function StockActions({ suppliers, products }: { suppliers: Supplier[]; products: Prod[] }) {
  const [open, setOpen] = useState<"produit" | "reception" | "ajustement" | null>(null);
  return (
    <>
      <div className="flex flex-wrap gap-2">
        <button onClick={() => setOpen("reception")} className="btn-ghost !py-2 !text-xs">📥 Réception</button>
        <button onClick={() => setOpen("ajustement")} className="btn-ghost !py-2 !text-xs">⚖️ Inventaire</button>
        <button onClick={() => setOpen("produit")} className="btn-primary !py-2 !text-xs">+ Produit</button>
      </div>
      <ProductForm open={open === "produit"} close={() => setOpen(null)} suppliers={suppliers} />
      <ReceiveForm open={open === "reception"} close={() => setOpen(null)} products={products} />
      <AdjustForm open={open === "ajustement"} close={() => setOpen(null)} products={products} />
    </>
  );
}

function useSubmit(url: string, close: () => void) {
  const router = useRouter();
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>, transform?: (d: any) => any) {
    e.preventDefault();
    setBusy(true); setErr("");
    const raw = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch(url, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(transform ? transform(raw) : raw),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error ?? "Erreur.");
    close(); router.refresh();
  }
  return { submit, err, busy, setErr };
}

function Err({ msg }: { msg: string }) {
  return msg ? <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{msg}</p> : null;
}

function ProductForm({ open, close, suppliers }: { open: boolean; close: () => void; suppliers: Supplier[] }) {
  const { submit, err, busy } = useSubmit("/api/products", close);
  return (
    <Modal open={open} onClose={close} title="Nouveau produit">
      <form onSubmit={submit} className="space-y-4">
        <Err msg={err} />
        <Field label="Nom commercial *"><input name="name" required placeholder="Ceftriaxone 1 g injectable" className={inputCls} /></Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="DCI"><input name="dci" placeholder="Ceftriaxone" className={inputCls} /></Field>
          <Field label="Code-barres"><input name="barcode" placeholder="600123…" className={inputCls} /></Field>
          <Field label="Prix d'achat (FCFA) *"><input name="purchasePrice" type="number" min="0" required className={inputCls} /></Field>
          <Field label="Prix de vente (FCFA) *"><input name="salePrice" type="number" min="0" required className={inputCls} /></Field>
          <Field label="Seuil d'alerte"><input name="alertThreshold" type="number" min="0" defaultValue={10} className={inputCls} /></Field>
          <Field label="Fournisseur">
            <select name="supplierId" className={inputCls}><option value="">—</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.nom}</option>)}</select>
          </Field>
        </div>
        <div className="rounded-xl bg-slate-50 p-4 dark:bg-white/5">
          <p className="mb-3 text-sm font-semibold">Lot initial (optionnel)</p>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Quantité"><input name="initialQuantity" type="number" min="0" defaultValue={0} className={inputCls} /></Field>
            <Field label="N° de lot"><input name="batchNo" placeholder="LOT-…" className={inputCls} /></Field>
            <Field label="Péremption"><input name="expiryDate" type="date" className={inputCls} /></Field>
          </div>
        </div>
        <button disabled={busy} className="btn-primary w-full disabled:opacity-50">{busy ? "Création…" : "Créer le produit"}</button>
      </form>
    </Modal>
  );
}

function ReceiveForm({ open, close, products }: { open: boolean; close: () => void; products: Prod[] }) {
  const { submit, err, busy } = useSubmit("/api/stock/receive", close);
  return (
    <Modal open={open} onClose={close} title="Réception de marchandise">
      <form onSubmit={submit} className="space-y-4">
        <Err msg={err} />
        <Field label="Produit *">
          <select name="productId" required className={inputCls}>
            <option value="">Sélectionner…</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.nom} (stock {p.stock})</option>)}
          </select>
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Quantité reçue *"><input name="quantity" type="number" min="1" required className={inputCls} /></Field>
          <Field label="N° de lot *"><input name="batchNo" required placeholder="LOT-…" className={inputCls} /></Field>
          <Field label="Date de péremption *"><input name="expiryDate" type="date" required className={inputCls} /></Field>
          <Field label="Coût unitaire (FCFA)"><input name="costPrice" type="number" min="0" className={inputCls} /></Field>
        </div>
        <Field label="Référence du bon" hint="Un lot déjà existant sera cumulé, pas dupliqué.">
          <input name="reference" placeholder="BC-1188" className={inputCls} />
        </Field>
        <button disabled={busy} className="btn-primary w-full disabled:opacity-50">{busy ? "Enregistrement…" : "Enregistrer la réception"}</button>
      </form>
    </Modal>
  );
}

function AdjustForm({ open, close, products }: { open: boolean; close: () => void; products: Prod[] }) {
  const { submit, err, busy } = useSubmit("/api/stock/adjust", close);
  return (
    <Modal open={open} onClose={close} title="Ajustement d'inventaire">
      <form onSubmit={submit} className="space-y-4">
        <Err msg={err} />
        <Field label="Produit *">
          <select name="productId" required className={inputCls}>
            <option value="">Sélectionner…</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.nom} (stock {p.stock})</option>)}
          </select>
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Écart *" hint="Négatif pour une sortie (ex. −3)">
            <input name="delta" type="number" required placeholder="-3" className={inputCls} />
          </Field>
          <Field label="Type">
            <select name="type" className={inputCls}>
              <option value="ADJUSTMENT">Correction de comptage</option>
              <option value="LOSS">Casse / perte</option>
              <option value="RETURN">Retour fournisseur</option>
            </select>
          </Field>
        </div>
        <Field label="Motif *" hint="Obligatoire : chaque écart doit être justifié et traçable.">
          <input name="reason" required minLength={3} placeholder="Casse au comptoir" className={inputCls} />
        </Field>
        <button disabled={busy} className="btn-primary w-full disabled:opacity-50">{busy ? "Enregistrement…" : "Valider l'ajustement"}</button>
      </form>
    </Modal>
  );
}
