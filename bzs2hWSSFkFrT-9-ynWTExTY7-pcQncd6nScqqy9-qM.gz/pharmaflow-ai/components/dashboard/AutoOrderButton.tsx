"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AutoOrderButton() {
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function run() {
    setBusy(true); setMsg(null);
    const res = await fetch("/api/purchase-orders", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ auto: true }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setMsg({ ok: false, text: d.error ?? "Erreur." });
    const n = d.commandes?.length ?? 0;
    setMsg({ ok: true, text: `${n} bon(s) de commande créé(s) : ${d.commandes.map((c: any) => c.reference).join(", ")}` });
    router.refresh();
  }

  return (
    <div className="flex flex-col items-end gap-2">
      <button onClick={run} disabled={busy} className="btn-ghost !py-2 !text-xs disabled:opacity-50">
        {busy ? "Génération…" : "Générer depuis l'IA"}
      </button>
      {msg && <p className={"max-w-xs text-right text-xs " + (msg.ok ? "text-brand-600" : "text-rose-600")}>{msg.text}</p>}
    </div>
  );
}
