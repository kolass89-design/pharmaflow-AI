"use client";
import { useState } from "react";
import { Card } from "./Shell";

export default function AiAssistant() {
  const [q, setQ] = useState("");
  const [rep, setRep] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function ask(e: React.FormEvent) {
    e.preventDefault();
    if (!q.trim() || busy) return;
    setBusy(true);
    const res = await fetch("/api/ai/ask", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question: q }),
    });
    const d = await res.json();
    setRep(d.answer ?? d.error ?? "Aucune réponse.");
    setBusy(false);
  }

  const exemples = [
    "Quels sont mes produits les plus rentables ?",
    "Que dois-je commander cette semaine ?",
    "Quel est mon chiffre d'affaires du mois ?",
  ];

  return (
    <Card title="Assistant — posez une question sur vos données">
      <form onSubmit={ask} className="flex flex-col gap-2 sm:flex-row">
        <input value={q} onChange={e => setQ(e.target.value)}
          placeholder="Ex. : quels sont mes produits les plus rentables ?"
          className="flex-1 rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />
        <button disabled={busy} className="btn-primary disabled:opacity-50">{busy ? "…" : "Demander"}</button>
      </form>
      <div className="mt-3 flex flex-wrap gap-2">
        {exemples.map(x => (
          <button key={x} onClick={() => setQ(x)} className="rounded-full border border-slate-300 px-3 py-1 text-xs muted dark:border-white/15">{x}</button>
        ))}
      </div>
      {rep && <p className="mt-4 whitespace-pre-line rounded-xl bg-brand-50 p-4 text-sm dark:bg-brand-500/10">{rep}</p>}
      <p className="mt-3 text-xs muted">
        L'assistant interroge uniquement les données agrégées de votre officine. Aucune identité patient n'est transmise.
      </p>
    </Card>
  );
}
