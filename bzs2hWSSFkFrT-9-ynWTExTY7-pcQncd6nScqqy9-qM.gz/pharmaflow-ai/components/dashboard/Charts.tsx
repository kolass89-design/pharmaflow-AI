"use client";
import { AreaChart, Area, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { fcfa } from "@/lib/utils";

export function SalesArea({ data }: { data: { jour: string; ventes: number }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs><linearGradient id="dg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#1ea36c" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#1ea36c" stopOpacity={0} /></linearGradient></defs>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} vertical={false} />
          <XAxis dataKey="jour" tickLine={false} axisLine={false} fontSize={12} />
          <YAxis tickFormatter={(v) => `${Math.round(v / 1000)}k`} tickLine={false} axisLine={false} fontSize={12} />
          <Tooltip formatter={(v: number) => fcfa(v)} />
          <Area type="monotone" dataKey="ventes" stroke="#128357" strokeWidth={2.5} fill="url(#dg)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function RevenueBars({ data }: { data: { m: string; recettes: number; depenses: number }[] }) {
  return (
    <div className="h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} vertical={false} />
          <XAxis dataKey="m" tickLine={false} axisLine={false} fontSize={12} />
          <YAxis tickFormatter={(v) => `${(v / 1_000_000).toFixed(1)}M`} tickLine={false} axisLine={false} fontSize={12} />
          <Tooltip formatter={(v: number) => fcfa(v)} /><Legend />
          <Bar dataKey="recettes" name="Recettes" fill="#128357" radius={[6, 6, 0, 0]} />
          <Bar dataKey="depenses" name="Dépenses estimées" fill="#2563eb" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function ForecastLines({ data }: { data: { j: string; reel?: number; prevu?: number }[] }) {
  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" opacity={0.2} vertical={false} />
          <XAxis dataKey="j" tickLine={false} axisLine={false} fontSize={12} />
          <YAxis tickFormatter={(v) => `${(v / 1_000_000).toFixed(1)}M`} tickLine={false} axisLine={false} fontSize={12} />
          <Tooltip formatter={(v: number) => fcfa(v)} /><Legend />
          <Line dataKey="reel" name="Réalisé" stroke="#128357" strokeWidth={2.5} connectNulls />
          <Line dataKey="prevu" name="Prévu" stroke="#2563eb" strokeWidth={2.5} strokeDasharray="6 4" connectNulls />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
