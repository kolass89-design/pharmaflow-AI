"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

type Opt = { id: string; nom: string };
type Ligne = { label: string; productId: string; dosage: string; quantity: number };

export default function PrescriptionForm({ patients, products }: { patients: Opt[]; products: Opt[] }) {
  const [open, setOpen] = useState(false);
  const [patientId, setPatientId] = useState("");
  const [prescriber, setPrescriber] = useState("");
  const [lignes, setLignes] = useState<Ligne[]>([{ label: "", productId: "", dosage: "", quantity: 1 }]);
  const [alertes, setAlertes] = useState<string[]>([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  const set = (i: number, k: keyof Ligne, v: string | number) =>
    setLignes(ls => ls.map((l, j) => j === i ? { ...l, [k]: v } : l));

  // Sélectionner un produit du catalogue pré-remplit le libellé.
  const pickProduct = (i: number, id: string) => {
    const p = products.find(x => x.id === id);
    setLignes(ls => ls.map((l, j) => j === i ? { ...l, productId: id, label: p?.nom ?? l.label } : l));
  };

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(""); setAlertes([]);
    const res = await fetch("/api/prescriptions", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId, prescriber,
        items: lignes.filter(l => l.label.trim()).map(l => ({ ...l, productId: l.productId || undefined })),
      }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error ?? "Erreur.");
    if (d.alertes?.length) { setAlertes(d.alertes); router.refresh(); return; }  // on montre l'alerte avant de fermer
    setOpen(false); setLignes([{ label: "", productId: "", dosage: "", quantity: 1 }]); router.refresh();
  }

  return (
    <>
      <button onClick={() => setOpen(true)} className="btn-primary !py-2 !text-xs">+ Nouvelle</button>
      <Modal open={open} onClose={() => setOpen(false)} title="Nouvelle ordonnance">
        <form onSubmit={submit} className="space-y-4">
          {err && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{err}</p>}
          {alertes.length > 0 && (
            <div className="rounded-xl bg-amber-50 p-3 text-sm dark:bg-amber-500/10">
              <p className="font-semibold text-amber-800 dark:text-amber-300">Ordonnance enregistrée avec alertes</p>
              <ul className="mt-2 space-y-1 text-xs text-amber-800 dark:text-amber-300">
                {alertes.map((a, i) => <li key={i}>{a}</li>)}
              </ul>
              <button type="button" onClick={() => { setOpen(false); setAlertes([]); }} className="btn-ghost mt-3 !py-1.5 !text-xs">J'ai pris connaissance</button>
            </div>
          )}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Patient *">
              <select value={patientId} onChange={e => setPatientId(e.target.value)} required className={inputCls}>
                <option value="">Sélectionner…</option>
                {patients.map(p => <option key={p.id} value={p.id}>{p.nom}</option>)}
              </select>
            </Field>
            <Field label="Prescripteur"><input value={prescriber} onChange={e => setPrescriber(e.target.value)} placeholder="Dr. …" className={inputCls} /></Field>
          </div>

          <div>
            <p className="mb-2 text-sm font-medium">Lignes prescrites</p>
            <div className="space-y-3">
              {lignes.map((l, i) => (
                <div key={i} className="rounded-xl border border-slate-200 p-3 dark:border-white/10">
                  <select value={l.productId} onChange={e => pickProduct(i, e.target.value)} className={inputCls + " !mt-0"}>
                    <option value="">Produit hors catalogue…</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.nom}</option>)}
                  </select>
                  <input value={l.label} onChange={e => set(i, "label", e.target.value)} placeholder="Libellé prescrit *" className={inputCls} />
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    <input value={l.dosage} onChange={e => set(i, "dosage", e.target.value)} placeholder="1 cp x3/j" className={inputCls + " !mt-0 col-span-2"} />
                    <input type="number" min={1} value={l.quantity} onChange={e => set(i, "quantity", Number(e.target.value))} className={inputCls + " !mt-0"} />
                  </div>
                  {lignes.length > 1 && (
                    <button type="button" onClick={() => setLignes(ls => ls.filter((_, j) => j !== i))} className="mt-2 text-xs text-rose-600">Retirer</button>
                  )}
                </div>
              ))}
            </div>
            <button type="button" onClick={() => setLignes(ls => [...ls, { label: "", productId: "", dosage: "", quantity: 1 }])}
              className="btn-ghost mt-3 !py-1.5 !text-xs">+ Ajouter une ligne</button>
          </div>

          <button disabled={busy} className="btn-primary w-full disabled:opacity-50">{busy ? "Enregistrement…" : "Enregistrer l'ordonnance"}</button>
        </form>
      </Modal>
    </>
  );
}
