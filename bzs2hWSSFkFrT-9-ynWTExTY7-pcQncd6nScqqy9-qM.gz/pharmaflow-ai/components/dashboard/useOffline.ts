"use client";
import { useCallback, useEffect, useState } from "react";
import { flushQueue, pendingCount, listQueue, isSupported, type SyncResult } from "@/lib/offline";

/**
 * État réseau + file locale.
 * La synchronisation se déclenche au retour de connexion, puis toutes les 30 s
 * tant qu'il reste des opérations en attente.
 */
export function useOffline() {
  const [online, setOnline] = useState(true);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);
  const [last, setLast] = useState<SyncResult | null>(null);

  const refresh = useCallback(async () => {
    if (isSupported()) setPending(await pendingCount());
  }, []);

  const sync = useCallback(async () => {
    if (!isSupported() || syncing || !navigator.onLine) return null;
    setSyncing(true);
    const r = await flushQueue();
    setSyncing(false);
    setPending(r.restantes);
    if (r.envoyees || r.doublons || r.echecs) setLast(r);
    return r;
  }, [syncing]);

  // Signale au serveur si la file dérive : le back-end ne peut pas le deviner seul.
  const signaler = useCallback(async () => {
    if (!isSupported() || !navigator.onLine) return;
    const ops = await listQueue();
    const enAttente = ops.filter(o => o.status === "pending").length;
    const echecs = ops.filter(o => o.status === "failed").length;
    if (!enAttente && !echecs) return;
    const plusAncienne = ops.filter(o => o.status !== "sent").map(o => o.createdAt).sort()[0];
    try {
      await fetch("/api/monitoring/queue", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enAttente, echecs,
          plusAncienneMs: plusAncienne ? Date.now() - plusAncienne : null,
        }),
      });
    } catch { /* la supervision ne doit jamais gêner la caisse */ }
  }, []);

  useEffect(() => {
    const up = () => {
      setOnline(navigator.onLine);
      if (navigator.onLine) void sync();
    };
    up();
    void refresh();
    window.addEventListener("online", up);
    window.addEventListener("offline", up);
    const timer = setInterval(() => { if (navigator.onLine) void sync(); }, 30_000);
    // Remontée d'état toutes les 5 minutes, et une fois au montage.
    void signaler();
    const heartbeat = setInterval(() => void signaler(), 300_000);
    return () => {
      window.removeEventListener("online", up);
      window.removeEventListener("offline", up);
      clearInterval(timer);
      clearInterval(heartbeat);
    };
  }, [sync, refresh, signaler]);

  return { online, pending, syncing, last, sync, refresh };
}
