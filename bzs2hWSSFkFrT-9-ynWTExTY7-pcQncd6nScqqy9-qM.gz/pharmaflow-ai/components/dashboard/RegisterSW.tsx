"use client";
import { useEffect } from "react";
import { flushQueue } from "@/lib/offline";

/** Enregistre le service worker : cache applicatif + disponibilité hors ligne. */
export default function RegisterSW() {
  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;
    const onLoad = () => navigator.serviceWorker.register("/sw.js").catch(() => {});
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad);

    // Le service worker peut réclamer un rejeu de la file (Background Sync).
    const onMessage = (e: MessageEvent) => {
      if (e.data?.type === "FLUSH_QUEUE") void flushQueue();
    };
    navigator.serviceWorker.addEventListener("message", onMessage);

    return () => {
      window.removeEventListener("load", onLoad);
      navigator.serviceWorker.removeEventListener("message", onMessage);
    };
  }, []);
  return null;
}
