"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useOffline } from "./useOffline";

/** Indicateur réseau + file d'attente, visible en permanence dans la barre du dashboard. */
export default function SyncBadge() {
  const { online, pending, syncing, sync } = useOffline();
  const router = useRouter();

  const run = async () => {
    const r = await sync();
    if (r && (r.envoyees || r.doublons)) router.refresh();
  };

  if (!online) {
    return (
      <Link href="/dashboard/synchronisation"
        className="flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
        <span className="h-2 w-2 rounded-full bg-amber-500" />
        Hors ligne{pending > 0 && ` · ${pending} en attente`}
      </Link>
    );
  }

  if (pending > 0) {
    return (
      <button onClick={run} disabled={syncing}
        className="flex items-center gap-2 rounded-full bg-trust-50 px-3 py-1 text-xs font-semibold text-trust-700 disabled:opacity-60 dark:bg-trust-500/10 dark:text-trust-300">
        <span className={"h-2 w-2 rounded-full bg-trust-500 " + (syncing ? "animate-pulse" : "")} />
        {syncing ? "Synchronisation…" : `${pending} à synchroniser`}
      </button>
    );
  }

  return (
    <span className="flex items-center gap-2 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
      <span className="h-2 w-2 rounded-full bg-emerald-500" />
      En ligne · synchronisé
    </span>
  );
}
