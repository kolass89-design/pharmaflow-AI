"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

/** Formulaire d'identité de l'officine — enregistrement réel. */
type Pharmacie = {
  name: string; city: string; district: string; country: string;
  licenseNo: string; phone: string; currency: string; openingHours: Record<string, string>;
};

export function FormulairePharmacie({ pharmacy }: { pharmacy: Pharmacie }) {
  const [etat, setEtat] = useState<{ type: "ok" | "err"; texte: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function enregistrer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setEtat(null);
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/pharmacy", {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
    });
    const d = await res.json();
    setBusy(false);
    setEtat(res.ok ? { type: "ok", texte: "Modifications enregistrées." } : { type: "err", texte: d.error ?? "Erreur." });
    if (res.ok) router.refresh();
  }

  const champs: [string, string, string][] = [
    ["name", "Nom", pharmacy.name], ["city", "Ville", pharmacy.city],
    ["district", "Quartier", pharmacy.district], ["licenseNo", "Numéro d'ordre", pharmacy.licenseNo],
    ["phone", "Téléphone", pharmacy.phone],
  ];

  return (
    <form onSubmit={enregistrer}>
      {champs.map(([nom, libelle, valeur]) => (
        <Field key={nom} label={libelle}>
          <input name={nom} defaultValue={valeur} className={inputCls} />
        </Field>
      ))}
      {etat && (
        <p className={"mt-3 rounded-xl p-3 text-sm " + (etat.type === "ok"
          ? "bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300"
          : "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300")}>{etat.texte}</p>
      )}
      <button disabled={busy} className="btn-primary mt-4 disabled:opacity-50">
        {busy ? "Enregistrement…" : "Enregistrer"}
      </button>
    </form>
  );
}

/** Modification des horaires d'ouverture. */
export function FormulaireHoraires({ horaires }: { horaires: Record<string, string> }) {
  const [ouvert, setOuvert] = useState(false);
  const [erreur, setErreur] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function enregistrer(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErreur("");
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/pharmacy", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ openingHours: f }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErreur(d.error ?? "Erreur.");
    setOuvert(false); router.refresh();
  }

  return (
    <>
      <button onClick={() => setOuvert(true)} className="btn-ghost mt-4 !py-2 !text-xs">Modifier les horaires</button>
      <Modal open={ouvert} onClose={() => setOuvert(false)} title="Horaires d'ouverture">
        <form onSubmit={enregistrer} className="space-y-4">
          {erreur && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{erreur}</p>}
          {([["lun_ven", "Lundi – vendredi"], ["sam", "Samedi"], ["dim", "Dimanche"]] as const).map(([k, l]) => (
            <Field key={k} label={l} hint="Format « 08:00-20:00 », ou « fermé ».">
              <input name={k} defaultValue={horaires[k] ?? ""} placeholder="08:00-20:00" className={inputCls} />
            </Field>
          ))}
          <p className="text-xs muted">
            Ces horaires alimentent l'espace patient : ils déterminent l'affichage « ouverte » ou « fermée ».
          </p>
          <button disabled={busy} className="btn-primary w-full disabled:opacity-50">
            {busy ? "Enregistrement…" : "Enregistrer"}
          </button>
        </form>
      </Modal>
    </>
  );
}

/** Invitation d'un membre de l'équipe. */
export function InviterMembre() {
  const [ouvert, setOuvert] = useState(false);
  const [erreur, setErreur] = useState("");
  const [busy, setBusy] = useState(false);
  const [cree, setCree] = useState<{ nom: string; email: string; motDePasse: string } | null>(null);
  const router = useRouter();

  async function inviter(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErreur("");
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/members", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErreur(d.error ?? "Erreur.");
    setCree({ nom: d.membre.nom, email: d.membre.email, motDePasse: d.motDePasseProvisoire });
    router.refresh();
  }

  function fermer() { setOuvert(false); setCree(null); setErreur(""); }

  return (
    <>
      <button onClick={() => setOuvert(true)} className="btn-primary !py-2 !text-xs">+ Inviter</button>
      <Modal open={ouvert} onClose={fermer} title={cree ? "Compte créé" : "Inviter un membre"}>
        {cree ? (
          <div className="space-y-4">
            <p className="text-sm">Compte créé pour <strong>{cree.nom}</strong> ({cree.email}).</p>
            <div className="rounded-xl bg-amber-50 p-4 dark:bg-amber-500/10">
              <p className="text-xs font-semibold text-amber-900 dark:text-amber-300">Mot de passe provisoire</p>
              <p className="mt-2 select-all font-mono text-lg font-bold tracking-wider">{cree.motDePasse}</p>
              <p className="mt-2 text-xs text-amber-800 dark:text-amber-300/90">
                Communiquez-le de vive voix : il ne sera plus jamais affiché.
                L'envoi automatique par email sera disponible une fois le service de messagerie configuré.
              </p>
            </div>
            <button onClick={fermer} className="btn-primary w-full">J'ai noté</button>
          </div>
        ) : (
          <form onSubmit={inviter} className="space-y-4">
            {erreur && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{erreur}</p>}
            <Field label="Nom complet *"><input name="fullName" required minLength={3} placeholder="Prénom Nom" className={inputCls} /></Field>
            <Field label="Email *"><input name="email" type="email" required placeholder="employe@officine.bj" className={inputCls} /></Field>
            <Field label="Rôle *">
              <select name="role" required className={inputCls}>
                <option value="PHARMACIST">Pharmacien — caisse, stock, ordonnances, patients</option>
                <option value="TECHNICIAN">Préparateur — vente et lecture du stock</option>
                <option value="CASHIER">Caissier — caisse uniquement</option>
                <option value="ACCOUNTANT">Comptable — comptabilité et rapports</option>
              </select>
            </Field>
            <button disabled={busy} className="btn-primary w-full disabled:opacity-50">
              {busy ? "Création…" : "Créer le compte"}
            </button>
          </form>
        )}
      </Modal>
    </>
  );
}

/** Suspension / réactivation d'un membre. */
export function BasculeMembre({ id, actif, nom }: { id: string; actif: boolean; nom: string }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function basculer() {
    if (actif && !confirm(`Suspendre l'accès de ${nom} ?`)) return;
    setBusy(true);
    const res = await fetch(`/api/members/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !actif }),
    });
    if (!res.ok) alert((await res.json()).error ?? "Action impossible.");
    setBusy(false);
    router.refresh();
  }

  return (
    <button onClick={basculer} disabled={busy}
      className={"text-xs font-semibold disabled:opacity-50 " + (actif ? "text-rose-600" : "text-brand-600")}>
      {actif ? "Suspendre" : "Réactiver"}
    </button>
  );
}
