"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Modal, { Field, inputCls } from "@/components/ui/Modal";

export default function PatientForm() {
  const [open, setOpen] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setErr("");
    const f = Object.fromEntries(new FormData(e.currentTarget).entries());
    const res = await fetch("/api/patients", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...f, consent: f.consent === "on" }),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error ?? "Erreur.");
    setOpen(false); router.refresh();
  }

  return (
    <>
      <button onClick={() => setOpen(true)} className="btn-primary !py-2 !text-xs">+ Patient</button>
      <Modal open={open} onClose={() => setOpen(false)} title="Nouveau dossier patient">
        <form onSubmit={submit} className="space-y-4">
          {err && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{err}</p>}
          <Field label="Nom complet *"><input name="fullName" required placeholder="Prénom Nom" className={inputCls} /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Téléphone / WhatsApp" hint="Chiffré en base (AES-256).">
              <input name="phone" type="tel" placeholder="+229 …" className={inputCls} />
            </Field>
            <Field label="Ville"><input name="city" placeholder="Cotonou" className={inputCls} /></Field>
          </div>
          <Field label="Allergies connues" hint="Séparez par des virgules. Utilisé pour alerter à la prescription.">
            <input name="allergies" placeholder="Pénicilline, Sulfamides" className={inputCls} />
          </Field>
          <Field label="Pathologies chroniques"><input name="chronicConditions" placeholder="Hypertension, Diabète type 2" className={inputCls} /></Field>
          <label className="flex gap-3 text-xs muted">
            <input type="checkbox" name="consent" defaultChecked className="mt-0.5 accent-brand-600" />
            Le patient consent à l'enregistrement de ses données de santé et aux rappels de traitement.
          </label>
          <button disabled={busy} className="btn-primary w-full disabled:opacity-50">{busy ? "Création…" : "Créer le dossier"}</button>
        </form>
      </Modal>
    </>
  );
}
