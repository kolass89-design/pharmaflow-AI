"use client";
import { useEffect, useRef, useState } from "react";
import { fcfa } from "@/lib/utils";

type Pharmacie = {
  id: string; nom: string; ville: string; quartier: string | null;
  telephone: string | null; whatsapp: string | null;
  latitude: number | null; longitude: number | null;
  ouverteMaintenant: boolean | null; deGarde: boolean;
};
type Resultat = {
  produitId: string; nom: string; dci: string | null; prix: number;
  surOrdonnance: boolean; disponibilite: "disponible" | "limite" | "indisponible";
  pharmacie: Pharmacie; distanceKm?: number;
};

const BADGES = {
  disponible: { texte: "En stock", classe: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300" },
  limite: { texte: "Stock limité", classe: "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300" },
  indisponible: { texte: "Épuisé", classe: "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-400" },
} as const;

export default function RechercheMedicament({ villes }: { villes: string[] }) {
  const [q, setQ] = useState("");
  const [ville, setVille] = useState("");
  const [position, setPosition] = useState<{ lat: number; lon: number } | null>(null);
  const [resultats, setResultats] = useState<Resultat[] | null>(null);
  const [chargement, setChargement] = useState(false);
  const [aReserver, setAReserver] = useState<Resultat | null>(null);
  const minuteur = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Recherche différée : sur un réseau mobile lent, une requête par frappe
  // saturerait la connexion et l'API.
  useEffect(() => {
    if (minuteur.current) clearTimeout(minuteur.current);
    if (q.trim().length < 2) { setResultats(null); return; }
    minuteur.current = setTimeout(async () => {
      setChargement(true);
      const p = new URLSearchParams({ q: q.trim() });
      if (ville) p.set("ville", ville);
      if (position) { p.set("lat", String(position.lat)); p.set("lon", String(position.lon)); }
      try {
        const r = await fetch(`/api/public/recherche?${p}`);
        const d = await r.json();
        setResultats(d.resultats ?? []);
      } catch {
        setResultats([]);
      }
      setChargement(false);
    }, 350);
    return () => { if (minuteur.current) clearTimeout(minuteur.current); };
  }, [q, ville, position]);

  function localiser() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (p) => setPosition({ lat: p.coords.latitude, lon: p.coords.longitude }),
      () => {},
      { timeout: 8000 },
    );
  }

  return (
    <>
      <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm sm:p-6 dark:border-white/10 dark:bg-white/5">
        <label className="block">
          <span className="text-sm font-medium">Quel médicament cherchez-vous ?</span>
          <input
            value={q} onChange={(e) => setQ(e.target.value)} autoFocus
            placeholder="Paracétamol, Coartem, sirop pour la toux…"
            className="mt-2 w-full rounded-xl border border-slate-300 px-4 py-3.5 text-base outline-none focus:border-brand-500 dark:border-white/15 dark:bg-transparent"
          />
        </label>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <select value={ville} onChange={(e) => setVille(e.target.value)}
            className="rounded-xl border border-slate-300 px-3 py-2 text-sm dark:border-white/15 dark:bg-transparent">
            <option value="">Toutes les villes</option>
            {villes.map((v) => <option key={v} value={v}>{v}</option>)}
          </select>
          <button onClick={localiser}
            className={"rounded-xl border px-3 py-2 text-sm font-medium transition " +
              (position ? "border-brand-500 bg-brand-50 text-brand-700 dark:bg-brand-500/10" : "border-slate-300 muted dark:border-white/15")}>
            {position ? "📍 Autour de moi" : "📍 Me localiser"}
          </button>
          <span className="text-xs muted">Sans accent, ça marche aussi.</span>
        </div>
      </div>

      {chargement && <p className="mt-6 text-center text-sm muted">Recherche en cours…</p>}

      {resultats && !chargement && (
        <div className="mt-6">
          {resultats.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-300 p-8 text-center dark:border-white/15">
              <p className="text-4xl">🔍</p>
              <p className="mt-3 font-semibold">Aucune officine partenaire n'a ce produit</p>
              <p className="mt-2 text-sm muted">
                Vérifiez l'orthographe, essayez la molécule (par exemple « paracétamol » plutôt
                qu'un nom de marque), ou appelez directement une pharmacie de garde.
              </p>
            </div>
          ) : (
            <>
              <p className="mb-3 text-sm muted">
                {resultats.length} résultat{resultats.length > 1 ? "s" : ""}
                {position && " — les plus proches d'abord"}
              </p>
              <ul className="space-y-3">
                {resultats.map((r) => (
                  <li key={`${r.produitId}`} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-white/10 dark:bg-white/5">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold">{r.nom}</p>
                        {r.dci && <p className="text-xs muted">{r.dci}</p>}
                        <p className="mt-2 text-sm">
                          <span className="font-medium">{r.pharmacie.nom}</span>
                          <span className="muted"> — {r.pharmacie.quartier ? `${r.pharmacie.quartier}, ` : ""}{r.pharmacie.ville}</span>
                          {r.distanceKm != null && <span className="muted"> · {r.distanceKm} km</span>}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          <span className={"rounded-full px-2.5 py-0.5 text-xs font-semibold " + BADGES[r.disponibilite].classe}>
                            {BADGES[r.disponibilite].texte}
                          </span>
                          {r.pharmacie.deGarde && (
                            <span className="rounded-full bg-trust-50 px-2.5 py-0.5 text-xs font-semibold text-trust-700 dark:bg-trust-500/10 dark:text-trust-300">
                              De garde
                            </span>
                          )}
                          {r.pharmacie.ouverteMaintenant === true && (
                            <span className="rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                              Ouverte
                            </span>
                          )}
                          {r.pharmacie.ouverteMaintenant === false && !r.pharmacie.deGarde && (
                            <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-semibold text-slate-600 dark:bg-white/10 dark:text-slate-400">
                              Fermée
                            </span>
                          )}
                          {r.surOrdonnance && (
                            <span className="rounded-full bg-rose-50 px-2.5 py-0.5 text-xs font-semibold text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
                              Sur ordonnance
                            </span>
                          )}
                        </div>
                      </div>
                      <p className="shrink-0 text-lg font-bold text-brand-600">{fcfa(r.prix)}</p>
                    </div>

                    <div className="mt-4 flex flex-wrap gap-2">
                      {r.surOrdonnance ? (
                        <p className="w-full rounded-xl bg-rose-50/70 p-3 text-xs text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
                          Ce médicament nécessite une ordonnance : présentez-vous au comptoir avec
                          votre prescription. Le pharmacien vérifiera la posologie avec vous.
                        </p>
                      ) : r.disponibilite !== "indisponible" ? (
                        <button onClick={() => setAReserver(r)} className="btn-primary !py-2 !text-sm">Réserver 2 h</button>
                      ) : null}
                      {r.pharmacie.telephone && (
                        <a href={`tel:${r.pharmacie.telephone.replace(/\s/g, "")}`} className="btn-ghost !py-2 !text-sm">Appeler</a>
                      )}
                      <a
                        href={r.pharmacie.latitude && r.pharmacie.longitude
                          ? `https://www.google.com/maps/dir/?api=1&destination=${r.pharmacie.latitude},${r.pharmacie.longitude}`
                          : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${r.pharmacie.nom} ${r.pharmacie.ville}`)}`}
                        target="_blank" rel="noopener" className="btn-ghost !py-2 !text-sm">
                        Itinéraire
                      </a>
                    </div>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}

      {aReserver && <FormulaireReservation resultat={aReserver} fermer={() => setAReserver(null)} />}
    </>
  );
}

function FormulaireReservation({ resultat, fermer }: { resultat: Resultat; fermer: () => void }) {
  const [nom, setNom] = useState("");
  const [telephone, setTelephone] = useState("");
  const [quantite, setQuantite] = useState(1);
  const [erreur, setErreur] = useState("");
  const [envoi, setEnvoi] = useState(false);
  const [confirmee, setConfirmee] = useState<any>(null);

  async function envoyer(e: React.FormEvent) {
    e.preventDefault();
    setEnvoi(true); setErreur("");
    const r = await fetch("/api/public/reservations", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: resultat.produitId, nom, telephone, quantite }),
    });
    const d = await r.json();
    setEnvoi(false);
    if (!r.ok) { setErreur(d.error ?? "La réservation n'a pas pu être enregistrée."); return; }
    setConfirmee(d.reservation);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4" onClick={fermer}>
      <div onClick={(e) => e.stopPropagation()} role="dialog" aria-modal="true"
        className="max-h-[92vh] w-full max-w-md overflow-y-auto rounded-t-2xl bg-white p-6 sm:rounded-2xl dark:bg-ink">
        {confirmee ? (
          <div className="text-center">
            <p className="text-5xl">✅</p>
            <h2 className="mt-4 text-xl font-bold">Réservation confirmée</h2>
            <p className="mt-4 rounded-xl bg-brand-50 px-4 py-3 text-2xl font-extrabold tracking-wider text-brand-700 dark:bg-brand-500/10 dark:text-brand-300">
              {confirmee.reference}
            </p>
            <p className="mt-4 text-sm muted">
              Présentez cette référence à la <strong>{confirmee.pharmacie.nom}</strong>
              {confirmee.pharmacie.quartier ? `, ${confirmee.pharmacie.quartier}` : ""}, {confirmee.pharmacie.ville}.
            </p>
            <p className="mt-2 text-sm">
              {confirmee.produit} × {confirmee.quantite} — <strong>{fcfa(confirmee.total)}</strong>
            </p>
            <p className="mt-3 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
              ⏰ Valable 2 heures, jusqu'à {new Date(confirmee.expireLe).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}.
              Le paiement se fait au comptoir.
            </p>
            <div className="mt-6 flex flex-col gap-2">
              {confirmee.pharmacie.telephone && (
                <a href={`tel:${confirmee.pharmacie.telephone.replace(/\s/g, "")}`} className="btn-ghost">Appeler la pharmacie</a>
              )}
              <button onClick={fermer} className="btn-primary">Terminer</button>
            </div>
          </div>
        ) : (
          <form onSubmit={envoyer} className="space-y-4">
            <div className="flex items-start justify-between gap-4">
              <h2 className="text-lg font-bold">Réserver ce médicament</h2>
              <button type="button" onClick={fermer} aria-label="Fermer" className="text-xl leading-none muted">×</button>
            </div>

            <div className="rounded-xl bg-slate-50 p-3 text-sm dark:bg-white/5">
              <p className="font-medium">{resultat.nom}</p>
              <p className="mt-0.5 text-xs muted">{resultat.pharmacie.nom} — {resultat.pharmacie.ville}</p>
              <p className="mt-1 font-semibold text-brand-600">{fcfa(resultat.prix)} l'unité</p>
            </div>

            {erreur && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{erreur}</p>}

            <label className="block">
              <span className="text-sm font-medium">Votre nom complet</span>
              <input value={nom} onChange={(e) => setNom(e.target.value)} required minLength={3}
                placeholder="Prénom Nom"
                className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-base dark:border-white/15 dark:bg-transparent" />
            </label>

            <label className="block">
              <span className="text-sm font-medium">Téléphone</span>
              <input value={telephone} onChange={(e) => setTelephone(e.target.value)} required type="tel"
                placeholder="+229 97 00 00 00"
                className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-base dark:border-white/15 dark:bg-transparent" />
              <span className="mt-1 block text-xs muted">
                Utilisé uniquement par la pharmacie pour vous joindre. Chiffré et supprimé après retrait.
              </span>
            </label>

            <label className="block">
              <span className="text-sm font-medium">Quantité</span>
              <select value={quantite} onChange={(e) => setQuantite(Number(e.target.value))}
                className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-base dark:border-white/15 dark:bg-transparent">
                {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>

            <p className="rounded-xl bg-slate-50 p-3 text-xs muted dark:bg-white/5">
              Aucun paiement en ligne : vous réglez au comptoir. La réservation tient 2 heures.
            </p>

            <button disabled={envoi} className="btn-primary w-full disabled:opacity-50">
              {envoi ? "Réservation…" : `Réserver — ${fcfa(resultat.prix * quantite)}`}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
