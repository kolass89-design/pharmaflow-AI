"use client";
import { useState } from "react";
import { fcfa } from "@/lib/utils";

const ETATS: Record<string, { texte: string; classe: string; aide: string }> = {
  ACTIVE: {
    texte: "Réservation active", classe: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300",
    aide: "Votre produit est mis de côté. Présentez votre référence au comptoir.",
  },
  COLLECTED: {
    texte: "Retirée", classe: "bg-slate-100 text-slate-600 dark:bg-white/10 dark:text-slate-400",
    aide: "Ce produit a déjà été récupéré.",
  },
  EXPIRED: {
    texte: "Expirée", classe: "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300",
    aide: "Le délai de 2 heures est dépassé, le produit est remis en vente. Vous pouvez réserver à nouveau.",
  },
  CANCELLED: {
    texte: "Annulée", classe: "bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300",
    aide: "Cette réservation a été annulée par l'officine.",
  },
};

export default function SuiviReservation() {
  const [reference, setReference] = useState("");
  const [resultat, setResultat] = useState<any>(null);
  const [erreur, setErreur] = useState("");
  const [chargement, setChargement] = useState(false);

  async function chercher(e: React.FormEvent) {
    e.preventDefault();
    setChargement(true); setErreur(""); setResultat(null);
    const r = await fetch(`/api/public/reservations/${encodeURIComponent(reference.trim())}`);
    const d = await r.json();
    setChargement(false);
    if (!r.ok) { setErreur(d.error ?? "Référence introuvable."); return; }
    setResultat(d);
  }

  const etat = resultat ? (ETATS[resultat.statut] ?? ETATS.ACTIVE) : null;

  return (
    <>
      <form onSubmit={chercher} className="flex flex-col gap-3 sm:flex-row">
        <input
          value={reference} onChange={(e) => setReference(e.target.value.toUpperCase())}
          placeholder="R-ABCD1234" required
          className="flex-1 rounded-xl border border-slate-300 px-4 py-3 text-base uppercase tracking-wider dark:border-white/15 dark:bg-transparent"
        />
        <button disabled={chargement} className="btn-primary disabled:opacity-50">
          {chargement ? "Recherche…" : "Vérifier"}
        </button>
      </form>

      {erreur && (
        <p className="mt-4 rounded-xl bg-rose-50 p-4 text-sm text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">
          {erreur} Vérifiez la référence : elle ne contient ni la lettre I ni la lettre O.
        </p>
      )}

      {resultat && etat && (
        <div className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 dark:border-white/10 dark:bg-white/5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-lg font-bold tracking-wider">{resultat.reference}</p>
            <span className={"rounded-full px-3 py-1 text-xs font-semibold " + etat.classe}>{etat.texte}</span>
          </div>
          <p className="mt-3 text-sm">
            {resultat.produit} × {resultat.quantite} — <strong>{fcfa(resultat.total)}</strong>
          </p>
          <p className="mt-1 text-sm muted">
            À retirer à la <strong>{resultat.pharmacie.nom}</strong>
            {resultat.pharmacie.quartier ? `, ${resultat.pharmacie.quartier}` : ""}, {resultat.pharmacie.ville}
          </p>
          <p className="mt-3 rounded-xl bg-slate-50 p-3 text-xs muted dark:bg-white/5">{etat.aide}</p>
          {resultat.pharmacie.telephone && (
            <a href={`tel:${resultat.pharmacie.telephone.replace(/\s/g, "")}`} className="btn-ghost mt-4 !py-2 !text-sm">
              Appeler la pharmacie
            </a>
          )}
        </div>
      )}
    </>
  );
}
