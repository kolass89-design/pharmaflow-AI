# Démarrage rapide

Vous venez de décompresser `pharmaflow-ai.tar.gz`. Voici comment lancer le projet.

## Prérequis
- **Node.js 20+** — https://nodejs.org
- **PostgreSQL 15+** — local, ou une base gratuite chez Neon / Supabase / Railway

## Installation (5 minutes)

```bash
cd pharmaflow-ai

# 1. Dépendances (le dossier node_modules n'est pas dans l'archive)
npm install

# 2. Configuration
cp .env.example .env
```

Ouvrez `.env` et renseignez au minimum trois valeurs :

```bash
DATABASE_URL="postgresql://user:motdepasse@localhost:5432/pharmaflow"
SESSION_SECRET="..."     # node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"
ENCRYPTION_KEY="..."     # node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

> ⚠️ `ENCRYPTION_KEY` chiffre les téléphones des patients. **Sauvegardez-la** :
> perdue, les données chiffrées deviennent illisibles définitivement.

```bash
# 3. Base de données
npm run db:deploy    # crée les 29 tables
npm run db:seed      # officine de démonstration + 640 ventes sur 60 jours

# 4. Lancement
npm run dev
```

Ouvrez **http://localhost:3000**
Connexion : `demo@pharmaflow.ai` / `demo1234`

## Vérifier que tout fonctionne

```bash
npm test          # 141 tests unitaires + 144 d'intégration + scénario hors ligne
npm run preflight # contrôle avant mise en production
```

## Ce qui n'est pas dans l'archive

| Absent | Pourquoi | Comment le récupérer |
|---|---|---|
| `node_modules/` | 661 Mo, regénérable | `npm install` |
| `.next/` | Build, regénérable | `npm run build` |
| `.env` | **Contient des secrets** | Copier `.env.example` |
| `backups/` | Données locales | Générées par `npm run backup` |

## Où aller ensuite

| Document | Contenu |
|---|---|
| **`docs/ETAT-DE-LIVRAISON.md`** | **À lire en premier** : ce qui marche, ce qui manque |
| `docs/INSTALLATION.md` | Déploiement Vercel, variables, checklist |
| `docs/ARCHITECTURE.md` | Architecture produit et technique |
| `docs/EXPLOITATION.md` | Sauvegardes, supervision, test terrain |
| `docs/TESTS.md` | Stratégie de tests |
| `docs/AGENT-WHATSAPP.md` | Moteur conversationnel, configuration Meta |
| `docs/ESPACE-PATIENT.md` | Interface patient, confidentialité |

## Mise sur Git

```bash
git init
git add .
git commit -m "PharmaFlow AI — version initiale"
git remote add origin https://github.com/VOTRE-COMPTE/pharmaflow-ai.git
git push -u origin main
```

Le `.gitignore` exclut déjà `node_modules`, `.next`, `.env` et `backups`.
**Ne versionnez jamais votre `.env`.**

## En cas de souci

| Problème | Solution |
|---|---|
| `Can't reach database server` | PostgreSQL n'est pas démarré, ou `DATABASE_URL` est incorrecte |
| `ENCRYPTION_KEY invalide` | 64 caractères hexadécimaux exactement |
| Build tué (`SIGKILL`) | Machine à faible mémoire — la limite est déjà fixée dans le script `build` |
| `unaccent does not exist` | La migration l'installe ; sinon `CREATE EXTENSION unaccent;` |
