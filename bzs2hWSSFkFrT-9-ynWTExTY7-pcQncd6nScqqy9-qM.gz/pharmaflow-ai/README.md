# PharmaFlow AI

**La pharmacie intelligente pour l'Afrique francophone.**
Plateforme SaaS de gestion d'officine : caisse POS hors ligne, stock et lots, ordonnances, patients, fournisseurs, comptabilité, IA prédictive et agent WhatsApp.

Marchés visés : Bénin · Togo · Côte d'Ivoire · Sénégal · Niger · Cameroun.

## Démarrage

```bash
npm install
cp .env.example .env          # renseignez DATABASE_URL
npm run db:push               # crée les 27 tables
npm run db:seed               # officine complète + 643 ventes sur 60 jours
npm run dev
```

Ouvrez http://localhost:3000 — connexion démo : `demo@pharmaflow.ai` / `demo1234`.

L'application fonctionne sur **PostgreSQL réel** : les ventes encaissées décrémentent
le stock (FEFO), créent des mouvements et alimentent la comptabilité et les prévisions IA.

## Ce qui est livré

**Site marketing** — accueil (hero, preuves, 10 fonctionnalités, démo interactive, IA, WhatsApp, espace patient, sécurité, calculateur de ROI, témoignages, ressources), fonctionnalités, démo, tarifs avec bascule mensuel/annuel et FAQ, pharmacies de garde filtrables, ressources, blog avec 4 articles rédigés, contact et mentions légales.

**Agent WhatsApp** — moteur conversationnel branché sur la base réelle : disponibilité, prix, horaires, itinéraire, réservation par « oui », suivi par référence. **Transfert humain systématique dès qu'une question devient thérapeutique** (posologie, grossesse, effets, interactions, symptômes). Idempotent face aux rejeux de Meta, signature HMAC obligatoire en production.

**Espace patient** — `/trouver-un-medicament` : recherche sans accent ou par DCI, comparaison des officines, disponibilité en trois paliers (jamais la quantité exacte), tri par distance, réservation 2 h sans compte, suivi par référence. Les médicaments sous ordonnance ne sont pas réservables en ligne.

**Application** — inscription en 3 étapes, connexion, dashboard complet à 10 modules : accueil, caisse POS interactive (panier, remise, 7 moyens de paiement, ticket), stock filtrable avec marges, ordonnances et OCR, patients, fournisseurs, comptabilité avec graphiques, IA avec assistant, WhatsApp, paramètres à 5 onglets.

**Écritures réelles** — création produit, réception fournisseur (cumul de lot, mise à jour du bon de commande), ajustement d'inventaire avec motif obligatoire, dossier patient avec téléphone chiffré AES-256, ordonnance avec contrôle automatique des allergies, bons de commande générés depuis les alertes de stock, dépenses. Chaque mutation est authentifiée, autorisée par rôle, validée et journalisée.

**Socle technique** — auth par session signée + RBAC 5 rôles, middleware de protection et d'en-têtes de sécurité, 9 routes API, schéma Prisma de 25 tables, manifeste PWA et service worker hors ligne, mode clair/sombre, responsive mobile/tablette/desktop.

## Tests

```bash
npm test            # 141 unitaires + 142 intégration + scénario terrain (~15 s)
npm run test:unit   # unitaires seuls (~2 s)
```

Base jetable créée et détruite automatiquement — la base de développement n'est
jamais touchée. Suite validée par injection de régressions volontaires
(voir `docs/TESTS.md`).

## Exploitation

```bash
npm run preflight        # contrôle avant production
npm run backup           # sauvegarde chiffrée AES-256
npm run backup:verify    # test de restauration complet
npm run test:terrain     # 30 encaissements réseau coupé
```

Sauvegardes chiffrées avec vérification de restauration, supervision avec masquage
des données de santé, sonde `/api/health`, alertes sur dérive de la file hors ligne.

## État de livraison

Le produit est **utilisable en pilote accompagné**, pas en déploiement commercial
autonome. Quatre fonctions attendent une intégration externe (envoi WhatsApp,
Mobile Money, email, SMS) et trois ne sont pas implémentées (OCR, impression de
ticket, double authentification).

👉 Détail complet et honnête : `docs/ETAT-DE-LIVRAISON.md`

## Déployer gratuitement

👉 **`DEPLOIEMENT-GRATUIT.md`** — Vercel + Neon en 30 minutes, ou Docker sur votre serveur.
La base de démonstration (638 ventes) est fournie dans `deploiement/base-demonstration.sql`.

## Documentation
- `docs/ETAT-DE-LIVRAISON.md` — ce qui marche, ce qui manque, ce qui bloque
- `docs/AGENT-WHATSAPP.md` — moteur conversationnel, règle déontologique, configuration Meta
- `docs/ESPACE-PATIENT.md` — interface patient, décisions de confidentialité
- `docs/TESTS.md` — stratégie de tests, couverture, validation par injection
- `docs/EXPLOITATION.md` — sauvegardes, supervision, test terrain, preflight
- `docs/BRANCHER-POSTGRESQL.md` — migration mock → base réelle, patrons de code, pièges
- `docs/ARCHITECTURE.md` — architecture produit et technique, sécurité, feuille de route
- `docs/INSTALLATION.md` — installation, variables, déploiement
- `prisma/schema.prisma` — modèle de données commenté

## Production
- **0 vulnérabilité** npm · Next.js 15.5.22
- Import/export CSV du catalogue (parseur sans dépendance, prévisualisation avant application)
- Caisse utilisable **sans réseau** : file IndexedDB, rejeu idempotent automatique
- Rate limiting Upstash Redis avec repli mémoire
- Migrations Prisma versionnées, validées par reconstruction sur base vierge
- PWA installable (icônes, raccourcis Caisse/Stock/Sync, page hors-ligne dédiée)
- Écran `/dashboard/synchronisation` : file locale, relance ou abandon des ventes refusées, export JSON
- Rotation de `ENCRYPTION_KEY` sans coupure (`npm run key:rotate`)

```bash
npm run db:deploy    # applique les migrations (production)
npm run db:seed      # jeu de données de démonstration
```

## Stack
Next.js 15 · TypeScript · Tailwind CSS · Recharts · Prisma · PostgreSQL

## Note
Projet original. Aucun texte, visuel, logo ou contenu tiers n'a été repris.
