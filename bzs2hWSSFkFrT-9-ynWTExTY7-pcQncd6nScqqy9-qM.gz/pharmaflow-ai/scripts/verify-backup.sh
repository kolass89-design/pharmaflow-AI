#!/usr/bin/env bash
#
# Test de restauration trimestriel.
#
# Sauvegarde, restaure dans une base jetable, compare les volumétries,
# puis supprime la base de test. C'est le SEUL moyen de prouver qu'une
# sauvegarde est exploitable.
#
# Usage : ./scripts/verify-backup.sh

set -euo pipefail

rouge() { printf '\033[31m%s\033[0m\n' "$*"; }
vert()  { printf '\033[32m%s\033[0m\n' "$*"; }
info()  { printf '  %-28s %s\n' "$1" "$2"; }

[[ -n "${DATABASE_URL:-}" ]] || { rouge "❌ DATABASE_URL absente."; exit 1; }

BASE_TEST="pharmaflow_verif_$(date +%s)"
ADMIN_URL="${DATABASE_URL%/*}/postgres"
CIBLE_URL="${DATABASE_URL%/*}/$BASE_TEST"

echo "→ Vérification de restauration — $(date '+%d/%m/%Y %H:%M')"
echo ""

echo "1. Sauvegarde"
SORTIE=$(BACKUP_DIR="${BACKUP_DIR:-./backups}" ./scripts/backup.sh 2>&1)
ARCHIVE=$(echo "$SORTIE" | grep '^ARCHIVE=' | cut -d= -f2-)
[[ -f "$ARCHIVE" ]] || { rouge "❌ Archive introuvable."; exit 1; }
info "archive" "$(basename "$ARCHIVE")"

echo ""
echo "2. Volumétrie de référence"
declare -A AVANT
for t in Sale SaleItem Product Patient StockMovement AuditLog; do
  AVANT[$t]=$(psql "$DATABASE_URL" -tAc "select count(*) from \"$t\"")
  info "$t" "${AVANT[$t]}"
done

echo ""
echo "3. Restauration dans une base jetable"
psql "$ADMIN_URL" -q -c "DROP DATABASE IF EXISTS $BASE_TEST;" -c "CREATE DATABASE $BASE_TEST;"
./scripts/restore.sh "$ARCHIVE" "$CIBLE_URL" > /dev/null 2>&1

echo ""
echo "4. Comparaison"
ECARTS=0
for t in "${!AVANT[@]}"; do
  APRES=$(psql "$CIBLE_URL" -tAc "select count(*) from \"$t\"" 2>/dev/null || echo "ERREUR")
  if [[ "$APRES" == "${AVANT[$t]}" ]]; then
    info "$t" "${AVANT[$t]} = $APRES  ✓"
  else
    rouge "  $t : ${AVANT[$t]} ≠ $APRES  ✗"
    ECARTS=$((ECARTS + 1))
  fi
done

echo ""
echo "5. Contrôle d'intégrité fonctionnelle"
ORPHELINS=$(psql "$CIBLE_URL" -tAc 'select count(*) from "SaleItem" si left join "Sale" s on s.id = si."saleId" where s.id is null')
info "lignes de vente orphelines" "$ORPHELINS"
[[ "$ORPHELINS" != "0" ]] && ECARTS=$((ECARTS + 1))

CA_SRC=$(psql "$DATABASE_URL" -tAc 'select coalesce(sum(total),0) from "Sale"')
CA_DST=$(psql "$CIBLE_URL" -tAc 'select coalesce(sum(total),0) from "Sale"')
if [[ "$CA_SRC" == "$CA_DST" ]]; then
  info "chiffre d'affaires total" "$CA_SRC FCFA  ✓"
else
  rouge "  chiffre d'affaires : $CA_SRC ≠ $CA_DST  ✗"; ECARTS=$((ECARTS + 1))
fi

psql "$ADMIN_URL" -q -c "DROP DATABASE $BASE_TEST;"
echo ""
if [[ "$ECARTS" -eq 0 ]]; then
  vert "✅ Restauration vérifiée — sauvegarde exploitable."
  echo "   Consignez cette date dans le registre : $(date '+%d/%m/%Y')"
else
  rouge "❌ $ECARTS écart(s) détecté(s) — la sauvegarde n'est PAS fiable."
  exit 1
fi
