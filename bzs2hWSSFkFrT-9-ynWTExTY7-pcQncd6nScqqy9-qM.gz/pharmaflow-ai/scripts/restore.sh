#!/usr/bin/env bash
#
# Restauration d'une sauvegarde PharmaFlow AI.
#
# Usage :
#   ./scripts/restore.sh <fichier.dump[.enc]> <DATABASE_URL_cible>
#
# La cible est TOUJOURS écrasée : ne jamais pointer sur la production
# sans avoir vérifié deux fois l'URL.

set -euo pipefail

FICHIER="${1:-}"
CIBLE="${2:-}"

rouge() { printf '\033[31m%s\033[0m\n' "$*"; }
vert()  { printf '\033[32m%s\033[0m\n' "$*"; }
info()  { printf '  %s\n' "$*"; }

if [[ -z "$FICHIER" || -z "$CIBLE" ]]; then
  echo "Usage : $0 <fichier.dump[.enc]> <DATABASE_URL_cible>"; exit 1
fi
[[ -f "$FICHIER" ]] || { rouge "❌ Fichier introuvable : $FICHIER"; exit 1; }

echo "→ Restauration depuis $(basename "$FICHIER")"

# Contrôle de l'empreinte si elle accompagne l'archive.
if [[ -f "$FICHIER.sha256" ]]; then
  ATTENDU=$(cat "$FICHIER.sha256")
  OBTENU=$(sha256sum "$FICHIER" | awk '{print $1}')
  if [[ "$ATTENDU" != "$OBTENU" ]]; then
    rouge "❌ Empreinte invalide — l'archive a été altérée. Restauration refusée."
    exit 1
  fi
  info "empreinte conforme"
fi

TRAVAIL="$FICHIER"
TEMPORAIRE=""
if [[ "$FICHIER" == *.enc ]]; then
  [[ -n "${BACKUP_PASSPHRASE:-}" ]] || { rouge "❌ BACKUP_PASSPHRASE requise pour une archive chiffrée."; exit 1; }
  TEMPORAIRE="$(mktemp)"
  if ! openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
        -in "$FICHIER" -out "$TEMPORAIRE" -pass env:BACKUP_PASSPHRASE 2>/dev/null; then
    rouge "❌ Déchiffrement impossible : phrase secrète incorrecte."
    rm -f "$TEMPORAIRE"; exit 1
  fi
  TRAVAIL="$TEMPORAIRE"
  info "archive déchiffrée"
fi

pg_restore --list "$TRAVAIL" > /dev/null 2>&1 || { rouge "❌ Dump illisible."; [[ -n "$TEMPORAIRE" ]] && rm -f "$TEMPORAIRE"; exit 1; }

# --clean --if-exists : la cible est remise à plat avant réinjection.
pg_restore --clean --if-exists --no-owner --no-acl --dbname="$CIBLE" "$TRAVAIL" 2>&1 \
  | grep -v "^pg_restore: warning" || true

[[ -n "$TEMPORAIRE" ]] && rm -f "$TEMPORAIRE"

TABLES=$(psql "$CIBLE" -tAc "select count(*) from information_schema.tables where table_schema='public'")
VENTES=$(psql "$CIBLE" -tAc "select count(*) from \"Sale\"" 2>/dev/null || echo "?")
info "tables restaurées : $TABLES"
info "ventes : $VENTES"

vert "✅ Restauration terminée."
