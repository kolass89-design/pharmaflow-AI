#!/usr/bin/env bash
#
# Suite de tests complète.
#
#   ./scripts/test.sh          tout (unitaires + intégration + terrain)
#   ./scripts/test.sh unit     unitaires seuls (rapides, sans base ni serveur)
#   ./scripts/test.sh api      intégration seule
#   ./scripts/test.sh terrain  scénario hors ligne seul
#
# La base de test et le serveur sont créés puis détruits automatiquement :
# la base de développement n'est jamais touchée.

set -uo pipefail
CIBLE="${1:-all}"
PORT="${TEST_PORT:-4199}"
KO=0

titre() { printf '\n\033[1m── %s\033[0m\n' "$*"; }
vert()  { printf '\033[32m%s\033[0m\n' "$*"; }
rouge() { printf '\033[31m%s\033[0m\n' "$*"; }

racine="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$racine" || exit 1

BASE_PRINCIPALE="${DATABASE_URL:-postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow}"
SANS_PARAM="${BASE_PRINCIPALE%%\?*}"
ADMIN_URL="${SANS_PARAM%/*}/postgres"
BASE_TEST="pharmaflow_test_$$"
URL_TEST="${SANS_PARAM%/*}/$BASE_TEST"
SRV_PID=""
BASE_CREEE=0

nettoyer() {
  [ -n "$SRV_PID" ] && kill "$SRV_PID" 2>/dev/null
  if [ "$BASE_CREEE" = "1" ]; then
    psql "$ADMIN_URL" -q -c "DROP DATABASE IF EXISTS $BASE_TEST WITH (FORCE);" >/dev/null 2>&1
  fi
}
trap nettoyer EXIT

# ─── Tests unitaires : ni base ni serveur requis ───
if [ "$CIBLE" = "all" ] || [ "$CIBLE" = "unit" ]; then
  titre "Tests unitaires"
  node --test tests/unit/ > /tmp/pf-unit.log 2>&1
  grep -E "^# (tests|pass|fail)" /tmp/pf-unit.log
  if ! grep -q "^# fail 0" /tmp/pf-unit.log; then
    KO=$((KO + 1))
    grep "^not ok" /tmp/pf-unit.log | head -10
    rouge "échecs unitaires"
  fi

  titre "Non-fuite via la supervision"
  if node tests/scrub.test.mjs >/dev/null 2>&1; then
    vert "  ✓ aucune donnée de santé exposée"
  else
    KO=$((KO + 1)); rouge "  ✗ fuite détectée"
  fi
fi

# ─── Intégration et terrain : base jetable + serveur dédié ───
if [ "$CIBLE" = "all" ] || [ "$CIBLE" = "api" ] || [ "$CIBLE" = "terrain" ]; then
  titre "Préparation de l'environnement de test"
  if ! psql "$ADMIN_URL" -q -c "DROP DATABASE IF EXISTS $BASE_TEST;" -c "CREATE DATABASE $BASE_TEST;" >/dev/null 2>&1; then
    rouge "  ✗ création de la base impossible"; exit 1
  fi
  BASE_CREEE=1
  echo "  base jetable : $BASE_TEST"

  if ! DATABASE_URL="$URL_TEST" npx prisma migrate deploy >/dev/null 2>&1; then
    rouge "  ✗ migrations"; exit 1
  fi
  echo "  migrations appliquées"

  if ! DATABASE_URL="$URL_TEST" npx tsx prisma/seed.ts >/dev/null 2>&1; then
    rouge "  ✗ seed"; exit 1
  fi
  echo "  données de démonstration chargées"

  if [ ! -d .next ]; then
    echo "  build préalable…"
    npm run build >/dev/null 2>&1
  fi

  # Un serveur résiduel d'une exécution précédente occuperait le port et
  # répondrait avec une base déjà supprimée. `next start` se renomme en
  # « next-server » : c'est ce nom qu'il faut cibler.
  if command -v fuser >/dev/null 2>&1; then
    fuser -k "${PORT}/tcp" >/dev/null 2>&1
  fi
  pkill -f "next-server" >/dev/null 2>&1
  pkill -f "next start -p ${PORT}" >/dev/null 2>&1
  sleep 2

  export WHATSAPP_APP_SECRET="${WHATSAPP_APP_SECRET:-secret-webhook-de-test}"
  export WHATSAPP_VERIFY_TOKEN="${WHATSAPP_VERIFY_TOKEN:-pharmaflow-dev}"
  DATABASE_URL="$URL_TEST" npx next start -p "$PORT" > /tmp/pf-test-server.log 2>&1 &
  SRV_PID=$!
  PRET=0
  for _ in $(seq 1 40); do
    if curl -sf "http://localhost:$PORT/api/health" >/dev/null 2>&1; then PRET=1; break; fi
    sleep 1
  done
  if [ "$PRET" != "1" ]; then
    rouge "  ✗ serveur injoignable sur le port $PORT"
    echo "    (un autre processus occupe-t-il ce port ? TEST_PORT=xxxx pour en changer)"
    tail -5 /tmp/pf-test-server.log
    exit 1
  fi
  echo "  serveur prêt sur le port $PORT"

  if [ "$CIBLE" != "terrain" ]; then
    titre "Tests d'intégration (API + base)"
    BASE_URL="http://localhost:$PORT" DATABASE_URL="$URL_TEST" \
      node --test tests/integration/ > /tmp/pf-api.log 2>&1
    grep -E "^# (tests|pass|fail)" /tmp/pf-api.log
    if ! grep -q "^# fail 0" /tmp/pf-api.log; then
      KO=$((KO + 1))
      grep "^not ok" /tmp/pf-api.log | head -10
      rouge "échecs d'intégration"
    fi
  fi

  if [ "$CIBLE" = "all" ] || [ "$CIBLE" = "terrain" ]; then
    titre "Test terrain — 30 encaissements hors ligne"
    if BASE_URL="http://localhost:$PORT" DATABASE_URL="$URL_TEST" \
         node scripts/test-terrain.mjs > /tmp/pf-terrain.log 2>&1; then
      tail -2 /tmp/pf-terrain.log
    else
      KO=$((KO + 1))
      tail -12 /tmp/pf-terrain.log
      rouge "test terrain en échec"
    fi
  fi
fi

echo ""
echo "════════════════════════════════════════════════"
if [ "$KO" -eq 0 ]; then
  vert "✅ Suite de tests réussie."
else
  rouge "❌ $KO bloc(s) en échec."
  exit 1
fi
