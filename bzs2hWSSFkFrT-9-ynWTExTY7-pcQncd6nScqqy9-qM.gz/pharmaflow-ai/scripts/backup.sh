#!/usr/bin/env bash
#
# Sauvegarde chiffrée de la base PharmaFlow AI.
#
# Une sauvegarde non chiffrée d'une base de santé est une fuite de données en
# attente : le dump contient les dossiers patients en clair (hors téléphones,
# chiffrés applicativement). On chiffre donc l'archive elle-même.
#
# Usage :
#   ./scripts/backup.sh                 # sauvegarde + vérification
#   BACKUP_DIR=/mnt/nas ./scripts/backup.sh
#
# Variables :
#   DATABASE_URL      chaîne PostgreSQL (obligatoire)
#   BACKUP_PASSPHRASE phrase secrète de chiffrement (obligatoire en production)
#   BACKUP_DIR        répertoire de destination (défaut : ./backups)
#   RETENTION_DAYS    purge au-delà de N jours (défaut : 30)

set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
HORODATAGE="$(date +%Y%m%d-%H%M%S)"

rouge()  { printf '\033[31m%s\033[0m\n' "$*"; }
vert()   { printf '\033[32m%s\033[0m\n' "$*"; }
info()   { printf '  %s\n' "$*"; }

if [[ -z "${DATABASE_URL:-}" ]]; then
  rouge "❌ DATABASE_URL absente."; exit 1
fi

if [[ -z "${BACKUP_PASSPHRASE:-}" ]]; then
  rouge "⚠️  BACKUP_PASSPHRASE absente : la sauvegarde ne sera PAS chiffrée."
  rouge "    Interdit en production — un dump contient des données de santé."
  if [[ "${ALLOW_UNENCRYPTED:-}" != "yes" ]]; then
    rouge "    Relancez avec ALLOW_UNENCRYPTED=yes si c'est un environnement de test."
    exit 1
  fi
fi

mkdir -p "$BACKUP_DIR"
BASE="$BACKUP_DIR/pharmaflow-$HORODATAGE"
DUMP="$BASE.dump"

echo "→ Sauvegarde PharmaFlow AI — $HORODATAGE"

# Format custom (-Fc) : compressé, restauration sélective possible, parallélisable.
pg_dump --format=custom --no-owner --no-acl --file="$DUMP" "$DATABASE_URL"
TAILLE=$(du -h "$DUMP" | cut -f1)
info "dump créé : $(basename "$DUMP") ($TAILLE)"

# Vérification d'intégrité AVANT chiffrement : un dump corrompu chiffré reste corrompu.
if ! pg_restore --list "$DUMP" > /dev/null 2>&1; then
  rouge "❌ Dump illisible — sauvegarde abandonnée."
  rm -f "$DUMP"; exit 1
fi
OBJETS=$(pg_restore --list "$DUMP" | grep -c "TABLE DATA" || true)
info "intégrité vérifiée : $OBJETS tables de données"

FINAL="$DUMP"
if [[ -n "${BACKUP_PASSPHRASE:-}" ]]; then
  # AES-256-CBC + PBKDF2 : chiffrement au repos de l'archive.
  openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt \
    -in "$DUMP" -out "$DUMP.enc" -pass env:BACKUP_PASSPHRASE
  rm -f "$DUMP"
  FINAL="$DUMP.enc"
  info "chiffré : $(basename "$FINAL")"
fi

# Empreinte : permet de détecter une altération silencieuse du stockage.
sha256sum "$FINAL" | awk '{print $1}' > "$FINAL.sha256"
info "empreinte : $(cut -c1-16 < "$FINAL.sha256")…"

SUPPRIMES=$(find "$BACKUP_DIR" -name 'pharmaflow-*' -mtime "+$RETENTION_DAYS" -print -delete 2>/dev/null | wc -l)
[[ "$SUPPRIMES" -gt 0 ]] && info "purge : $SUPPRIMES fichier(s) de plus de $RETENTION_DAYS jours"

vert "✅ Sauvegarde terminée"
# Ligne machine-lisible (sans couleur) pour les scripts appelants.
echo "ARCHIVE=$FINAL"

cat <<TXT

  Restauration :
    ./scripts/restore.sh "$FINAL" "postgresql://…/base_cible"

  Rappel : une sauvegarde jamais restaurée n'est pas une sauvegarde.
  Testez la restauration chaque trimestre — ./scripts/verify-backup.sh
TXT
