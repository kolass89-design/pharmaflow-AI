#!/usr/bin/env bash
#
# Contrôle avant mise en production.
# À exécuter sur l'environnement cible AVANT d'ouvrir le service aux officines.
#
# Usage : ./scripts/preflight.sh [URL_APPLICATION]

set -uo pipefail
URL="${1:-http://localhost:3000}"
KO=0

vert()  { printf '  \033[32m✓\033[0m %s\n' "$*"; }
rouge() { printf '  \033[31m✗\033[0m %s\n' "$*"; KO=$((KO+1)); }
orange(){ printf '  \033[33m!\033[0m %s\n' "$*"; }

echo ""
echo "═══ Contrôle avant production — $URL ═══"

echo ""
echo "1. Variables d'environnement"
[[ -n "${DATABASE_URL:-}" ]] && vert "DATABASE_URL définie" || rouge "DATABASE_URL manquante"
if [[ "${SESSION_SECRET:-}" =~ ^.{32,}$ ]]; then vert "SESSION_SECRET (≥32 car.)"; else rouge "SESSION_SECRET trop courte ou absente"; fi
if [[ "${ENCRYPTION_KEY:-}" =~ ^[0-9a-fA-F]{64}$ ]]; then vert "ENCRYPTION_KEY valide"; else rouge "ENCRYPTION_KEY invalide (64 hex attendus)"; fi
[[ -n "${BACKUP_PASSPHRASE:-}" ]] && vert "BACKUP_PASSPHRASE définie" || rouge "BACKUP_PASSPHRASE manquante (sauvegardes non chiffrées)"
[[ -n "${UPSTASH_REDIS_REST_URL:-}" ]] && vert "Redis configuré" || orange "Redis absent : rate limiting en mémoire (instance unique uniquement)"
[[ -n "${MONITORING_WEBHOOK_URL:-}" ]] && vert "Supervision configurée" || orange "MONITORING_WEBHOOK_URL absente : alertes en logs seulement"

echo ""
echo "2. Secrets non triviaux"
for v in SESSION_SECRET ENCRYPTION_KEY BACKUP_PASSPHRASE; do
  val="${!v:-}"
  case "$val" in
    *dev*|*change*|*test*|*exemple*|*example*|0123456789*)
      rouge "$v semble être une valeur d'exemple — à régénérer" ;;
    "") ;;
    *) vert "$v personnalisée" ;;
  esac
done

echo ""
echo "3. Dépendances"
if npm audit --audit-level=high --production >/dev/null 2>&1; then vert "aucune vulnérabilité haute"; else rouge "vulnérabilités détectées (npm audit)"; fi

echo ""
echo "4. Base de données"
if [[ -n "${DATABASE_URL:-}" ]]; then
  if psql "$DATABASE_URL" -tAc "SELECT 1" >/dev/null 2>&1; then
    vert "connexion établie"
    N=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM _prisma_migrations WHERE finished_at IS NOT NULL" 2>/dev/null || echo 0)
    [[ "$N" -gt 0 ]] && vert "$N migration(s) appliquée(s)" || rouge "aucune migration appliquée (npm run db:deploy)"
    SSL=$([[ "$DATABASE_URL" == *sslmode=require* || "$DATABASE_URL" == *localhost* || "$DATABASE_URL" == *127.0.0.1* ]] && echo ok || echo non)
    [[ "$SSL" == "ok" ]] && vert "connexion chiffrée ou locale" || rouge "ajoutez ?sslmode=require à DATABASE_URL"
  else
    rouge "base injoignable"
  fi
fi

echo ""
echo "5. Application"
CODE=$(curl -s -o /tmp/pf-health.json -w '%{http_code}' "$URL/api/health" 2>/dev/null || echo 000)
if [[ "$CODE" == "200" || "$CODE" == "503" ]]; then
  ETAT=$(python3 -c "import json;print(json.load(open('/tmp/pf-health.json'))['status'])" 2>/dev/null || echo "?")
  [[ "$ETAT" == "ok" ]] && vert "sonde de santé : ok" || orange "sonde de santé : $ETAT"
else
  rouge "sonde /api/health injoignable (HTTP $CODE)"
fi
for f in /manifest.webmanifest /sw.js /icon-512.png; do
  C=$(curl -s -o /dev/null -w '%{http_code}' "$URL$f" 2>/dev/null || echo 000)
  [[ "$C" == "200" ]] && vert "PWA $f" || rouge "PWA $f absent (HTTP $C)"
done

echo ""
echo "6. Sauvegardes"
if [[ -x ./scripts/verify-backup.sh ]]; then vert "script de vérification présent"; else rouge "scripts/verify-backup.sh manquant"; fi
DERNIERE=$(find "${BACKUP_DIR:-./backups}" -name 'pharmaflow-*' -mtime -1 2>/dev/null | head -1)
[[ -n "$DERNIERE" ]] && vert "sauvegarde de moins de 24 h" || orange "aucune sauvegarde récente"

echo ""
echo "────────────────────────────────────────────────────"
if [[ "$KO" -eq 0 ]]; then
  printf '\033[32m✅ Prêt pour la production.\033[0m\n\n'
else
  printf '\033[31m❌ %s point(s) bloquant(s) à corriger.\033[0m\n\n' "$KO"
  exit 1
fi
