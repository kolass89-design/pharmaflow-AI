/**
 * Test terrain : simulation d'une coupure réseau en pleine journée de comptoir.
 *
 * Reproduit fidèlement la logique de lib/offline.ts (file IndexedDB) et la
 * confronte au vrai serveur. Vérifie ce qui compte réellement pour une officine :
 *   1. aucune vente perdue pendant la coupure
 *   2. aucune vente dupliquée à la resynchronisation
 *   3. le stock final correspond exactement aux unités vendues
 *   4. le chiffre d'affaires est juste au franc près
 *   5. les refus métier sont isolés, pas noyés
 *
 * Usage : node scripts/test-terrain.mjs
 * Variables : BASE_URL, DATABASE_URL
 */

import { execSync } from "node:child_process";

const BASE = process.env.BASE_URL ?? "http://localhost:3990";
const PG = process.env.DATABASE_URL ?? "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow";
const NB_VENTES = Number(process.env.NB_VENTES ?? 30);

const sql = (q) => execSync(`psql "${PG}" -tAc ${JSON.stringify(q.replace(/\s+/g, " ").trim())}`, { encoding: "utf8" }).trim();
const vert = (s) => `\x1b[32m${s}\x1b[0m`;
const rouge = (s) => `\x1b[31m${s}\x1b[0m`;
const gris = (s) => `\x1b[90m${s}\x1b[0m`;

let cookie = "";
let echecsTest = 0;

function verifier(libelle, attendu, obtenu) {
  const ok = String(attendu) === String(obtenu);
  if (!ok) echecsTest++;
  console.log(`  ${ok ? vert("✓") : rouge("✗")} ${libelle.padEnd(42)} ${ok ? obtenu : rouge(`${obtenu} (attendu ${attendu})`)}`);
}

/* ─────────── File locale (réplique de lib/offline.ts) ─────────── */
const queue = [];
const enqueue = (payload) => {
  const uuid = crypto.randomUUID();
  queue.push({ uuid, payload: { ...payload, offlineUuid: uuid }, status: "pending", tries: 0 });
  return uuid;
};

async function flush() {
  let envoyees = 0, doublons = 0, echecs = 0;
  for (const op of queue.filter((o) => o.status === "pending")) {
    try {
      const res = await fetch(`${BASE}/api/sales`, {
        method: "POST",
        headers: { "Content-Type": "application/json", cookie },
        body: JSON.stringify(op.payload),
      });
      if (res.ok) {
        const d = await res.json().catch(() => ({}));
        if (d?.duplicate) doublons++; else envoyees++;
        op.status = "sent";
        op.ref = d?.sale?.reference;
        op.total = d?.sale?.total;
      } else if (res.status >= 400 && res.status < 500 && res.status !== 429) {
        const d = await res.json().catch(() => ({}));
        op.status = "failed";
        op.lastError = d?.error ?? `HTTP ${res.status}`;
        echecs++;
      } else {
        op.tries++;                       // 5xx : on retentera
      }
    } catch (e) {
      op.tries++;
      op.lastError = e.message;
      break;                              // réseau coupé : inutile d'insister
    }
  }
  return { envoyees, doublons, echecs, restantes: queue.filter((o) => o.status !== "sent").length };
}

/* ─────────── Scénario ─────────── */
async function main() {
  console.log(`\n═══ Test terrain — ${NB_VENTES} encaissements hors ligne ═══\n`);

  const login = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "demo@pharmaflow.ai", password: "demo1234" }),
  });
  if (!login.ok) throw new Error("Connexion impossible");
  cookie = login.headers.get("set-cookie").split(";")[0];

  // Produits largement approvisionnés, pour que la coupure seule soit testée.
  const lignes = sql(`
    SELECT p.id || '|' || p."salePrice" || '|' || COALESCE(SUM(b.quantity), 0)
    FROM "Product" p LEFT JOIN "ProductBatch" b ON b."productId" = p.id
    WHERE p."isActive" = true
      AND p."pharmacyId" = (SELECT m."pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id = m."userId" WHERE u.email = 'demo@pharmaflow.ai' LIMIT 1)
    GROUP BY p.id, p."salePrice" HAVING COALESCE(SUM(b.quantity), 0) > 60
    ORDER BY SUM(b.quantity) DESC LIMIT 4`).split("\n").filter(Boolean);

  const produits = lignes.map((l) => {
    const [id, prix, stock] = l.split("|");
    return { id, prix: Number(prix), stock: Number(stock) };
  });
  if (produits.length < 2) throw new Error("Stock insuffisant pour le test — relancez le seed.");

  const etatInitial = Object.fromEntries(
    produits.map((p) => [p.id, Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${p.id}'`))])
  );
  const ventesAvant = Number(sql(`SELECT COUNT(*) FROM "Sale"`));
  const mouvementsAvant = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "StockMovement" WHERE type='OUT' AND reason='Vente comptoir'`));
  const caAvant = Number(sql(`SELECT COALESCE(SUM(total),0) FROM "Sale"`));

  console.log(gris(`  État initial : ${ventesAvant} ventes · ${caAvant.toLocaleString("fr-FR")} FCFA`));
  console.log(gris(`  Produits testés : ${produits.length}\n`));

  /* 1. Coupure réseau */
  console.log("1. Réseau coupé — le comptoir continue");
  const methodes = ["CASH", "MTN_MOMO", "MOOV_MONEY", "WAVE", "CELTIIS_CASH"];
  const attendu = {};
  let caAttendu = 0;

  for (let i = 0; i < NB_VENTES; i++) {
    const nb = 1 + (i % 2);
    const choisis = [];
    for (let j = 0; j < nb; j++) choisis.push(produits[(i + j) % produits.length]);
    const uniques = [...new Map(choisis.map((p) => [p.id, p])).values()];

    const items = uniques.map((p) => {
      const quantity = 1 + (i % 2);
      attendu[p.id] = (attendu[p.id] ?? 0) + quantity;
      return { productId: p.id, quantity };
    });
    const sousTotal = items.reduce((t, it) => {
      const p = produits.find((x) => x.id === it.productId);
      return t + p.prix * it.quantity;
    }, 0);
    const remise = i % 10 === 0 ? 5 : 0;
    caAttendu += sousTotal - Math.round((sousTotal * remise) / 100);

    enqueue({ items, method: methodes[i % methodes.length], discountPercent: remise });
  }
  console.log(`  ${NB_VENTES} ventes encaissées et mises en file locale`);
  verifier("aucune vente écrite en base", ventesAvant, sql(`SELECT COUNT(*) FROM "Sale"`));

  /* 2. Une vente impossible se glisse dans la file */
  console.log("\n2. Une vente dépasse le stock disponible");
  enqueue({ items: [{ productId: produits[0].id, quantity: 999_999 }], method: "CASH" });
  console.log(gris("  (le préparateur ne pouvait pas le savoir : le stock était figé)"));

  /* 3. Retour du réseau */
  console.log("\n3. Retour du réseau — resynchronisation");
  const r1 = await flush();
  console.log(gris(`  ${JSON.stringify(r1)}`));
  verifier("ventes synchronisées", NB_VENTES, r1.envoyees);
  verifier("refus métier isolés", 1, r1.echecs);
  verifier("aucun doublon", 0, r1.doublons);

  /* 4. Double synchronisation (onglet rouvert, clic manuel…) */
  console.log("\n4. Synchronisation relancée deux fois");
  queue.filter((o) => o.status === "sent").forEach((o) => { o.status = "pending"; });
  const r2 = await flush();
  console.log(gris(`  ${JSON.stringify(r2)}`));
  verifier("détectés comme doublons", NB_VENTES, r2.doublons);
  verifier("aucune vente recréée", 0, r2.envoyees);

  /* 5. Cohérence finale */
  console.log("\n5. Cohérence des données");
  verifier("ventes en base", ventesAvant + NB_VENTES, sql(`SELECT COUNT(*) FROM "Sale"`));
  verifier("chiffre d'affaires", caAvant + caAttendu, sql(`SELECT COALESCE(SUM(total),0) FROM "Sale"`));

  for (const p of produits) {
    const attenduStock = etatInitial[p.id] - (attendu[p.id] ?? 0);
    verifier(`stock ${p.id.slice(-6)}`, attenduStock, sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${p.id}'`));
  }

  const totalUnites = Object.values(attendu).reduce((a, b) => a + b, 0);
  const mouvementsApres = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "StockMovement" WHERE type='OUT' AND reason='Vente comptoir'`));
  verifier("mouvements de sortie tracés", totalUnites, mouvementsApres - mouvementsAvant);
  verifier("lignes de vente orphelines", 0,
    sql(`SELECT COUNT(*) FROM "SaleItem" si LEFT JOIN "Sale" s ON s.id = si."saleId" WHERE s.id IS NULL`));
  verifier("paiement pour chaque vente", 0,
    sql(`SELECT COUNT(*) FROM "Sale" s LEFT JOIN "Payment" p ON p."saleId" = s.id WHERE p.id IS NULL`));

  /* 6. État de la file */
  console.log("\n6. File locale après resynchronisation");
  const enEchec = queue.filter((o) => o.status === "failed");
  verifier("opérations restant en file", 1, queue.filter((o) => o.status !== "sent").length);
  for (const o of enEchec) console.log(gris(`  échec conservé : ${o.lastError}`));

  console.log("\n" + "─".repeat(62));
  if (echecsTest === 0) {
    console.log(vert(`✅ Test terrain réussi — ${NB_VENTES} ventes, aucune perte, aucun doublon.`));
  } else {
    console.log(rouge(`❌ ${echecsTest} vérification(s) en échec.`));
    process.exit(1);
  }
}

main().catch((e) => { console.error(rouge(`\n❌ ${e.message}`)); process.exit(1); });
