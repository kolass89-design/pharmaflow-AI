/**
 * Chargeur de modules applicatifs pour les tests.
 *
 * Les modules sous lib/ sont en TypeScript et certains portent `server-only`,
 * qui lève une exception hors du runtime Next.js. On les transpile à la volée
 * avec esbuild (déjà présent via tsx) après avoir retiré ce marqueur.
 *
 * On teste ainsi le VRAI code applicatif, jamais une réimplémentation.
 */
import { readFileSync, mkdirSync, writeFileSync, rmSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { join, dirname } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ici = dirname(fileURLToPath(import.meta.url));
const racine = join(ici, "..", "..");
const cache = join(racine, "node_modules", ".test-build");

function compiler(relatif) {
  let source = readFileSync(join(racine, relatif), "utf8").replace(/^import ["']server-only["'];?\s*$/m, "");
  // `next/headers` n'existe que dans le runtime Next : on le remplace par un
  // bouchon. Les fonctions testées ici (RBAC, hachage, signature) n'en dépendent pas.
  source = source.replace(/^import \{ cookies \} from ["']next\/headers["'];?\s*$/m,
    "const cookies = async () => ({ get: () => undefined });");
  mkdirSync(cache, { recursive: true });
  const nom = relatif.replace(/[\/\\]/g, "_").replace(/\.ts$/, "");
  const dossierSource = join(racine, dirname(relatif));
  const entree = join(dossierSource, `.__test_${nom}.ts`);
  const sortie = join(cache, `${nom}.mjs`);
  writeFileSync(entree, source);
  try {
    execFileSync(
      join(racine, "node_modules", ".bin", "esbuild"),
      [entree, "--bundle", "--platform=node", "--format=esm", "--packages=external", `--outfile=${sortie}`, "--log-level=error"],
      { cwd: racine },
    );
  } finally {
    rmSync(entree, { force: true });   // jamais de résidu dans lib/, même en cas d'échec
  }
  return sortie;
}

const charger = async (relatif) => import(pathToFileURL(compiler(relatif)).href);

const importer = await charger("lib/import.ts");
const crypto = await charger("lib/crypto-core.ts");
const monitoring = await charger("lib/monitoring.ts");
const auth = await charger("lib/auth.ts");
const utils = await charger("lib/utils.ts");
const whatsapp = await charger("lib/whatsapp/moteur.ts");

export const { parseCatalogCsv, templateCsv } = importer;
export const { encrypt, decrypt, maskPhone, needsRewrap } = crypto;
export const { scrub, SEUILS } = monitoring;
export const { can, PERMISSIONS, hashPassword, verifyPassword, encodeSession, decodeSession } = auth;
export const { fcfa, cn } = utils;
export const { detecterIntention, extraireProduit } = whatsapp;
