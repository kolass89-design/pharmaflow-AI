/**
 * Tests des actions de paramétrage et d'administration.
 * Ces routes viennent remplacer des boutons qui, jusqu'ici, ne faisaient rien.
 */
import { test, describe, before } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const PG = process.env.DATABASE_URL ?? "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow";
const sql = (q) => execFileSync("psql", [PG, "-tAc", q.replace(/\s+/g, " ").trim()], { encoding: "utf8" }).trim();

let cookie = "";
const appel = (chemin, methode, corps) =>
  fetch(`${BASE}${chemin}`, {
    method: methode, headers: { "Content-Type": "application/json", cookie },
    ...(corps ? { body: JSON.stringify(corps) } : {}),
  });

before(async () => {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "demo@pharmaflow.ai", password: "demo1234" }),
  });
  cookie = r.headers.get("set-cookie").split(";")[0];
});

describe("Paramètres de l'officine", () => {
  test("enregistre les modifications d'identité", async () => {
    const r = await appel("/api/pharmacy", "PATCH", { phone: "+229 21 30 99 99" });
    assert.equal(r.status, 200);
    assert.equal(sql(`SELECT phone FROM "Pharmacy" WHERE id=(SELECT m."pharmacyId" FROM "PharmacyMember" m JOIN "User" u ON u.id=m."userId" WHERE u.email='demo@pharmaflow.ai' LIMIT 1)`), "+229 21 30 99 99");
  });

  test("enregistre des horaires valides", async () => {
    const r = await appel("/api/pharmacy", "PATCH", { openingHours: { lun_ven: "07:00-21:00", sam: "08:00-19:00", dim: "fermé" } });
    assert.equal(r.status, 200);
  });

  test("refuse un format d'horaire invalide", async () => {
    const r = await appel("/api/pharmacy", "PATCH", { openingHours: { lun_ven: "n'importe quoi" } });
    assert.equal(r.status, 422);
    assert.match((await r.json()).error, /Format attendu/);
  });

  test("refuse une modification sans session", async () => {
    const r = await fetch(`${BASE}/api/pharmacy`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ phone: "x" }),
    });
    assert.ok([401, 403].includes(r.status));
  });
});

describe("Gestion de l'équipe", () => {
  const email = `test.membre.${Date.now()}@pharmaflow.ai`;
  let idMembre;

  test("invite un membre et renvoie un mot de passe provisoire", async () => {
    const r = await appel("/api/members", "POST", { fullName: "Nouveau Préparateur", email, role: "TECHNICIAN" });
    assert.equal(r.status, 200);
    const d = await r.json();
    assert.ok(d.motDePasseProvisoire?.length >= 8, "un secret exploitable doit être fourni");
    idMembre = d.membre.id;
  });

  test("le membre peut réellement se connecter", async () => {
    const invit = await appel("/api/members", "POST", {
      fullName: "Test Connexion", email: `connexion.${Date.now()}@pharmaflow.ai`, role: "CASHIER",
    });
    const d = await invit.json();
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: d.membre.email, password: d.motDePasseProvisoire }),
    });
    assert.equal(login.status, 200, "le mot de passe provisoire doit fonctionner");
  });

  test("refuse un email déjà utilisé", async () => {
    const r = await appel("/api/members", "POST", { fullName: "Doublon", email, role: "CASHIER" });
    assert.equal(r.status, 409);
  });

  test("refuse un rôle de titulaire", async () => {
    const r = await appel("/api/members", "POST", {
      fullName: "Faux Titulaire", email: `owner.${Date.now()}@x.bj`, role: "OWNER",
    });
    assert.equal(r.status, 422, "on ne crée pas un second titulaire par simple invitation");
  });

  test("suspend puis réactive un membre", async () => {
    assert.equal((await appel(`/api/members/${idMembre}`, "PATCH", { isActive: false })).status, 200);
    assert.equal(sql(`SELECT "isActive" FROM "User" WHERE id='${idMembre}'`), "f");
    assert.equal((await appel(`/api/members/${idMembre}`, "PATCH", { isActive: true })).status, 200);
  });

  test("un membre suspendu ne peut plus se connecter", async () => {
    const invit = await appel("/api/members", "POST", {
      fullName: "Test Suspension", email: `susp.${Date.now()}@pharmaflow.ai`, role: "CASHIER",
    });
    const d = await invit.json();
    await appel(`/api/members/${d.membre.id}`, "PATCH", { isActive: false });
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: d.membre.email, password: d.motDePasseProvisoire }),
    });
    assert.equal(login.status, 401, "un compte suspendu doit être refusé");
  });

  test("impossible de se suspendre soi-même", async () => {
    const moi = sql(`SELECT id FROM "User" WHERE email='demo@pharmaflow.ai'`);
    const r = await appel(`/api/members/${moi}`, "PATCH", { isActive: false });
    assert.equal(r.status, 409);
  });

  test("un caissier ne peut pas inviter", async () => {
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: "ismael.koudjo@pharmaflow.ai", password: "demo1234" }),
    });
    const c = login.headers.get("set-cookie").split(";")[0];
    const r = await fetch(`${BASE}/api/members`, {
      method: "POST", headers: { "Content-Type": "application/json", cookie: c },
      body: JSON.stringify({ fullName: "Intrus", email: `intrus.${Date.now()}@x.bj`, role: "CASHIER" }),
    });
    assert.equal(r.status, 403);
  });
});

describe("Rappels de traitement", () => {
  test("crée un rappel et signale que l'envoi n'est pas actif", async () => {
    const patientId = sql(`SELECT id FROM "Patient" LIMIT 1`);
    const r = await appel("/api/reminders", "POST", {
      patientId, label: "Amlodipine — 1 comprimé le matin", schedule: "Chaque jour 07:00", channel: "WHATSAPP",
    });
    assert.equal(r.status, 200);
    const d = await r.json();
    assert.match(d.avertissement, /validation/i, "l'utilisateur doit savoir qu'aucun message ne partira encore");
  });

  test("refuse un patient d'une autre officine", async () => {
    const autre = sql(`
      SELECT id FROM "Patient" WHERE "pharmacyId" <> (SELECT m."pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id=m."userId" WHERE u.email='demo@pharmaflow.ai' LIMIT 1) LIMIT 1`);
    if (!autre) return;
    const r = await appel("/api/reminders", "POST", { patientId: autre, label: "Test", schedule: "Chaque jour" });
    assert.equal(r.status, 404);
  });
});

describe("Exports comptables", () => {
  test("export des ventes en CSV", async () => {
    const r = await appel("/api/accounting/export?type=ventes", "GET");
    assert.equal(r.status, 200);
    assert.match(r.headers.get("content-disposition") ?? "", /ventes-pharmaflow/);
    // fetch() interprète le BOM comme marqueur d'encodage et le retire du texte :
    // on le vérifie donc sur les octets bruts.
    const octets = new Uint8Array(await r.clone().arrayBuffer());
    assert.deepEqual([...octets.slice(0, 3)], [0xef, 0xbb, 0xbf], "BOM UTF-8 requis pour Excel");
    assert.match(await r.text(), /Reference/);
  });

  test("export des dépenses", async () => {
    const r = await appel("/api/accounting/export?type=depenses", "GET");
    assert.equal(r.status, 200);
    assert.match(await r.text(), /Categorie/);
  });

  test("un caissier ne peut pas exporter la comptabilité", async () => {
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: "ismael.koudjo@pharmaflow.ai", password: "demo1234" }),
    });
    const c = login.headers.get("set-cookie").split(";")[0];
    const r = await fetch(`${BASE}/api/accounting/export`, { headers: { cookie: c } });
    assert.equal(r.status, 403);
  });
});

describe("Conversations WhatsApp", () => {
  let idConv;
  before(() => { idConv = sql(`SELECT id FROM "WhatsappConversation" LIMIT 1`); });

  test("le pharmacien reprend la main", async () => {
    const r = await appel(`/api/conversations/${idConv}`, "PATCH", { status: "HUMAN" });
    assert.equal(r.status, 200);
    assert.equal(sql(`SELECT status FROM "WhatsappConversation" WHERE id='${idConv}'`), "HUMAN");
  });

  test("répondre enregistre le message et avertit s'il n'est pas transmis", async () => {
    const avant = Number(sql(`SELECT COUNT(*) FROM "WhatsappMessage" WHERE "conversationId"='${idConv}'`));
    const r = await appel(`/api/conversations/${idConv}`, "POST", { message: "Bonjour, je vous réponds en personne." });
    assert.equal(r.status, 200);
    const d = await r.json();
    assert.equal(Number(sql(`SELECT COUNT(*) FROM "WhatsappMessage" WHERE "conversationId"='${idConv}'`)), avant + 1);
    if (!d.envoye) assert.match(d.avertissement, /non transmis/i);
  });

  test("message vide refusé", async () => {
    assert.equal((await appel(`/api/conversations/${idConv}`, "POST", { message: "" })).status, 422);
  });

  test("conversation d'une autre officine inaccessible", async () => {
    const autre = sql(`
      SELECT id FROM "WhatsappConversation" WHERE "pharmacyId" <> (SELECT m."pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id=m."userId" WHERE u.email='demo@pharmaflow.ai' LIMIT 1) LIMIT 1`);
    if (!autre) return;
    assert.equal((await appel(`/api/conversations/${autre}`, "PATCH", { status: "HUMAN" })).status, 404);
  });
});

describe("Statut des ordonnances", () => {
  test("marque une ordonnance comme servie", async () => {
    const id = sql(`SELECT id FROM "Prescription" WHERE status='PENDING' LIMIT 1`);
    if (!id) return;
    const r = await appel(`/api/prescriptions/${id}`, "PATCH", { status: "SERVED" });
    assert.equal(r.status, 200);
    assert.equal(sql(`SELECT status FROM "Prescription" WHERE id='${id}'`), "SERVED");
  });
});
