/**
 * Tests de l'espace patient (API publiques, sans authentification).
 *
 * Ces routes sont les plus exposées du produit : accessibles à tous, elles
 * touchent au stock et créent des enregistrements. Les invariants vérifiés ici
 * sont autant de garde-fous contre l'abus et la fuite d'information.
 */
import { test, describe, before } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const PG = process.env.DATABASE_URL ?? "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow";

const sql = (q) => execFileSync("psql", [PG, "-tAc", q.replace(/\s+/g, " ").trim()], { encoding: "utf8" }).trim();
const get = (chemin) => fetch(`${BASE}${chemin}`);
const post = (chemin, corps) =>
  fetch(`${BASE}${chemin}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(corps),
  });

let produitLibre;      // réservable sans ordonnance
let produitOrdonnance; // soumis à prescription

before(async () => {
  const libre = await (await get("/api/public/recherche?q=sels")).json();
  produitLibre = libre.resultats[0];
  const ord = await (await get("/api/public/recherche?q=amoxicilline")).json();
  produitOrdonnance = ord.resultats[0];
  assert.ok(produitLibre, "aucun produit libre trouvé — relancez le seed");
  assert.ok(produitOrdonnance, "aucun produit sous ordonnance trouvé");
});

describe("Recherche publique", () => {
  test("trouve un médicament écrit sans accent", async () => {
    // Sur un clavier de téléphone, personne ne tape « Paracétamol ».
    const d = await (await get("/api/public/recherche?q=paracetamol")).json();
    assert.ok(d.total > 0, "la recherche sans accent doit aboutir");
    assert.ok(d.resultats.every((r) => /parac[eé]tamol/i.test(r.nom + r.dci)));
  });

  test("trouve aussi avec les accents", async () => {
    const d = await (await get(`/api/public/recherche?q=${encodeURIComponent("paracétamol")}`)).json();
    assert.ok(d.total > 0);
  });

  test("recherche par DCI, pas seulement par nom commercial", async () => {
    const d = await (await get("/api/public/recherche?q=artemether")).json();
    assert.ok(d.total > 0, "la DCI doit être interrogeable");
  });

  test("compare plusieurs officines pour un même produit", async () => {
    const d = await (await get("/api/public/recherche?q=paracetamol")).json();
    const officines = new Set(d.resultats.map((r) => r.pharmacie.id));
    assert.ok(officines.size >= 2, "le patient doit pouvoir comparer les officines");
  });

  test("ne divulgue JAMAIS la quantité exacte en stock", async () => {
    const brut = await (await get("/api/public/recherche?q=paracetamol")).text();
    for (const champ of ['"stock"', '"quantity"', '"batches"', '"alertThreshold"', '"purchasePrice"']) {
      assert.equal(brut.includes(champ), false, `${champ} ne doit pas être exposé publiquement`);
    }
    const d = JSON.parse(brut);
    assert.ok(["disponible", "limite", "indisponible"].includes(d.resultats[0].disponibilite));
  });

  test("ne divulgue pas le prix d'achat ni la marge", async () => {
    const brut = await (await get("/api/public/recherche?q=sels")).text();
    assert.equal(/marge|purchasePrice|prixAchat/i.test(brut), false);
  });

  test("signale les médicaments soumis à ordonnance", async () => {
    const d = await (await get("/api/public/recherche?q=amoxicilline")).json();
    assert.ok(d.resultats.every((r) => r.surOrdonnance === true));
  });

  test("trie par distance quand la position est fournie", async () => {
    const d = await (await get("/api/public/recherche?q=paracetamol&lat=6.3612&lon=2.4501")).json();
    const avecDistance = d.resultats.filter((r) => r.distanceKm != null);
    assert.ok(avecDistance.length > 0, "la distance doit être calculée");
    assert.ok(avecDistance.every((r) => r.distanceKm >= 0 && r.distanceKm < 20000));
  });

  test("filtre par ville", async () => {
    const d = await (await get("/api/public/recherche?q=paracetamol&ville=Cotonou")).json();
    assert.ok(d.resultats.every((r) => r.pharmacie.ville.toLowerCase() === "cotonou"));
  });

  test("refuse une requête trop courte", async () => {
    const d = await (await get("/api/public/recherche?q=a")).json();
    assert.equal(d.resultats.length, 0);
    assert.match(d.message, /2 caractères/);
  });

  test("indique l'état d'ouverture et de garde", async () => {
    const d = await (await get("/api/public/recherche?q=paracetamol")).json();
    const p = d.resultats[0].pharmacie;
    assert.ok("ouverteMaintenant" in p && "deGarde" in p);
    assert.equal(typeof p.deGarde, "boolean");
  });

  test("une recherche sans résultat renvoie une liste vide, pas une erreur", async () => {
    const r = await get("/api/public/recherche?q=zzzinexistantzzz");
    assert.equal(r.status, 200);
    assert.equal((await r.json()).total, 0);
  });
});

describe("Réservation patient", () => {
  test("crée une réservation avec une référence lisible au téléphone", async () => {
    const r = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Marie Sossou", telephone: "+229 97 00 11 22", quantite: 2,
    });
    assert.equal(r.status, 201);
    const { reservation } = await r.json();
    // Ni I ni O : évite les confusions avec 1 et 0 quand on dicte la référence.
    assert.match(reservation.reference, /^R-[ABCDEFGHJKLMNPQRSTUVWXYZ]{4}\d{4}$/);
    assert.equal(reservation.total, reservation.prixUnitaire * 2);
    assert.ok(reservation.pharmacie.nom);
  });

  test("le stock N'EST PAS décrémenté par une réservation", async () => {
    // Une réservation n'est pas une vente : sinon n'importe qui pourrait
    // vider le stock affiché d'une officine depuis son téléphone.
    const idProduit = produitLibre.produitId;
    const avant = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${idProduit}'`));
    await post("/api/public/reservations", {
      productId: idProduit, nom: "Test Stock", telephone: "+229 97 00 00 01", quantite: 1,
    });
    const apres = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${idProduit}'`));
    assert.equal(apres, avant, "le stock doit rester intact tant que la vente n'est pas faite");
  });

  test("refuse un médicament soumis à ordonnance", async () => {
    const r = await post("/api/public/reservations", {
      productId: produitOrdonnance.produitId, nom: "Test Patient", telephone: "+229 97 00 11 22",
    });
    assert.equal(r.status, 403);
    assert.match((await r.json()).error, /ordonnance/i);
  });

  test("le téléphone du patient est chiffré en base", async () => {
    const r = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Chiffrement Test", telephone: "+229 91 55 44 33",
    });
    const { reservation } = await r.json();
    const brut = sql(`SELECT "customerPhoneEnc" FROM "Reservation" WHERE reference='${reservation.reference}'`);
    assert.match(brut, /^v1:/, "le numéro doit être chiffré");
    assert.equal(brut.includes("91"), false);
  });

  test("valide le nom et le téléphone", async () => {
    const sansNom = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "X", telephone: "+229 97 00 11 22",
    });
    assert.equal(sansNom.status, 422);

    const telInvalide = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Nom Correct", telephone: "abc",
    });
    assert.equal(telInvalide.status, 422);
  });

  test("plafonne la quantité réservable", async () => {
    const r = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Gros Client", telephone: "+229 97 00 11 22", quantite: 999,
    });
    if (r.status === 201) {
      assert.ok((await r.json()).reservation.quantite <= 5, "5 unités maximum par réservation web");
    } else {
      assert.ok([409, 422, 429].includes(r.status));
    }
  });

  test("refuse un produit inexistant", async () => {
    const r = await post("/api/public/reservations", {
      productId: "inexistant", nom: "Test Patient", telephone: "+229 97 00 11 22",
    });
    assert.ok([404, 429].includes(r.status), `attendu 404 (ou 429 si quota atteint), reçu ${r.status}`);
  });

  test("le quota horaire finit par bloquer les demandes répétées", async () => {
    // Protection contre un robot qui réserverait tout le stock d'une officine.
    let bloque = false;
    for (let i = 0; i < 8; i++) {
      const r = await post("/api/public/reservations", {
        productId: produitLibre.produitId, nom: `Robot ${i}`, telephone: "+229 97 99 88 77",
      });
      if (r.status === 429) { bloque = true; break; }
    }
    assert.ok(bloque, "le quota de réservations doit finir par s'appliquer");
  });
});

describe("Suivi de réservation", () => {
  let reference;

  before(async () => {
    const r = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Suivi Test", telephone: "+229 96 11 22 33",
    });
    reference = (await r.json()).reservation.reference;
  });

  test("consultable par sa référence", async () => {
    const d = await (await get(`/api/public/reservations/${reference}`)).json();
    assert.equal(d.reference, reference);
    assert.equal(d.statut, "ACTIVE");
    assert.ok(d.pharmacie.nom);
  });

  test("n'expose aucune donnée personnelle du patient", async () => {
    // La référence tient lieu de secret : quiconque la devine ne doit rien
    // apprendre sur l'identité du réservataire.
    const brut = await (await get(`/api/public/reservations/${reference}`)).text();
    assert.equal(brut.includes("Suivi Test"), false, "le nom ne doit pas être renvoyé");
    assert.equal(/96\s*11|customerPhone/.test(brut), false, "le téléphone ne doit pas être renvoyé");
  });

  test("référence insensible à la casse", async () => {
    const r = await get(`/api/public/reservations/${reference.toLowerCase()}`);
    assert.equal(r.status, 200);
  });

  test("référence inconnue → 404", async () => {
    assert.equal((await get("/api/public/reservations/R-ZZZZ0000")).status, 404);
  });

  test("une réservation expirée est signalée comme telle", async () => {
    // Réservation dédiée : modifier celle des autres tests les rendrait dépendants.
    const ref = sql(`SELECT reference FROM "Reservation" WHERE status='ACTIVE' ORDER BY "createdAt" DESC LIMIT 1`);
    if (!ref) return;
    sql(`UPDATE "Reservation" SET "expiresAt" = now() - interval '1 hour' WHERE reference = '${ref}'`);
    const d = await (await get(`/api/public/reservations/${ref}`)).json();
    assert.equal(d.statut, "EXPIRED");
  });
});

describe("Annuaire des officines", () => {
  test("liste les pharmacies partenaires", async () => {
    const d = await (await get("/api/public/pharmacies")).json();
    assert.ok(d.pharmacies.length >= 2);
    assert.ok(d.villes.includes("Cotonou"));
  });

  test("expose les coordonnées utiles, pas les données de gestion", async () => {
    const brut = await (await get("/api/public/pharmacies")).text();
    for (const champ of ["subscription", "licenseNo", "currency"]) {
      assert.equal(brut.includes(champ), false, `${champ} ne regarde pas le public`);
    }
    const d = JSON.parse(brut);
    assert.ok("telephone" in d.pharmacies[0] && "ouverteMaintenant" in d.pharmacies[0]);
  });

  test("filtre par ville", async () => {
    const d = await (await get("/api/public/pharmacies?ville=Cotonou")).json();
    assert.ok(d.pharmacies.every((p) => p.ville === "Cotonou"));
  });
});

describe("Circuit complet — de la réservation au retrait", () => {
  test("le pharmacien voit la réservation puis la clôture", async () => {
    // 1. Le patient réserve depuis son téléphone
    const creation = await post("/api/public/reservations", {
      productId: produitLibre.produitId, nom: "Circuit Complet", telephone: "+229 95 12 34 56",
    });
    if (creation.status === 429) return;   // quota atteint par les tests précédents
    assert.equal(creation.status, 201);
    const { reservation } = await creation.json();

    // 2. Elle est visible en base pour l'officine concernée
    const id = sql(`SELECT id FROM "Reservation" WHERE reference='${reservation.reference}'`);
    assert.ok(id, "la réservation doit exister");
    assert.equal(sql(`SELECT status FROM "Reservation" WHERE id='${id}'`), "ACTIVE");

    // 3. Le pharmacien la marque comme retirée
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: "demo@pharmaflow.ai", password: "demo1234" }),
    });
    const cookie = login.headers.get("set-cookie").split(";")[0];

    const maj = await fetch(`${BASE}/api/reservations/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json", cookie },
      body: JSON.stringify({ status: "COLLECTED" }),
    });
    assert.equal(maj.status, 200);
    assert.equal(sql(`SELECT status FROM "Reservation" WHERE id='${id}'`), "COLLECTED");

    // 4. Le patient voit le nouvel état
    const suivi = await (await get(`/api/public/reservations/${reservation.reference}`)).json();
    assert.equal(suivi.statut, "COLLECTED");

    // 5. Une seconde clôture est refusée
    const rejeu = await fetch(`${BASE}/api/reservations/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json", cookie },
      body: JSON.stringify({ status: "CANCELLED" }),
    });
    assert.equal(rejeu.status, 409);
  });

  test("une officine ne peut pas clôturer la réservation d'une autre", async () => {
    const autre = sql(`
      SELECT r.id FROM "Reservation" r
      WHERE r."pharmacyId" <> (SELECT m."pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id = m."userId" WHERE u.email = 'demo@pharmaflow.ai' LIMIT 1)
      LIMIT 1`);
    if (!autre) return;
    const login = await fetch(`${BASE}/api/auth/login`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: "demo@pharmaflow.ai", password: "demo1234" }),
    });
    const cookie = login.headers.get("set-cookie").split(";")[0];
    const r = await fetch(`${BASE}/api/reservations/${autre}`, {
      method: "PATCH", headers: { "Content-Type": "application/json", cookie },
      body: JSON.stringify({ status: "COLLECTED" }),
    });
    assert.equal(r.status, 404);
  });

  test("la clôture exige une session authentifiée", async () => {
    const id = sql(`SELECT id FROM "Reservation" LIMIT 1`);
    const r = await fetch(`${BASE}/api/reservations/${id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "COLLECTED" }),
    });
    assert.ok([401, 403].includes(r.status));
  });
});
