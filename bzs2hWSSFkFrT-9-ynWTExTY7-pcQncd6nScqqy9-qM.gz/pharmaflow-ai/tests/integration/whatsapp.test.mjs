/**
 * Tests de l'agent WhatsApp.
 *
 * Le risque principal n'est pas technique mais déontologique : un automate qui
 * répondrait à une question de posologie engagerait la responsabilité du
 * pharmacien titulaire. La couverture du transfert humain est donc la plus
 * dense de ce fichier.
 */
import { test, describe, before } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import crypto from "node:crypto";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const PG = process.env.DATABASE_URL ?? "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow";

const sql = (q) => execFileSync("psql", [PG, "-tAc", q.replace(/\s+/g, " ").trim()], { encoding: "utf8" }).trim();

// Le webhook exige une signature HMAC en production — et `next start` fixe
// NODE_ENV=production. Les tests signent donc comme le ferait Meta.
const SECRET = process.env.WHATSAPP_APP_SECRET ?? "";
function signer(corps) {
  const h = { "Content-Type": "application/json" };
  if (SECRET) h["x-hub-signature-256"] = "sha256=" + crypto.createHmac("sha256", SECRET).update(corps).digest("hex");
  return h;
}
const poster = (corps) => fetch(`${BASE}/api/whatsapp/webhook`, { method: "POST", headers: signer(corps), body: corps });

let compteur = 0;
/** Chaque test utilise un numéro distinct : les conversations sont isolées. */
const nouveauNumero = () => `+2299${String(1000000 + compteur++).slice(0, 7)}`;

async function envoyer(texte, telephone) {
  const corps = JSON.stringify({ message: { text: texte, from: telephone, id: `msg-${Date.now()}-${Math.random()}` } });
  const r = await poster(corps);
  const d = await r.json();
  return { statut: r.status, ...(d.resultats?.[0] ?? {}) };
}

before(() => {
  // Le webhook a besoin d'une officine dotée d'un numéro WhatsApp.
  const n = sql(`SELECT COUNT(*) FROM "Pharmacy" WHERE "whatsappNo" IS NOT NULL`);
  assert.ok(Number(n) > 0, "aucune officine avec numéro WhatsApp — relancez le seed");
});

/* ─────────────── Vérification du webhook ─────────────── */

describe("Vérification du webhook Meta", () => {
  test("accepte le bon token", async () => {
    const r = await fetch(`${BASE}/api/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=pharmaflow-dev&hub.challenge=42`);
    assert.equal(r.status, 200);
    assert.equal(await r.text(), "42");
  });

  test("refuse un token erroné", async () => {
    const r = await fetch(`${BASE}/api/whatsapp/webhook?hub.mode=subscribe&hub.verify_token=faux&hub.challenge=42`);
    assert.equal(r.status, 403);
  });

  test("refuse un mode inattendu", async () => {
    const r = await fetch(`${BASE}/api/whatsapp/webhook?hub.mode=autre&hub.verify_token=pharmaflow-dev&hub.challenge=42`);
    assert.equal(r.status, 403);
  });
});

/* ─────────────── Sécurité déontologique ─────────────── */

describe("Refus de conseil médical", () => {
  const questionsInterdites = [
    "Quelle posologie pour l'amoxicilline ?",
    "Combien de comprimés par jour ?",
    "Je suis enceinte, puis-je prendre du paracétamol ?",
    "Quels sont les effets secondaires ?",
    "Est-ce dangereux avec mon traitement ?",
    "J'ai mal au ventre depuis 3 jours",
    "Je fais de la fièvre, que prendre ?",
    "Y a-t-il une interaction avec mon anticoagulant ?",
    "Je suis allergique à la pénicilline, que me conseillez-vous ?",
    "Puis-je donner ça à mon bébé de 6 mois ?",
  ];

  for (const q of questionsInterdites) {
    test(`transfert humain : « ${q.slice(0, 45)}… »`, async () => {
      const r = await envoyer(q, nouveauNumero());
      assert.equal(r.handoff, true, "cette question exige un pharmacien");
      assert.equal(r.intention, "conseil_medical");
      // Le bot ne doit surtout pas glisser un conseil dans sa réponse.
      assert.equal(/prenez|prends|comprimés? par jour|toutes les \d+ heures/i.test(r.reply), false,
        "aucune indication thérapeutique ne doit figurer dans la réponse");
    });
  }

  test("la conversation passe en HUMAN_REQUIRED", async () => {
    const tel = nouveauNumero();
    await envoyer("Quelle dose pour un enfant ?", tel);
    assert.equal(sql(`SELECT status FROM "WhatsappConversation" WHERE phone='${tel}'`), "HUMAN_REQUIRED");
  });

  test("une demande explicite de pharmacien est transférée", async () => {
    const r = await envoyer("Je veux parler à un pharmacien", nouveauNumero());
    assert.equal(r.handoff, true);
    assert.equal(r.intention, "humain");
  });

  test("le bot se tait quand un humain a repris la main", async () => {
    const tel = nouveauNumero();
    await envoyer("Bonjour", tel);
    sql(`UPDATE "WhatsappConversation" SET status='HUMAN' WHERE phone='${tel}'`);
    const r = await envoyer("Vous avez du paracétamol ?", tel);
    assert.equal(r.reply, "", "le bot ne doit pas couper la parole au pharmacien");
  });
});

/* ─────────────── Recherche de produit ─────────────── */

describe("Recherche de disponibilité", () => {
  test("répond avec le prix pour un produit en stock", async () => {
    const r = await envoyer("Bonjour, avez-vous du paracétamol ?", nouveauNumero());
    assert.equal(r.handoff, false);
    assert.match(r.reply, /disponible/i);
    assert.match(r.reply, /FCFA/);
    assert.match(r.reply, /oui/i, "le bot doit proposer la réservation");
  });

  test("fonctionne sans accent", async () => {
    const r = await envoyer("paracetamol", nouveauNumero());
    assert.match(r.reply, /disponible/i);
  });

  test("fonctionne par molécule (DCI)", async () => {
    const r = await envoyer("artemether", nouveauNumero());
    assert.match(r.reply, /disponible|épuisé/i);
  });

  test("retire les formules de politesse pour isoler le produit", async () => {
    const r = await envoyer("Bonjour, est-ce que vous avez du paracétamol s'il vous plaît ?", nouveauNumero());
    assert.match(r.reply, /disponible/i);
  });

  test("produit inconnu : réponse honnête, sans invention", async () => {
    const r = await envoyer("Avez-vous du zzzzmedicamentinexistant ?", nouveauNumero());
    assert.match(r.reply, /ne trouve pas|orthographe/i);
    assert.equal(/disponible/i.test(r.reply), false, "le bot ne doit jamais affirmer une disponibilité fausse");
  });

  test("un médicament sous ordonnance est signalé et non réservable", async () => {
    const r = await envoyer("amoxicilline", nouveauNumero());
    assert.match(r.reply, /ordonnance/i);
    assert.match(r.reply, /comptoir/i);
  });
});

/* ─────────────── Réservation ─────────────── */

describe("Réservation par conversation", () => {
  test("le « oui » réserve le produit précédemment proposé", async () => {
    const tel = nouveauNumero();
    const recherche = await envoyer("sels de réhydratation", tel);
    assert.match(recherche.reply, /disponible/i);

    const confirmation = await envoyer("oui", tel);
    assert.ok(confirmation.reservation, "une réservation doit être créée");
    assert.match(confirmation.reservation.reference, /^R-[ABCDEFGHJKLMNPQRSTUVWXYZ]{4}\d{4}$/);
    assert.match(confirmation.reply, /confirmée/i);
    assert.match(confirmation.reply, /2 heures/i);
  });

  test("la réservation est bien enregistrée avec sa source", async () => {
    const tel = nouveauNumero();
    await envoyer("sels de réhydratation", tel);
    const c = await envoyer("oui", tel);
    const ref = c.reservation.reference;
    assert.equal(sql(`SELECT source FROM "Reservation" WHERE reference='${ref}'`), "WHATSAPP");
    assert.equal(sql(`SELECT status FROM "Reservation" WHERE reference='${ref}'`), "ACTIVE");
  });

  test("le stock n'est pas décrémenté par une réservation WhatsApp", async () => {
    const id = sql(`SELECT id FROM "Product" WHERE name LIKE 'Sels%' LIMIT 1`);
    const avant = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${id}'`));
    const tel = nouveauNumero();
    await envoyer("sels de réhydratation", tel);
    await envoyer("oui", tel);
    const apres = Number(sql(`SELECT COALESCE(SUM(quantity),0) FROM "ProductBatch" WHERE "productId"='${id}'`));
    assert.equal(apres, avant, "le produit est mis de côté, pas vendu");
  });

  test("« oui » sans contexte demande une précision", async () => {
    const r = await envoyer("oui", nouveauNumero());
    assert.match(r.reply, /quel produit/i);
    assert.equal(r.reservation, undefined);
  });

  test("« non » n'engage rien", async () => {
    const tel = nouveauNumero();
    await envoyer("sels de réhydratation", tel);
    const r = await envoyer("non", tel);
    assert.equal(r.reservation, undefined);
    assert.match(r.reply, /rien n'est réservé/i);
  });

  test("un produit sous ordonnance ne peut pas être réservé même après « oui »", async () => {
    const tel = nouveauNumero();
    await envoyer("amoxicilline", tel);
    const r = await envoyer("oui", tel);
    assert.equal(r.reservation, undefined);
    assert.match(r.reply, /ordonnance/i);
  });

  test("la réservation est visible dans le suivi public", async () => {
    const tel = nouveauNumero();
    await envoyer("sels de réhydratation", tel);
    const c = await envoyer("oui", tel);
    const suivi = await (await fetch(`${BASE}/api/public/reservations/${c.reservation.reference}`)).json();
    assert.equal(suivi.statut, "ACTIVE");
  });
});

/* ─────────────── Informations pratiques ─────────────── */

describe("Informations pratiques", () => {
  test("horaires", async () => {
    const r = await envoyer("Quels sont vos horaires ?", nouveauNumero());
    assert.equal(r.intention, "horaires");
    assert.match(r.reply, /Lundi|horaires/i);
  });

  test("adresse avec lien d'itinéraire", async () => {
    const r = await envoyer("Où êtes-vous situés ?", nouveauNumero());
    assert.equal(r.intention, "adresse");
    assert.match(r.reply, /maps\.google\.com/);
  });

  test("salutation seule : message d'accueil", async () => {
    const r = await envoyer("Bonjour", nouveauNumero());
    assert.equal(r.intention, "salutation");
    assert.match(r.reply, /Bienvenue|Bonjour/i);
    assert.equal(r.handoff, false);
  });

  test("suivi d'une réservation par sa référence", async () => {
    const tel = nouveauNumero();
    await envoyer("sels de réhydratation", tel);
    const c = await envoyer("oui", tel);
    const r = await envoyer(`Où en est ma réservation ${c.reservation.reference} ?`, nouveauNumero());
    assert.match(r.reply, new RegExp(c.reservation.reference));
  });

  test("référence inconnue : réponse claire", async () => {
    const r = await envoyer("ma reservation R-ZZZZ0000", nouveauNumero());
    assert.match(r.reply, /Aucune réservation|Vérifiez/i);
  });
});

/* ─────────────── Robustesse ─────────────── */

describe("Robustesse du webhook", () => {
  test("persiste les messages entrants et sortants", async () => {
    const tel = nouveauNumero();
    await envoyer("Bonjour", tel);
    const n = Number(sql(`
      SELECT COUNT(*) FROM "WhatsappMessage" m
      JOIN "WhatsappConversation" c ON c.id = m."conversationId" WHERE c.phone='${tel}'`));
    assert.ok(n >= 2, "le message reçu et la réponse doivent être conservés");
  });

  test("réutilise la conversation existante", async () => {
    const tel = nouveauNumero();
    await envoyer("Bonjour", tel);
    await envoyer("paracétamol", tel);
    assert.equal(sql(`SELECT COUNT(*) FROM "WhatsappConversation" WHERE phone='${tel}'`), "1");
  });

  test("un rejeu du même message ne crée pas de doublon", async () => {
    const tel = nouveauNumero();
    const idMessage = `rejeu-${Date.now()}`;
    const corps = JSON.stringify({ message: { text: "Bonjour", from: tel, id: idMessage } });

    await poster(corps);
    const seconde = await (await poster(corps)).json();
    assert.equal(seconde.resultats[0].statut, "doublon", "Meta rejoue les webhooks non acquittés");
  });

  test("une requête non signée est rejetée en production", async () => {
    const r = await fetch(`${BASE}/api/whatsapp/webhook`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: { text: "Bonjour", from: "+22997000099", id: "nonsigne" } }),
    });
    if (SECRET) {
      assert.equal(r.status, 401, "sans signature valide, le webhook doit refuser");
    } else {
      assert.equal(r.status, 200);   // pas de secret configuré : mode ouvert
    }
  });

  test("une charge illisible renvoie 200 (sinon Meta rejoue en boucle)", async () => {
    const r = await poster("{ ceci n'est pas du json");
    assert.equal(r.status, 200);
  });

  test("un message non textuel est ignoré sans erreur", async () => {
    const r = await poster(JSON.stringify({ entry: [{ changes: [{ value: { messages: [{ type: "image", from: "+229970000" }] } }] }] }));
    assert.equal(r.status, 200);
    assert.equal((await r.json()).traites, 0);
  });

  test("comprend le format officiel de Meta", async () => {
    const tel = nouveauNumero();
    const r = await poster(JSON.stringify({
      object: "whatsapp_business_account",
      entry: [{
        changes: [{
          value: {
            metadata: { phone_number_id: "123456" },
            messages: [{ type: "text", from: tel, id: `meta-${Date.now()}`, text: { body: "paracétamol" } }],
          },
        }],
      }],
    }));
    const d = await r.json();
    assert.equal(d.traites, 1);
    assert.match(d.resultats[0].reply, /disponible|trouve pas/i);
  });
});
