/**
 * Tests d'intégration : API réelle, base réelle.
 *
 * Ils protègent les invariants métier qu'aucun test unitaire ne peut couvrir :
 * transactions, décrément FEFO, cloisonnement multi-officines, idempotence.
 *
 * Prérequis : serveur démarré (BASE_URL) et base amorcée (npm run db:seed).
 */
import { test, describe, before } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const PG = process.env.DATABASE_URL ?? "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow";

const sql = (q) =>
  execFileSync("psql", [PG, "-tAc", q.replace(/\s+/g, " ").trim()], { encoding: "utf8" }).trim();

let cookieOwner = "";
let cookieCaissier = "";
let produit;

async function connexion(email, motDePasse = "demo1234") {
  const r = await fetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password: motDePasse }),
  });
  if (!r.ok) throw new Error(`connexion ${email} : HTTP ${r.status}`);
  return r.headers.get("set-cookie").split(";")[0];
}

const appel = (chemin, { cookie, methode = "GET", corps } = {}) =>
  fetch(`${BASE}${chemin}`, {
    method: methode,
    headers: { "Content-Type": "application/json", ...(cookie ? { cookie } : {}) },
    ...(corps ? { body: JSON.stringify(corps) } : {}),
  });

before(async () => {
  cookieOwner = await connexion("demo@pharmaflow.ai");
  // Le seed donne le même mot de passe à toute l'équipe.
  cookieCaissier = await connexion("ismael.koudjo@pharmaflow.ai");

  const ligne = sql(`
    SELECT p.id || '|' || p."salePrice" || '|' || COALESCE(SUM(b.quantity), 0)
    FROM "Product" p JOIN "ProductBatch" b ON b."productId" = p.id
    WHERE p."isActive" = true
      AND p."pharmacyId" = (SELECT m."pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id = m."userId" WHERE u.email = 'demo@pharmaflow.ai' LIMIT 1)
    GROUP BY p.id, p."salePrice"
    HAVING COALESCE(SUM(b.quantity), 0) > 50 ORDER BY SUM(b.quantity) DESC LIMIT 1`);
  const [id, prix, stock] = ligne.split("|");
  produit = { id, prix: Number(prix), stock: Number(stock) };
});

/* ─────────────────── Authentification ─────────────────── */

describe("Authentification", () => {
  test("connexion valide", async () => {
    const r = await appel("/api/auth/login", {
      methode: "POST", corps: { email: "demo@pharmaflow.ai", password: "demo1234" },
    });
    assert.equal(r.status, 200);
    assert.match(r.headers.get("set-cookie"), /pf_session=/);
    assert.match(r.headers.get("set-cookie"), /HttpOnly/i, "le cookie doit être inaccessible au JS");
  });

  test("mot de passe erroné", async () => {
    const r = await appel("/api/auth/login", {
      methode: "POST", corps: { email: "demo@pharmaflow.ai", password: "faux" },
    });
    assert.equal(r.status, 401);
  });

  test("le message ne révèle pas l'existence du compte", async () => {
    const inconnu = await (await appel("/api/auth/login", {
      methode: "POST", corps: { email: `absent-${Date.now()}@x.bj`, password: "x" },
    })).json();
    const connu = await (await appel("/api/auth/login", {
      methode: "POST", corps: { email: "demo@pharmaflow.ai", password: "faux" },
    })).json();
    assert.equal(inconnu.error, connu.error, "les deux messages doivent être identiques");
  });

  test("corps invalide rejeté", async () => {
    const r = await appel("/api/auth/login", { methode: "POST", corps: { email: 42 } });
    assert.equal(r.status, 422);
  });
});

/* ─────────────────── Protection des routes ─────────────────── */

describe("Protection des routes", () => {
  const protegees = [
    ["/api/products", "GET"], ["/api/patients", "GET"], ["/api/expenses", "GET"],
    ["/api/sales", "POST"], ["/api/stock/receive", "POST"], ["/api/stock/adjust", "POST"],
    ["/api/prescriptions", "POST"], ["/api/purchase-orders", "POST"], ["/api/stock/export", "GET"],
  ];

  for (const [chemin, methode] of protegees) {
    test(`${methode} ${chemin} sans session → 401/403`, async () => {
      const r = await appel(chemin, { methode, corps: methode === "POST" ? {} : undefined });
      assert.ok([401, 403].includes(r.status), `attendu 401/403, reçu ${r.status}`);
    });
  }

  test("/dashboard redirige vers la connexion", async () => {
    const r = await fetch(`${BASE}/dashboard`, { redirect: "manual" });
    assert.equal(r.status, 307);
    assert.match(r.headers.get("location"), /connexion/);
  });

  test("/api/health reste public", async () => {
    const r = await appel("/api/health");
    assert.ok([200, 503].includes(r.status));
    const d = await r.json();
    assert.equal(JSON.stringify(d).includes("password"), false, "aucun secret exposé");
  });
});

/* ─────────────────── Permissions ─────────────────── */

describe("Permissions par rôle", () => {
  test("le caissier peut encaisser", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieCaissier, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 1 }], offlineUuid: crypto.randomUUID() },
    });
    assert.equal(r.status, 201);
  });

  test("le caissier ne peut pas créer de produit", async () => {
    const r = await appel("/api/products", {
      cookie: cookieCaissier, methode: "POST",
      corps: { name: "Interdit", purchasePrice: 1, salePrice: 2 },
    });
    assert.equal(r.status, 403);
  });

  test("le caissier ne voit pas la comptabilité", async () => {
    assert.equal((await appel("/api/expenses", { cookie: cookieCaissier })).status, 403);
  });

  test("le titulaire accède à tout", async () => {
    assert.equal((await appel("/api/expenses", { cookie: cookieOwner })).status, 200);
    assert.equal((await appel("/api/products", { cookie: cookieOwner })).status, 200);
  });
});

/* ─────────────────── Ventes : le cœur métier ─────────────────── */

describe("Enregistrement des ventes", () => {
  test("décrémente le stock du montant exact", async () => {
    const avant = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 3 }], method: "CASH", offlineUuid: crypto.randomUUID() },
    });
    assert.equal(r.status, 201);
    const apres = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    assert.equal(apres, avant - 3);
  });

  test("applique la remise sur le total", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: {
        items: [{ productId: produit.id, quantity: 2 }],
        discountPercent: 10, method: "MTN_MOMO", offlineUuid: crypto.randomUUID(),
      },
    });
    const { sale } = await r.json();
    assert.equal(sale.subtotal, produit.prix * 2);
    assert.equal(sale.discount, Math.round(produit.prix * 2 * 0.1));
    assert.equal(sale.total, sale.subtotal - sale.discount);
  });

  test("plafonne une remise abusive à 50 %", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 1 }], discountPercent: 500, offlineUuid: crypto.randomUUID() },
    });
    const { sale } = await r.json();
    assert.ok(sale.total >= sale.subtotal * 0.5, "une remise de 500 % viderait la caisse");
  });

  test("refuse une vente dépassant le stock", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 9_999_999 }], offlineUuid: crypto.randomUUID() },
    });
    assert.equal(r.status, 409);
    assert.match((await r.json()).error, /Stock insuffisant/);
  });

  test("un refus ne laisse aucune trace en base (transaction)", async () => {
    const ventesAvant = Number(sql(`SELECT COUNT(*) FROM "Sale"`));
    const stockAvant = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: {
        items: [{ productId: produit.id, quantity: 1 }, { productId: produit.id, quantity: 9_999_999 }],
        offlineUuid: crypto.randomUUID(),
      },
    });
    assert.equal(Number(sql(`SELECT COUNT(*) FROM "Sale"`)), ventesAvant, "aucune vente partielle");
    assert.equal(Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`)), stockAvant,
      "le stock ne doit pas bouger si la transaction échoue");
  });

  test("panier vide rejeté", async () => {
    const r = await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps: { items: [] } });
    assert.equal(r.status, 422);
  });

  test("produit inexistant rejeté", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: "inexistant", quantity: 1 }], offlineUuid: crypto.randomUUID() },
    });
    assert.equal(r.status, 404);
  });

  test("un paiement Mobile Money avertit qu'aucun débit n'a lieu", async () => {
    // Sans agrégateur configuré, la plateforme n'encaisse rien : le caissier
    // doit vérifier son téléphone marchand avant de laisser partir le client.
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 1 }], method: "MTN_MOMO", offlineUuid: crypto.randomUUID() },
    });
    const d = await r.json();
    assert.equal(d.encaissementNonAutomatique, true);
    assert.match(d.avertissement, /NON débité/);
  });

  test("un paiement en espèces n'affiche aucun avertissement", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 1 }], method: "CASH", offlineUuid: crypto.randomUUID() },
    });
    const d = await r.json();
    assert.ok(!d.encaissementNonAutomatique, "les espèces sont encaissées par le caissier lui-même");
  });

  test("chaque vente génère un paiement et des mouvements", async () => {
    const r = await appel("/api/sales", {
      cookie: cookieOwner, methode: "POST",
      corps: { items: [{ productId: produit.id, quantity: 1 }], method: "WAVE", offlineUuid: crypto.randomUUID() },
    });
    const { sale } = await r.json();
    assert.equal(Number(sql(`SELECT COUNT(*) FROM "Payment" WHERE "saleId"='${sale.id}'`)), 1);
    assert.ok(Number(sql(`SELECT COUNT(*) FROM "StockMovement" WHERE reference='${sale.reference}'`)) >= 1);
  });
});

/* ─────────────────── Idempotence hors ligne ─────────────────── */

describe("Idempotence de la synchronisation", () => {
  test("le même offlineUuid ne crée qu'une seule vente", async () => {
    const uuid = crypto.randomUUID();
    const corps = { items: [{ productId: produit.id, quantity: 1 }], offlineUuid: uuid };
    const ventesAvant = Number(sql(`SELECT COUNT(*) FROM "Sale"`));

    const r1 = await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps });
    const r2 = await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps });
    const r3 = await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps });

    assert.equal(r1.status, 201);
    assert.equal((await r2.json()).duplicate, true);
    assert.equal((await r3.json()).duplicate, true);
    assert.equal(Number(sql(`SELECT COUNT(*) FROM "Sale"`)), ventesAvant + 1);
  });

  test("un rejeu ne décrémente pas le stock une seconde fois", async () => {
    const uuid = crypto.randomUUID();
    const corps = { items: [{ productId: produit.id, quantity: 2 }], offlineUuid: uuid };
    const avant = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps });
    await appel("/api/sales", { cookie: cookieOwner, methode: "POST", corps });
    assert.equal(Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`)), avant - 2);
  });

  test("/api/sync est idempotent sur les doublons de la file", async () => {
    const uuid = crypto.randomUUID();
    const r = await appel("/api/sync", {
      cookie: cookieOwner, methode: "POST",
      corps: { operations: [{ offlineUuid: uuid }, { offlineUuid: uuid }, {}] },
    });
    const d = await r.json();
    assert.equal(d.applied, 1);
    assert.ok(d.results.some((x) => x.status === "duplicate"));
    assert.ok(d.results.some((x) => x.status === "rejected"), "une opération sans UUID est refusée");
  });
});

/* ─────────────────── Cloisonnement multi-officines ─────────────────── */

describe("Cloisonnement entre officines", () => {
  test("impossible de lire un patient d'une autre pharmacie", async () => {
    const autre = sql(`
      SELECT p.id FROM "Patient" p
      WHERE p."pharmacyId" <> (SELECT "pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id = m."userId" WHERE u.email = 'demo@pharmaflow.ai' LIMIT 1)
      LIMIT 1`);
    if (!autre) return; // aucune seconde officine en base
    const r = await appel(`/api/patients/${autre}`, { cookie: cookieOwner });
    assert.equal(r.status, 404);
  });

  test("la liste des produits ne contient que ceux de l'officine", async () => {
    const { data } = await (await appel("/api/products", { cookie: cookieOwner })).json();
    const attendu = Number(sql(`
      SELECT COUNT(*) FROM "Product"
      WHERE "isActive" = true AND "pharmacyId" = (SELECT "pharmacyId" FROM "PharmacyMember" m
        JOIN "User" u ON u.id = m."userId" WHERE u.email = 'demo@pharmaflow.ai' LIMIT 1)`));
    assert.equal(data.length, attendu);
  });
});

/* ─────────────────── Stock ─────────────────── */

describe("Mouvements de stock", () => {
  test("une réception incrémente et trace", async () => {
    const avant = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    const r = await appel("/api/stock/receive", {
      cookie: cookieOwner, methode: "POST",
      corps: { productId: produit.id, quantity: 25, batchNo: `TEST-${Date.now()}`, expiryDate: "2028-12-31" },
    });
    assert.equal(r.status, 200);
    assert.equal((await r.json()).stock, avant + 25);
  });

  test("un lot déjà périmé est refusé", async () => {
    const r = await appel("/api/stock/receive", {
      cookie: cookieOwner, methode: "POST",
      corps: { productId: produit.id, quantity: 10, batchNo: "OLD", expiryDate: "2020-01-01" },
    });
    assert.equal(r.status, 422);
  });

  test("un ajustement exige un motif", async () => {
    const r = await appel("/api/stock/adjust", {
      cookie: cookieOwner, methode: "POST", corps: { productId: produit.id, delta: -1 },
    });
    assert.equal(r.status, 422);
    assert.match((await r.json()).error, /Motif/);
  });

  test("un ajustement négatif décrémente", async () => {
    const avant = Number(sql(`SELECT SUM(quantity) FROM "ProductBatch" WHERE "productId"='${produit.id}'`));
    const r = await appel("/api/stock/adjust", {
      cookie: cookieOwner, methode: "POST",
      corps: { productId: produit.id, delta: -2, reason: "Casse au comptoir", type: "LOSS" },
    });
    assert.equal((await r.json()).stock, avant - 2);
  });

  test("un écart nul est refusé", async () => {
    const r = await appel("/api/stock/adjust", {
      cookie: cookieOwner, methode: "POST", corps: { productId: produit.id, delta: 0, reason: "rien" },
    });
    assert.equal(r.status, 422);
  });

  test("prix de vente inférieur au prix d'achat refusé", async () => {
    const r = await appel("/api/products", {
      cookie: cookieOwner, methode: "POST",
      corps: { name: `Test ${Date.now()}`, purchasePrice: 5000, salePrice: 1000 },
    });
    assert.equal(r.status, 422);
  });
});

/* ─────────────────── Patients ─────────────────── */

describe("Données patients", () => {
  test("le téléphone est chiffré en base et masqué en liste", async () => {
    const nom = `Test Chiffrement ${Date.now()}`;
    const creation = await appel("/api/patients", {
      cookie: cookieOwner, methode: "POST",
      corps: { fullName: nom, phone: "+229 91 88 77 66", city: "Cotonou", consent: true },
    });
    assert.equal(creation.status, 200);
    const { patient } = await creation.json();

    const brut = sql(`SELECT "phoneEnc" FROM "Patient" WHERE id='${patient.id}'`);
    assert.match(brut, /^v1:/, "le numéro doit être chiffré");
    assert.equal(brut.includes("91"), false);

    const { data } = await (await appel(`/api/patients?q=${encodeURIComponent(nom)}`, { cookie: cookieOwner })).json();
    assert.ok(data[0].telephone.includes("••"), "masqué en liste");

    const fiche = await (await appel(`/api/patients/${patient.id}`, { cookie: cookieOwner })).json();
    assert.equal(fiche.patient.telephone, "+229 91 88 77 66", "déchiffré à l'ouverture");
  });

  test("l'ouverture d'une fiche est journalisée", async () => {
    const id = sql(`SELECT id FROM "Patient" LIMIT 1`);
    const avant = Number(sql(`SELECT COUNT(*) FROM "AuditLog" WHERE action='PATIENT_VIEW' AND "entityId"='${id}'`));
    await appel(`/api/patients/${id}`, { cookie: cookieOwner });
    assert.equal(Number(sql(`SELECT COUNT(*) FROM "AuditLog" WHERE action='PATIENT_VIEW' AND "entityId"='${id}'`)), avant + 1);
  });

  test("nom trop court refusé", async () => {
    const r = await appel("/api/patients", { cookie: cookieOwner, methode: "POST", corps: { fullName: "X" } });
    assert.equal(r.status, 422);
  });
});

/* ─────────────────── Ordonnances ─────────────────── */

describe("Ordonnances", () => {
  test("une allergie déclarée déclenche une alerte sans bloquer", async () => {
    const nom = `Allergique ${Date.now()}`;
    const { patient } = await (await appel("/api/patients", {
      cookie: cookieOwner, methode: "POST",
      corps: { fullName: nom, allergies: "Paracétamol", consent: true },
    })).json();

    const r = await appel("/api/prescriptions", {
      cookie: cookieOwner, methode: "POST",
      corps: { patientId: patient.id, prescriber: "Dr Test", items: [{ label: "Paracétamol 1 g", quantity: 1 }] },
    });
    const d = await r.json();
    assert.equal(r.status, 200);
    assert.ok(d.prescription.id, "l'ordonnance est enregistrée : le pharmacien décide");
    assert.ok(d.alertes.length >= 1);
    assert.match(d.alertes[0], /allergie/i);
  });

  test("ordonnance sans ligne refusée", async () => {
    const id = sql(`SELECT id FROM "Patient" LIMIT 1`);
    const r = await appel("/api/prescriptions", {
      cookie: cookieOwner, methode: "POST", corps: { patientId: id, items: [] },
    });
    assert.equal(r.status, 422);
  });
});

/* ─────────────────── Intégrité globale ─────────────────── */

describe("Intégrité de la base", () => {
  test("aucune ligne de vente orpheline", () => {
    assert.equal(sql(`SELECT COUNT(*) FROM "SaleItem" si LEFT JOIN "Sale" s ON s.id=si."saleId" WHERE s.id IS NULL`), "0");
  });

  test("chaque vente a un paiement", () => {
    assert.equal(sql(`SELECT COUNT(*) FROM "Sale" s LEFT JOIN "Payment" p ON p."saleId"=s.id WHERE p.id IS NULL`), "0");
  });

  test("aucun stock négatif", () => {
    assert.equal(sql(`SELECT COUNT(*) FROM "ProductBatch" WHERE quantity < 0`), "0");
  });

  test("aucune vente à total négatif", () => {
    assert.equal(sql(`SELECT COUNT(*) FROM "Sale" WHERE total < 0`), "0");
  });

  test("le total de chaque vente correspond à ses lignes", () => {
    const incoherentes = sql(`
      SELECT COUNT(*) FROM (
        SELECT s.id FROM "Sale" s JOIN "SaleItem" si ON si."saleId" = s.id
        GROUP BY s.id, s.subtotal HAVING SUM(si."lineTotal") <> s.subtotal
      ) x`);
    assert.equal(incoherentes, "0");
  });
});
