/**
 * Tests du parseur de catalogue.
 *
 * C'est le point d'entrée le plus exposé aux données réelles : chaque officine
 * exporte son stock différemment. Un bug ici corrompt silencieusement un
 * catalogue entier, d'où la couverture serrée des formats francophones.
 */
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { parseCatalogCsv, templateCsv } from "../helpers/load.mjs";

const enTete = "Nom;DCI;Code-barres;Categorie;Prix achat;Prix vente;Seuil;Quantite;Lot;Peremption;Fournisseur";
const csv = (...lignes) => [enTete, ...lignes].join("\r\n");

describe("parseCatalogCsv — séparateurs et encodage", () => {
  test("accepte le point-virgule (export Excel francophone)", () => {
    const r = parseCatalogCsv(csv("Doliprane;Paracétamol;;Antalgique;350;600;50;100;L1;31/12/2027;UBIPHARM"));
    assert.equal(r.rows.length, 1);
    assert.equal(r.rows[0].name, "Doliprane");
  });

  test("accepte la virgule (export anglophone)", () => {
    const r = parseCatalogCsv("Nom,Prix achat,Prix vente\nDoliprane,350,600");
    assert.equal(r.rows.length, 1);
    assert.equal(r.rows[0].purchasePrice, 350);
  });

  test("accepte la tabulation (copier-coller depuis un tableur)", () => {
    const r = parseCatalogCsv("Nom\tPrix achat\tPrix vente\nDoliprane\t350\t600");
    assert.equal(r.rows.length, 1);
  });

  test("retire le BOM UTF-8 ajouté par Excel", () => {
    const r = parseCatalogCsv("\uFEFFNom;Prix achat;Prix vente\r\nDoliprane;350;600");
    assert.equal(r.rows[0].name, "Doliprane");
  });

  test("tolère les fins de ligne Unix comme Windows", () => {
    const unix = parseCatalogCsv("Nom;Prix achat;Prix vente\nA;1;2\nB;3;4");
    assert.equal(unix.rows.length, 2);
  });
});

describe("parseCatalogCsv — reconnaissance des en-têtes", () => {
  const synonymes = [
    ["Désignation", "name"], ["Produit", "name"], ["Libellé", "name"], ["Article", "name"],
    ["Molécule (DCI)", "dci"], ["Principe actif", "dci"],
    ["Code barre", "barcode"], ["EAN", "barcode"], ["Gencod", "barcode"],
    ["Prix d'achat", "purchasePrice"], ["PA", "purchasePrice"], ["Coût", "purchasePrice"],
    ["Prix de vente", "salePrice"], ["PPV", "salePrice"], ["Prix public", "salePrice"],
    ["Qté", "quantity"], ["Stock actuel", "quantity"],
    ["Stock mini", "alertThreshold"], ["Seuil alerte", "alertThreshold"],
    ["Date péremption", "expiryDate"], ["Expiration", "expiryDate"],
    ["Grossiste", "supplierName"], ["Laboratoire", "supplierName"],
  ];

  for (const [libelle, champ] of synonymes) {
    test(`« ${libelle} » → ${champ}`, () => {
      const r = parseCatalogCsv(`Nom;Prix achat;Prix vente;${libelle}\nX;1;2;valeur`);
      assert.ok(r.colonnesReconnues.includes(champ), `${libelle} non reconnu`);
    });
  }

  test("insensible aux accents, à la casse et à la ponctuation", () => {
    const r = parseCatalogCsv("NOM;PRIX D'ACHAT;prix_de_vente\nX;1;2");
    assert.equal(r.colonnesManquantes.length, 0);
  });

  test("signale les colonnes obligatoires absentes", () => {
    const r = parseCatalogCsv("Nom;Couleur\nX;bleu");
    assert.deepEqual(r.colonnesManquantes, ["purchasePrice", "salePrice"]);
    assert.equal(r.rows.length, 0);
    assert.match(r.issues[0].message, /introuvables/);
  });
});

describe("parseCatalogCsv — montants", () => {
  const cas = [
    ["350", 350, "entier simple"],
    ["2 450", 2450, "espace comme séparateur de milliers"],
    ["2 450,00", 2450, "virgule décimale française"],
    ["1.234,56", 1235, "format français complet (arrondi)"],
    ["1,234.56", 1235, "format anglophone (arrondi)"],
    ["2500 FCFA", 2500, "devise accolée"],
    ["  700  ", 700, "espaces superflus"],
  ];

  for (const [brut, attendu, libelle] of cas) {
    test(`${libelle} : « ${brut} » → ${attendu}`, () => {
      const r = parseCatalogCsv(`Nom;Prix achat;Prix vente\nX;${brut};99999`);
      assert.equal(r.rows[0].purchasePrice, attendu);
    });
  }

  test("rejette un montant illisible et ignore la ligne", () => {
    const r = parseCatalogCsv(csv("X;;;;abc;600;;;;;"));
    assert.equal(r.rows.length, 0);
    assert.match(r.issues[0].message, /illisible/);
  });

  test("signale une marge négative sans bloquer l'import", () => {
    const r = parseCatalogCsv(csv("X;;;;5000;1200;;;;;"));
    assert.equal(r.rows.length, 1, "la ligne reste importable");
    assert.ok(r.issues.some(i => /inférieur au prix d'achat/.test(i.message)));
  });
});

describe("parseCatalogCsv — dates de péremption", () => {
  const cas = [
    ["31/12/2027", "2027-12-31", "JJ/MM/AAAA"],
    ["2027-12-31", "2027-12-31", "ISO"],
    ["31-12-2027", "2027-12-31", "tirets"],
    ["09/2027", "2027-09-30", "MM/AAAA → fin de mois"],
    ["02/2028", "2028-02-29", "février bissextile"],
    ["01/03/27", "2027-03-01", "année sur 2 chiffres"],
  ];

  for (const [brut, attendu, libelle] of cas) {
    test(`${libelle} : « ${brut} » → ${attendu}`, () => {
      const r = parseCatalogCsv(csv(`X;;;;100;200;;10;L1;${brut};`));
      assert.equal(r.rows[0].expiryDate, attendu);
    });
  }

  test("rejette une date impossible (32/13)", () => {
    const r = parseCatalogCsv(csv("X;;;;100;200;;10;L1;32/13/2027;"));
    assert.equal(r.rows[0].expiryDate, null);
  });

  test("un lot périmé est signalé et son stock mis à zéro", () => {
    const r = parseCatalogCsv(csv("X;;;;100;200;;40;L1;01/01/2020;"));
    assert.equal(r.rows[0].quantity, 0, "le stock périmé ne doit pas entrer");
    assert.ok(r.issues.some(i => /périmé/.test(i.message)));
  });

  test("une quantité sans date valide n'entre pas en stock", () => {
    const r = parseCatalogCsv(csv("X;;;;100;200;;40;L1;;"));
    assert.equal(r.rows[0].quantity, 0);
    assert.ok(r.issues.some(i => /sans date de péremption/.test(i.message)));
  });
});

describe("parseCatalogCsv — robustesse", () => {
  test("gère les guillemets et les séparateurs à l'intérieur", () => {
    const r = parseCatalogCsv('Nom;Prix achat;Prix vente\n"Efferalgan 1 g, effervescent";900;1500');
    assert.equal(r.rows[0].name, "Efferalgan 1 g, effervescent");
  });

  test("gère les guillemets échappés", () => {
    const r = parseCatalogCsv('Nom;Prix achat;Prix vente\n"Sirop ""Toux"" 200ml";900;1500');
    assert.equal(r.rows[0].name, 'Sirop "Toux" 200ml');
  });

  test("détecte les doublons par code-barres", () => {
    const r = parseCatalogCsv(csv(
      "Doliprane;;600123;;350;600;;;;;",
      "Doliprane bis;;600123;;350;600;;;;;",
    ));
    assert.equal(r.rows.length, 1, "seule la première occurrence est retenue");
    assert.ok(r.issues.some(i => i.champ === "doublon"));
  });

  test("détecte les doublons par nom quand le code-barres manque", () => {
    const r = parseCatalogCsv(csv("Doliprane;;;;350;600;;;;;", "Doliprane;;;;350;600;;;;;"));
    assert.equal(r.rows.length, 1);
  });

  test("ignore une ligne sans nom de produit", () => {
    const r = parseCatalogCsv(csv(";;;;350;600;;;;;"));
    assert.equal(r.rows.length, 0);
    assert.match(r.issues[0].message, /Nom du produit manquant/);
  });

  test("ignore les lignes vides", () => {
    const r = parseCatalogCsv("Nom;Prix achat;Prix vente\nA;1;2\n\n\nB;3;4");
    assert.equal(r.rows.length, 2);
  });

  test("gère un fichier vide", () => {
    const r = parseCatalogCsv("");
    assert.equal(r.rows.length, 0);
    assert.match(r.issues[0].message, /vide/);
  });

  test("tronque au-delà de 5 000 lignes", () => {
    const lignes = Array.from({ length: 5200 }, (_, i) => `Produit ${i};;;;100;200;;;;;`);
    const r = parseCatalogCsv(csv(...lignes));
    assert.equal(r.rows.length, 5000);
    assert.ok(r.issues.some(i => /tronqué/.test(i.message)));
  });

  test("les numéros de ligne signalés correspondent au fichier", () => {
    // ligne 1 = en-tête, donc la 2e donnée est la ligne 3
    const r = parseCatalogCsv(csv("Bon;;;;100;200;;;;;", ";;;;100;200;;;;;"));
    assert.equal(r.issues[0].ligne, 3);
  });

  test("seuil d'alerte par défaut à 10", () => {
    const r = parseCatalogCsv("Nom;Prix achat;Prix vente\nX;100;200");
    assert.equal(r.rows[0].alertThreshold, 10);
  });
});

describe("templateCsv", () => {
  test("le modèle fourni est relisible par le parseur", () => {
    const r = parseCatalogCsv(templateCsv());
    assert.equal(r.rows.length, 3);
    assert.equal(r.colonnesManquantes.length, 0);
    assert.equal(r.issues.length, 0, "le modèle ne doit produire aucune anomalie");
  });

  test("le modèle commence par un BOM (ouverture correcte dans Excel)", () => {
    assert.ok(templateCsv().startsWith("\uFEFF"));
  });
});
