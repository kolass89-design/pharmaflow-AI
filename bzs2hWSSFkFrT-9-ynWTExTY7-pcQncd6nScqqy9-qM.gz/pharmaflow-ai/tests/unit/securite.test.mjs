/**
 * Tests de sécurité : contrôle d'accès, chiffrement, sessions, masquage.
 *
 * Ces tests protègent les invariants qui, s'ils cassent, exposent des données
 * de santé. Ils doivent échouer bruyamment à la moindre régression.
 */
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import {
  can, PERMISSIONS, hashPassword, verifyPassword, encodeSession, decodeSession,
  encrypt, decrypt, maskPhone, needsRewrap, scrub, fcfa,
} from "../helpers/load.mjs";

/* ─────────────────── RBAC ─────────────────── */

describe("Contrôle d'accès par rôle", () => {
  test("le titulaire a tous les droits", () => {
    for (const p of ["pos.sell", "stock.write", "patients.read", "accounting.write", "users.manage"]) {
      assert.ok(can("OWNER", p), `OWNER devrait pouvoir ${p}`);
    }
  });

  test("le caissier encaisse mais ne modifie pas le catalogue", () => {
    assert.ok(can("CASHIER", "pos.sell"));
    assert.ok(can("CASHIER", "pos.close"));
    assert.ok(can("CASHIER", "stock.read"));
    assert.equal(can("CASHIER", "stock.write"), false);
    assert.equal(can("CASHIER", "accounting.read"), false);
    assert.equal(can("CASHIER", "users.manage"), false);
  });

  test("le comptable ne touche jamais aux dossiers patients", () => {
    assert.ok(can("ACCOUNTANT", "accounting.read"));
    assert.equal(can("ACCOUNTANT", "patients.read"), false,
      "un comptable n'a aucune raison d'accéder aux données de santé");
    assert.equal(can("ACCOUNTANT", "prescriptions.read"), false);
    assert.equal(can("ACCOUNTANT", "pos.sell"), false);
  });

  test("le préparateur consulte les patients sans les modifier", () => {
    assert.ok(can("TECHNICIAN", "patients.read"));
    assert.equal(can("TECHNICIAN", "patients.write"), false);
    assert.equal(can("TECHNICIAN", "stock.write"), false);
  });

  test("le pharmacien couvre l'exercice officinal sans l'administration", () => {
    for (const p of ["pos.sell", "stock.write", "prescriptions.write", "patients.write", "whatsapp.write"]) {
      assert.ok(can("PHARMACIST", p), `PHARMACIST devrait pouvoir ${p}`);
    }
    assert.equal(can("PHARMACIST", "users.manage"), false);
  });

  test("les jokers ne débordent pas sur un préfixe voisin", () => {
    // "pos.*" ne doit pas autoriser "postal.envoi"
    assert.equal(can("CASHIER", "postal.envoi"), false);
    assert.equal(can("PHARMACIST", "stockage.supprimer"), false);
  });

  test("une permission inconnue est toujours refusée (sauf OWNER)", () => {
    for (const r of ["PHARMACIST", "TECHNICIAN", "CASHIER", "ACCOUNTANT"]) {
      assert.equal(can(r, "permission.inexistante"), false);
    }
  });

  test("tous les rôles déclarés ont une matrice", () => {
    for (const r of ["OWNER", "PHARMACIST", "TECHNICIAN", "CASHIER", "ACCOUNTANT"]) {
      assert.ok(Array.isArray(PERMISSIONS[r]), `matrice absente pour ${r}`);
    }
  });
});

/* ─────────────────── Mots de passe ─────────────────── */

describe("Hachage des mots de passe", () => {
  test("le mot de passe n'apparaît jamais dans le hachage", () => {
    const h = hashPassword("MonMotDePasse2026!");
    assert.equal(h.includes("MonMotDePasse2026!"), false);
    assert.match(h, /^scrypt\$[0-9a-f]{32}\$[0-9a-f]{128}$/);
  });

  test("deux hachages du même mot de passe diffèrent (sel unique)", () => {
    assert.notEqual(hashPassword("identique"), hashPassword("identique"));
  });

  test("vérification correcte", () => {
    const h = hashPassword("bon-mot-de-passe");
    assert.ok(verifyPassword("bon-mot-de-passe", h));
    assert.equal(verifyPassword("mauvais", h), false);
  });

  test("un caractère de différence suffit à échouer", () => {
    const h = hashPassword("motdepasse");
    assert.equal(verifyPassword("motdepassE", h), false);
  });

  test("gère les caractères accentués et emoji", () => {
    const pw = "Sénégal2026🇸🇳";
    assert.ok(verifyPassword(pw, hashPassword(pw)));
  });
});

/* ─────────────────── Sessions ─────────────────── */

describe("Sessions signées", () => {
  const session = { userId: "u1", email: "a@b.bj", role: "OWNER", pharmacyId: "ph1", name: "Dr X" };

  test("aller-retour fidèle", () => {
    assert.deepEqual(decodeSession(encodeSession(session)), session);
  });

  test("une charge utile modifiée est rejetée", () => {
    const [, sig] = encodeSession(session).split(".");
    const falsifie = Buffer.from(JSON.stringify({ ...session, role: "OWNER", pharmacyId: "AUTRE" })).toString("base64url");
    assert.equal(decodeSession(`${falsifie}.${sig}`), null,
      "changer de pharmacie sans re-signer doit être impossible");
  });

  test("une signature tronquée est rejetée", () => {
    const [body, sig] = encodeSession(session).split(".");
    assert.equal(decodeSession(`${body}.${sig.slice(0, -4)}`), null);
  });

  test("jeton vide, absent ou malformé", () => {
    for (const t of [undefined, "", "sansPoint", "a.b.c.d", "..", "x."]) {
      assert.equal(decodeSession(t), null, `jeton « ${t} » aurait dû être rejeté`);
    }
  });

  test("une élévation de privilège est détectée", () => {
    const cashier = { ...session, role: "CASHIER" };
    const [body] = encodeSession(cashier).split(".");
    const eleve = Buffer.from(JSON.stringify({ ...cashier, role: "OWNER" })).toString("base64url");
    const [, sigOrigine] = encodeSession(cashier).split(".");
    assert.equal(decodeSession(`${eleve}.${sigOrigine}`), null);
    assert.ok(body);
  });
});

/* ─────────────────── Chiffrement patients ─────────────────── */

describe("Chiffrement des données patients", () => {
  const CLE_A = "0".repeat(64);
  const CLE_B = crypto.randomBytes(32).toString("hex");

  const avecCles = (courante, anciennes) => {
    process.env.ENCRYPTION_KEY = courante;
    if (anciennes) process.env.ENCRYPTION_KEY_OLD = anciennes;
    else delete process.env.ENCRYPTION_KEY_OLD;
  };

  test("aller-retour", () => {
    avecCles(CLE_A);
    assert.equal(decrypt(encrypt("+229 97 12 34 56")), "+229 97 12 34 56");
  });

  test("le clair n'apparaît jamais dans le chiffré", () => {
    avecCles(CLE_A);
    const c = encrypt("+229 97 12 34 56");
    assert.equal(c.includes("97"), false);
    assert.match(c, /^v1:/);
  });

  test("deux chiffrements du même clair diffèrent (IV aléatoire)", () => {
    avecCles(CLE_A);
    assert.notEqual(encrypt("identique"), encrypt("identique"));
  });

  test("une donnée altérée est rejetée (authentification GCM)", () => {
    avecCles(CLE_A);
    const c = encrypt("+229 97 12 34 56");
    const p = c.split(":");
    const brut = Buffer.from(p[3], "base64url");
    brut[0] ^= 0xff;
    assert.equal(decrypt(`${p[0]}:${p[1]}:${p[2]}:${brut.toString("base64url")}`), null);
  });

  test("illisible avec une autre clé", () => {
    avecCles(CLE_A);
    const c = encrypt("+229 97 12 34 56");
    avecCles(CLE_B);
    assert.equal(decrypt(c), null);
  });

  test("rotation : l'ancienne clé déclarée rend la donnée lisible", () => {
    avecCles(CLE_A);
    const c = encrypt("+229 97 12 34 56");
    avecCles(CLE_B, CLE_A);
    assert.equal(decrypt(c), "+229 97 12 34 56");
  });

  test("needsRewrap distingue ce qui doit être réécrit", () => {
    avecCles(CLE_A);
    const c = encrypt("test");
    assert.equal(needsRewrap(c), false, "déjà sous la clé courante");
    avecCles(CLE_B, CLE_A);
    assert.equal(needsRewrap(c), true, "chiffré sous l'ancienne clé");
    assert.equal(needsRewrap("+229 en clair"), true, "valeur héritée non chiffrée");
    assert.equal(needsRewrap(null), false);
  });

  test("une clé invalide lève une erreur explicite", () => {
    avecCles("trop-courte");
    assert.throws(() => encrypt("x"), /64 caractères hexadécimaux/);
    avecCles(CLE_A);
  });

  test("valeurs vides gérées sans exception", () => {
    avecCles(CLE_A);
    assert.equal(encrypt(null), null);
    assert.equal(encrypt(""), null);
    assert.equal(decrypt(null), null);
  });
});

describe("Masquage téléphonique", () => {
  test("masque la partie centrale", () => {
    const m = maskPhone("+229 97 12 34 56");
    assert.ok(m.includes("••"));
    assert.equal(m.includes("1234"), false);
    assert.ok(m.endsWith("56"), "les deux derniers chiffres aident à identifier l'appel");
  });

  test("valeurs limites", () => {
    assert.equal(maskPhone(null), "—");
    assert.equal(maskPhone("123"), "••");
  });
});

/* ─────────────────── Supervision ─────────────────── */

describe("Non-fuite via la supervision", () => {
  test("les champs de santé sont masqués", () => {
    const r = scrub({
      patient: { fullName: "Adjovi Sènou", phoneEnc: "v1:x", allergies: "Pénicilline" },
      user: { passwordHash: "scrypt$a$b", email: "a@b.bj" },
      headers: { authorization: "Bearer x", cookie: "pf_session=y" },
      patientId: "pt_1",
    });
    assert.equal(r.patient.fullName, "[masqué]");
    assert.equal(r.patient.phoneEnc, "[masqué]");
    assert.equal(r.patient.allergies, "[masqué]");
    assert.equal(r.user.passwordHash, "[masqué]");
    assert.equal(r.headers.authorization, "[masqué]");
    assert.equal(r.headers.cookie, "[masqué]");
    assert.equal(r.patientId, "[masqué]");
    assert.equal(r.user.email, "a@b.bj", "l'email reste utile au diagnostic");
  });

  test("le masquage est insensible à la casse et aux variantes", () => {
    const r = scrub({ PhoneEnc: "x", USER_PASSWORD: "y", monToken: "z" });
    assert.equal(r.PhoneEnc, "[masqué]");
    assert.equal(r.USER_PASSWORD, "[masqué]");
    assert.equal(r.monToken, "[masqué]");
  });

  test("les tableaux sont tronqués et la profondeur limitée", () => {
    assert.equal(scrub(Array.from({ length: 50 }, (_, i) => i)).length, 20);
    const profond = { a: { b: { c: { d: { e: { f: "trop loin" } } } } } };
    assert.equal(JSON.stringify(scrub(profond)).includes("trop loin"), false);
  });

  test("les valeurs primitives traversent intactes", () => {
    assert.equal(scrub(42), 42);
    assert.equal(scrub("texte"), "texte");
    assert.equal(scrub(null), null);
  });
});

/* ─────────────────── Formatage monétaire ─────────────────── */

describe("Formatage FCFA", () => {
  test("séparateur de milliers et devise", () => {
    assert.match(fcfa(1234567), /1.234.567 FCFA/);
  });

  test("le FCFA n'a pas de décimale", () => {
    assert.equal(fcfa(2500.7).includes(","), false);
  });

  test("zéro et négatif", () => {
    assert.equal(fcfa(0), "0 FCFA");
    assert.ok(fcfa(-500).includes("500"));
  });
});
