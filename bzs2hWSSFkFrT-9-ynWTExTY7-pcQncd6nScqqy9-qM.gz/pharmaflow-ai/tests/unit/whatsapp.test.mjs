/**
 * Détection d'intention de l'agent WhatsApp.
 *
 * Tests unitaires purs : ils tournent sans base ni serveur, donc à chaque
 * sauvegarde. La classification est le point où une régression est la plus
 * dangereuse — un conseil médical mal détecté engage le pharmacien.
 */
import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { detecterIntention, extraireProduit } from "../helpers/load.mjs";

describe("Conseil médical — transfert obligatoire", () => {
  const cas = [
    "Quelle posologie pour l'amoxicilline ?",
    "combien de comprimés par jour",
    "Quelle dose pour un enfant de 5 ans ?",
    "Je suis enceinte, puis-je en prendre ?",
    "Ma femme allaite, est-ce compatible ?",
    "C'est pour un bébé de 3 mois",
    "Quels sont les effets secondaires ?",
    "Y a-t-il des effets indésirables ?",
    "des contre-indications ?",
    "Je suis allergique aux sulfamides",
    "Est-ce dangereux ?",
    "Puis-je prendre ça avec mon anticoagulant ?",
    "interaction avec mon traitement",
    "J'ai mal à la tête depuis 3 jours",
    "je souffre de fièvre",
    "Quels symptômes dois-je surveiller ?",
    "Pouvez-vous renouveler mon traitement ?",
  ];
  for (const m of cas) {
    test(`« ${m.slice(0, 42)} »`, () => {
      assert.equal(detecterIntention(m), "conseil_medical",
        "toute question thérapeutique doit partir au pharmacien");
    });
  }
});

describe("Intentions logistiques", () => {
  const cas = [
    ["Bonjour", "salutation"],
    ["bjr", "salutation"],
    ["Salut !", "salutation"],
    ["Quels sont vos horaires ?", "horaires"],
    ["vous êtes ouvert le dimanche ?", "horaires"],
    ["Quelle est votre adresse ?", "adresse"],
    ["comment venir chez vous", "adresse"],
    ["oui", "confirmation"],
    ["OK d'accord", "confirmation"],
    ["non merci", "annulation"],
    ["annuler", "annulation"],
    ["où en est ma réservation ?", "suivi"],
    ["je veux parler à un pharmacien", "humain"],
    ["paracétamol", "recherche"],
    ["Avez-vous du Doliprane ?", "recherche"],
    ["je cherche de l'ibuprofène", "recherche"],
  ];
  for (const [message, attendu] of cas) {
    test(`« ${message} » → ${attendu}`, () => {
      assert.equal(detecterIntention(message), attendu);
    });
  }
});

describe("Priorité des règles", () => {
  test("le conseil médical prime sur la recherche", () => {
    assert.equal(detecterIntention("Avez-vous du paracétamol ? Quelle dose pour un enfant ?"), "conseil_medical");
  });

  test("une salutation suivie d'une question est une recherche", () => {
    // « Bonjour, avez-vous du paracétamol ? » ne doit pas se réduire à un bonjour.
    assert.equal(detecterIntention("Bonjour, avez-vous du paracétamol ?"), "recherche");
  });

  test("une salutation seule reste une salutation", () => {
    assert.equal(detecterIntention("Bonjour !"), "salutation");
    assert.equal(detecterIntention("bonsoir"), "salutation");
  });

  test("le conseil médical prime même après une salutation", () => {
    assert.equal(detecterIntention("Bonsoir, je suis enceinte, que puis-je prendre ?"), "conseil_medical");
  });

  test("un message vide n'échoue pas", () => {
    assert.equal(detecterIntention(""), "salutation");
  });
});

describe("Extraction du nom de produit", () => {
  const cas = [
    ["Bonjour, avez-vous du paracétamol ?", "paracetamol"],
    ["je cherche de l'ibuprofène svp", "ibuprofene"],
    ["Est-ce que vous avez des sels de réhydratation ?", "sels de rehydratation"],
    ["il me faut du coartem merci", "coartem"],
    ["AMOXICILLINE", "amoxicilline"],
  ];
  for (const [message, attendu] of cas) {
    test(`« ${message.slice(0, 40)} » → « ${attendu} »`, () => {
      assert.equal(extraireProduit(message), attendu);
    });
  }

  test("supprime les accents pour la recherche", () => {
    assert.equal(extraireProduit("Paracétamol").includes("é"), false);
  });

  test("ne renvoie rien d'exploitable pour un message vide", () => {
    assert.ok(extraireProduit("bonjour").length < 3);
  });
});
