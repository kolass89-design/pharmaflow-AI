/**
 * Vérifie que la supervision ne peut pas exfiltrer de données de santé.
 * Test en boîte noire : réimplémenté ? non — on importe la vraie logique
 * via une copie sans `server-only`, générée à la volée.
 */
import { readFileSync, writeFileSync, unlinkSync } from "node:fs";
import { execSync } from "node:child_process";

const src = readFileSync("lib/monitoring.ts", "utf8").replace('import "server-only";\n', "");
writeFileSync("lib/.monitoring-test.ts", src);

const runner = `
import { scrub } from "./lib/.monitoring-test";
const out = scrub({
  saleId: "s_123", total: 4900,
  patient: { fullName: "Adjovi Sènou", phoneEnc: "v1:abc:def", allergies: "Pénicilline" },
  user: { email: "demo@pharmaflow.ai", passwordHash: "scrypt$sel$hash" },
  headers: { authorization: "Bearer xyz", cookie: "pf_session=abc" },
  items: Array.from({ length: 40 }, (_, i) => ({ n: i })),
});
console.log(JSON.stringify(out));
`;
writeFileSync("run-scrub-test.ts", runner);

const brut = execSync("npx tsx run-scrub-test.ts", { encoding: "utf8" }).trim();
unlinkSync("lib/.monitoring-test.ts");
unlinkSync("run-scrub-test.ts");

const r = JSON.parse(brut);
let ko = 0;
const check = (label, cond) => {
  console.log(`  ${cond ? "\x1b[32m✓\x1b[0m" : "\x1b[31m✗\x1b[0m"} ${label}`);
  if (!cond) ko++;
};

console.log("\n=== Masquage des données sensibles ===");
check("nom du patient masqué",        r.patient.fullName === "[masqué]");
check("téléphone chiffré masqué",     r.patient.phoneEnc === "[masqué]");
check("allergies masquées",           r.patient.allergies === "[masqué]");
check("hash de mot de passe masqué",  r.user.passwordHash === "[masqué]");
check("en-tête Authorization masqué", r.headers.authorization === "[masqué]");
check("cookie de session masqué",     r.headers.cookie === "[masqué]");
check("données techniques conservées", r.saleId === "s_123" && r.total === 4900);
check("email conservé (non sensible)", r.user.email === "demo@pharmaflow.ai");
check("tableaux tronqués à 20",        r.items.length === 20);

console.log(ko === 0 ? "\n\x1b[32m✅ Aucune fuite possible via la supervision.\x1b[0m\n"
                     : `\n\x1b[31m❌ ${ko} contrôle(s) en échec.\x1b[0m\n`);
process.exit(ko === 0 ? 0 : 1);
