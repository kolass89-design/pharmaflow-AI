--
-- PostgreSQL database dump
--

\restrict Q9LUETWUf9XJco2gLNsIWqLlpImCiEeJXlFUboPhUqnE0yuVb9AYx6mBwcatfjh

-- Dumped from database version 17.10 (Debian 17.10-0+deb13u1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public."_PermissionToRole" DROP CONSTRAINT IF EXISTS "_PermissionToRole_B_fkey";
ALTER TABLE IF EXISTS ONLY public."_PermissionToRole" DROP CONSTRAINT IF EXISTS "_PermissionToRole_A_fkey";
ALTER TABLE IF EXISTS ONLY public."WhatsappMessage" DROP CONSTRAINT IF EXISTS "WhatsappMessage_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public."WhatsappConversation" DROP CONSTRAINT IF EXISTS "WhatsappConversation_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."TreatmentReminder" DROP CONSTRAINT IF EXISTS "TreatmentReminder_patientId_fkey";
ALTER TABLE IF EXISTS ONLY public."Supplier" DROP CONSTRAINT IF EXISTS "Supplier_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_patientId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."Reservation" DROP CONSTRAINT IF EXISTS "Reservation_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Reservation" DROP CONSTRAINT IF EXISTS "Reservation_conversationId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrder" DROP CONSTRAINT IF EXISTS "PurchaseOrder_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrder" DROP CONSTRAINT IF EXISTS "PurchaseOrder_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrderItem" DROP CONSTRAINT IF EXISTS "PurchaseOrderItem_orderId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."ProductBatch" DROP CONSTRAINT IF EXISTS "ProductBatch_productId_fkey";
ALTER TABLE IF EXISTS ONLY public."Prescription" DROP CONSTRAINT IF EXISTS "Prescription_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Prescription" DROP CONSTRAINT IF EXISTS "Prescription_patientId_fkey";
ALTER TABLE IF EXISTS ONLY public."PrescriptionItem" DROP CONSTRAINT IF EXISTS "PrescriptionItem_prescriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public."PharmacyMember" DROP CONSTRAINT IF EXISTS "PharmacyMember_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."PharmacyMember" DROP CONSTRAINT IF EXISTS "PharmacyMember_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public."PharmacyMember" DROP CONSTRAINT IF EXISTS "PharmacyMember_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public."Patient" DROP CONSTRAINT IF EXISTS "Patient_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public."GuardSchedule" DROP CONSTRAINT IF EXISTS "GuardSchedule_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."Expense" DROP CONSTRAINT IF EXISTS "Expense_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_pharmacyId_fkey";
ALTER TABLE IF EXISTS ONLY public."AiRecommendation" DROP CONSTRAINT IF EXISTS "AiRecommendation_pharmacyId_fkey";
DROP INDEX IF EXISTS public."_PermissionToRole_B_index";
DROP INDEX IF EXISTS public."_PermissionToRole_AB_unique";
DROP INDEX IF EXISTS public."WhatsappConversation_pharmacyId_lastMessageAt_idx";
DROP INDEX IF EXISTS public."User_email_key";
DROP INDEX IF EXISTS public."Subscription_pharmacyId_key";
DROP INDEX IF EXISTS public."StockMovement_pharmacyId_createdAt_idx";
DROP INDEX IF EXISTS public."Sale_pharmacyId_soldAt_idx";
DROP INDEX IF EXISTS public."Sale_pharmacyId_reference_key";
DROP INDEX IF EXISTS public."Sale_offlineUuid_key";
DROP INDEX IF EXISTS public."Role_name_key";
DROP INDEX IF EXISTS public."Reservation_reference_key";
DROP INDEX IF EXISTS public."Reservation_pharmacyId_status_idx";
DROP INDEX IF EXISTS public."PurchaseOrder_pharmacyId_reference_key";
DROP INDEX IF EXISTS public."Product_pharmacyId_name_idx";
DROP INDEX IF EXISTS public."Product_pharmacyId_barcode_key";
DROP INDEX IF EXISTS public."ProductBatch_productId_expiryDate_idx";
DROP INDEX IF EXISTS public."Pharmacy_city_country_idx";
DROP INDEX IF EXISTS public."PharmacyMember_userId_pharmacyId_key";
DROP INDEX IF EXISTS public."Permission_code_key";
DROP INDEX IF EXISTS public."Patient_pharmacyId_fullName_idx";
DROP INDEX IF EXISTS public."Invoice_reference_key";
DROP INDEX IF EXISTS public."GuardSchedule_city_startsAt_idx";
DROP INDEX IF EXISTS public."Expense_pharmacyId_spentAt_idx";
DROP INDEX IF EXISTS public."AuditLog_pharmacyId_createdAt_idx";
DROP INDEX IF EXISTS public."AiRecommendation_pharmacyId_createdAt_idx";
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public."WhatsappMessage" DROP CONSTRAINT IF EXISTS "WhatsappMessage_pkey";
ALTER TABLE IF EXISTS ONLY public."WhatsappConversation" DROP CONSTRAINT IF EXISTS "WhatsappConversation_pkey";
ALTER TABLE IF EXISTS ONLY public."User" DROP CONSTRAINT IF EXISTS "User_pkey";
ALTER TABLE IF EXISTS ONLY public."TreatmentReminder" DROP CONSTRAINT IF EXISTS "TreatmentReminder_pkey";
ALTER TABLE IF EXISTS ONLY public."Supplier" DROP CONSTRAINT IF EXISTS "Supplier_pkey";
ALTER TABLE IF EXISTS ONLY public."Subscription" DROP CONSTRAINT IF EXISTS "Subscription_pkey";
ALTER TABLE IF EXISTS ONLY public."StockMovement" DROP CONSTRAINT IF EXISTS "StockMovement_pkey";
ALTER TABLE IF EXISTS ONLY public."Sale" DROP CONSTRAINT IF EXISTS "Sale_pkey";
ALTER TABLE IF EXISTS ONLY public."SaleItem" DROP CONSTRAINT IF EXISTS "SaleItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Role" DROP CONSTRAINT IF EXISTS "Role_pkey";
ALTER TABLE IF EXISTS ONLY public."Reservation" DROP CONSTRAINT IF EXISTS "Reservation_pkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrder" DROP CONSTRAINT IF EXISTS "PurchaseOrder_pkey";
ALTER TABLE IF EXISTS ONLY public."PurchaseOrderItem" DROP CONSTRAINT IF EXISTS "PurchaseOrderItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Product" DROP CONSTRAINT IF EXISTS "Product_pkey";
ALTER TABLE IF EXISTS ONLY public."ProductBatch" DROP CONSTRAINT IF EXISTS "ProductBatch_pkey";
ALTER TABLE IF EXISTS ONLY public."Prescription" DROP CONSTRAINT IF EXISTS "Prescription_pkey";
ALTER TABLE IF EXISTS ONLY public."PrescriptionItem" DROP CONSTRAINT IF EXISTS "PrescriptionItem_pkey";
ALTER TABLE IF EXISTS ONLY public."Pharmacy" DROP CONSTRAINT IF EXISTS "Pharmacy_pkey";
ALTER TABLE IF EXISTS ONLY public."PharmacyMember" DROP CONSTRAINT IF EXISTS "PharmacyMember_pkey";
ALTER TABLE IF EXISTS ONLY public."Permission" DROP CONSTRAINT IF EXISTS "Permission_pkey";
ALTER TABLE IF EXISTS ONLY public."Payment" DROP CONSTRAINT IF EXISTS "Payment_pkey";
ALTER TABLE IF EXISTS ONLY public."Patient" DROP CONSTRAINT IF EXISTS "Patient_pkey";
ALTER TABLE IF EXISTS ONLY public."Invoice" DROP CONSTRAINT IF EXISTS "Invoice_pkey";
ALTER TABLE IF EXISTS ONLY public."GuardSchedule" DROP CONSTRAINT IF EXISTS "GuardSchedule_pkey";
ALTER TABLE IF EXISTS ONLY public."Expense" DROP CONSTRAINT IF EXISTS "Expense_pkey";
ALTER TABLE IF EXISTS ONLY public."AuditLog" DROP CONSTRAINT IF EXISTS "AuditLog_pkey";
ALTER TABLE IF EXISTS ONLY public."AiRecommendation" DROP CONSTRAINT IF EXISTS "AiRecommendation_pkey";
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TABLE IF EXISTS public."_PermissionToRole";
DROP TABLE IF EXISTS public."WhatsappMessage";
DROP TABLE IF EXISTS public."WhatsappConversation";
DROP TABLE IF EXISTS public."User";
DROP TABLE IF EXISTS public."TreatmentReminder";
DROP TABLE IF EXISTS public."Supplier";
DROP TABLE IF EXISTS public."Subscription";
DROP TABLE IF EXISTS public."StockMovement";
DROP TABLE IF EXISTS public."SaleItem";
DROP TABLE IF EXISTS public."Sale";
DROP TABLE IF EXISTS public."Role";
DROP TABLE IF EXISTS public."Reservation";
DROP TABLE IF EXISTS public."PurchaseOrderItem";
DROP TABLE IF EXISTS public."PurchaseOrder";
DROP TABLE IF EXISTS public."ProductBatch";
DROP TABLE IF EXISTS public."Product";
DROP TABLE IF EXISTS public."PrescriptionItem";
DROP TABLE IF EXISTS public."Prescription";
DROP TABLE IF EXISTS public."PharmacyMember";
DROP TABLE IF EXISTS public."Pharmacy";
DROP TABLE IF EXISTS public."Permission";
DROP TABLE IF EXISTS public."Payment";
DROP TABLE IF EXISTS public."Patient";
DROP TABLE IF EXISTS public."Invoice";
DROP TABLE IF EXISTS public."GuardSchedule";
DROP TABLE IF EXISTS public."Expense";
DROP TABLE IF EXISTS public."AuditLog";
DROP TABLE IF EXISTS public."AiRecommendation";
DROP TYPE IF EXISTS public."SubStatus";
DROP TYPE IF EXISTS public."SaleStatus";
DROP TYPE IF EXISTS public."RoleName";
DROP TYPE IF EXISTS public."PrescriptionStatus";
DROP TYPE IF EXISTS public."PoStatus";
DROP TYPE IF EXISTS public."PlanTier";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."MovementType";
DROP TYPE IF EXISTS public."Currency";
DROP TYPE IF EXISTS public."Country";
DROP TYPE IF EXISTS public."ConversationStatus";
DROP EXTENSION IF EXISTS unaccent;
--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: ConversationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ConversationStatus" AS ENUM (
    'BOT',
    'HUMAN_REQUIRED',
    'HUMAN',
    'CLOSED'
);


--
-- Name: Country; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Country" AS ENUM (
    'BJ',
    'TG',
    'CI',
    'SN',
    'NE',
    'CM',
    'OTHER'
);


--
-- Name: Currency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Currency" AS ENUM (
    'XOF',
    'XAF',
    'GNF',
    'USD',
    'EUR'
);


--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'ADJUSTMENT',
    'RETURN',
    'LOSS',
    'TRANSFER'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'MTN_MOMO',
    'MOOV_MONEY',
    'ORANGE_MONEY',
    'CELTIIS_CASH',
    'WAVE',
    'CARD',
    'BANK_TRANSFER',
    'INSURANCE'
);


--
-- Name: PlanTier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanTier" AS ENUM (
    'STARTER',
    'PRO',
    'ENTERPRISE'
);


--
-- Name: PoStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PoStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'PREPARING',
    'IN_TRANSIT',
    'PARTIAL',
    'RECEIVED',
    'CANCELLED'
);


--
-- Name: PrescriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PrescriptionStatus" AS ENUM (
    'PENDING',
    'PARTIAL',
    'SERVED',
    'ARCHIVED'
);


--
-- Name: RoleName; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RoleName" AS ENUM (
    'OWNER',
    'PHARMACIST',
    'TECHNICIAN',
    'CASHIER',
    'ACCOUNTANT'
);


--
-- Name: SaleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SaleStatus" AS ENUM (
    'COMPLETED',
    'REFUNDED',
    'PARTIALLY_REFUNDED',
    'PENDING_SYNC'
);


--
-- Name: SubStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubStatus" AS ENUM (
    'TRIALING',
    'ACTIVE',
    'PAST_DUE',
    'CANCELLED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiRecommendation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiRecommendation" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    type text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    title text NOT NULL,
    detail text NOT NULL,
    payload jsonb,
    "isDismissed" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AuditLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AuditLog" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "userId" text,
    action text NOT NULL,
    entity text,
    "entityId" text,
    ip text,
    "userAgent" text,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Expense; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Expense" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    category text NOT NULL,
    label text NOT NULL,
    amount integer NOT NULL,
    "spentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "receiptUrl" text
);


--
-- Name: GuardSchedule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."GuardSchedule" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "startsAt" timestamp(3) without time zone NOT NULL,
    "endsAt" timestamp(3) without time zone NOT NULL,
    city text NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL
);


--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    reference text NOT NULL,
    amount integer NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "issuedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "pdfUrl" text
);


--
-- Name: Patient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Patient" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "fullName" text NOT NULL,
    "phoneEnc" text,
    "birthDate" timestamp(3) without time zone,
    gender text,
    city text,
    allergies text,
    "chronicConditions" text,
    "consentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    "saleId" text,
    "invoiceId" text,
    method public."PaymentMethod" NOT NULL,
    amount integer NOT NULL,
    "providerRef" text,
    status text DEFAULT 'SUCCEEDED'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Permission" (
    id text NOT NULL,
    code text NOT NULL,
    label text NOT NULL
);


--
-- Name: Pharmacy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Pharmacy" (
    id text NOT NULL,
    name text NOT NULL,
    city text NOT NULL,
    district text,
    country public."Country" DEFAULT 'BJ'::public."Country" NOT NULL,
    currency public."Currency" DEFAULT 'XOF'::public."Currency" NOT NULL,
    "licenseNo" text,
    phone text,
    "whatsappNo" text,
    "openingHours" jsonb,
    latitude double precision,
    longitude double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PharmacyMember; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PharmacyMember" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "pharmacyId" text NOT NULL,
    "roleId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Prescription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Prescription" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "patientId" text NOT NULL,
    prescriber text,
    "issuedAt" timestamp(3) without time zone NOT NULL,
    "imageUrl" text,
    "ocrText" text,
    notes text,
    status public."PrescriptionStatus" DEFAULT 'PENDING'::public."PrescriptionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PrescriptionItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PrescriptionItem" (
    id text NOT NULL,
    "prescriptionId" text NOT NULL,
    "productId" text,
    label text NOT NULL,
    dosage text,
    duration text,
    quantity integer DEFAULT 1 NOT NULL,
    served integer DEFAULT 0 NOT NULL
);


--
-- Name: Product; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Product" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    name text NOT NULL,
    dci text,
    form text,
    dosage text,
    barcode text,
    category text,
    "purchasePrice" integer NOT NULL,
    "salePrice" integer NOT NULL,
    "alertThreshold" integer DEFAULT 10 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "supplierId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "requiresPrescription" boolean DEFAULT false NOT NULL
);


--
-- Name: ProductBatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ProductBatch" (
    id text NOT NULL,
    "productId" text NOT NULL,
    "batchNo" text NOT NULL,
    quantity integer NOT NULL,
    "expiryDate" timestamp(3) without time zone NOT NULL,
    "costPrice" integer,
    "receivedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PurchaseOrder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PurchaseOrder" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "supplierId" text NOT NULL,
    reference text NOT NULL,
    status public."PoStatus" DEFAULT 'DRAFT'::public."PoStatus" NOT NULL,
    "totalAmount" integer DEFAULT 0 NOT NULL,
    "expectedAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "invoiceUrl" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PurchaseOrderItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PurchaseOrderItem" (
    id text NOT NULL,
    "orderId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer NOT NULL,
    "unitCost" integer NOT NULL,
    received integer DEFAULT 0 NOT NULL
);


--
-- Name: Reservation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Reservation" (
    id text NOT NULL,
    "conversationId" text,
    "pharmacyId" text NOT NULL,
    "productId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    reference text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "customerName" text,
    "customerPhoneEnc" text,
    "productLabel" text,
    source text DEFAULT 'WHATSAPP'::text NOT NULL,
    "unitPrice" integer
);


--
-- Name: Role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Role" (
    id text NOT NULL,
    name public."RoleName" NOT NULL,
    label text NOT NULL
);


--
-- Name: Sale; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Sale" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "userId" text,
    "patientId" text,
    "prescriptionId" text,
    reference text NOT NULL,
    subtotal integer NOT NULL,
    discount integer DEFAULT 0 NOT NULL,
    total integer NOT NULL,
    status public."SaleStatus" DEFAULT 'COMPLETED'::public."SaleStatus" NOT NULL,
    "offlineUuid" text,
    "soldAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: SaleItem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SaleItem" (
    id text NOT NULL,
    "saleId" text NOT NULL,
    "productId" text NOT NULL,
    "batchId" text,
    quantity integer NOT NULL,
    "unitPrice" integer NOT NULL,
    discount integer DEFAULT 0 NOT NULL,
    "lineTotal" integer NOT NULL
);


--
-- Name: StockMovement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."StockMovement" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    "productId" text NOT NULL,
    "batchId" text,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reason text,
    reference text,
    "userId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    plan public."PlanTier" DEFAULT 'STARTER'::public."PlanTier" NOT NULL,
    status public."SubStatus" DEFAULT 'TRIALING'::public."SubStatus" NOT NULL,
    "billingCycle" text DEFAULT 'MONTHLY'::text NOT NULL,
    amount integer DEFAULT 19000 NOT NULL,
    currency public."Currency" DEFAULT 'XOF'::public."Currency" NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "renewsAt" timestamp(3) without time zone
);


--
-- Name: Supplier; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Supplier" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    name text NOT NULL,
    country public."Country" DEFAULT 'BJ'::public."Country" NOT NULL,
    contact text,
    email text,
    phone text,
    "leadTimeHours" integer DEFAULT 72 NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: TreatmentReminder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TreatmentReminder" (
    id text NOT NULL,
    "patientId" text NOT NULL,
    label text NOT NULL,
    schedule text NOT NULL,
    channel text DEFAULT 'WHATSAPP'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "fullName" text NOT NULL,
    phone text,
    "mfaSecret" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: WhatsappConversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WhatsappConversation" (
    id text NOT NULL,
    "pharmacyId" text NOT NULL,
    phone text NOT NULL,
    status public."ConversationStatus" DEFAULT 'BOT'::public."ConversationStatus" NOT NULL,
    "lastMessageAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: WhatsappMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."WhatsappMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    direction text NOT NULL,
    sender text NOT NULL,
    body text NOT NULL,
    "providerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: _PermissionToRole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."_PermissionToRole" (
    "A" text NOT NULL,
    "B" text NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AiRecommendation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiRecommendation" (id, "pharmacyId", type, severity, title, detail, payload, "isDismissed", "createdAt") FROM stdin;
cms1t22cp033mnr6bpdkg6xsc	cms1t20wv000onr6b55iy581v	RESTOCK	URGENT	Rupture prévue sous 6 jours	Paracétamol 1 g — commander 180 boîtes (saison des pluies, +24 % de demande).	\N	f	2026-07-26 12:59:46.921
cms1t22cp033nnr6bhdyyga65	cms1t20wv000onr6b55iy581v	DORMANT	INFO	Produit dormant	Vitamine B12 injectable — 0 vente en 45 jours. Envisager un retour fournisseur.	\N	f	2026-07-26 12:59:46.921
cms1t22cp033onr6bgdfw7kru	cms1t20wv000onr6b55iy581v	EXPIRY	WARNING	Expiration proche	LOT-S330 (Sérum physiologique) expire dans 25 jours — promotion suggérée.	\N	f	2026-07-26 12:59:46.921
cms1t22cp033pnr6b9b7anq58	cms1t20wv000onr6b55iy581v	PRICING	INFO	Marge optimisable	Amlodipine 5 mg : marge 41 %, hausse de 5 % possible sans perte de volume.	\N	f	2026-07-26 12:59:46.921
\.


--
-- Data for Name: AuditLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AuditLog" (id, "pharmacyId", "userId", action, entity, "entityId", ip, "userAgent", metadata, "createdAt") FROM stdin;
cms1t22ct033unr6b3qvv43h9	cms1t20wv000onr6b55iy581v	cms1t20y6000pnr6bff7mdivr	PATIENT_VIEW	Patient	cms1t214q0035nr6bxwke21xg	\N	\N	\N	2026-07-26 12:59:46.925
cms1t22ct033vnr6bwk36sma3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	SALE_CREATE	Sale	\N	\N	\N	\N	2026-07-26 12:59:46.925
cms1t22ct033wnr6bq4h8tlr8	cms1t20wv000onr6b55iy581v	cms1t210q000vnr6b7r9y0xjl	STOCK_RECEIVE	PurchaseOrder	\N	\N	\N	\N	2026-07-26 12:59:46.925
cms1t22ct033xnr6b3jro3gzm	cms1t20wv000onr6b55iy581v	\N	BACKUP_SUCCESS	System	\N	\N	\N	\N	2026-07-26 12:59:46.925
\.


--
-- Data for Name: Expense; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Expense" (id, "pharmacyId", category, label, amount, "spentAt", "receiptUrl") FROM stdin;
cms1t22c8032xnr6b8bto7rhq	cms1t20wv000onr6b55iy581v	Achats	Facture UBIPHARM juillet	6950000	2026-07-26 12:59:46.904	\N
cms1t22c9032znr6buxe0vgo1	cms1t20wv000onr6b55iy581v	Salaires	Masse salariale juillet	980000	2026-07-26 12:59:46.906	\N
cms1t22cb0331nr6blssw28kb	cms1t20wv000onr6b55iy581v	Loyer	Loyer local commercial	250000	2026-07-26 12:59:46.907	\N
cms1t22cc0333nr6b2u62gltk	cms1t20wv000onr6b55iy581v	Énergie	SBEE + carburant groupe	180000	2026-07-26 12:59:46.908	\N
cms1t22cd0335nr6bdc8yud7q	cms1t20wv000onr6b55iy581v	Logiciel	Abonnement PharmaFlow AI	39000	2026-07-26 12:59:46.909	\N
cms1t22ce0337nr6bulqj4x1c	cms1t20wv000onr6b55iy581v	Divers	Entretien et fournitures	141000	2026-07-26 12:59:46.91	\N
\.


--
-- Data for Name: GuardSchedule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."GuardSchedule" (id, "pharmacyId", "startsAt", "endsAt", city, "isPublished") FROM stdin;
cms1t22cq033rnr6bws01x85t	cms1t20wv000onr6b55iy581v	2026-07-25 08:00:00	2026-07-31 20:00:00	Cotonou	t
cms1t22cs033tnr6b112hujre	cms1t213c0016nr6b2mn38qkv	2026-08-01 08:00:00	2026-08-07 20:00:00	Cotonou	t
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Invoice" (id, "subscriptionId", reference, amount, status, "issuedAt", "paidAt", "pdfUrl") FROM stdin;
\.


--
-- Data for Name: Patient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Patient" (id, "pharmacyId", "fullName", "phoneEnc", "birthDate", gender, city, allergies, "chronicConditions", "consentAt", "createdAt") FROM stdin;
cms1t214q0035nr6bxwke21xg	cms1t20wv000onr6b55iy581v	Adjovi Sènou	\N	\N	\N	Cotonou	Pénicilline	Hypertension	2026-07-26 12:59:45.338	2026-07-26 12:59:45.338
cms1t214r0037nr6bm73szalf	cms1t20wv000onr6b55iy581v	Kouassi N'Guessan	\N	\N	\N	Cotonou	\N	\N	2026-07-26 12:59:45.339	2026-07-26 12:59:45.34
cms1t214s0039nr6bqwp5oiay	cms1t20wv000onr6b55iy581v	Fatou Mbaye	\N	\N	\N	Cotonou	Sulfamides	Diabète type 2	2026-07-26 12:59:45.34	2026-07-26 12:59:45.341
cms1t214t003bnr6b0vm5hxl9	cms1t20wv000onr6b55iy581v	Ibrahim Salou	\N	\N	\N	Porto-Novo	\N	\N	2026-07-26 12:59:45.341	2026-07-26 12:59:45.341
cms1t214u003dnr6blfrkvove	cms1t20wv000onr6b55iy581v	Bernadette Agbo	\N	\N	\N	Cotonou	Aspirine	Asthme	2026-07-26 12:59:45.342	2026-07-26 12:59:45.342
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, "saleId", "invoiceId", method, amount, "providerRef", status, "createdAt") FROM stdin;
cms1t2152003snr6bpukycedu	cms1t2151003onr6bnwud5kgb	\N	CASH	4700	\N	SUCCEEDED	2026-07-26 12:59:45.35
cms1t2155003ynr6b0ietej5r	cms1t2155003unr6bwpbbqzf7	\N	MOOV_MONEY	4100	\N	SUCCEEDED	2026-07-26 12:59:45.354
cms1t21580043nr6bx8p6nf9r	cms1t21580040nr6b5scrzqss	\N	CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:45.356
cms1t215a0048nr6b5ll5mmrc	cms1t215a0045nr6b481vzicb	\N	MTN_MOMO	700	\N	SUCCEEDED	2026-07-26 12:59:45.359
cms1t215c004fnr6bluvww8pj	cms1t215c004anr6b5911j9gk	\N	CASH	6200	\N	SUCCEEDED	2026-07-26 12:59:45.361
cms1t215f004mnr6bf479fgnp	cms1t215f004hnr6beii3gk95	\N	MTN_MOMO	12500	\N	SUCCEEDED	2026-07-26 12:59:45.363
cms1t215i004snr6bonzh6p5c	cms1t215i004onr6b9ch3u2hp	\N	MOOV_MONEY	5300	\N	SUCCEEDED	2026-07-26 12:59:45.366
cms1t215k004ynr6bb7mivxci	cms1t215k004unr6bwgaa6v2u	\N	CARD	5100	\N	SUCCEEDED	2026-07-26 12:59:45.368
cms1t215m0054nr6bhnx6pz5v	cms1t215m0050nr6bdgeu0b3y	\N	CELTIIS_CASH	6300	\N	SUCCEEDED	2026-07-26 12:59:45.371
cms1t215p005bnr6bfy80lgbn	cms1t215p0056nr6b3fnbt8mb	\N	MOOV_MONEY	4200	\N	SUCCEEDED	2026-07-26 12:59:45.373
cms1t215r005inr6bx0566gvy	cms1t215r005dnr6bzyz37pwu	\N	MOOV_MONEY	9700	\N	SUCCEEDED	2026-07-26 12:59:45.376
cms1t215u005onr6bn48yr29p	cms1t215u005knr6bnayndrpj	\N	CELTIIS_CASH	7200	\N	SUCCEEDED	2026-07-26 12:59:45.378
cms1t215w005vnr6bprdo2mwr	cms1t215w005qnr6bzqyr8w3d	\N	CARD	10000	\N	SUCCEEDED	2026-07-26 12:59:45.38
cms1t215y0062nr6bqs9e6s24	cms1t215y005xnr6bwnipt8u2	\N	MTN_MOMO	10700	\N	SUCCEEDED	2026-07-26 12:59:45.383
cms1t21600069nr6bvcizv35b	cms1t21600064nr6b3nltdua5	\N	CASH	8650	\N	SUCCEEDED	2026-07-26 12:59:45.385
cms1t2163006fnr6brtjs3e4w	cms1t2163006bnr6belfz3r25	\N	CARD	2550	\N	SUCCEEDED	2026-07-26 12:59:45.387
cms1t2165006knr6brgms81ep	cms1t2165006hnr6bsjgz3ixx	\N	WAVE	5000	\N	SUCCEEDED	2026-07-26 12:59:45.389
cms1t2167006qnr6bwit4g5kb	cms1t2167006mnr6b09sbkypy	\N	CELTIIS_CASH	5100	\N	SUCCEEDED	2026-07-26 12:59:45.391
cms1t2169006vnr6bj2l8httl	cms1t2169006snr6b5xab38za	\N	MTN_MOMO	2900	\N	SUCCEEDED	2026-07-26 12:59:45.393
cms1t216b0072nr6bxy0pbxv5	cms1t216b006xnr6bstwm89g4	\N	WAVE	6000	\N	SUCCEEDED	2026-07-26 12:59:45.395
cms1t216d0079nr6beq3slkpm	cms1t216d0074nr6bk7jvr0rp	\N	CELTIIS_CASH	8550	\N	SUCCEEDED	2026-07-26 12:59:45.398
cms1t216f007gnr6b57ytm6b7	cms1t216f007bnr6bq7x7b7uv	\N	MTN_MOMO	11300	\N	SUCCEEDED	2026-07-26 12:59:45.4
cms1t216i007mnr6b2ugc1hti	cms1t216h007inr6bn3gfco94	\N	WAVE	8600	\N	SUCCEEDED	2026-07-26 12:59:45.402
cms1t216k007snr6b0a9pklr4	cms1t216k007onr6brl74o6wt	\N	WAVE	6400	\N	SUCCEEDED	2026-07-26 12:59:45.404
cms1t216m007xnr6bx3q1bb7y	cms1t216m007unr6byizw8nsl	\N	WAVE	1400	\N	SUCCEEDED	2026-07-26 12:59:45.407
cms1t216p0084nr6boi0xwb0h	cms1t216p007znr6bwqu6d39y	\N	WAVE	11500	\N	SUCCEEDED	2026-07-26 12:59:45.409
cms1t216s008bnr6by6o2ytxl	cms1t216s0086nr6bx4720lro	\N	MOOV_MONEY	13300	\N	SUCCEEDED	2026-07-26 12:59:45.412
cms1t216u008gnr6bogsbd937	cms1t216u008dnr6bn9s3vuya	\N	MOOV_MONEY	700	\N	SUCCEEDED	2026-07-26 12:59:45.415
cms1t216x008mnr6bgxuqsha7	cms1t216x008inr6b6h5b6rh6	\N	MOOV_MONEY	5700	\N	SUCCEEDED	2026-07-26 12:59:45.417
cms1t216z008rnr6bouoc63hn	cms1t216z008onr6bzfy17owe	\N	MTN_MOMO	700	\N	SUCCEEDED	2026-07-26 12:59:45.419
cms1t2171008xnr6bwov1st36	cms1t2171008tnr6bzap4zhsw	\N	MTN_MOMO	9100	\N	SUCCEEDED	2026-07-26 12:59:45.421
cms1t21730094nr6boqyec2i4	cms1t2173008znr6beylz8jbb	\N	MOOV_MONEY	8400	\N	SUCCEEDED	2026-07-26 12:59:45.424
cms1t21750099nr6biuaa8tpe	cms1t21750096nr6bt2n0o6ka	\N	CELTIIS_CASH	700	\N	SUCCEEDED	2026-07-26 12:59:45.426
cms1t2177009gnr6b0woircfs	cms1t2177009bnr6bksa4etu6	\N	CELTIIS_CASH	5400	\N	SUCCEEDED	2026-07-26 12:59:45.428
cms1t217a009lnr6b9272lcgl	cms1t217a009inr6bdkt8dnpi	\N	MTN_MOMO	1100	\N	SUCCEEDED	2026-07-26 12:59:45.43
cms1t217c009qnr6b4ov6wz3k	cms1t217c009nnr6bqc2x5znn	\N	CELTIIS_CASH	700	\N	SUCCEEDED	2026-07-26 12:59:45.432
cms1t217e009wnr6b48y26bob	cms1t217e009snr6bybqsm0zn	\N	MTN_MOMO	7500	\N	SUCCEEDED	2026-07-26 12:59:45.434
cms1t217g00a1nr6bffgu0jph	cms1t217g009ynr6bhq08w3mr	\N	MTN_MOMO	700	\N	SUCCEEDED	2026-07-26 12:59:45.436
cms1t217i00a8nr6bnv3h428w	cms1t217i00a3nr6bdv1w4g3x	\N	CARD	8300	\N	SUCCEEDED	2026-07-26 12:59:45.438
cms1t217k00aenr6b0vr6nm70	cms1t217k00aanr6bordo3p36	\N	CASH	5700	\N	SUCCEEDED	2026-07-26 12:59:45.44
cms1t217m00aknr6bzshp5cfm	cms1t217m00agnr6bansb3jqi	\N	MOOV_MONEY	4600	\N	SUCCEEDED	2026-07-26 12:59:45.443
cms1t217o00aqnr6b5livs5lw	cms1t217o00amnr6bk63hroay	\N	WAVE	3900	\N	SUCCEEDED	2026-07-26 12:59:45.445
cms1t217r00axnr6b6mdw9ipv	cms1t217r00asnr6bdoxs0870	\N	MOOV_MONEY	10600	\N	SUCCEEDED	2026-07-26 12:59:45.448
cms1t217u00b4nr6bjiew7lyt	cms1t217u00aznr6bv7n9ypuy	\N	WAVE	4700	\N	SUCCEEDED	2026-07-26 12:59:45.45
cms1t217w00b9nr6bopfew2le	cms1t217w00b6nr6bvk7updgz	\N	CELTIIS_CASH	700	\N	SUCCEEDED	2026-07-26 12:59:45.452
cms1t217y00bgnr6byu53e0nn	cms1t217y00bbnr6b37iqve1e	\N	MTN_MOMO	8400	\N	SUCCEEDED	2026-07-26 12:59:45.455
cms1t218100bmnr6bqcbsybgz	cms1t218100binr6bwlbzf5hj	\N	WAVE	10000	\N	SUCCEEDED	2026-07-26 12:59:45.457
cms1t218300brnr6b14yot32i	cms1t218300bonr6blqzsqkb9	\N	MTN_MOMO	1400	\N	SUCCEEDED	2026-07-26 12:59:45.459
cms1t218500bynr6baunjwpoa	cms1t218500btnr6bul7u1g6t	\N	CELTIIS_CASH	9700	\N	SUCCEEDED	2026-07-26 12:59:45.461
cms1t218700c3nr6buoh6bl6j	cms1t218700c0nr6bglis7yfv	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.464
cms1t218a00canr6b16p8sfqm	cms1t218900c5nr6b6lihneyp	\N	WAVE	7100	\N	SUCCEEDED	2026-07-26 12:59:45.466
cms1t218c00chnr6bwtnrgwpc	cms1t218c00ccnr6bplz20onj	\N	CELTIIS_CASH	7650	\N	SUCCEEDED	2026-07-26 12:59:45.468
cms1t218f00conr6be45b4gbt	cms1t218f00cjnr6b65wmbmak	\N	WAVE	8300	\N	SUCCEEDED	2026-07-26 12:59:45.471
cms1t218h00cunr6b3e266vum	cms1t218h00cqnr6btpzzetph	\N	CARD	4600	\N	SUCCEEDED	2026-07-26 12:59:45.473
cms1t218j00d0nr6b0t4q4qvg	cms1t218j00cwnr6b3enubeil	\N	MOOV_MONEY	5900	\N	SUCCEEDED	2026-07-26 12:59:45.476
cms1t218m00d7nr6bsz6wjzts	cms1t218m00d2nr6bkru5pgq7	\N	CARD	11200	\N	SUCCEEDED	2026-07-26 12:59:45.478
cms1t218o00denr6b8m26cmbq	cms1t218o00d9nr6b15gipjzg	\N	MTN_MOMO	11000	\N	SUCCEEDED	2026-07-26 12:59:45.48
cms1t218r00djnr6b8yh4dr09	cms1t218q00dgnr6bk2wnw6ul	\N	CELTIIS_CASH	4200	\N	SUCCEEDED	2026-07-26 12:59:45.483
cms1t218t00dpnr6bxnwzv2a4	cms1t218t00dlnr6b0za9pmxt	\N	CASH	5300	\N	SUCCEEDED	2026-07-26 12:59:45.485
cms1t218v00dwnr6brblu94ov	cms1t218v00drnr6b6gce71y9	\N	CARD	8300	\N	SUCCEEDED	2026-07-26 12:59:45.487
cms1t218x00e2nr6b4enea25q	cms1t218x00dynr6bq3fpzlos	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:45.49
cms1t219000e7nr6bs6w7j442	cms1t219000e4nr6becokoyol	\N	CASH	2200	\N	SUCCEEDED	2026-07-26 12:59:45.492
cms1t219200eenr6b4q0yr848	cms1t219200e9nr6bhhzygs5o	\N	MTN_MOMO	4800	\N	SUCCEEDED	2026-07-26 12:59:45.494
cms1t219400ejnr6b7rahsa9b	cms1t219400egnr6bwcargq9a	\N	MOOV_MONEY	1400	\N	SUCCEEDED	2026-07-26 12:59:45.497
cms1t219600eonr6bgvr0oehn	cms1t219600elnr6bje0qmhjr	\N	WAVE	5800	\N	SUCCEEDED	2026-07-26 12:59:45.499
cms1t219800evnr6bum2opnnd	cms1t219800eqnr6bo1dilwka	\N	CASH	9000	\N	SUCCEEDED	2026-07-26 12:59:45.501
cms1t219b00f0nr6bxc71lv07	cms1t219b00exnr6bx4n4xdwp	\N	WAVE	1100	\N	SUCCEEDED	2026-07-26 12:59:45.503
cms1t219c00f6nr6bgbr1naqp	cms1t219c00f2nr6b3wn4ipgz	\N	MOOV_MONEY	8900	\N	SUCCEEDED	2026-07-26 12:59:45.505
cms1t219f00fbnr6b2wueaxkm	cms1t219f00f8nr6bex0cqw68	\N	CELTIIS_CASH	2300	\N	SUCCEEDED	2026-07-26 12:59:45.507
cms1t219g00fgnr6b2k3qam6z	cms1t219g00fdnr6buib92k4l	\N	WAVE	700	\N	SUCCEEDED	2026-07-26 12:59:45.509
cms1t219j00fnnr6babbqjyhq	cms1t219j00finr6bxiiqtaoq	\N	MTN_MOMO	9300	\N	SUCCEEDED	2026-07-26 12:59:45.511
cms1t219m00fsnr6boec4zxo9	cms1t219m00fpnr6b6qmd6hdj	\N	CASH	4200	\N	SUCCEEDED	2026-07-26 12:59:45.514
cms1t219o00fynr6bh7o8pw1q	cms1t219o00funr6bmnslwms5	\N	WAVE	6100	\N	SUCCEEDED	2026-07-26 12:59:45.516
cms1t219q00g4nr6bp45rfh0m	cms1t219q00g0nr6b7rly0p6j	\N	MOOV_MONEY	8200	\N	SUCCEEDED	2026-07-26 12:59:45.519
cms1t219t00ganr6bzn1m4ls2	cms1t219t00g6nr6b3j98x563	\N	CASH	8000	\N	SUCCEEDED	2026-07-26 12:59:45.521
cms1t219v00ghnr6bn7o1pkvx	cms1t219v00gcnr6btkyka0t3	\N	MOOV_MONEY	9300	\N	SUCCEEDED	2026-07-26 12:59:45.523
cms1t219x00gmnr6b7vq8p6bm	cms1t219x00gjnr6bo9xmxv2z	\N	MOOV_MONEY	4200	\N	SUCCEEDED	2026-07-26 12:59:45.526
cms1t219z00gsnr6b5cmhfwl5	cms1t219z00gonr6bm40otior	\N	CELTIIS_CASH	3900	\N	SUCCEEDED	2026-07-26 12:59:45.528
cms1t21a200gznr6bybrx2p9j	cms1t21a200gunr6b41fn4mul	\N	CELTIIS_CASH	7500	\N	SUCCEEDED	2026-07-26 12:59:45.53
cms1t21a500h6nr6bad4g6qmn	cms1t21a500h1nr6bw6gremyx	\N	CELTIIS_CASH	9200	\N	SUCCEEDED	2026-07-26 12:59:45.534
cms1t21a800hcnr6byt2j6en7	cms1t21a800h8nr6bov9dndzv	\N	CARD	3900	\N	SUCCEEDED	2026-07-26 12:59:45.536
cms1t21ab00hinr6bvsk5pl6t	cms1t21ab00henr6bu8c8z3nb	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.539
cms1t21ad00hnnr6bwzpc9t9f	cms1t21ad00hknr6bhp6woaws	\N	CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:45.542
cms1t21af00htnr6bgd8lizt6	cms1t21af00hpnr6b9wcuo47y	\N	CELTIIS_CASH	7100	\N	SUCCEEDED	2026-07-26 12:59:45.544
cms1t21ai00hznr6bv0p2ui98	cms1t21ah00hvnr6bwuk0sll6	\N	CELTIIS_CASH	7100	\N	SUCCEEDED	2026-07-26 12:59:45.546
cms1t21ak00i4nr6baai5d0kq	cms1t21ak00i1nr6b0hcbcs8o	\N	CASH	1100	\N	SUCCEEDED	2026-07-26 12:59:45.548
cms1t21am00i9nr6bmh4gxtjt	cms1t21am00i6nr6bqyso4gxj	\N	MOOV_MONEY	2900	\N	SUCCEEDED	2026-07-26 12:59:45.55
cms1t21ao00ignr6b7sbswpdu	cms1t21ao00ibnr6bke4cg7jt	\N	CARD	7500	\N	SUCCEEDED	2026-07-26 12:59:45.552
cms1t21ar00ilnr6b462a0bj5	cms1t21aq00iinr6baqrpeykl	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:45.555
cms1t21at00iqnr6boay16734	cms1t21at00innr6blzf5jv9z	\N	MTN_MOMO	3600	\N	SUCCEEDED	2026-07-26 12:59:45.557
cms1t21av00iwnr6b9m15svqc	cms1t21av00isnr6burclbzuv	\N	MOOV_MONEY	8000	\N	SUCCEEDED	2026-07-26 12:59:45.559
cms1t21ax00j2nr6b0n3mlno8	cms1t21ax00iynr6bftwb1x3r	\N	CASH	4700	\N	SUCCEEDED	2026-07-26 12:59:45.561
cms1t21az00j8nr6b5twz6qj3	cms1t21az00j4nr6bu5sw442i	\N	WAVE	3200	\N	SUCCEEDED	2026-07-26 12:59:45.564
cms1t21b200jenr6bvw1tice0	cms1t21b200janr6b7kpvkrh4	\N	CELTIIS_CASH	1800	\N	SUCCEEDED	2026-07-26 12:59:45.566
cms1t21b500jknr6b5ix6me04	cms1t21b400jgnr6bmtietzdu	\N	MOOV_MONEY	9600	\N	SUCCEEDED	2026-07-26 12:59:45.569
cms1t21b700jrnr6bokegvt8f	cms1t21b700jmnr6b84qzjrch	\N	MOOV_MONEY	8300	\N	SUCCEEDED	2026-07-26 12:59:45.571
cms1t21ba00jxnr6b3cwd1fnu	cms1t21ba00jtnr6bqiiaxycz	\N	CELTIIS_CASH	7800	\N	SUCCEEDED	2026-07-26 12:59:45.574
cms1t21bd00k4nr6bqmxppj09	cms1t21bd00jznr6brudgtyec	\N	CARD	8600	\N	SUCCEEDED	2026-07-26 12:59:45.577
cms1t21bf00kanr6b0vgjadpy	cms1t21bf00k6nr6b9m3us5aq	\N	CELTIIS_CASH	3300	\N	SUCCEEDED	2026-07-26 12:59:45.58
cms1t21bi00khnr6bt594lkjs	cms1t21bi00kcnr6btswmnc8w	\N	WAVE	4400	\N	SUCCEEDED	2026-07-26 12:59:45.582
cms1t21bk00konr6bj8htz8iz	cms1t21bk00kjnr6bhyo4fru2	\N	WAVE	10300	\N	SUCCEEDED	2026-07-26 12:59:45.585
cms1t21bn00ktnr6bbq4jo0dl	cms1t21bn00kqnr6b5e07es4r	\N	MTN_MOMO	4200	\N	SUCCEEDED	2026-07-26 12:59:45.587
cms1t21bp00l0nr6bynx29qzp	cms1t21bp00kvnr6baim031ps	\N	CARD	7000	\N	SUCCEEDED	2026-07-26 12:59:45.59
cms1t21bs00l7nr6bew4o51jt	cms1t21bs00l2nr6b8whu69u9	\N	CARD	11500	\N	SUCCEEDED	2026-07-26 12:59:45.592
cms1t21bv00lenr6bpam5lxn5	cms1t21bu00l9nr6bjr0j79bs	\N	MTN_MOMO	5200	\N	SUCCEEDED	2026-07-26 12:59:45.595
cms1t21bx00ljnr6bhi8ftuy2	cms1t21bx00lgnr6b5p71e320	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:45.597
cms1t21bz00lqnr6byn3qq4hl	cms1t21bz00llnr6bmamgdq0v	\N	CELTIIS_CASH	10900	\N	SUCCEEDED	2026-07-26 12:59:45.6
cms1t21c200lwnr6bgby66l0e	cms1t21c200lsnr6b76pubzh4	\N	CASH	6400	\N	SUCCEEDED	2026-07-26 12:59:45.602
cms1t21c400m2nr6bez4fvfgb	cms1t21c400lynr6br9yvnhca	\N	CELTIIS_CASH	3300	\N	SUCCEEDED	2026-07-26 12:59:45.605
cms1t21c700m8nr6b6g88eupf	cms1t21c700m4nr6bei29qv5w	\N	MTN_MOMO	4500	\N	SUCCEEDED	2026-07-26 12:59:45.607
cms1t21c900mdnr6bn6sq0ob9	cms1t21c900manr6bzbebgnzp	\N	MOOV_MONEY	2100	\N	SUCCEEDED	2026-07-26 12:59:45.609
cms1t21cb00minr6b75ouaa5h	cms1t21cb00mfnr6bthg1yywh	\N	MOOV_MONEY	2300	\N	SUCCEEDED	2026-07-26 12:59:45.611
cms1t21cd00monr6b22t8xnxr	cms1t21cd00mknr6bzau6mwc7	\N	MOOV_MONEY	6500	\N	SUCCEEDED	2026-07-26 12:59:45.613
cms1t21cf00munr6b4vim2hrz	cms1t21cf00mqnr6b9c55rw3o	\N	WAVE	6400	\N	SUCCEEDED	2026-07-26 12:59:45.616
cms1t21ci00mznr6brhd4zjbf	cms1t21ci00mwnr6be0xu0q7q	\N	MTN_MOMO	350	\N	SUCCEEDED	2026-07-26 12:59:45.618
cms1t21ck00n4nr6bgpa2srf0	cms1t21ck00n1nr6bhj21i97u	\N	MTN_MOMO	4600	\N	SUCCEEDED	2026-07-26 12:59:45.62
cms1t21cm00n9nr6b94bpn5dt	cms1t21cm00n6nr6bawpzjbfi	\N	WAVE	1800	\N	SUCCEEDED	2026-07-26 12:59:45.622
cms1t21co00nfnr6bjmdj1z14	cms1t21co00nbnr6b27ez4uyu	\N	CELTIIS_CASH	3200	\N	SUCCEEDED	2026-07-26 12:59:45.625
cms1t21cr00nlnr6bu7dt81hv	cms1t21cr00nhnr6bpix9gjcq	\N	CELTIIS_CASH	5100	\N	SUCCEEDED	2026-07-26 12:59:45.627
cms1t21ct00nsnr6b3ojpv2ed	cms1t21ct00nnnr6byin90bde	\N	WAVE	5650	\N	SUCCEEDED	2026-07-26 12:59:45.63
cms1t21cw00nynr6b9yczz8ra	cms1t21cw00nunr6bweax036u	\N	CELTIIS_CASH	3900	\N	SUCCEEDED	2026-07-26 12:59:45.632
cms1t21cy00o4nr6bm53nysty	cms1t21cy00o0nr6b0a1vsv95	\N	MOOV_MONEY	6500	\N	SUCCEEDED	2026-07-26 12:59:45.635
cms1t21d100o9nr6bloti25vc	cms1t21d000o6nr6bg0mcmwzn	\N	WAVE	350	\N	SUCCEEDED	2026-07-26 12:59:45.637
cms1t21d300ofnr6bfk9ikazt	cms1t21d300obnr6bxx10mfz4	\N	MTN_MOMO	3600	\N	SUCCEEDED	2026-07-26 12:59:45.639
cms1t21d500oknr6br745jy8r	cms1t21d500ohnr6bby1ysuf9	\N	WAVE	2500	\N	SUCCEEDED	2026-07-26 12:59:45.641
cms1t21d700opnr6bwkb5jgrc	cms1t21d700omnr6bbu1zvs2n	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.644
cms1t21d900ownr6bvr2udz5i	cms1t21d900ornr6b7opnpj28	\N	CARD	8700	\N	SUCCEEDED	2026-07-26 12:59:45.646
cms1t21dc00p1nr6bwaeiff5c	cms1t21dc00oynr6bclcb5yea	\N	CASH	2900	\N	SUCCEEDED	2026-07-26 12:59:45.648
cms1t21de00p7nr6bbin0flnj	cms1t21de00p3nr6biawd5o48	\N	MOOV_MONEY	5200	\N	SUCCEEDED	2026-07-26 12:59:45.65
cms1t21dg00pdnr6bfjxx62fz	cms1t21dg00p9nr6bgdmg1n6z	\N	MTN_MOMO	11800	\N	SUCCEEDED	2026-07-26 12:59:45.653
cms1t21dj00pjnr6bddjk5na1	cms1t21dj00pfnr6bhwvfrbdy	\N	CASH	9600	\N	SUCCEEDED	2026-07-26 12:59:45.655
cms1t21dl00pqnr6bxp7vnp1n	cms1t21dl00plnr6bbu71uo2g	\N	CARD	7600	\N	SUCCEEDED	2026-07-26 12:59:45.658
cms1t21do00pvnr6bwtzg28ha	cms1t21do00psnr6b0doj3zsd	\N	MOOV_MONEY	2900	\N	SUCCEEDED	2026-07-26 12:59:45.66
cms1t21dq00q1nr6bsqf3vn63	cms1t21dq00pxnr6bx56uz32s	\N	MOOV_MONEY	3600	\N	SUCCEEDED	2026-07-26 12:59:45.662
cms1t21ds00q8nr6bdlbqqvsp	cms1t21ds00q3nr6bt1jem3vm	\N	CASH	8600	\N	SUCCEEDED	2026-07-26 12:59:45.665
cms1t21dv00qdnr6b74v6p8su	cms1t21dv00qanr6bw449e5zv	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:45.667
cms1t21dx00qinr6bpzxtnsy5	cms1t21dx00qfnr6bmj7ic24t	\N	CARD	1500	\N	SUCCEEDED	2026-07-26 12:59:45.669
cms1t21dz00qonr6be1mfe0h4	cms1t21dz00qknr6b6m1fed14	\N	CASH	3000	\N	SUCCEEDED	2026-07-26 12:59:45.672
cms1t21e200qunr6b4urogos8	cms1t21e200qqnr6b346gkjld	\N	MTN_MOMO	6100	\N	SUCCEEDED	2026-07-26 12:59:45.674
cms1t21e400r0nr6bi1xwkvxo	cms1t21e400qwnr6bwnum2h94	\N	MTN_MOMO	4800	\N	SUCCEEDED	2026-07-26 12:59:45.677
cms1t21e700r5nr6b0ttca0tq	cms1t21e700r2nr6b27yq1fdk	\N	MTN_MOMO	2200	\N	SUCCEEDED	2026-07-26 12:59:45.679
cms1t21e900rcnr6buzaln0ga	cms1t21e900r7nr6bt8cuoloo	\N	MOOV_MONEY	8400	\N	SUCCEEDED	2026-07-26 12:59:45.681
cms1t21ec00rhnr6belqfeyhl	cms1t21eb00renr6b0hcux5k7	\N	CARD	2100	\N	SUCCEEDED	2026-07-26 12:59:45.684
cms1t21ee00rnnr6bjr3milzy	cms1t21ee00rjnr6bpt9v3xld	\N	CELTIIS_CASH	5500	\N	SUCCEEDED	2026-07-26 12:59:45.686
cms1t21eg00rtnr6bkny0aaqu	cms1t21eg00rpnr6bx7ro9hdu	\N	CARD	4800	\N	SUCCEEDED	2026-07-26 12:59:45.689
cms1t21ej00s0nr6baumr818r	cms1t21ej00rvnr6bre43tkfy	\N	CELTIIS_CASH	6000	\N	SUCCEEDED	2026-07-26 12:59:45.691
cms1t21el00s5nr6bgr9skb58	cms1t21el00s2nr6bnew6jm5x	\N	CELTIIS_CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:45.694
cms1t21eo00scnr6b8gesrhxf	cms1t21eo00s7nr6bilyp3esk	\N	CARD	10200	\N	SUCCEEDED	2026-07-26 12:59:45.696
cms1t21er00sinr6bl79ufz83	cms1t21er00senr6ba5nh5nf8	\N	CARD	7800	\N	SUCCEEDED	2026-07-26 12:59:45.699
cms1t21eu00spnr6b3wost2vl	cms1t21eu00sknr6bkdwajpii	\N	MOOV_MONEY	5100	\N	SUCCEEDED	2026-07-26 12:59:45.702
cms1t21ew00sunr6bdyip3eqj	cms1t21ew00srnr6b4louos0w	\N	CELTIIS_CASH	700	\N	SUCCEEDED	2026-07-26 12:59:45.705
cms1t21ez00t1nr6b99s3csba	cms1t21ez00swnr6b8en21m0w	\N	WAVE	6800	\N	SUCCEEDED	2026-07-26 12:59:45.707
cms1t21f100t6nr6bscbzxn1y	cms1t21f100t3nr6bzzp1q38l	\N	WAVE	2100	\N	SUCCEEDED	2026-07-26 12:59:45.709
cms1t21f300tdnr6btbp7mpsw	cms1t21f300t8nr6bu4bcxvfg	\N	CASH	14000	\N	SUCCEEDED	2026-07-26 12:59:45.711
cms1t21f600tknr6bnk4t3q0w	cms1t21f600tfnr6b4cr0f7gm	\N	CARD	8300	\N	SUCCEEDED	2026-07-26 12:59:45.714
cms1t21f800trnr6b88ad30oa	cms1t21f800tmnr6bkgw5t0if	\N	CARD	8300	\N	SUCCEEDED	2026-07-26 12:59:45.716
cms1t21fb00tynr6bs6jroxj3	cms1t21fb00ttnr6bgonzdwz1	\N	CELTIIS_CASH	7600	\N	SUCCEEDED	2026-07-26 12:59:45.719
cms1t21fe00u3nr6b4s8a9wvq	cms1t21fe00u0nr6bc21qvimu	\N	CASH	1800	\N	SUCCEEDED	2026-07-26 12:59:45.722
cms1t21fg00uanr6bigf7tndj	cms1t21fg00u5nr6by9ts894h	\N	MOOV_MONEY	7300	\N	SUCCEEDED	2026-07-26 12:59:45.724
cms1t21fi00uhnr6b8ojuw2px	cms1t21fi00ucnr6bkxvue0z9	\N	CELTIIS_CASH	5900	\N	SUCCEEDED	2026-07-26 12:59:45.726
cms1t21fk00umnr6bweuovzd9	cms1t21fk00ujnr6but2q7xab	\N	MOOV_MONEY	2900	\N	SUCCEEDED	2026-07-26 12:59:45.729
cms1t21fm00usnr6b7ri8gu6g	cms1t21fm00uonr6bo4b4lu84	\N	CASH	4700	\N	SUCCEEDED	2026-07-26 12:59:45.731
cms1t21fo00uxnr6bkkosa5nz	cms1t21fo00uunr6b95xpw4fz	\N	MOOV_MONEY	1500	\N	SUCCEEDED	2026-07-26 12:59:45.733
cms1t21fq00v2nr6bccaqyew7	cms1t21fq00uznr6b8wdqj5xf	\N	MOOV_MONEY	4600	\N	SUCCEEDED	2026-07-26 12:59:45.735
cms1t21fs00v7nr6bxl28aafi	cms1t21fs00v4nr6btu2s5j20	\N	MOOV_MONEY	6800	\N	SUCCEEDED	2026-07-26 12:59:45.737
cms1t21fv00venr6brm6xs4rj	cms1t21fu00v9nr6bq5bh8i1c	\N	WAVE	7900	\N	SUCCEEDED	2026-07-26 12:59:45.739
cms1t21fx00vlnr6bx6dnq6w3	cms1t21fx00vgnr6b122qi9mk	\N	MOOV_MONEY	5200	\N	SUCCEEDED	2026-07-26 12:59:45.741
cms1t21fz00vrnr6bth6j2pnb	cms1t21fz00vnnr6bu7to0r6z	\N	CASH	5900	\N	SUCCEEDED	2026-07-26 12:59:45.744
cms1t21g200vynr6b8ltd80ne	cms1t21g200vtnr6bnscq2gnk	\N	WAVE	8900	\N	SUCCEEDED	2026-07-26 12:59:45.746
cms1t21g400w3nr6bumylwrla	cms1t21g400w0nr6bqrpl27jm	\N	WAVE	5800	\N	SUCCEEDED	2026-07-26 12:59:45.749
cms1t21g700w8nr6b8jybb8xc	cms1t21g600w5nr6b29tnqvk8	\N	CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:45.751
cms1t21g900wenr6bquwj8zt8	cms1t21g900wanr6bgspc3fx0	\N	CELTIIS_CASH	5300	\N	SUCCEEDED	2026-07-26 12:59:45.753
cms1t21gb00wjnr6bt3pjpdt9	cms1t21gb00wgnr6bo7fksqxi	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.756
cms1t21gd00wonr6batlj959y	cms1t21gd00wlnr6bk6jvtq4y	\N	MOOV_MONEY	2500	\N	SUCCEEDED	2026-07-26 12:59:45.758
cms1t21gg00wunr6baxnegkoj	cms1t21gg00wqnr6b3lq4noue	\N	MTN_MOMO	6600	\N	SUCCEEDED	2026-07-26 12:59:45.76
cms1t21gj00x0nr6b00ge5ok1	cms1t21gi00wwnr6bht153dzm	\N	CARD	2600	\N	SUCCEEDED	2026-07-26 12:59:45.763
cms1t21gl00x5nr6bvi34ik3l	cms1t21gl00x2nr6bgle6m1o1	\N	CARD	1400	\N	SUCCEEDED	2026-07-26 12:59:45.765
cms1t21gn00xcnr6bspg5ciuk	cms1t21gn00x7nr6bs4lm2wit	\N	CARD	12600	\N	SUCCEEDED	2026-07-26 12:59:45.768
cms1t21gq00xhnr6b3sxo57o4	cms1t21gq00xenr6buivx9d0s	\N	CELTIIS_CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:45.77
cms1t21gs00xmnr6biss0wev2	cms1t21gs00xjnr6bm5vck9cs	\N	MOOV_MONEY	2200	\N	SUCCEEDED	2026-07-26 12:59:45.772
cms1t21gu00xtnr6beofc7xns	cms1t21gu00xonr6bfqfx1u0m	\N	CELTIIS_CASH	7900	\N	SUCCEEDED	2026-07-26 12:59:45.775
cms1t21gx00xynr6bcc0q2i0z	cms1t21gx00xvnr6b9xp258p5	\N	CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:45.777
cms1t21gz00y5nr6b2m686ht8	cms1t21gz00y0nr6b4s6kz5eh	\N	WAVE	7100	\N	SUCCEEDED	2026-07-26 12:59:45.779
cms1t21h200ycnr6bxc6s7nzl	cms1t21h200y7nr6b9yu34bvf	\N	WAVE	12200	\N	SUCCEEDED	2026-07-26 12:59:45.782
cms1t21h500yhnr6bcjisnpm7	cms1t21h500yenr6bxjrrxgnm	\N	CASH	1100	\N	SUCCEEDED	2026-07-26 12:59:45.785
cms1t21h700yonr6b6krow03s	cms1t21h700yjnr6bmcvf7rrs	\N	MTN_MOMO	9100	\N	SUCCEEDED	2026-07-26 12:59:45.787
cms1t21ha00yvnr6bdotbfv1x	cms1t21ha00yqnr6b3ifcejx6	\N	CELTIIS_CASH	7450	\N	SUCCEEDED	2026-07-26 12:59:45.79
cms1t21hc00z2nr6bem8f1y0p	cms1t21hc00yxnr6bt0jzcftr	\N	MOOV_MONEY	6850	\N	SUCCEEDED	2026-07-26 12:59:45.793
cms1t21hf00z7nr6babdu3m9f	cms1t21hf00z4nr6bml7nyjvu	\N	CASH	5800	\N	SUCCEEDED	2026-07-26 12:59:45.795
cms1t21hh00zenr6btl2zr8kv	cms1t21hh00z9nr6b7gnyzrvp	\N	CARD	11100	\N	SUCCEEDED	2026-07-26 12:59:45.797
cms1t21hj00zlnr6bviyxou36	cms1t21hj00zgnr6b3d6rb0jp	\N	CASH	4450	\N	SUCCEEDED	2026-07-26 12:59:45.8
cms1t21hm00zrnr6bnxjb0out	cms1t21hm00znnr6b36ldufcw	\N	WAVE	6700	\N	SUCCEEDED	2026-07-26 12:59:45.802
cms1t21hp00zynr6bonaifki7	cms1t21ho00ztnr6b290lu4ts	\N	MTN_MOMO	9700	\N	SUCCEEDED	2026-07-26 12:59:45.805
cms1t21hr0104nr6bnvgpui4l	cms1t21hr0100nr6b672wbsw1	\N	MTN_MOMO	5700	\N	SUCCEEDED	2026-07-26 12:59:45.807
cms1t21ht0109nr6bvvfcgr9d	cms1t21ht0106nr6bw823eghw	\N	CELTIIS_CASH	2200	\N	SUCCEEDED	2026-07-26 12:59:45.809
cms1t21hv010enr6b5ia30psr	cms1t21hv010bnr6bs3sv5s5v	\N	CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:45.812
cms1t21hx010knr6bvj448e9b	cms1t21hx010gnr6bvb59eldp	\N	WAVE	3200	\N	SUCCEEDED	2026-07-26 12:59:45.814
cms1t21i0010rnr6b7g92k26w	cms1t21i0010mnr6b00vutqjx	\N	MOOV_MONEY	10500	\N	SUCCEEDED	2026-07-26 12:59:45.816
cms1t21i2010ynr6bxic8a2f7	cms1t21i2010tnr6b9rc0tep1	\N	CASH	6200	\N	SUCCEEDED	2026-07-26 12:59:45.819
cms1t21i40115nr6buy8gj74l	cms1t21i40110nr6b0lbhicne	\N	MOOV_MONEY	7350	\N	SUCCEEDED	2026-07-26 12:59:45.821
cms1t21i7011cnr6bjyeynu9z	cms1t21i70117nr6bx4gm7ylk	\N	MTN_MOMO	8900	\N	SUCCEEDED	2026-07-26 12:59:45.823
cms1t21i9011inr6bzw0xgh9n	cms1t21i9011enr6bvqv7w1ge	\N	CARD	4400	\N	SUCCEEDED	2026-07-26 12:59:45.825
cms1t21ib011onr6bomja16dc	cms1t21ib011knr6b0uwbzrob	\N	MOOV_MONEY	9000	\N	SUCCEEDED	2026-07-26 12:59:45.827
cms1t21id011vnr6bus19nx1u	cms1t21id011qnr6bosyu3hq8	\N	WAVE	10700	\N	SUCCEEDED	2026-07-26 12:59:45.83
cms1t21ig0120nr6brq0nv0cr	cms1t21ig011xnr6be2iec6kx	\N	MOOV_MONEY	700	\N	SUCCEEDED	2026-07-26 12:59:45.832
cms1t21ii0125nr6bom2dx9ne	cms1t21ih0122nr6b12v44rid	\N	WAVE	1800	\N	SUCCEEDED	2026-07-26 12:59:45.834
cms1t21ij012bnr6b9m1gauk4	cms1t21ij0127nr6b5q8rr7j1	\N	CELTIIS_CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:45.836
cms1t21im012gnr6b1sw702s8	cms1t21im012dnr6b647v15yc	\N	CELTIIS_CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:45.838
cms1t21io012lnr6b79u2sefz	cms1t21io012inr6bwr4t1oym	\N	MOOV_MONEY	2100	\N	SUCCEEDED	2026-07-26 12:59:45.84
cms1t21iq012qnr6b32lvjpwd	cms1t21iq012nnr6b33nfy9es	\N	MTN_MOMO	6800	\N	SUCCEEDED	2026-07-26 12:59:45.842
cms1t21is012xnr6bv64u40hd	cms1t21is012snr6bmjoeyhq0	\N	CELTIIS_CASH	5100	\N	SUCCEEDED	2026-07-26 12:59:45.844
cms1t21iu0132nr6bno3kctpm	cms1t21iu012znr6bwioqu3jx	\N	CARD	4200	\N	SUCCEEDED	2026-07-26 12:59:45.846
cms1t21iw0138nr6b3ksv4wh1	cms1t21iw0134nr6b7sxqx0k3	\N	MTN_MOMO	6900	\N	SUCCEEDED	2026-07-26 12:59:45.848
cms1t21iy013enr6bhbxrplio	cms1t21iy013anr6bep0qcefq	\N	MOOV_MONEY	7150	\N	SUCCEEDED	2026-07-26 12:59:45.851
cms1t21j2013lnr6bhmol37xr	cms1t21j1013gnr6bfij6qx1k	\N	WAVE	8200	\N	SUCCEEDED	2026-07-26 12:59:45.854
cms1t21j6013qnr6bxgi6j8v2	cms1t21j6013nnr6bimohuiwe	\N	CARD	3000	\N	SUCCEEDED	2026-07-26 12:59:45.858
cms1t21j9013xnr6bj9fsk8ux	cms1t21j9013snr6b11jfvt44	\N	MOOV_MONEY	6400	\N	SUCCEEDED	2026-07-26 12:59:45.861
cms1t21jc0142nr6b9tgytk34	cms1t21jc013znr6boqqmt3w8	\N	CASH	3400	\N	SUCCEEDED	2026-07-26 12:59:45.864
cms1t21je0148nr6b5ibjjb9d	cms1t21je0144nr6b36d1audi	\N	CARD	5800	\N	SUCCEEDED	2026-07-26 12:59:45.866
cms1t21jg014fnr6bzxrmg95r	cms1t21jg014anr6b5ks76ybr	\N	CASH	6600	\N	SUCCEEDED	2026-07-26 12:59:45.869
cms1t21jj014knr6b3vat5b18	cms1t21jj014hnr6bo8tyahe6	\N	CASH	700	\N	SUCCEEDED	2026-07-26 12:59:45.871
cms1t21jl014rnr6bo6319gek	cms1t21jl014mnr6b6dx4m3qp	\N	MTN_MOMO	3200	\N	SUCCEEDED	2026-07-26 12:59:45.873
cms1t21jn014ynr6b004t6zfq	cms1t21jn014tnr6b40ctsh2f	\N	WAVE	10200	\N	SUCCEEDED	2026-07-26 12:59:45.876
cms1t21jq0154nr6bgx4hp9t5	cms1t21jq0150nr6bsomeg2pe	\N	MOOV_MONEY	7100	\N	SUCCEEDED	2026-07-26 12:59:45.878
cms1t21js0159nr6bzrzzp3mp	cms1t21js0156nr6bbxikvt54	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.88
cms1t21ju015fnr6bpgt63hqi	cms1t21ju015bnr6b4gkhcvcz	\N	CASH	3900	\N	SUCCEEDED	2026-07-26 12:59:45.883
cms1t21jw015lnr6b2zcodfsw	cms1t21jw015hnr6bkbvwi9z2	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:45.885
cms1t21jz015rnr6bqrgicblf	cms1t21jz015nnr6b433ro2es	\N	MTN_MOMO	3700	\N	SUCCEEDED	2026-07-26 12:59:45.887
cms1t21k1015ynr6bty5wst0i	cms1t21k1015tnr6bupz4kxrl	\N	CARD	2850	\N	SUCCEEDED	2026-07-26 12:59:45.89
cms1t21k40165nr6bbljm3abx	cms1t21k40160nr6bk0zube5e	\N	CASH	10500	\N	SUCCEEDED	2026-07-26 12:59:45.892
cms1t21k7016bnr6bdmsdw19v	cms1t21k70167nr6b3za04rro	\N	CARD	5000	\N	SUCCEEDED	2026-07-26 12:59:45.895
cms1t21ka016inr6bywm8a8pt	cms1t21ka016dnr6bc1kau2ru	\N	MOOV_MONEY	6250	\N	SUCCEEDED	2026-07-26 12:59:45.898
cms1t21kd016onr6bvxsdiiwk	cms1t21kd016knr6bynw4qvhn	\N	CASH	11800	\N	SUCCEEDED	2026-07-26 12:59:45.901
cms1t21kh016unr6b3erpdmsm	cms1t21kh016qnr6b8edt2eug	\N	CASH	3200	\N	SUCCEEDED	2026-07-26 12:59:45.905
cms1t21kl016znr6byta1i41h	cms1t21kl016wnr6bpyqt49qr	\N	CARD	4200	\N	SUCCEEDED	2026-07-26 12:59:45.909
cms1t21kp0176nr6be4gkd9q4	cms1t21kp0171nr6bxwu9clt0	\N	MTN_MOMO	10600	\N	SUCCEEDED	2026-07-26 12:59:45.913
cms1t21ks017cnr6ba2gt68pu	cms1t21ks0178nr6b1yejxftr	\N	CARD	8400	\N	SUCCEEDED	2026-07-26 12:59:45.916
cms1t21kw017jnr6b1rtt498w	cms1t21kv017enr6by48fe9gg	\N	CARD	6300	\N	SUCCEEDED	2026-07-26 12:59:45.92
cms1t21ky017pnr6b2rtzyqhf	cms1t21ky017lnr6bonti9qqm	\N	MOOV_MONEY	2850	\N	SUCCEEDED	2026-07-26 12:59:45.923
cms1t21l1017vnr6bnggw51qa	cms1t21l1017rnr6b1d5t7hwn	\N	CARD	6000	\N	SUCCEEDED	2026-07-26 12:59:45.926
cms1t21l50180nr6bgvkxnj3o	cms1t21l5017xnr6bjy8z0zpi	\N	CARD	2300	\N	SUCCEEDED	2026-07-26 12:59:45.929
cms1t21l90186nr6blzotpd37	cms1t21l90182nr6bxfa5dnm0	\N	MOOV_MONEY	6500	\N	SUCCEEDED	2026-07-26 12:59:45.933
cms1t21lc018cnr6bdagrer8z	cms1t21lc0188nr6b1kk8hhtl	\N	CELTIIS_CASH	2450	\N	SUCCEEDED	2026-07-26 12:59:45.936
cms1t21lw018inr6bsb6a5l3c	cms1t21lw018enr6b7e0dw4f8	\N	MTN_MOMO	3400	\N	SUCCEEDED	2026-07-26 12:59:45.939
cms1t21m3018nnr6bxhibffvt	cms1t21m3018knr6buw28gvm1	\N	MOOV_MONEY	2100	\N	SUCCEEDED	2026-07-26 12:59:45.963
cms1t21m6018unr6bw5bxugu0	cms1t21m6018pnr6bx376rwob	\N	MTN_MOMO	5500	\N	SUCCEEDED	2026-07-26 12:59:45.967
cms1t21ma0190nr6bedeslkze	cms1t21m9018wnr6b9gpzkcg1	\N	CARD	9100	\N	SUCCEEDED	2026-07-26 12:59:45.97
cms1t21mc0195nr6b9mv5b8qc	cms1t21mc0192nr6b8pfo5trf	\N	CELTIIS_CASH	3000	\N	SUCCEEDED	2026-07-26 12:59:45.973
cms1t21mf019bnr6bzhgzl8uk	cms1t21mf0197nr6b88c47l9u	\N	MTN_MOMO	7100	\N	SUCCEEDED	2026-07-26 12:59:45.975
cms1t21mi019inr6b0x2jpo0v	cms1t21mi019dnr6br4c7mmpi	\N	CELTIIS_CASH	8100	\N	SUCCEEDED	2026-07-26 12:59:45.978
cms1t21mk019onr6b9qm89ly1	cms1t21mk019knr6bpqs0866s	\N	CELTIIS_CASH	3200	\N	SUCCEEDED	2026-07-26 12:59:45.981
cms1t21mn019unr6b7mapb0q7	cms1t21mn019qnr6bzusa5h4s	\N	CELTIIS_CASH	8800	\N	SUCCEEDED	2026-07-26 12:59:45.983
cms1t21mp01a1nr6bf52cb359	cms1t21mp019wnr6b3mf06eec	\N	CARD	6800	\N	SUCCEEDED	2026-07-26 12:59:45.985
cms1t21ms01a7nr6b7ub9mket	cms1t21mr01a3nr6bdrh3l8p4	\N	WAVE	4000	\N	SUCCEEDED	2026-07-26 12:59:45.988
cms1t21mu01acnr6bkrml8hr0	cms1t21mu01a9nr6bi6gvhewi	\N	MOOV_MONEY	5800	\N	SUCCEEDED	2026-07-26 12:59:45.99
cms1t21mw01ahnr6bew8ooh64	cms1t21mw01aenr6brw2jjku8	\N	MTN_MOMO	5800	\N	SUCCEEDED	2026-07-26 12:59:45.993
cms1t21mz01annr6bbhf3e9it	cms1t21mz01ajnr6bqxl94cbi	\N	CARD	11000	\N	SUCCEEDED	2026-07-26 12:59:45.995
cms1t21n101asnr6bl4snp1dw	cms1t21n101apnr6bo4zgr2xa	\N	WAVE	3000	\N	SUCCEEDED	2026-07-26 12:59:45.998
cms1t21n401aynr6b9abxzrsc	cms1t21n401aunr6bgtjhlmzg	\N	CARD	7200	\N	SUCCEEDED	2026-07-26 12:59:46
cms1t21na01b3nr6bugfd071n	cms1t21na01b0nr6bp2q82rfu	\N	CASH	3600	\N	SUCCEEDED	2026-07-26 12:59:46.006
cms1t21nd01b8nr6bqhmoh0si	cms1t21nd01b5nr6bywia663s	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.009
cms1t21nf01bfnr6betqc6cl1	cms1t21nf01banr6bz3tw4ujr	\N	MOOV_MONEY	5200	\N	SUCCEEDED	2026-07-26 12:59:46.011
cms1t21nh01bknr6bqpbhpr5l	cms1t21nh01bhnr6bj1vulbz7	\N	CASH	5800	\N	SUCCEEDED	2026-07-26 12:59:46.013
cms1t21nj01bqnr6bqufy44y4	cms1t21nj01bmnr6bc3rufpj6	\N	MTN_MOMO	4300	\N	SUCCEEDED	2026-07-26 12:59:46.015
cms1t21nm01bxnr6b6qhivuff	cms1t21nm01bsnr6bbyntqzbd	\N	MOOV_MONEY	7800	\N	SUCCEEDED	2026-07-26 12:59:46.018
cms1t21np01c4nr6bs9hkxf5q	cms1t21np01bznr6bmsgxix2r	\N	CARD	5400	\N	SUCCEEDED	2026-07-26 12:59:46.021
cms1t21nr01cbnr6b5ymvhefw	cms1t21nr01c6nr6baqrhnzif	\N	WAVE	8000	\N	SUCCEEDED	2026-07-26 12:59:46.024
cms1t21nu01chnr6btocd3e73	cms1t21nu01cdnr6bnk7t3xjq	\N	MOOV_MONEY	3700	\N	SUCCEEDED	2026-07-26 12:59:46.026
cms1t21nw01cmnr6b7g1427kq	cms1t21nw01cjnr6bd2sgtleh	\N	MTN_MOMO	2500	\N	SUCCEEDED	2026-07-26 12:59:46.029
cms1t21nz01ctnr6bl1jtlct9	cms1t21nz01conr6b1tq8bfss	\N	WAVE	11600	\N	SUCCEEDED	2026-07-26 12:59:46.031
cms1t21o201cznr6bkj4jjnpn	cms1t21o101cvnr6b2nlbu2y8	\N	MTN_MOMO	2850	\N	SUCCEEDED	2026-07-26 12:59:46.034
cms1t21o501d6nr6bfydl2ndd	cms1t21o501d1nr6bh0jqxkkt	\N	CASH	8000	\N	SUCCEEDED	2026-07-26 12:59:46.037
cms1t21o801dcnr6bsupwnel1	cms1t21o801d8nr6blyjjjn61	\N	CELTIIS_CASH	4950	\N	SUCCEEDED	2026-07-26 12:59:46.04
cms1t21oa01dinr6burzn6kra	cms1t21oa01denr6bnzh82u99	\N	CELTIIS_CASH	3500	\N	SUCCEEDED	2026-07-26 12:59:46.043
cms1t21od01donr6b8r8538da	cms1t21od01dknr6bflzw13d4	\N	WAVE	6100	\N	SUCCEEDED	2026-07-26 12:59:46.045
cms1t21og01dvnr6bmf6piutx	cms1t21of01dqnr6b048d2cn2	\N	WAVE	13200	\N	SUCCEEDED	2026-07-26 12:59:46.048
cms1t21oi01e2nr6bengboyq1	cms1t21oi01dxnr6bfyxho4ij	\N	CELTIIS_CASH	9000	\N	SUCCEEDED	2026-07-26 12:59:46.05
cms1t21ok01e9nr6bqg453ksc	cms1t21ok01e4nr6bxqdp0t1n	\N	CELTIIS_CASH	7900	\N	SUCCEEDED	2026-07-26 12:59:46.053
cms1t21on01egnr6befmt5br5	cms1t21on01ebnr6blbs40dol	\N	MOOV_MONEY	7100	\N	SUCCEEDED	2026-07-26 12:59:46.055
cms1t21op01elnr6bzum1cplg	cms1t21op01einr6boyo17w88	\N	MTN_MOMO	5800	\N	SUCCEEDED	2026-07-26 12:59:46.058
cms1t21or01esnr6b0jmajfoh	cms1t21or01ennr6bnk48dmr5	\N	CELTIIS_CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:46.06
cms1t21ou01exnr6btcbxv2eb	cms1t21ou01eunr6bu7r05v5u	\N	CELTIIS_CASH	1400	\N	SUCCEEDED	2026-07-26 12:59:46.062
cms1t21ox01f4nr6bglre7s49	cms1t21ox01eznr6bwx77v6kr	\N	CARD	8000	\N	SUCCEEDED	2026-07-26 12:59:46.065
cms1t21oz01fbnr6bn6htskfo	cms1t21oz01f6nr6bzibjpsdc	\N	WAVE	4850	\N	SUCCEEDED	2026-07-26 12:59:46.068
cms1t21p201fhnr6bwoprcbu5	cms1t21p201fdnr6b17gfrlc1	\N	MTN_MOMO	3600	\N	SUCCEEDED	2026-07-26 12:59:46.07
cms1t21p401fonr6b6mhww094	cms1t21p401fjnr6b5vjyw52m	\N	MOOV_MONEY	7200	\N	SUCCEEDED	2026-07-26 12:59:46.072
cms1t21p701fvnr6bdmquec4j	cms1t21p701fqnr6bftgxdu8b	\N	WAVE	11800	\N	SUCCEEDED	2026-07-26 12:59:46.075
cms1t21p901g1nr6bxgttxu18	cms1t21p901fxnr6b6r26saw9	\N	CASH	3700	\N	SUCCEEDED	2026-07-26 12:59:46.078
cms1t21pc01g6nr6bvdka7ktu	cms1t21pc01g3nr6bgqlayrhw	\N	MOOV_MONEY	1500	\N	SUCCEEDED	2026-07-26 12:59:46.08
cms1t21pe01gbnr6bm64b7a8o	cms1t21pe01g8nr6b762lvarh	\N	CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:46.082
cms1t21ph01ginr6bhgeyf6e1	cms1t21pg01gdnr6brinwn2ea	\N	MOOV_MONEY	5850	\N	SUCCEEDED	2026-07-26 12:59:46.085
cms1t21pj01gnnr6be38cef3s	cms1t21pj01gknr6bcyf911kk	\N	WAVE	2500	\N	SUCCEEDED	2026-07-26 12:59:46.088
cms1t21pl01gunr6bj32ullyv	cms1t21pl01gpnr6boe5pazdq	\N	WAVE	14400	\N	SUCCEEDED	2026-07-26 12:59:46.09
cms1t21po01h1nr6b9qrfc3no	cms1t21po01gwnr6bwt0585ve	\N	WAVE	12600	\N	SUCCEEDED	2026-07-26 12:59:46.093
cms1t21pr01h6nr6btp0irm5c	cms1t21pr01h3nr6buzqckh7j	\N	CARD	4200	\N	SUCCEEDED	2026-07-26 12:59:46.095
cms1t21pu01hbnr6b6pmdeymx	cms1t21pt01h8nr6bb1789ohc	\N	WAVE	5800	\N	SUCCEEDED	2026-07-26 12:59:46.098
cms1t21pw01hgnr6bayckiwyj	cms1t21pw01hdnr6bpk78v3da	\N	MTN_MOMO	3600	\N	SUCCEEDED	2026-07-26 12:59:46.1
cms1t21py01hlnr6b1j8ppdth	cms1t21py01hinr6bas7ddxu0	\N	MTN_MOMO	1100	\N	SUCCEEDED	2026-07-26 12:59:46.103
cms1t21q001hsnr6b3yf4sb7o	cms1t21q001hnnr6bgugtfpsx	\N	MOOV_MONEY	9000	\N	SUCCEEDED	2026-07-26 12:59:46.105
cms1t21q301hxnr6b3wjocxg7	cms1t21q301hunr6bjjnucpzs	\N	CARD	700	\N	SUCCEEDED	2026-07-26 12:59:46.107
cms1t21q501i4nr6bq8b8aal5	cms1t21q501hznr6b8se6hy21	\N	MTN_MOMO	4950	\N	SUCCEEDED	2026-07-26 12:59:46.109
cms1t21q701ianr6bc0x03jvc	cms1t21q701i6nr6bfowewc32	\N	WAVE	4900	\N	SUCCEEDED	2026-07-26 12:59:46.112
cms1t21qa01ignr6ba6ndvr4a	cms1t21qa01icnr6bha6e0itf	\N	CELTIIS_CASH	5500	\N	SUCCEEDED	2026-07-26 12:59:46.114
cms1t21qc01imnr6b90rky7d6	cms1t21qc01iinr6btndf8jlw	\N	WAVE	4000	\N	SUCCEEDED	2026-07-26 12:59:46.116
cms1t21qe01isnr6bjtlrw9pf	cms1t21qe01ionr6br9l4jli1	\N	MOOV_MONEY	4100	\N	SUCCEEDED	2026-07-26 12:59:46.119
cms1t21qh01ixnr6biabj1yyr	cms1t21qh01iunr6b5aeo3bay	\N	CASH	1500	\N	SUCCEEDED	2026-07-26 12:59:46.122
cms1t21qj01j4nr6bs57cg7py	cms1t21qj01iznr6bpaysrfgy	\N	MOOV_MONEY	3900	\N	SUCCEEDED	2026-07-26 12:59:46.124
cms1t21qm01j9nr6b3yrujllo	cms1t21qm01j6nr6b2wokanmo	\N	CELTIIS_CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:46.126
cms1t21qo01jgnr6b5qkd86ni	cms1t21qo01jbnr6bvutbbrz6	\N	CASH	10600	\N	SUCCEEDED	2026-07-26 12:59:46.128
cms1t21qq01jmnr6bbivg0kot	cms1t21qq01jinr6b0falh4pm	\N	MTN_MOMO	9200	\N	SUCCEEDED	2026-07-26 12:59:46.131
cms1t21qt01jtnr6ba1axa17u	cms1t21qt01jonr6b61cufjsk	\N	CARD	12900	\N	SUCCEEDED	2026-07-26 12:59:46.133
cms1t21qv01k0nr6brdlf9b3b	cms1t21qv01jvnr6bsreh7qbl	\N	CELTIIS_CASH	6200	\N	SUCCEEDED	2026-07-26 12:59:46.136
cms1t21qx01k5nr6bbpbxb7u1	cms1t21qx01k2nr6boofc333a	\N	MOOV_MONEY	700	\N	SUCCEEDED	2026-07-26 12:59:46.138
cms1t21qz01kbnr6bbude97e3	cms1t21qz01k7nr6b9d6xnj0s	\N	WAVE	3250	\N	SUCCEEDED	2026-07-26 12:59:46.14
cms1t21r201kgnr6brnll9c4v	cms1t21r201kdnr6bme9f7gz2	\N	CARD	4600	\N	SUCCEEDED	2026-07-26 12:59:46.142
cms1t21r401kmnr6bnu6bz1fu	cms1t21r301kinr6by2ccr6hj	\N	CARD	11800	\N	SUCCEEDED	2026-07-26 12:59:46.144
cms1t21r601ktnr6bvtp2tfuq	cms1t21r601konr6b08cpv61m	\N	CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:46.146
cms1t21r801l0nr6b1uv7ag7h	cms1t21r801kvnr6brwyuvaqb	\N	WAVE	7000	\N	SUCCEEDED	2026-07-26 12:59:46.148
cms1t21ra01l5nr6bjcnxh9cq	cms1t21ra01l2nr6bltgzzsx3	\N	MTN_MOMO	2300	\N	SUCCEEDED	2026-07-26 12:59:46.15
cms1t21rc01lbnr6by2rzkqyo	cms1t21rc01l7nr6b5nvne3at	\N	CARD	5900	\N	SUCCEEDED	2026-07-26 12:59:46.153
cms1t21rf01lgnr6boqecgodn	cms1t21rf01ldnr6bvjisa8ib	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.156
cms1t21ri01lnnr6bi3kdk22y	cms1t21rh01linr6bd61bidpa	\N	CELTIIS_CASH	10200	\N	SUCCEEDED	2026-07-26 12:59:46.158
cms1t21rk01ltnr6bvog381fz	cms1t21rk01lpnr6brd79qkzc	\N	CARD	6500	\N	SUCCEEDED	2026-07-26 12:59:46.16
cms1t21rm01lznr6bt6a5wbzz	cms1t21rm01lvnr6bosudv5f2	\N	CASH	5700	\N	SUCCEEDED	2026-07-26 12:59:46.162
cms1t21ro01m5nr6bysf8tvz8	cms1t21ro01m1nr6b1r6yoexv	\N	CARD	4300	\N	SUCCEEDED	2026-07-26 12:59:46.165
cms1t21rr01manr6bzeso2r2c	cms1t21rr01m7nr6bqru6sgtf	\N	WAVE	1100	\N	SUCCEEDED	2026-07-26 12:59:46.167
cms1t21rt01mfnr6bgqva6ywf	cms1t21rt01mcnr6bx6ezv5cq	\N	WAVE	3000	\N	SUCCEEDED	2026-07-26 12:59:46.169
cms1t21rv01mlnr6bzjub20lp	cms1t21rv01mhnr6bhedjoaup	\N	CARD	10000	\N	SUCCEEDED	2026-07-26 12:59:46.171
cms1t21rx01msnr6b7kxvgg6t	cms1t21rx01mnnr6bc6c3ra5w	\N	MOOV_MONEY	6500	\N	SUCCEEDED	2026-07-26 12:59:46.173
cms1t21rz01mznr6bjkgb0dm7	cms1t21rz01munr6bu3vo8w63	\N	CASH	5900	\N	SUCCEEDED	2026-07-26 12:59:46.176
cms1t21s201n5nr6be1br7f3x	cms1t21s201n1nr6b190lovdq	\N	WAVE	5700	\N	SUCCEEDED	2026-07-26 12:59:46.178
cms1t21s401nbnr6b7o2cuzsm	cms1t21s401n7nr6b6j0n2wmg	\N	MOOV_MONEY	4800	\N	SUCCEEDED	2026-07-26 12:59:46.18
cms1t21s601nhnr6b81gq2a03	cms1t21s601ndnr6bhzy9owuw	\N	WAVE	4600	\N	SUCCEEDED	2026-07-26 12:59:46.183
cms1t21s901nnnr6b4qy0vqmm	cms1t21s901njnr6b1bvxk09t	\N	MTN_MOMO	2100	\N	SUCCEEDED	2026-07-26 12:59:46.185
cms1t21sb01ntnr6bqq27xo0c	cms1t21sb01npnr6bcibrja3y	\N	WAVE	6500	\N	SUCCEEDED	2026-07-26 12:59:46.187
cms1t21sd01o0nr6by7zzywyc	cms1t21sd01nvnr6bmbil8szw	\N	CASH	10600	\N	SUCCEEDED	2026-07-26 12:59:46.189
cms1t21sf01o5nr6b4mh4xb9o	cms1t21sf01o2nr6bb902fqmi	\N	CELTIIS_CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:46.192
cms1t21sh01oanr6bwq1wovt5	cms1t21sh01o7nr6b0oseoyaq	\N	CARD	3600	\N	SUCCEEDED	2026-07-26 12:59:46.194
cms1t21sj01ognr6bamp4gcn5	cms1t21sj01ocnr6ba3hlg71z	\N	WAVE	3600	\N	SUCCEEDED	2026-07-26 12:59:46.196
cms1t21sm01onnr6b8jcepxrl	cms1t21sl01oinr6bt23vciq6	\N	WAVE	6800	\N	SUCCEEDED	2026-07-26 12:59:46.198
cms1t21so01osnr6bleu26jsz	cms1t21so01opnr6bkn7iwk9u	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:46.2
cms1t21sq01oynr6bu43qysho	cms1t21sq01ounr6b5yl2vfuq	\N	CARD	4300	\N	SUCCEEDED	2026-07-26 12:59:46.202
cms1t21ss01p5nr6bavmnx8g6	cms1t21ss01p0nr6b2fbekyn9	\N	WAVE	5400	\N	SUCCEEDED	2026-07-26 12:59:46.204
cms1t21sv01panr6bhkzulphg	cms1t21su01p7nr6bfr3zersm	\N	WAVE	1100	\N	SUCCEEDED	2026-07-26 12:59:46.207
cms1t21sx01phnr6b79nlud4u	cms1t21sx01pcnr6b7u2sqbxv	\N	MOOV_MONEY	11200	\N	SUCCEEDED	2026-07-26 12:59:46.209
cms1t21sz01pnnr6bewruuvoc	cms1t21sz01pjnr6bvfqmd77z	\N	MTN_MOMO	6500	\N	SUCCEEDED	2026-07-26 12:59:46.211
cms1t21t101ptnr6bf4v2s5kn	cms1t21t101ppnr6bwaiyhqoh	\N	CASH	6700	\N	SUCCEEDED	2026-07-26 12:59:46.214
cms1t21t301pznr6baohryuvm	cms1t21t301pvnr6b2bqiap6p	\N	CELTIIS_CASH	11800	\N	SUCCEEDED	2026-07-26 12:59:46.216
cms1t21t601q6nr6b5ta5eywg	cms1t21t601q1nr6b97y7kcwm	\N	CELTIIS_CASH	6200	\N	SUCCEEDED	2026-07-26 12:59:46.218
cms1t21t801qbnr6b0w2omv7r	cms1t21t801q8nr6bzolyuxeh	\N	CARD	1400	\N	SUCCEEDED	2026-07-26 12:59:46.22
cms1t21ta01qinr6b6i9e604t	cms1t21ta01qdnr6bxxfp5luz	\N	CELTIIS_CASH	7600	\N	SUCCEEDED	2026-07-26 12:59:46.223
cms1t21td01qonr6b701xgbaf	cms1t21tc01qknr6bwxv65i4w	\N	CASH	9400	\N	SUCCEEDED	2026-07-26 12:59:46.225
cms1t21tf01qunr6bpc4cicwq	cms1t21tf01qqnr6bhhpfdgv1	\N	CASH	3500	\N	SUCCEEDED	2026-07-26 12:59:46.227
cms1t21th01r1nr6bsqta6dfz	cms1t21th01qwnr6busw2w6ao	\N	CARD	6400	\N	SUCCEEDED	2026-07-26 12:59:46.229
cms1t21tj01r7nr6b6xjo11cs	cms1t21tj01r3nr6b94nlgiu1	\N	CARD	4500	\N	SUCCEEDED	2026-07-26 12:59:46.232
cms1t21tm01renr6bzjpxqy3c	cms1t21tm01r9nr6brhb0p3ms	\N	MOOV_MONEY	6750	\N	SUCCEEDED	2026-07-26 12:59:46.234
cms1t21tp01rlnr6bk97zxjgi	cms1t21tp01rgnr6bludblckr	\N	WAVE	8100	\N	SUCCEEDED	2026-07-26 12:59:46.237
cms1t21tr01rsnr6bia78duae	cms1t21tr01rnnr6b602e4agp	\N	MOOV_MONEY	14000	\N	SUCCEEDED	2026-07-26 12:59:46.239
cms1t21tt01rznr6b25mg851l	cms1t21tt01runr6bc2znncfm	\N	MTN_MOMO	8200	\N	SUCCEEDED	2026-07-26 12:59:46.242
cms1t21tv01s5nr6bubessvto	cms1t21tv01s1nr6b0tg1qyv5	\N	CASH	2850	\N	SUCCEEDED	2026-07-26 12:59:46.244
cms1t21ty01sanr6b4ea1ybrx	cms1t21ty01s7nr6bmnweyatp	\N	CASH	3400	\N	SUCCEEDED	2026-07-26 12:59:46.246
cms1t21u001shnr6b01r1tpiu	cms1t21u001scnr6bn27zb2rf	\N	CASH	10000	\N	SUCCEEDED	2026-07-26 12:59:46.249
cms1t21u301snnr6b4a18f51i	cms1t21u301sjnr6bs18pkxs9	\N	CARD	4000	\N	SUCCEEDED	2026-07-26 12:59:46.251
cms1t21u501stnr6bd0ojh3z7	cms1t21u501spnr6bx168hegu	\N	MOOV_MONEY	7200	\N	SUCCEEDED	2026-07-26 12:59:46.253
cms1t21u701synr6b8z9don6p	cms1t21u701svnr6b35c96s49	\N	CARD	3000	\N	SUCCEEDED	2026-07-26 12:59:46.256
cms1t21u901t4nr6bjikzxwcc	cms1t21u901t0nr6bffnbmrfq	\N	CASH	3500	\N	SUCCEEDED	2026-07-26 12:59:46.258
cms1t21ub01t9nr6bdj88355u	cms1t21ub01t6nr6b80mcq4xg	\N	MTN_MOMO	2900	\N	SUCCEEDED	2026-07-26 12:59:46.26
cms1t21ud01tenr6b6176icuy	cms1t21ud01tbnr6b1jz17c0m	\N	MTN_MOMO	4200	\N	SUCCEEDED	2026-07-26 12:59:46.262
cms1t21uf01tknr6bjjnibw8k	cms1t21uf01tgnr6bjyxgr2tb	\N	MOOV_MONEY	6100	\N	SUCCEEDED	2026-07-26 12:59:46.264
cms1t21uh01tpnr6b0fpeixhl	cms1t21uh01tmnr6bb2za7otu	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:46.266
cms1t21uk01twnr6binh92565	cms1t21uk01trnr6b7rwtixr3	\N	WAVE	5400	\N	SUCCEEDED	2026-07-26 12:59:46.268
cms1t21um01u3nr6bekz4s5sq	cms1t21um01tynr6b7a6uykgz	\N	CELTIIS_CASH	4400	\N	SUCCEEDED	2026-07-26 12:59:46.27
cms1t21uo01u9nr6bp839pbqx	cms1t21uo01u5nr6be7ielynx	\N	CASH	9200	\N	SUCCEEDED	2026-07-26 12:59:46.273
cms1t21ur01ufnr6bp1al3s1e	cms1t21ur01ubnr6bgzd1z9xi	\N	MTN_MOMO	7600	\N	SUCCEEDED	2026-07-26 12:59:46.275
cms1t21ut01umnr6buxldeqxz	cms1t21ut01uhnr6bcbaz4n7g	\N	WAVE	14700	\N	SUCCEEDED	2026-07-26 12:59:46.277
cms1t21uv01urnr6bkj9647v7	cms1t21uv01uonr6bn9qz36hm	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.279
cms1t21ux01uynr6b7zhdwunz	cms1t21ux01utnr6bvw3mtbfl	\N	MOOV_MONEY	4700	\N	SUCCEEDED	2026-07-26 12:59:46.281
cms1t21uz01v4nr6boypmfu4b	cms1t21uz01v0nr6bshdro7is	\N	WAVE	5700	\N	SUCCEEDED	2026-07-26 12:59:46.284
cms1t21v101vbnr6b78flljoz	cms1t21v101v6nr6boief2ezz	\N	MOOV_MONEY	10200	\N	SUCCEEDED	2026-07-26 12:59:46.286
cms1t21v401vinr6by9q4w18g	cms1t21v401vdnr6byy9t8rvu	\N	CELTIIS_CASH	7200	\N	SUCCEEDED	2026-07-26 12:59:46.288
cms1t21v601vpnr6braigu8md	cms1t21v601vknr6br26skgpc	\N	MOOV_MONEY	10600	\N	SUCCEEDED	2026-07-26 12:59:46.291
cms1t21v901vwnr6br2iyyam6	cms1t21v901vrnr6bpem2f7e3	\N	MOOV_MONEY	12100	\N	SUCCEEDED	2026-07-26 12:59:46.293
cms1t21vb01w1nr6blr8jko7l	cms1t21vb01vynr6bkbnq3bf8	\N	MOOV_MONEY	2900	\N	SUCCEEDED	2026-07-26 12:59:46.295
cms1t21vd01w8nr6bymh31qkj	cms1t21vd01w3nr6bsnkpmrgq	\N	WAVE	7400	\N	SUCCEEDED	2026-07-26 12:59:46.298
cms1t21vg01wdnr6bnd2woh88	cms1t21vg01wanr6b9aqlwkqk	\N	CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:46.3
cms1t21vi01wjnr6bgsjwvyiz	cms1t21vi01wfnr6bs1wv467r	\N	CARD	3600	\N	SUCCEEDED	2026-07-26 12:59:46.302
cms1t21vl01wqnr6b3lpm3zgo	cms1t21vl01wlnr6b8hv21a9l	\N	CELTIIS_CASH	13800	\N	SUCCEEDED	2026-07-26 12:59:46.305
cms1t21vn01wwnr6bnvkmfkz3	cms1t21vn01wsnr6biafl5bje	\N	WAVE	7600	\N	SUCCEEDED	2026-07-26 12:59:46.308
cms1t21vq01x1nr6beofpdtw5	cms1t21vp01wynr6bbkaak3il	\N	CARD	4200	\N	SUCCEEDED	2026-07-26 12:59:46.31
cms1t21vs01x8nr6bt7hsc0h2	cms1t21vs01x3nr6b82e3t9te	\N	CARD	9500	\N	SUCCEEDED	2026-07-26 12:59:46.312
cms1t21vu01xfnr6bmio2phdx	cms1t21vu01xanr6b42eh15eq	\N	MTN_MOMO	9800	\N	SUCCEEDED	2026-07-26 12:59:46.315
cms1t21vx01xmnr6bt2n3plmj	cms1t21vw01xhnr6boxew51e0	\N	MTN_MOMO	9800	\N	SUCCEEDED	2026-07-26 12:59:46.317
cms1t21vz01xsnr6bsu7o89ck	cms1t21vz01xonr6b2uzv6gls	\N	MTN_MOMO	1800	\N	SUCCEEDED	2026-07-26 12:59:46.319
cms1t21w101xynr6b2j43ux06	cms1t21w101xunr6bf1nnmxql	\N	CELTIIS_CASH	7200	\N	SUCCEEDED	2026-07-26 12:59:46.321
cms1t21w301y4nr6bosd8spul	cms1t21w301y0nr6bc0ys7yq1	\N	CARD	6500	\N	SUCCEEDED	2026-07-26 12:59:46.324
cms1t21w601yanr6bruzn7t7n	cms1t21w501y6nr6b2g7c5oqc	\N	MTN_MOMO	4300	\N	SUCCEEDED	2026-07-26 12:59:46.326
cms1t21w901ygnr6b8uoefxlm	cms1t21w901ycnr6b7of9633t	\N	CARD	11000	\N	SUCCEEDED	2026-07-26 12:59:46.329
cms1t21wb01ylnr6bexo60f2k	cms1t21wb01yinr6bdkoowsc9	\N	WAVE	3000	\N	SUCCEEDED	2026-07-26 12:59:46.332
cms1t21we01ysnr6bn09xl703	cms1t21we01ynnr6b4uv8v1sf	\N	WAVE	15600	\N	SUCCEEDED	2026-07-26 12:59:46.334
cms1t21wg01yznr6b13of3agq	cms1t21wg01yunr6bdqkma7ih	\N	CARD	9200	\N	SUCCEEDED	2026-07-26 12:59:46.337
cms1t21wj01z4nr6bad387k9o	cms1t21wj01z1nr6bbllligcf	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:46.339
cms1t21wl01zbnr6bbz6wb3vz	cms1t21wl01z6nr6byftoc2jy	\N	CELTIIS_CASH	7400	\N	SUCCEEDED	2026-07-26 12:59:46.342
cms1t21wo01zinr6bhpttfcyj	cms1t21wo01zdnr6beq0kt0ph	\N	CARD	6300	\N	SUCCEEDED	2026-07-26 12:59:46.344
cms1t21wq01znnr6bdembftoh	cms1t21wq01zknr6bpsp1rd1l	\N	WAVE	5000	\N	SUCCEEDED	2026-07-26 12:59:46.346
cms1t21wt01zsnr6bfilkbzvn	cms1t21wt01zpnr6bu2t9pqyu	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.349
cms1t21wv01zynr6boo5w2jez	cms1t21wv01zunr6b3qiwswih	\N	CARD	4100	\N	SUCCEEDED	2026-07-26 12:59:46.352
cms1t21wy0204nr6b2prbvt44	cms1t21wy0200nr6berv5n2qm	\N	CARD	9000	\N	SUCCEEDED	2026-07-26 12:59:46.354
cms1t21x00209nr6byeu1pmar	cms1t21x00206nr6bnszfmyev	\N	MOOV_MONEY	4200	\N	SUCCEEDED	2026-07-26 12:59:46.357
cms1t21x3020gnr6bl3maf2ll	cms1t21x3020bnr6bhwcv23y1	\N	CASH	13400	\N	SUCCEEDED	2026-07-26 12:59:46.359
cms1t21x5020mnr6b7zclhvva	cms1t21x5020inr6beca5wvna	\N	WAVE	4900	\N	SUCCEEDED	2026-07-26 12:59:46.362
cms1t21x8020tnr6bfury6170	cms1t21x8020onr6b0nmct3eb	\N	CASH	8100	\N	SUCCEEDED	2026-07-26 12:59:46.364
cms1t21xa020znr6bm0ggagco	cms1t21xa020vnr6bxp2i5qhm	\N	WAVE	2900	\N	SUCCEEDED	2026-07-26 12:59:46.367
cms1t21xd0215nr6b2z4hsfed	cms1t21xd0211nr6bpm72nuol	\N	WAVE	3600	\N	SUCCEEDED	2026-07-26 12:59:46.369
cms1t21xf021anr6bmipqxjku	cms1t21xf0217nr6bx9m74wdj	\N	CELTIIS_CASH	3400	\N	SUCCEEDED	2026-07-26 12:59:46.372
cms1t21xh021fnr6bdhha6sqd	cms1t21xh021cnr6boyswuk2s	\N	CASH	3600	\N	SUCCEEDED	2026-07-26 12:59:46.374
cms1t21xk021mnr6b1oc0eub5	cms1t21xj021hnr6be1t6zl7h	\N	CARD	7200	\N	SUCCEEDED	2026-07-26 12:59:46.376
cms1t21xm021snr6b9hsu6uun	cms1t21xm021onr6b5p1kctaw	\N	CARD	5400	\N	SUCCEEDED	2026-07-26 12:59:46.379
cms1t21xp021xnr6b320o1kkz	cms1t21xp021unr6bhp5vlpst	\N	MTN_MOMO	5800	\N	SUCCEEDED	2026-07-26 12:59:46.381
cms1t21xr0224nr6bo6frbhk2	cms1t21xr021znr6bbw2nh180	\N	CASH	9200	\N	SUCCEEDED	2026-07-26 12:59:46.384
cms1t21xu0229nr6bi0agg77h	cms1t21xu0226nr6b5k2nkrwt	\N	MOOV_MONEY	1400	\N	SUCCEEDED	2026-07-26 12:59:46.386
cms1t21xw022fnr6bkrlk2ex8	cms1t21xw022bnr6bnjv8oqf5	\N	CARD	4600	\N	SUCCEEDED	2026-07-26 12:59:46.388
cms1t21xy022mnr6bk07ap88f	cms1t21xy022hnr6b32mg6qyd	\N	CASH	9300	\N	SUCCEEDED	2026-07-26 12:59:46.391
cms1t21y1022tnr6b2rpmmes2	cms1t21y1022onr6b363vwzod	\N	MTN_MOMO	5700	\N	SUCCEEDED	2026-07-26 12:59:46.393
cms1t21y30230nr6be5dcwa7c	cms1t21y3022vnr6bv9zh17ni	\N	MTN_MOMO	10700	\N	SUCCEEDED	2026-07-26 12:59:46.396
cms1t21y60237nr6bcp3agj68	cms1t21y60232nr6b4hg6h111	\N	CELTIIS_CASH	7300	\N	SUCCEEDED	2026-07-26 12:59:46.398
cms1t21y9023dnr6bxwcda06x	cms1t21y80239nr6b26ha24u2	\N	CARD	2900	\N	SUCCEEDED	2026-07-26 12:59:46.401
cms1t21yb023jnr6b6tpilvzp	cms1t21yb023fnr6b7d1v5dti	\N	CELTIIS_CASH	8000	\N	SUCCEEDED	2026-07-26 12:59:46.404
cms1t21ye023pnr6b5olh1ghd	cms1t21ye023lnr6bx94ei8fm	\N	CASH	1050	\N	SUCCEEDED	2026-07-26 12:59:46.406
cms1t21yg023unr6bbtrpj6ti	cms1t21yg023rnr6bg8uemk8x	\N	CARD	6800	\N	SUCCEEDED	2026-07-26 12:59:46.409
cms1t21yi0241nr6bxc5qekz6	cms1t21yi023wnr6bbstg1s58	\N	CARD	7800	\N	SUCCEEDED	2026-07-26 12:59:46.411
cms1t21yl0246nr6bim3wkgk4	cms1t21yl0243nr6bnylwbnj7	\N	WAVE	2100	\N	SUCCEEDED	2026-07-26 12:59:46.413
cms1t21yn024cnr6b6vvm0fgq	cms1t21yn0248nr6bxhsatslw	\N	MOOV_MONEY	2150	\N	SUCCEEDED	2026-07-26 12:59:46.415
cms1t21yp024jnr6byw282v5z	cms1t21yp024enr6bdx7t5pfw	\N	MTN_MOMO	7800	\N	SUCCEEDED	2026-07-26 12:59:46.418
cms1t21ys024qnr6bwkr1fgv7	cms1t21ys024lnr6b5cajsig4	\N	CELTIIS_CASH	9500	\N	SUCCEEDED	2026-07-26 12:59:46.42
cms1t21yu024xnr6bil0vfedl	cms1t21yu024snr6bd5vzx0zb	\N	MOOV_MONEY	5000	\N	SUCCEEDED	2026-07-26 12:59:46.423
cms1t21yx0252nr6b59nkmtbh	cms1t21yx024znr6bf8bhgmh1	\N	MTN_MOMO	2200	\N	SUCCEEDED	2026-07-26 12:59:46.425
cms1t21yz0258nr6bljaxnspu	cms1t21yz0254nr6bhc328g6v	\N	CASH	1450	\N	SUCCEEDED	2026-07-26 12:59:46.427
cms1t21z1025enr6bacsrguw2	cms1t21z1025anr6bp5buu03w	\N	CELTIIS_CASH	7200	\N	SUCCEEDED	2026-07-26 12:59:46.429
cms1t21z3025jnr6bnik6ob5m	cms1t21z3025gnr6b13jjdn74	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:46.432
cms1t21z5025qnr6bho0q4wsl	cms1t21z5025lnr6b6dihz8dg	\N	CARD	13800	\N	SUCCEEDED	2026-07-26 12:59:46.434
cms1t21z7025vnr6bi0vzp9v3	cms1t21z7025snr6bkbts19pq	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:46.436
cms1t21z90261nr6bzl5b7ufw	cms1t21z9025xnr6biagbng16	\N	CASH	10000	\N	SUCCEEDED	2026-07-26 12:59:46.438
cms1t21zb0267nr6bsm2i379w	cms1t21zb0263nr6b2ql97ka7	\N	CARD	3350	\N	SUCCEEDED	2026-07-26 12:59:46.44
cms1t21zd026enr6bw6bsayug	cms1t21zd0269nr6bnrw3ahw6	\N	CASH	6100	\N	SUCCEEDED	2026-07-26 12:59:46.442
cms1t21zg026lnr6b64e2h6v7	cms1t21zg026gnr6b7bu26emk	\N	CARD	10300	\N	SUCCEEDED	2026-07-26 12:59:46.444
cms1t21zi026rnr6bkfwgms9i	cms1t21zi026nnr6b746trdex	\N	MOOV_MONEY	4800	\N	SUCCEEDED	2026-07-26 12:59:46.447
cms1t21zl026xnr6bwhmg9h3c	cms1t21zl026tnr6bupeywp0g	\N	CASH	6100	\N	SUCCEEDED	2026-07-26 12:59:46.45
cms1t21zo0274nr6br06bebx1	cms1t21zo026znr6bpqvhlarv	\N	CARD	14100	\N	SUCCEEDED	2026-07-26 12:59:46.452
cms1t21zr027bnr6bbpxj85jg	cms1t21zr0276nr6bkpt1tgwu	\N	CELTIIS_CASH	11500	\N	SUCCEEDED	2026-07-26 12:59:46.455
cms1t21zu027gnr6bjl86affc	cms1t21zu027dnr6bug5dei70	\N	WAVE	3600	\N	SUCCEEDED	2026-07-26 12:59:46.458
cms1t21zw027nnr6b1yrf9vxg	cms1t21zw027inr6b7vtz7fbn	\N	MTN_MOMO	4650	\N	SUCCEEDED	2026-07-26 12:59:46.461
cms1t21zz027snr6bq1qhlo9w	cms1t21zz027pnr6b78o0yyef	\N	WAVE	700	\N	SUCCEEDED	2026-07-26 12:59:46.463
cms1t2201027ynr6bz5pbrod3	cms1t2201027unr6bslu05946	\N	MOOV_MONEY	5700	\N	SUCCEEDED	2026-07-26 12:59:46.465
cms1t22030283nr6buhygzbvu	cms1t22030280nr6bql633yyh	\N	WAVE	700	\N	SUCCEEDED	2026-07-26 12:59:46.468
cms1t2206028anr6b2eidw2g4	cms1t22060285nr6bpb0yvcl3	\N	CELTIIS_CASH	6050	\N	SUCCEEDED	2026-07-26 12:59:46.47
cms1t2208028hnr6b3d0ah0a4	cms1t2208028cnr6bh83e3ex7	\N	WAVE	7300	\N	SUCCEEDED	2026-07-26 12:59:46.473
cms1t220b028nnr6bfzvzyuez	cms1t220b028jnr6byptjhhej	\N	WAVE	5500	\N	SUCCEEDED	2026-07-26 12:59:46.475
cms1t220e028tnr6bp7at07n2	cms1t220d028pnr6bisn4v8d6	\N	MTN_MOMO	9300	\N	SUCCEEDED	2026-07-26 12:59:46.478
cms1t220g0290nr6b2jgpadwy	cms1t220g028vnr6bghwigx78	\N	CARD	5650	\N	SUCCEEDED	2026-07-26 12:59:46.481
cms1t220j0296nr6brdbyygsk	cms1t220j0292nr6byht70eht	\N	CARD	4500	\N	SUCCEEDED	2026-07-26 12:59:46.483
cms1t220l029dnr6bwxs5ve33	cms1t220l0298nr6b60ukxswy	\N	CELTIIS_CASH	9000	\N	SUCCEEDED	2026-07-26 12:59:46.486
cms1t220o029inr6b544718f5	cms1t220o029fnr6bvwos42qg	\N	WAVE	3400	\N	SUCCEEDED	2026-07-26 12:59:46.488
cms1t220q029nnr6bzr7luu3n	cms1t220q029knr6bf5bjjqc8	\N	MOOV_MONEY	1800	\N	SUCCEEDED	2026-07-26 12:59:46.491
cms1t220s029unr6bun5ddg7l	cms1t220s029pnr6b9vrry3kn	\N	CASH	9700	\N	SUCCEEDED	2026-07-26 12:59:46.493
cms1t220v02a1nr6b1i0k2lfg	cms1t220v029wnr6b2a56q29e	\N	MOOV_MONEY	6200	\N	SUCCEEDED	2026-07-26 12:59:46.495
cms1t220x02a6nr6bdsnhd9c5	cms1t220x02a3nr6bbvr7c7f1	\N	CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:46.498
cms1t221002acnr6bdp7pggak	cms1t220z02a8nr6bhmi0ki97	\N	CELTIIS_CASH	3400	\N	SUCCEEDED	2026-07-26 12:59:46.5
cms1t221202ahnr6b32hss2j2	cms1t221202aenr6byoxua6q7	\N	CELTIIS_CASH	350	\N	SUCCEEDED	2026-07-26 12:59:46.502
cms1t221402amnr6bg18bvzhr	cms1t221402ajnr6bqjbzz2s4	\N	WAVE	4200	\N	SUCCEEDED	2026-07-26 12:59:46.504
cms1t221602asnr6b40ikb6gh	cms1t221602aonr6bph5478rt	\N	WAVE	5400	\N	SUCCEEDED	2026-07-26 12:59:46.507
cms1t221802aynr6b7or435r3	cms1t221802aunr6b3yb4zcmv	\N	WAVE	1800	\N	SUCCEEDED	2026-07-26 12:59:46.509
cms1t221b02b5nr6b3s0vn1jn	cms1t221b02b0nr6b7bd8s431	\N	MOOV_MONEY	14400	\N	SUCCEEDED	2026-07-26 12:59:46.511
cms1t221d02bcnr6b244ctnyt	cms1t221d02b7nr6bsjappy0z	\N	WAVE	5550	\N	SUCCEEDED	2026-07-26 12:59:46.513
cms1t221f02bjnr6blgsd2prr	cms1t221f02benr6bit6jy98p	\N	WAVE	11900	\N	SUCCEEDED	2026-07-26 12:59:46.515
cms1t221h02bonr6btamsluqp	cms1t221h02blnr6bjur0vmyq	\N	WAVE	1500	\N	SUCCEEDED	2026-07-26 12:59:46.518
cms1t221j02bunr6bmt6chwsr	cms1t221j02bqnr6bcbeh8xep	\N	CARD	6100	\N	SUCCEEDED	2026-07-26 12:59:46.52
cms1t221m02bznr6bszfx2bfm	cms1t221m02bwnr6bgu8fipmg	\N	CASH	1100	\N	SUCCEEDED	2026-07-26 12:59:46.522
cms1t221o02c4nr6bhiikmt0u	cms1t221o02c1nr6bztb4120j	\N	CARD	1100	\N	SUCCEEDED	2026-07-26 12:59:46.524
cms1t221q02canr6bt832d526	cms1t221q02c6nr6bsc04yuph	\N	CELTIIS_CASH	2900	\N	SUCCEEDED	2026-07-26 12:59:46.526
cms1t221s02chnr6bx1m4y70r	cms1t221s02ccnr6b9mmq2h4s	\N	CARD	11500	\N	SUCCEEDED	2026-07-26 12:59:46.529
cms1t221v02conr6bu6xkks4k	cms1t221u02cjnr6bv6b128nq	\N	WAVE	7200	\N	SUCCEEDED	2026-07-26 12:59:46.531
cms1t221x02cunr6bzziwdfcj	cms1t221x02cqnr6balo08b04	\N	WAVE	7200	\N	SUCCEEDED	2026-07-26 12:59:46.533
cms1t222002d0nr6byl3ga8rn	cms1t222002cwnr6brd2hn3oh	\N	WAVE	6000	\N	SUCCEEDED	2026-07-26 12:59:46.536
cms1t222202d6nr6b1mycr0gi	cms1t222202d2nr6b6h1vr1of	\N	CARD	8800	\N	SUCCEEDED	2026-07-26 12:59:46.539
cms1t222502ddnr6ba8ys5ivv	cms1t222502d8nr6bv53y0q5a	\N	CARD	9400	\N	SUCCEEDED	2026-07-26 12:59:46.541
cms1t222702dknr6bp3flzbb5	cms1t222702dfnr6bzudl2p7o	\N	MOOV_MONEY	7500	\N	SUCCEEDED	2026-07-26 12:59:46.544
cms1t222a02drnr6bxd1n91c6	cms1t222a02dmnr6bj3bdllmw	\N	MTN_MOMO	3950	\N	SUCCEEDED	2026-07-26 12:59:46.546
cms1t222d02dwnr6bqv3ty0kt	cms1t222d02dtnr6bt2h0bnz0	\N	WAVE	1800	\N	SUCCEEDED	2026-07-26 12:59:46.549
cms1t222f02e3nr6b0og5kfd6	cms1t222f02dynr6bkumapl0i	\N	MTN_MOMO	11000	\N	SUCCEEDED	2026-07-26 12:59:46.551
cms1t222h02e8nr6bvw93e861	cms1t222h02e5nr6br5dzeoum	\N	CASH	1800	\N	SUCCEEDED	2026-07-26 12:59:46.554
cms1t222k02efnr6bfugr7k0n	cms1t222j02eanr6bro2yoezr	\N	MTN_MOMO	8300	\N	SUCCEEDED	2026-07-26 12:59:46.556
cms1t222m02eknr6bqc4gx1n1	cms1t222m02ehnr6b0k1vytbf	\N	CARD	2500	\N	SUCCEEDED	2026-07-26 12:59:46.558
cms1t222o02epnr6bfhf1y623	cms1t222o02emnr6bkmdr8c0u	\N	MOOV_MONEY	3600	\N	SUCCEEDED	2026-07-26 12:59:46.56
cms1t222r02evnr6b7cq0dw7j	cms1t222q02ernr6bv98y6jui	\N	WAVE	12600	\N	SUCCEEDED	2026-07-26 12:59:46.563
cms1t222u02f0nr6bpcwvgfvj	cms1t222u02exnr6but4tupya	\N	MTN_MOMO	1800	\N	SUCCEEDED	2026-07-26 12:59:46.566
cms1t222w02f5nr6besifpezu	cms1t222w02f2nr6bpm07gvyo	\N	MOOV_MONEY	1800	\N	SUCCEEDED	2026-07-26 12:59:46.568
cms1t222y02fbnr6bm60ld5md	cms1t222y02f7nr6bq0tbzuuc	\N	MTN_MOMO	3600	\N	SUCCEEDED	2026-07-26 12:59:46.571
cms1t223102fgnr6bgie5eme5	cms1t223102fdnr6b9adxoeny	\N	MOOV_MONEY	350	\N	SUCCEEDED	2026-07-26 12:59:46.573
cms1t223302fnnr6bf3ooi27z	cms1t223302finr6b3xh7k3m0	\N	CASH	6800	\N	SUCCEEDED	2026-07-26 12:59:46.576
cms1t223602ftnr6b11ckh4fy	cms1t223602fpnr6buqkkme02	\N	CELTIIS_CASH	4800	\N	SUCCEEDED	2026-07-26 12:59:46.578
cms1t223802fynr6brixd2fdl	cms1t223802fvnr6b52ytvdfl	\N	CARD	1100	\N	SUCCEEDED	2026-07-26 12:59:46.58
cms1t223a02g4nr6bqejvdwkw	cms1t223a02g0nr6bpqgd3h1m	\N	MOOV_MONEY	3900	\N	SUCCEEDED	2026-07-26 12:59:46.583
cms1t223d02g9nr6b8n92beuf	cms1t223d02g6nr6bh84diasr	\N	MTN_MOMO	5800	\N	SUCCEEDED	2026-07-26 12:59:46.585
cms1t223f02ggnr6btepojxp0	cms1t223f02gbnr6bwomvn0u2	\N	CASH	6350	\N	SUCCEEDED	2026-07-26 12:59:46.587
cms1t223h02glnr6b7icrene7	cms1t223h02ginr6bis975pq7	\N	CELTIIS_CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:46.59
cms1t223k02grnr6bpekt778q	cms1t223k02gnnr6b76r2a5kv	\N	MTN_MOMO	2900	\N	SUCCEEDED	2026-07-26 12:59:46.592
cms1t223m02gwnr6bnssxbhe7	cms1t223m02gtnr6b0v6di209	\N	MOOV_MONEY	1500	\N	SUCCEEDED	2026-07-26 12:59:46.594
cms1t223o02h1nr6bu1yi16x9	cms1t223o02gynr6bkskkmy48	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:46.597
cms1t223r02h6nr6bv0vqk525	cms1t223r02h3nr6bwlay4116	\N	MTN_MOMO	4200	\N	SUCCEEDED	2026-07-26 12:59:46.599
cms1t223t02hdnr6bfv87395h	cms1t223t02h8nr6bnaxacrqa	\N	CASH	12900	\N	SUCCEEDED	2026-07-26 12:59:46.601
cms1t223v02hjnr6b9os7h8iv	cms1t223v02hfnr6badmgehlc	\N	CASH	2800	\N	SUCCEEDED	2026-07-26 12:59:46.604
cms1t223y02hqnr6bewxr1pro	cms1t223y02hlnr6bwvp86ns6	\N	MTN_MOMO	9700	\N	SUCCEEDED	2026-07-26 12:59:46.606
cms1t224002hxnr6b1ha9w9re	cms1t224002hsnr6bg01ojweb	\N	CARD	10700	\N	SUCCEEDED	2026-07-26 12:59:46.609
cms1t224302i4nr6b68vjv8zg	cms1t224302hznr6brrsiqqfo	\N	CASH	9400	\N	SUCCEEDED	2026-07-26 12:59:46.611
cms1t224502ibnr6b58cwq4sp	cms1t224502i6nr6brxhtizdv	\N	CARD	9300	\N	SUCCEEDED	2026-07-26 12:59:46.614
cms1t224802iinr6brii594v8	cms1t224802idnr6bqs3t7wvx	\N	WAVE	10350	\N	SUCCEEDED	2026-07-26 12:59:46.616
cms1t224a02ionr6bhuobxovt	cms1t224a02iknr6bfxha6mov	\N	CASH	7100	\N	SUCCEEDED	2026-07-26 12:59:46.619
cms1t224d02iunr6bqga7qfbk	cms1t224d02iqnr6ba4n4sa2k	\N	WAVE	7000	\N	SUCCEEDED	2026-07-26 12:59:46.621
cms1t224f02j0nr6bd5jx0rhn	cms1t224f02iwnr6bc9zu2px4	\N	MOOV_MONEY	8300	\N	SUCCEEDED	2026-07-26 12:59:46.624
cms1t224h02j5nr6bcofbz0qg	cms1t224h02j2nr6b7waj437e	\N	CELTIIS_CASH	2200	\N	SUCCEEDED	2026-07-26 12:59:46.626
cms1t224j02jbnr6b7hepc9ew	cms1t224j02j7nr6bm9armtw9	\N	MTN_MOMO	9200	\N	SUCCEEDED	2026-07-26 12:59:46.628
cms1t224m02jinr6bcmngj7tt	cms1t224m02jdnr6b46aak3o4	\N	CELTIIS_CASH	9500	\N	SUCCEEDED	2026-07-26 12:59:46.63
cms1t224o02jnnr6bxxp4v7ok	cms1t224o02jknr6bgvfvvpfy	\N	WAVE	1100	\N	SUCCEEDED	2026-07-26 12:59:46.633
cms1t224q02junr6b4j90bmgk	cms1t224q02jpnr6bon505417	\N	CASH	8900	\N	SUCCEEDED	2026-07-26 12:59:46.635
cms1t224t02k0nr6b6mpfs9l7	cms1t224t02jwnr6b2pxp6mdd	\N	WAVE	6000	\N	SUCCEEDED	2026-07-26 12:59:46.637
cms1t224v02k7nr6bm4yj79b2	cms1t224v02k2nr6br2fhd99u	\N	MOOV_MONEY	8800	\N	SUCCEEDED	2026-07-26 12:59:46.639
cms1t224x02kcnr6bm0znc2ze	cms1t224x02k9nr6bprnxrvvc	\N	CASH	1800	\N	SUCCEEDED	2026-07-26 12:59:46.642
cms1t224z02kjnr6be1ndorz0	cms1t224z02kenr6bo4i19yh1	\N	MOOV_MONEY	6600	\N	SUCCEEDED	2026-07-26 12:59:46.644
cms1t225202kpnr6bxvxy5leo	cms1t225202klnr6b1oz60pt9	\N	WAVE	7300	\N	SUCCEEDED	2026-07-26 12:59:46.646
cms1t225402kvnr6bsd6m37ao	cms1t225402krnr6borcll07q	\N	WAVE	7100	\N	SUCCEEDED	2026-07-26 12:59:46.649
cms1t225702l1nr6bi5syc7yo	cms1t225702kxnr6bh70cu7sz	\N	WAVE	5500	\N	SUCCEEDED	2026-07-26 12:59:46.651
cms1t225a02l7nr6bprrae2dp	cms1t225a02l3nr6bdschqnfw	\N	CARD	7900	\N	SUCCEEDED	2026-07-26 12:59:46.654
cms1t225c02lcnr6bch17yfy4	cms1t225c02l9nr6brq6gfhai	\N	MOOV_MONEY	6800	\N	SUCCEEDED	2026-07-26 12:59:46.657
cms1t225e02linr6bib1jb4lo	cms1t225e02lenr6b585l08yf	\N	WAVE	3350	\N	SUCCEEDED	2026-07-26 12:59:46.659
cms1t225h02lpnr6bl3oovcrt	cms1t225h02lknr6b6v8w51qw	\N	MTN_MOMO	5850	\N	SUCCEEDED	2026-07-26 12:59:46.661
cms1t225j02lvnr6bbb6977qm	cms1t225j02lrnr6bl2n9qafd	\N	WAVE	4300	\N	SUCCEEDED	2026-07-26 12:59:46.664
cms1t225m02m1nr6b8mmjkcx4	cms1t225m02lxnr6b9oqewjll	\N	MOOV_MONEY	5100	\N	SUCCEEDED	2026-07-26 12:59:46.666
cms1t225o02m6nr6bi56j38w9	cms1t225o02m3nr6btoqsrv5t	\N	CELTIIS_CASH	1400	\N	SUCCEEDED	2026-07-26 12:59:46.669
cms1t225q02mdnr6b6hpgb6ov	cms1t225q02m8nr6b78n0oyby	\N	MOOV_MONEY	10700	\N	SUCCEEDED	2026-07-26 12:59:46.67
cms1t225t02minr6b3dxotb58	cms1t225t02mfnr6bzh1kwtou	\N	MOOV_MONEY	2500	\N	SUCCEEDED	2026-07-26 12:59:46.673
cms1t225v02mpnr6bhp8s8cjf	cms1t225v02mknr6bq99vyi1o	\N	CARD	8000	\N	SUCCEEDED	2026-07-26 12:59:46.675
cms1t225y02mwnr6b9l83erqc	cms1t225y02mrnr6bbepb6hr6	\N	CARD	11100	\N	SUCCEEDED	2026-07-26 12:59:46.678
cms1t226002n2nr6bf9r6f0ra	cms1t226002mynr6b2j60dedk	\N	CARD	7100	\N	SUCCEEDED	2026-07-26 12:59:46.68
cms1t226202n8nr6b7ck0p99b	cms1t226202n4nr6bhbkawypy	\N	CARD	8000	\N	SUCCEEDED	2026-07-26 12:59:46.683
cms1t226502nfnr6bbnso4ujw	cms1t226502nanr6b5n7hebto	\N	CARD	9400	\N	SUCCEEDED	2026-07-26 12:59:46.685
cms1t226702nmnr6bh9o6vgsj	cms1t226702nhnr6b9q59ieu4	\N	MTN_MOMO	7200	\N	SUCCEEDED	2026-07-26 12:59:46.688
cms1t226a02nrnr6b4z93m1lm	cms1t226a02nonr6biay4xsde	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.69
cms1t226c02nynr6bw6zs8u6t	cms1t226c02ntnr6bxxzb8d0p	\N	CASH	8700	\N	SUCCEEDED	2026-07-26 12:59:46.692
cms1t226e02o3nr6bwna63bbo	cms1t226e02o0nr6bwkdrwbno	\N	CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:46.695
cms1t226g02oanr6b562s4lca	cms1t226g02o5nr6bv787wy19	\N	WAVE	5500	\N	SUCCEEDED	2026-07-26 12:59:46.697
cms1t226j02ohnr6bhwrv6hte	cms1t226j02ocnr6bl7f5ga3h	\N	CELTIIS_CASH	5700	\N	SUCCEEDED	2026-07-26 12:59:46.699
cms1t226l02oonr6bv6r2k4ta	cms1t226l02ojnr6b1eyuepgw	\N	CARD	7500	\N	SUCCEEDED	2026-07-26 12:59:46.701
cms1t226n02ounr6b622wgwl7	cms1t226n02oqnr6bv2vflf3g	\N	MTN_MOMO	12600	\N	SUCCEEDED	2026-07-26 12:59:46.704
cms1t226q02p0nr6bo4un4tgv	cms1t226p02ownr6bypprzylf	\N	MTN_MOMO	7500	\N	SUCCEEDED	2026-07-26 12:59:46.706
cms1t226s02p5nr6bzv8ldnt5	cms1t226s02p2nr6bru35ckl8	\N	MTN_MOMO	700	\N	SUCCEEDED	2026-07-26 12:59:46.709
cms1t226v02pbnr6bnvdcj6z7	cms1t226v02p7nr6bzslcoqfx	\N	WAVE	1800	\N	SUCCEEDED	2026-07-26 12:59:46.711
cms1t226x02phnr6b9m5kh0z9	cms1t226x02pdnr6biuibatdf	\N	CARD	4900	\N	SUCCEEDED	2026-07-26 12:59:46.714
cms1t227002ponr6bibrpmsc1	cms1t226z02pjnr6b9wzpcn61	\N	CARD	9600	\N	SUCCEEDED	2026-07-26 12:59:46.716
cms1t227202punr6bwyz8ilmq	cms1t227202pqnr6bg9ueytd1	\N	MOOV_MONEY	5100	\N	SUCCEEDED	2026-07-26 12:59:46.718
cms1t227402q0nr6b4iopcbiq	cms1t227402pwnr6brn24yx0z	\N	MOOV_MONEY	7100	\N	SUCCEEDED	2026-07-26 12:59:46.721
cms1t227702q7nr6bdt6kby91	cms1t227702q2nr6bz5hisrvl	\N	MOOV_MONEY	5050	\N	SUCCEEDED	2026-07-26 12:59:46.723
cms1t227902qcnr6b66arieu9	cms1t227902q9nr6bvd33v2bj	\N	MOOV_MONEY	2500	\N	SUCCEEDED	2026-07-26 12:59:46.725
cms1t227b02qinr6b4lttd5r4	cms1t227b02qenr6b4h1afiqv	\N	CASH	4300	\N	SUCCEEDED	2026-07-26 12:59:46.728
cms1t227e02qonr6bgm7ynm6t	cms1t227e02qknr6bl0x6e8k4	\N	CELTIIS_CASH	5700	\N	SUCCEEDED	2026-07-26 12:59:46.73
cms1t227g02qvnr6brcrltpkm	cms1t227g02qqnr6bgx38qmt9	\N	WAVE	6400	\N	SUCCEEDED	2026-07-26 12:59:46.732
cms1t227i02r1nr6bv7efp2b9	cms1t227i02qxnr6bg8spg54q	\N	WAVE	4800	\N	SUCCEEDED	2026-07-26 12:59:46.735
cms1t227l02r6nr6b4ilyttky	cms1t227l02r3nr6bhb4un4a6	\N	CASH	2200	\N	SUCCEEDED	2026-07-26 12:59:46.737
cms1t227n02rdnr6bdw0h8bsv	cms1t227n02r8nr6bnclgw7nb	\N	MTN_MOMO	5900	\N	SUCCEEDED	2026-07-26 12:59:46.739
cms1t227p02rknr6bme78upcq	cms1t227p02rfnr6bzo6316rl	\N	CARD	6600	\N	SUCCEEDED	2026-07-26 12:59:46.741
cms1t227r02rpnr6b2asinjph	cms1t227r02rmnr6bj6yzjxoc	\N	MTN_MOMO	2100	\N	SUCCEEDED	2026-07-26 12:59:46.744
cms1t227t02rvnr6balg0a92q	cms1t227t02rrnr6bfndlmgui	\N	CELTIIS_CASH	4600	\N	SUCCEEDED	2026-07-26 12:59:46.746
cms1t227w02s1nr6b7ott8ige	cms1t227w02rxnr6bdzhqsx65	\N	CASH	3500	\N	SUCCEEDED	2026-07-26 12:59:46.748
cms1t227z02s6nr6be80kqyb4	cms1t227z02s3nr6bhpo8hwc9	\N	MTN_MOMO	2300	\N	SUCCEEDED	2026-07-26 12:59:46.752
cms1t228202scnr6b2afxwpuf	cms1t228102s8nr6b0ina1nbk	\N	MOOV_MONEY	5300	\N	SUCCEEDED	2026-07-26 12:59:46.754
cms1t228402shnr6b0jdlul4w	cms1t228402senr6bwcrvwwt4	\N	CARD	2100	\N	SUCCEEDED	2026-07-26 12:59:46.756
cms1t228602sonr6bmuecxaf5	cms1t228602sjnr6b4j6tmvzf	\N	WAVE	11400	\N	SUCCEEDED	2026-07-26 12:59:46.759
cms1t228902stnr6bdlmjdl0t	cms1t228902sqnr6bb2ckagfx	\N	CARD	5000	\N	SUCCEEDED	2026-07-26 12:59:46.761
cms1t228b02sznr6blvomd6yc	cms1t228b02svnr6b2ff8x16y	\N	MOOV_MONEY	7900	\N	SUCCEEDED	2026-07-26 12:59:46.763
cms1t228d02t5nr6bmdo5ovbo	cms1t228d02t1nr6b6mz95x1f	\N	CARD	2900	\N	SUCCEEDED	2026-07-26 12:59:46.765
cms1t228f02tanr6bomkpg1qf	cms1t228f02t7nr6bbp69fszj	\N	CELTIIS_CASH	1500	\N	SUCCEEDED	2026-07-26 12:59:46.768
cms1t228h02tfnr6b2vnmir8c	cms1t228h02tcnr6bpxv5wqe2	\N	CELTIIS_CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.77
cms1t228j02tknr6b0ds09h6q	cms1t228j02thnr6b1tscpsmp	\N	WAVE	2500	\N	SUCCEEDED	2026-07-26 12:59:46.772
cms1t228l02tqnr6bu2s1jkt5	cms1t228l02tmnr6bavk8l7l1	\N	CELTIIS_CASH	4800	\N	SUCCEEDED	2026-07-26 12:59:46.773
cms1t228o02txnr6bgkdv3yvl	cms1t228o02tsnr6bv4077z85	\N	CARD	12500	\N	SUCCEEDED	2026-07-26 12:59:46.776
cms1t228q02u3nr6bh8p3wz63	cms1t228q02tznr6bdxrnt6xv	\N	MOOV_MONEY	5350	\N	SUCCEEDED	2026-07-26 12:59:46.779
cms1t228t02u8nr6bijxkpw61	cms1t228t02u5nr6bhwaaxny8	\N	WAVE	3600	\N	SUCCEEDED	2026-07-26 12:59:46.781
cms1t228v02udnr6bmeqrk07b	cms1t228v02uanr6bl7vhr9l9	\N	CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:46.784
cms1t228y02ujnr6bozb60xae	cms1t228y02ufnr6bprl99jvk	\N	CELTIIS_CASH	9600	\N	SUCCEEDED	2026-07-26 12:59:46.786
cms1t229102uqnr6b5u6hsof5	cms1t229102ulnr6bu4fqybdj	\N	CELTIIS_CASH	5650	\N	SUCCEEDED	2026-07-26 12:59:46.789
cms1t229402uvnr6b6cd615ox	cms1t229402usnr6bcy7whe2f	\N	WAVE	2900	\N	SUCCEEDED	2026-07-26 12:59:46.792
cms1t229602v1nr6bu3597gcn	cms1t229602uxnr6b8lk8ui1r	\N	CASH	2900	\N	SUCCEEDED	2026-07-26 12:59:46.795
cms1t229902v6nr6bjvxi023g	cms1t229902v3nr6bfjsflci1	\N	CARD	1400	\N	SUCCEEDED	2026-07-26 12:59:46.797
cms1t229b02vdnr6bqr557jph	cms1t229b02v8nr6bbkylbyht	\N	CASH	12500	\N	SUCCEEDED	2026-07-26 12:59:46.799
cms1t229e02vjnr6blcflfx8g	cms1t229d02vfnr6bs9b0l6gt	\N	MOOV_MONEY	4500	\N	SUCCEEDED	2026-07-26 12:59:46.802
cms1t229g02vonr6boqstv8d0	cms1t229g02vlnr6b076qbxsj	\N	CASH	5000	\N	SUCCEEDED	2026-07-26 12:59:46.804
cms1t229i02vunr6bf7k6jn2y	cms1t229i02vqnr6b3k9n5ew9	\N	CELTIIS_CASH	7800	\N	SUCCEEDED	2026-07-26 12:59:46.807
cms1t229l02vznr6b3thk6vk9	cms1t229l02vwnr6b0dbx3fc9	\N	CELTIIS_CASH	2100	\N	SUCCEEDED	2026-07-26 12:59:46.809
cms1t229n02w6nr6brt3gedv1	cms1t229n02w1nr6bqeva2xzl	\N	WAVE	7500	\N	SUCCEEDED	2026-07-26 12:59:46.811
cms1t229p02wdnr6bzbjvypl8	cms1t229p02w8nr6boyhqmvt1	\N	CELTIIS_CASH	8400	\N	SUCCEEDED	2026-07-26 12:59:46.814
cms1t229s02wknr6b42yfugir	cms1t229s02wfnr6bkxo8u5pc	\N	WAVE	7000	\N	SUCCEEDED	2026-07-26 12:59:46.816
cms1t229u02wrnr6bcjzbzhu5	cms1t229u02wmnr6bmnkx1qxe	\N	WAVE	6000	\N	SUCCEEDED	2026-07-26 12:59:46.819
cms1t229x02wwnr6bkwp6reau	cms1t229x02wtnr6bq3yhryle	\N	CARD	2500	\N	SUCCEEDED	2026-07-26 12:59:46.821
cms1t229z02x1nr6bjht8xgm9	cms1t229z02wynr6b2uamn2bp	\N	MOOV_MONEY	700	\N	SUCCEEDED	2026-07-26 12:59:46.823
cms1t22a102x7nr6b0fy9pu64	cms1t22a102x3nr6blwwpzkfr	\N	CELTIIS_CASH	9200	\N	SUCCEEDED	2026-07-26 12:59:46.825
cms1t22a302xenr6b39fsnibq	cms1t22a302x9nr6bbx3kxgrd	\N	WAVE	5400	\N	SUCCEEDED	2026-07-26 12:59:46.828
cms1t22a502xknr6bllzuiicq	cms1t22a502xgnr6bauvulkif	\N	CASH	7200	\N	SUCCEEDED	2026-07-26 12:59:46.83
cms1t22a802xrnr6bcuyxzihm	cms1t22a802xmnr6br5782tjy	\N	MOOV_MONEY	12900	\N	SUCCEEDED	2026-07-26 12:59:46.832
cms1t22aa02xwnr6b47u9wur8	cms1t22aa02xtnr6b1o67aysy	\N	CELTIIS_CASH	3000	\N	SUCCEEDED	2026-07-26 12:59:46.834
cms1t22ac02y1nr6bpg9eow7c	cms1t22ac02xynr6bwwozssso	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:46.836
cms1t22ae02y6nr6blyqvyvz2	cms1t22ae02y3nr6b8kczhjwu	\N	MOOV_MONEY	2300	\N	SUCCEEDED	2026-07-26 12:59:46.838
cms1t22ag02ycnr6b3mz9hkx9	cms1t22ag02y8nr6bilfutb4v	\N	CASH	6400	\N	SUCCEEDED	2026-07-26 12:59:46.84
cms1t22ai02yjnr6b16izt2fc	cms1t22ai02yenr6brz82ilxr	\N	MTN_MOMO	12500	\N	SUCCEEDED	2026-07-26 12:59:46.843
cms1t22ak02ypnr6b1h4efgk2	cms1t22ak02ylnr6bk90dg8sw	\N	CELTIIS_CASH	2150	\N	SUCCEEDED	2026-07-26 12:59:46.845
cms1t22an02yunr6bru93zv0m	cms1t22an02yrnr6bvyyufx1d	\N	CARD	5800	\N	SUCCEEDED	2026-07-26 12:59:46.847
cms1t22ap02z1nr6b0sbbvusr	cms1t22ap02ywnr6brv8ohmvc	\N	CELTIIS_CASH	4700	\N	SUCCEEDED	2026-07-26 12:59:46.85
cms1t22as02z7nr6bkmyndr6b	cms1t22as02z3nr6bj5qzpyan	\N	WAVE	5200	\N	SUCCEEDED	2026-07-26 12:59:46.852
cms1t22av02zenr6bkyvrcyb8	cms1t22au02z9nr6bf35aqmde	\N	CARD	9500	\N	SUCCEEDED	2026-07-26 12:59:46.855
cms1t22ax02zlnr6bv49lfn32	cms1t22ax02zgnr6bbryg9mz8	\N	MOOV_MONEY	6400	\N	SUCCEEDED	2026-07-26 12:59:46.857
cms1t22az02zsnr6b2022w7j2	cms1t22az02znnr6b6zvevx5e	\N	CELTIIS_CASH	7600	\N	SUCCEEDED	2026-07-26 12:59:46.86
cms1t22b202zxnr6b2xn8ue83	cms1t22b202zunr6b8y697sqr	\N	CARD	4200	\N	SUCCEEDED	2026-07-26 12:59:46.862
cms1t22b30302nr6b1cs0acio	cms1t22b302zznr6b32cnuav5	\N	WAVE	1100	\N	SUCCEEDED	2026-07-26 12:59:46.864
cms1t22b50309nr6bb56ykxri	cms1t22b50304nr6bt65b1joo	\N	WAVE	9500	\N	SUCCEEDED	2026-07-26 12:59:46.866
cms1t22b7030fnr6bf2bvb6w1	cms1t22b7030bnr6b94dns7hy	\N	MTN_MOMO	6100	\N	SUCCEEDED	2026-07-26 12:59:46.868
cms1t22b9030lnr6b9ajj4pmo	cms1t22b9030hnr6b0oyb8hil	\N	WAVE	7100	\N	SUCCEEDED	2026-07-26 12:59:46.87
cms1t22bc030snr6bt4ni3spb	cms1t22bc030nnr6bhne7rt5j	\N	WAVE	7450	\N	SUCCEEDED	2026-07-26 12:59:46.872
cms1t22be030xnr6b01lffitx	cms1t22be030unr6bgbl9surg	\N	CARD	2200	\N	SUCCEEDED	2026-07-26 12:59:46.874
cms1t22bg0312nr6b8p9afb5a	cms1t22bg030znr6b1miqcsih	\N	MTN_MOMO	5800	\N	SUCCEEDED	2026-07-26 12:59:46.876
cms1t22bi0318nr6bwrgnb2sg	cms1t22bi0314nr6b783wxeor	\N	MOOV_MONEY	7300	\N	SUCCEEDED	2026-07-26 12:59:46.878
cms1t22bk031fnr6brf4thfnq	cms1t22bk031anr6byhq4o6us	\N	MOOV_MONEY	5000	\N	SUCCEEDED	2026-07-26 12:59:46.881
cms1t22bn031knr6bv7lmok7g	cms1t22bn031hnr6b9rccdjw2	\N	WAVE	2500	\N	SUCCEEDED	2026-07-26 12:59:46.883
cms1t22bp031qnr6bqwwh03fu	cms1t22bp031mnr6b1eh0glbp	\N	CELTIIS_CASH	8200	\N	SUCCEEDED	2026-07-26 12:59:46.885
cms1t22br031vnr6btt0ldbxr	cms1t22br031snr6boqnjbuz6	\N	CELTIIS_CASH	2500	\N	SUCCEEDED	2026-07-26 12:59:46.887
cms1t22bt0322nr6b1sberott	cms1t22bt031xnr6b6ukq045p	\N	MOOV_MONEY	5500	\N	SUCCEEDED	2026-07-26 12:59:46.889
cms1t22bw0327nr6brj5kjxqe	cms1t22bw0324nr6b512b5g0i	\N	CELTIIS_CASH	2300	\N	SUCCEEDED	2026-07-26 12:59:46.892
cms1t22by032dnr6bfotw5nwi	cms1t22by0329nr6bnj6tuq7l	\N	CARD	7200	\N	SUCCEEDED	2026-07-26 12:59:46.895
cms1t22c1032knr6bbeikhllz	cms1t22c1032fnr6b4qa0s1cs	\N	MTN_MOMO	6000	\N	SUCCEEDED	2026-07-26 12:59:46.897
cms1t22c3032qnr6b1o5jnwss	cms1t22c3032mnr6be36eq99a	\N	MTN_MOMO	6600	\N	SUCCEEDED	2026-07-26 12:59:46.899
cms1t22c5032vnr6bvrf1uguz	cms1t22c5032snr6bkk9urxlc	\N	MTN_MOMO	5000	\N	SUCCEEDED	2026-07-26 12:59:46.902
\.


--
-- Data for Name: Permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Permission" (id, code, label) FROM stdin;
cms1t20wc0000nr6bi6olduhx	pos.sell	Encaisser une vente
cms1t20wc0001nr6bk1ywg4gb	pos.refund	Rembourser une vente
cms1t20wc0002nr6bsgj8yvv0	pos.close	Clôturer la caisse
cms1t20wc0003nr6bkntfh20x	stock.read	Consulter le stock
cms1t20wc0004nr6blxo7mdy4	stock.write	Créer et modifier des produits
cms1t20wc0005nr6bq9qki098	stock.move	Enregistrer un mouvement de stock
cms1t20wc0006nr6b6kstk1ls	prescriptions.read	Consulter les ordonnances
cms1t20wc0007nr6bbkybvywc	prescriptions.write	Créer et servir des ordonnances
cms1t20wc0008nr6b1t6w9snr	patients.read	Consulter les dossiers patients
cms1t20wc0009nr6bxc1m5qvw	patients.write	Modifier les dossiers patients
cms1t20wc000anr6b28c3js5v	suppliers.read	Consulter les fournisseurs
cms1t20wc000bnr6bq44remji	suppliers.write	Gérer commandes et fournisseurs
cms1t20wc000cnr6bw49b1w9e	accounting.read	Consulter la comptabilité
cms1t20wc000dnr6b6ffem65y	accounting.write	Saisir dépenses et exports
cms1t20wc000enr6bnrd68z8l	ai.read	Consulter les recommandations IA
cms1t20wc000fnr6b2lhl80r1	whatsapp.read	Lire les conversations
cms1t20wc000gnr6bb1yv4ks5	whatsapp.write	Répondre aux patients
cms1t20wc000hnr6bjuxs1yts	settings.write	Modifier les paramètres
cms1t20wc000inr6bvdm909az	users.manage	Gérer les utilisateurs
\.


--
-- Data for Name: Pharmacy; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Pharmacy" (id, name, city, district, country, currency, "licenseNo", phone, "whatsappNo", "openingHours", latitude, longitude, "createdAt") FROM stdin;
cms1t20wv000onr6b55iy581v	Pharmacie Étoile	Cotonou	Gbégamey	BJ	XOF	BJ-PH-2019-0447	+229 21 30 44 12	+229 97 00 00 00	{"dim": "09:00-13:00", "sam": "08:00-20:00", "lun_ven": "07:30-21:00"}	6.3703	2.3912	2026-07-26 12:59:45.055
cms1t213c0016nr6b2mn38qkv	Pharmacie Sainte-Rita	Cotonou	Akpakpa	BJ	XOF	\N	+229 21 33 08 45	+229 96 55 22 11	{"dim": "fermé", "sam": "08:00-19:00", "lun_ven": "08:00-20:00"}	6.3612	2.4501	2026-07-26 12:59:45.289
\.


--
-- Data for Name: PharmacyMember; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PharmacyMember" (id, "userId", "pharmacyId", "roleId", "isActive", "createdAt") FROM stdin;
cms1t20y6000rnr6bl9qfl0mp	cms1t20y6000pnr6bff7mdivr	cms1t20wv000onr6b55iy581v	cms1t20wf000jnr6b4v4fy08d	t	2026-07-26 12:59:45.102
cms1t20zi000unr6bv7slmvqx	cms1t20zi000snr6bkwt2cefn	cms1t20wv000onr6b55iy581v	cms1t20wk000knr6blaiu7gyh	t	2026-07-26 12:59:45.15
cms1t210q000xnr6b16obgm16	cms1t210q000vnr6b7r9y0xjl	cms1t20wv000onr6b55iy581v	cms1t20wn000lnr6bpzfl15gl	t	2026-07-26 12:59:45.195
cms1t211z0010nr6bbuwk4e3i	cms1t211z000ynr6b1czgd91f	cms1t20wv000onr6b55iy581v	cms1t20wq000mnr6b4ey11cjn	t	2026-07-26 12:59:45.239
cms1t21370013nr6bzqnw9zqz	cms1t21370011nr6bgnfndxb4	cms1t20wv000onr6b55iy581v	cms1t20ws000nnr6b79wxt179	t	2026-07-26 12:59:45.283
\.


--
-- Data for Name: Prescription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Prescription" (id, "pharmacyId", "patientId", prescriber, "issuedAt", "imageUrl", "ocrText", notes, status, "createdAt") FROM stdin;
cms1t214v003fnr6b0n42cld8	cms1t20wv000onr6b55iy581v	cms1t214q0035nr6bxwke21xg	Dr. Hounkpatin	2026-07-25 12:59:45.343	\N	\N	Traitement de 7 jours, contrôle tensionnel dans 2 semaines.	SERVED	2026-07-26 12:59:45.344
cms1t214y003knr6bjudiit9z	cms1t20wv000onr6b55iy581v	cms1t214s0039nr6bqwp5oiay	Dr. Diop	2026-07-26 12:59:45.346	\N	\N	\N	PENDING	2026-07-26 12:59:45.347
\.


--
-- Data for Name: PrescriptionItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PrescriptionItem" (id, "prescriptionId", "productId", label, dosage, duration, quantity, served) FROM stdin;
cms1t214v003gnr6ba8zux32n	cms1t214v003fnr6b0n42cld8	cms1t213j001fnr6bo0xtxete	Amoxicilline 500 mg	1 gél. x3/jour	7 jours	2	2
cms1t214v003hnr6bhf6e7xgn	cms1t214v003fnr6b0n42cld8	cms1t213n001knr6bouk3a3tn	Paracétamol 1 g	1 cp. si douleur	5 jours	1	1
cms1t214v003inr6bs9b2zrq1	cms1t214v003fnr6b0n42cld8	cms1t21420024nr6bx6rfau6u	Amlodipine 5 mg	1 cp. le matin	30 jours	1	1
cms1t214y003lnr6b04r8720q	cms1t214y003knr6bjudiit9z	cms1t213u001unr6bchir3jer	Metformine 850 mg	1 cp. matin et soir	30 jours	2	0
cms1t214z003mnr6bm2t5z9av	cms1t214y003knr6bjudiit9z	cms1t2148002enr6bduz6y0pt	Oméprazole 20 mg	1 gél. à jeun	14 jours	1	0
\.


--
-- Data for Name: Product; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Product" (id, "pharmacyId", name, dci, form, dosage, barcode, category, "purchasePrice", "salePrice", "alertThreshold", "isActive", "supplierId", "createdAt", "updatedAt", "isPublic", "requiresPrescription") FROM stdin;
cms1t213j001fnr6bo0xtxete	cms1t20wv000onr6b55iy581v	Amoxicilline 500 mg (12 gél.)	Amoxicilline	Gélule	500 mg	6001234500011	Antibiotique	1600	2500	40	t	cms1t213f0019nr6bd75ia6qv	2026-07-26 12:59:45.295	2026-07-26 12:59:45.295	t	t
cms1t213n001knr6bouk3a3tn	cms1t20wv000onr6b55iy581v	Paracétamol 1 g (8 cp.)	Paracétamol	Comprimé	1 g	6001234500028	Antalgique	420	700	60	t	cms1t213g001bnr6bwddqp84x	2026-07-26 12:59:45.3	2026-07-26 12:59:45.3	t	f
cms1t213r001pnr6b1h8a1knk	cms1t20wv000onr6b55iy581v	Artéméther/Luméfantrine 20/120	Artéméther + Luméfantrine	Comprimé	20/120 mg	6001234500035	Antipaludique	1750	2900	35	t	cms1t213f0019nr6bd75ia6qv	2026-07-26 12:59:45.303	2026-07-26 12:59:45.303	t	f
cms1t213u001unr6bchir3jer	cms1t20wv000onr6b55iy581v	Metformine 850 mg (30 cp.)	Metformine	Comprimé	850 mg	6001234500042	Antidiabétique	1200	2100	25	t	cms1t213h001dnr6bf4bapvdt	2026-07-26 12:59:45.306	2026-07-26 12:59:45.306	t	t
cms1t213y001znr6bn4g49x3z	cms1t20wv000onr6b55iy581v	Sérum physiologique 5 ml x20	Chlorure de sodium 0,9 %	Unidose	5 ml	6001234500059	Dispositif	900	1500	30	t	cms1t213g001bnr6bwddqp84x	2026-07-26 12:59:45.311	2026-07-26 12:59:45.311	t	f
cms1t21420024nr6bx6rfau6u	cms1t20wv000onr6b55iy581v	Amlodipine 5 mg (30 cp.)	Amlodipine	Comprimé	5 mg	6001234500066	Antihypertenseur	1050	1800	20	t	cms1t213h001dnr6bf4bapvdt	2026-07-26 12:59:45.314	2026-07-26 12:59:45.314	t	t
cms1t21450029nr6bveyybk94	cms1t20wv000onr6b55iy581v	Ibuprofène 400 mg (20 cp.)	Ibuprofène	Comprimé	400 mg	6001234500073	Anti-inflammatoire	650	1100	40	t	cms1t213f0019nr6bd75ia6qv	2026-07-26 12:59:45.318	2026-07-26 12:59:45.318	t	f
cms1t2148002enr6bduz6y0pt	cms1t20wv000onr6b55iy581v	Oméprazole 20 mg (14 gél.)	Oméprazole	Gélule	20 mg	6001234500080	Anti-ulcéreux	1350	2300	25	t	cms1t213h001dnr6bf4bapvdt	2026-07-26 12:59:45.32	2026-07-26 12:59:45.32	t	t
cms1t214b002jnr6bleifzk78	cms1t20wv000onr6b55iy581v	Sels de réhydratation orale (sachet)	SRO	Poudre	20,5 g	6001234500097	Pédiatrie	180	350	100	t	cms1t213g001bnr6bwddqp84x	2026-07-26 12:59:45.323	2026-07-26 12:59:45.323	t	f
cms1t214f002onr6b0nbz3phb	cms1t20wv000onr6b55iy581v	Vitamine B12 injectable (5 amp.)	Cyanocobalamine	Ampoule	1000 µg	6001234500103	Vitamine	2100	3400	10	t	cms1t213f0019nr6bd75ia6qv	2026-07-26 12:59:45.327	2026-07-26 12:59:45.327	t	f
cms1t214i002tnr6b7n23fpf1	cms1t213c0016nr6b2mn38qkv	Paracétamol 1 g (8 cp.)	Paracétamol	\N	\N	\N	Général	400	650	25	t	\N	2026-07-26 12:59:45.331	2026-07-26 12:59:45.331	t	f
cms1t214k002wnr6b8m83lwhz	cms1t213c0016nr6b2mn38qkv	Artéméther/Luméfantrine 20/120	Artéméther + Luméfantrine	\N	\N	\N	Général	1700	2750	25	t	\N	2026-07-26 12:59:45.333	2026-07-26 12:59:45.333	t	f
cms1t214m002znr6bfxmgt8qk	cms1t213c0016nr6b2mn38qkv	Sels de réhydratation orale (sachet)	SRO	\N	\N	\N	Général	175	300	25	t	\N	2026-07-26 12:59:45.335	2026-07-26 12:59:45.335	t	f
cms1t214o0032nr6blyft2db4	cms1t213c0016nr6b2mn38qkv	Ibuprofène 400 mg (20 cp.)	Ibuprofène	\N	\N	\N	Général	630	1000	25	t	\N	2026-07-26 12:59:45.336	2026-07-26 12:59:45.336	t	f
\.


--
-- Data for Name: ProductBatch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ProductBatch" (id, "productId", "batchNo", quantity, "expiryDate", "costPrice", "receivedAt") FROM stdin;
cms1t213j001gnr6brtago8y2	cms1t213j001fnr6bo0xtxete	LOT-A231	126	2027-03-31 00:00:00	1600	2026-07-26 12:59:45.295
cms1t213n001lnr6bx72860r3	cms1t213n001knr6bouk3a3tn	LOT-P118	28	2026-11-30 00:00:00	420	2026-07-26 12:59:45.3
cms1t213r001qnr6bf8qb6nln	cms1t213r001pnr6b1h8a1knk	LOT-M442	15	2026-09-15 00:00:00	1750	2026-07-26 12:59:45.303
cms1t213u001vnr6bpu7eo58c	cms1t213u001unr6bchir3jer	LOT-D907	74	2028-01-31 00:00:00	1200	2026-07-26 12:59:45.306
cms1t213y0020nr6biutj5xzj	cms1t213y001znr6bn4g49x3z	LOT-S330	9	2026-08-20 00:00:00	900	2026-07-26 12:59:45.311
cms1t21420025nr6b363i03ty	cms1t21420024nr6bx6rfau6u	LOT-C551	58	2027-06-30 00:00:00	1050	2026-07-26 12:59:45.314
cms1t2145002anr6bw6lpx9qz	cms1t21450029nr6bveyybk94	LOT-I204	92	2027-10-31 00:00:00	650	2026-07-26 12:59:45.318
cms1t2148002fnr6b1cxewyx1	cms1t2148002enr6bduz6y0pt	LOT-O615	47	2027-12-31 00:00:00	1350	2026-07-26 12:59:45.32
cms1t214b002knr6b6wa50arx	cms1t214b002jnr6bleifzk78	LOT-R881	240	2028-04-30 00:00:00	180	2026-07-26 12:59:45.323
cms1t214f002pnr6bi3f35xl1	cms1t214f002onr6b0nbz3phb	LOT-V119	33	2027-02-28 00:00:00	2100	2026-07-26 12:59:45.327
cms1t214i002unr6b2bq9xc8x	cms1t214i002tnr6b7n23fpf1	LOT-SR01	140	2027-05-31 00:00:00	400	2026-07-26 12:59:45.331
cms1t214k002xnr6bcf2mpx1i	cms1t214k002wnr6b8m83lwhz	LOT-SR02	95	2027-08-31 00:00:00	1700	2026-07-26 12:59:45.333
cms1t214m0030nr6b6u8jj3x4	cms1t214m002znr6bfxmgt8qk	LOT-SR03	320	2028-06-30 00:00:00	175	2026-07-26 12:59:45.335
cms1t214o0033nr6bktzbs4bz	cms1t214o0032nr6blyft2db4	LOT-SR04	110	2027-11-30 00:00:00	630	2026-07-26 12:59:45.336
\.


--
-- Data for Name: PurchaseOrder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrder" (id, "pharmacyId", "supplierId", reference, status, "totalAmount", "expectedAt", "receivedAt", "invoiceUrl", "createdAt") FROM stdin;
cms1t22cf0339nr6b4nkntbdz	cms1t20wv000onr6b55iy581v	cms1t213f0019nr6bd75ia6qv	BC-1187	RECEIVED	1240000	\N	2026-07-24 12:59:46.911	\N	2026-07-26 12:59:46.911
cms1t22ci033cnr6b14adp13z	cms1t20wv000onr6b55iy581v	cms1t213g001bnr6bwddqp84x	BC-1188	IN_TRANSIT	430000	2026-07-27 12:59:46.914	\N	\N	2026-07-26 12:59:46.914
\.


--
-- Data for Name: PurchaseOrderItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseOrderItem" (id, "orderId", "productId", quantity, "unitCost", received) FROM stdin;
cms1t22cf033anr6b36ascv7r	cms1t22cf0339nr6b4nkntbdz	cms1t213j001fnr6bo0xtxete	100	1600	100
cms1t22ci033dnr6b3w7yhwgk	cms1t22ci033cnr6b14adp13z	cms1t213n001knr6bouk3a3tn	200	420	0
\.


--
-- Data for Name: Reservation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Reservation" (id, "conversationId", "pharmacyId", "productId", quantity, reference, "expiresAt", status, "createdAt", "customerName", "customerPhoneEnc", "productLabel", source, "unitPrice") FROM stdin;
cms1t22cn033lnr6b9vk4hjni	cms1t22ck033fnr6bh7azworc	cms1t20wv000onr6b55iy581v	cms1t213j001fnr6bo0xtxete	1	R-8842	2026-07-26 14:59:46.919	ACTIVE	2026-07-26 12:59:46.919	\N	\N	\N	WHATSAPP	\N
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Role" (id, name, label) FROM stdin;
cms1t20wf000jnr6b4v4fy08d	OWNER	Pharmacien titulaire
cms1t20wk000knr6blaiu7gyh	PHARMACIST	Pharmacien
cms1t20wn000lnr6bpzfl15gl	TECHNICIAN	Préparateur
cms1t20wq000mnr6b4ey11cjn	CASHIER	Caissier
cms1t20ws000nnr6b79wxt179	ACCOUNTANT	Comptable
\.


--
-- Data for Name: Sale; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Sale" (id, "pharmacyId", "userId", "patientId", "prescriptionId", reference, subtotal, discount, total, status, "offlineUuid", "soldAt") FROM stdin;
cms1t2151003onr6bnwud5kgb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89001	4700	0	4700	COMPLETED	\N	2026-05-28 09:00:00
cms1t2155003unr6bwpbbqzf7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89002	4100	0	4100	COMPLETED	\N	2026-05-28 09:37:00
cms1t21580040nr6b5scrzqss	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89003	2100	0	2100	COMPLETED	\N	2026-05-28 10:14:00
cms1t215a0045nr6b481vzicb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89004	700	0	700	COMPLETED	\N	2026-05-28 10:51:00
cms1t215c004anr6b5911j9gk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89005	6200	0	6200	COMPLETED	\N	2026-05-28 11:28:00
cms1t215f004hnr6beii3gk95	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89006	12500	0	12500	COMPLETED	\N	2026-05-28 12:05:00
cms1t215i004onr6b9ch3u2hp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89007	5300	0	5300	COMPLETED	\N	2026-05-28 12:42:00
cms1t215k004unr6bwgaa6v2u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89008	5100	0	5100	COMPLETED	\N	2026-05-28 13:19:00
cms1t215m0050nr6bdgeu0b3y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89009	6300	0	6300	COMPLETED	\N	2026-05-28 13:56:00
cms1t215p0056nr6b3fnbt8mb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89010	4200	0	4200	COMPLETED	\N	2026-05-29 09:00:00
cms1t215r005dnr6bzyz37pwu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89011	9700	0	9700	COMPLETED	\N	2026-05-29 09:37:00
cms1t215u005knr6bnayndrpj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89012	7200	0	7200	COMPLETED	\N	2026-05-29 10:14:00
cms1t215w005qnr6bzqyr8w3d	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89013	10000	0	10000	COMPLETED	\N	2026-05-29 10:51:00
cms1t215y005xnr6bwnipt8u2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89014	10700	0	10700	COMPLETED	\N	2026-05-29 11:28:00
cms1t21600064nr6b3nltdua5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89015	8650	0	8650	COMPLETED	\N	2026-05-29 12:05:00
cms1t2163006bnr6belfz3r25	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89016	2550	0	2550	COMPLETED	\N	2026-05-29 12:42:00
cms1t2165006hnr6bsjgz3ixx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89017	5000	0	5000	COMPLETED	\N	2026-05-29 13:19:00
cms1t2167006mnr6b09sbkypy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89018	5100	0	5100	COMPLETED	\N	2026-05-29 13:56:00
cms1t2169006snr6b5xab38za	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89019	2900	0	2900	COMPLETED	\N	2026-05-30 09:00:00
cms1t216b006xnr6bstwm89g4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89020	6000	0	6000	COMPLETED	\N	2026-05-30 09:37:00
cms1t216d0074nr6bk7jvr0rp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89021	8550	0	8550	COMPLETED	\N	2026-05-30 10:14:00
cms1t216f007bnr6bq7x7b7uv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89022	11300	0	11300	COMPLETED	\N	2026-05-30 10:51:00
cms1t216h007inr6bn3gfco94	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89023	8600	0	8600	COMPLETED	\N	2026-05-30 11:28:00
cms1t216k007onr6brl74o6wt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89024	6400	0	6400	COMPLETED	\N	2026-05-30 12:05:00
cms1t216m007unr6byizw8nsl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89025	1400	0	1400	COMPLETED	\N	2026-05-30 12:42:00
cms1t216p007znr6bwqu6d39y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89026	11500	0	11500	COMPLETED	\N	2026-05-30 13:19:00
cms1t216s0086nr6bx4720lro	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89027	13300	0	13300	COMPLETED	\N	2026-05-30 13:56:00
cms1t216u008dnr6bn9s3vuya	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89028	700	0	700	COMPLETED	\N	2026-05-30 14:33:00
cms1t216x008inr6b6h5b6rh6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89029	5700	0	5700	COMPLETED	\N	2026-05-31 09:00:00
cms1t216z008onr6bzfy17owe	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89030	700	0	700	COMPLETED	\N	2026-05-31 09:37:00
cms1t2171008tnr6bzap4zhsw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89031	9100	0	9100	COMPLETED	\N	2026-05-31 10:14:00
cms1t2173008znr6beylz8jbb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89032	8400	0	8400	COMPLETED	\N	2026-05-31 10:51:00
cms1t21750096nr6bt2n0o6ka	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89033	700	0	700	COMPLETED	\N	2026-05-31 11:28:00
cms1t2177009bnr6bksa4etu6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89034	5400	0	5400	COMPLETED	\N	2026-05-31 12:05:00
cms1t217a009inr6bdkt8dnpi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89035	1100	0	1100	COMPLETED	\N	2026-05-31 12:42:00
cms1t217c009nnr6bqc2x5znn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89036	700	0	700	COMPLETED	\N	2026-06-01 09:00:00
cms1t217e009snr6bybqsm0zn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89037	7500	0	7500	COMPLETED	\N	2026-06-01 09:37:00
cms1t217g009ynr6bhq08w3mr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89038	700	0	700	COMPLETED	\N	2026-06-01 10:14:00
cms1t217i00a3nr6bdv1w4g3x	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89039	8300	0	8300	COMPLETED	\N	2026-06-01 10:51:00
cms1t217k00aanr6bordo3p36	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89040	5700	0	5700	COMPLETED	\N	2026-06-01 11:28:00
cms1t217m00agnr6bansb3jqi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89041	4600	0	4600	COMPLETED	\N	2026-06-01 12:05:00
cms1t217o00amnr6bk63hroay	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89042	3900	0	3900	COMPLETED	\N	2026-06-01 12:42:00
cms1t217r00asnr6bdoxs0870	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89043	10600	0	10600	COMPLETED	\N	2026-06-01 13:19:00
cms1t217u00aznr6bv7n9ypuy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89044	4700	0	4700	COMPLETED	\N	2026-06-01 13:56:00
cms1t217w00b6nr6bvk7updgz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89045	700	0	700	COMPLETED	\N	2026-06-01 14:33:00
cms1t217y00bbnr6b37iqve1e	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89046	8400	0	8400	COMPLETED	\N	2026-06-01 15:10:00
cms1t218100binr6bwlbzf5hj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89047	10000	0	10000	COMPLETED	\N	2026-06-01 15:47:00
cms1t218300bonr6blqzsqkb9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89048	1400	0	1400	COMPLETED	\N	2026-06-02 09:00:00
cms1t218500btnr6bul7u1g6t	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89049	9700	0	9700	COMPLETED	\N	2026-06-02 09:37:00
cms1t218700c0nr6bglis7yfv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89050	5000	0	5000	COMPLETED	\N	2026-06-02 10:14:00
cms1t218900c5nr6b6lihneyp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89051	7100	0	7100	COMPLETED	\N	2026-06-02 10:51:00
cms1t218c00ccnr6bplz20onj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89052	7650	0	7650	COMPLETED	\N	2026-06-02 11:28:00
cms1t218f00cjnr6b65wmbmak	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89053	8300	0	8300	COMPLETED	\N	2026-06-02 12:05:00
cms1t218h00cqnr6btpzzetph	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89054	4600	0	4600	COMPLETED	\N	2026-06-02 12:42:00
cms1t218j00cwnr6b3enubeil	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89055	5900	0	5900	COMPLETED	\N	2026-06-02 13:19:00
cms1t218m00d2nr6bkru5pgq7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89056	11200	0	11200	COMPLETED	\N	2026-06-02 13:56:00
cms1t218o00d9nr6b15gipjzg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89057	11000	0	11000	COMPLETED	\N	2026-06-02 14:33:00
cms1t218q00dgnr6bk2wnw6ul	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89058	4200	0	4200	COMPLETED	\N	2026-06-02 15:10:00
cms1t218t00dlnr6b0za9pmxt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89059	5300	0	5300	COMPLETED	\N	2026-06-02 15:47:00
cms1t218v00drnr6b6gce71y9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89060	8300	0	8300	COMPLETED	\N	2026-06-03 09:00:00
cms1t218x00dynr6bq3fpzlos	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89061	2500	0	2500	COMPLETED	\N	2026-06-03 09:37:00
cms1t219000e4nr6becokoyol	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89062	2200	0	2200	COMPLETED	\N	2026-06-03 10:14:00
cms1t219200e9nr6bhhzygs5o	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89063	4800	0	4800	COMPLETED	\N	2026-06-03 10:51:00
cms1t219400egnr6bwcargq9a	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89064	1400	0	1400	COMPLETED	\N	2026-06-03 11:28:00
cms1t219600elnr6bje0qmhjr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89065	5800	0	5800	COMPLETED	\N	2026-06-03 12:05:00
cms1t219800eqnr6bo1dilwka	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89066	9000	0	9000	COMPLETED	\N	2026-06-03 12:42:00
cms1t219b00exnr6bx4n4xdwp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89067	1100	0	1100	COMPLETED	\N	2026-06-03 13:19:00
cms1t219c00f2nr6b3wn4ipgz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89068	8900	0	8900	COMPLETED	\N	2026-06-03 13:56:00
cms1t219f00f8nr6bex0cqw68	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89069	2300	0	2300	COMPLETED	\N	2026-06-03 14:33:00
cms1t219g00fdnr6buib92k4l	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89070	700	0	700	COMPLETED	\N	2026-06-03 15:10:00
cms1t219j00finr6bxiiqtaoq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89071	9300	0	9300	COMPLETED	\N	2026-06-03 15:47:00
cms1t219m00fpnr6b6qmd6hdj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89072	4200	0	4200	COMPLETED	\N	2026-06-04 09:00:00
cms1t219o00funr6bmnslwms5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89073	6100	0	6100	COMPLETED	\N	2026-06-04 09:37:00
cms1t219q00g0nr6b7rly0p6j	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89074	8200	0	8200	COMPLETED	\N	2026-06-04 10:14:00
cms1t219t00g6nr6b3j98x563	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89075	8000	0	8000	COMPLETED	\N	2026-06-04 10:51:00
cms1t219v00gcnr6btkyka0t3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89076	9300	0	9300	COMPLETED	\N	2026-06-04 11:28:00
cms1t219x00gjnr6bo9xmxv2z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89077	4200	0	4200	COMPLETED	\N	2026-06-04 12:05:00
cms1t219z00gonr6bm40otior	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89078	3900	0	3900	COMPLETED	\N	2026-06-04 12:42:00
cms1t21a200gunr6b41fn4mul	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89079	7500	0	7500	COMPLETED	\N	2026-06-04 13:19:00
cms1t21a500h1nr6bw6gremyx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89080	9200	0	9200	COMPLETED	\N	2026-06-04 13:56:00
cms1t21a800h8nr6bov9dndzv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89081	3900	0	3900	COMPLETED	\N	2026-06-04 14:33:00
cms1t21ab00henr6bu8c8z3nb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89082	5000	0	5000	COMPLETED	\N	2026-06-04 15:10:00
cms1t21ad00hknr6bhp6woaws	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89083	6800	0	6800	COMPLETED	\N	2026-06-04 15:47:00
cms1t21af00hpnr6b9wcuo47y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89084	7100	0	7100	COMPLETED	\N	2026-06-04 16:24:00
cms1t21ah00hvnr6bwuk0sll6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89085	7100	0	7100	COMPLETED	\N	2026-06-04 17:01:00
cms1t21ak00i1nr6b0hcbcs8o	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89086	1100	0	1100	COMPLETED	\N	2026-06-05 09:00:00
cms1t21am00i6nr6bqyso4gxj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89087	2900	0	2900	COMPLETED	\N	2026-06-05 09:37:00
cms1t21ao00ibnr6bke4cg7jt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89088	7500	0	7500	COMPLETED	\N	2026-06-05 10:14:00
cms1t21aq00iinr6baqrpeykl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89089	2500	0	2500	COMPLETED	\N	2026-06-05 10:51:00
cms1t21at00innr6blzf5jv9z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89090	3600	0	3600	COMPLETED	\N	2026-06-05 11:28:00
cms1t21av00isnr6burclbzuv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89091	8000	0	8000	COMPLETED	\N	2026-06-05 12:05:00
cms1t21ax00iynr6bftwb1x3r	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89092	4700	0	4700	COMPLETED	\N	2026-06-05 12:42:00
cms1t21az00j4nr6bu5sw442i	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89093	3200	0	3200	COMPLETED	\N	2026-06-05 13:19:00
cms1t21b200janr6b7kpvkrh4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89094	1800	0	1800	COMPLETED	\N	2026-06-06 09:00:00
cms1t21b400jgnr6bmtietzdu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89095	9600	0	9600	COMPLETED	\N	2026-06-06 09:37:00
cms1t21b700jmnr6b84qzjrch	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89096	8300	0	8300	COMPLETED	\N	2026-06-06 10:14:00
cms1t21ba00jtnr6bqiiaxycz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89097	7800	0	7800	COMPLETED	\N	2026-06-06 10:51:00
cms1t21bd00jznr6brudgtyec	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89098	8600	0	8600	COMPLETED	\N	2026-06-06 11:28:00
cms1t21bf00k6nr6b9m3us5aq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89099	3300	0	3300	COMPLETED	\N	2026-06-06 12:05:00
cms1t21bi00kcnr6btswmnc8w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89100	4400	0	4400	COMPLETED	\N	2026-06-06 12:42:00
cms1t21bk00kjnr6bhyo4fru2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89101	10300	0	10300	COMPLETED	\N	2026-06-06 13:19:00
cms1t21bn00kqnr6b5e07es4r	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89102	4200	0	4200	COMPLETED	\N	2026-06-06 13:56:00
cms1t21bp00kvnr6baim031ps	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89103	7000	0	7000	COMPLETED	\N	2026-06-06 14:33:00
cms1t21bs00l2nr6b8whu69u9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89104	11500	0	11500	COMPLETED	\N	2026-06-06 15:10:00
cms1t21bu00l9nr6bjr0j79bs	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89105	5200	0	5200	COMPLETED	\N	2026-06-06 15:47:00
cms1t21bx00lgnr6b5p71e320	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89106	5000	0	5000	COMPLETED	\N	2026-06-06 16:24:00
cms1t21bz00llnr6bmamgdq0v	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89107	10900	0	10900	COMPLETED	\N	2026-06-06 17:01:00
cms1t21c200lsnr6b76pubzh4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89108	6400	0	6400	COMPLETED	\N	2026-06-07 09:00:00
cms1t21c400lynr6br9yvnhca	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89109	3300	0	3300	COMPLETED	\N	2026-06-07 09:37:00
cms1t21c700m4nr6bei29qv5w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89110	4500	0	4500	COMPLETED	\N	2026-06-07 10:14:00
cms1t21c900manr6bzbebgnzp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89111	2100	0	2100	COMPLETED	\N	2026-06-07 10:51:00
cms1t21cb00mfnr6bthg1yywh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89112	2300	0	2300	COMPLETED	\N	2026-06-08 09:00:00
cms1t21cd00mknr6bzau6mwc7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89113	6500	0	6500	COMPLETED	\N	2026-06-08 09:37:00
cms1t21cf00mqnr6b9c55rw3o	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89114	6400	0	6400	COMPLETED	\N	2026-06-08 10:14:00
cms1t21ci00mwnr6be0xu0q7q	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89115	350	0	350	COMPLETED	\N	2026-06-08 10:51:00
cms1t21ck00n1nr6bhj21i97u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89116	4600	0	4600	COMPLETED	\N	2026-06-08 11:28:00
cms1t21cm00n6nr6bawpzjbfi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89117	1800	0	1800	COMPLETED	\N	2026-06-08 12:05:00
cms1t21co00nbnr6b27ez4uyu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89118	3200	0	3200	COMPLETED	\N	2026-06-08 12:42:00
cms1t21cr00nhnr6bpix9gjcq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89119	5100	0	5100	COMPLETED	\N	2026-06-08 13:19:00
cms1t21ct00nnnr6byin90bde	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89120	5650	0	5650	COMPLETED	\N	2026-06-08 13:56:00
cms1t21cw00nunr6bweax036u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89121	3900	0	3900	COMPLETED	\N	2026-06-08 14:33:00
cms1t21cy00o0nr6b0a1vsv95	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89122	6500	0	6500	COMPLETED	\N	2026-06-08 15:10:00
cms1t21d000o6nr6bg0mcmwzn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89123	350	0	350	COMPLETED	\N	2026-06-09 09:00:00
cms1t21d300obnr6bxx10mfz4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89124	3600	0	3600	COMPLETED	\N	2026-06-09 09:37:00
cms1t21d500ohnr6bby1ysuf9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89125	2500	0	2500	COMPLETED	\N	2026-06-09 10:14:00
cms1t21d700omnr6bbu1zvs2n	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89126	5000	0	5000	COMPLETED	\N	2026-06-09 10:51:00
cms1t21d900ornr6b7opnpj28	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89127	8700	0	8700	COMPLETED	\N	2026-06-09 11:28:00
cms1t21dc00oynr6bclcb5yea	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89128	2900	0	2900	COMPLETED	\N	2026-06-09 12:05:00
cms1t21de00p3nr6biawd5o48	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89129	5200	0	5200	COMPLETED	\N	2026-06-09 12:42:00
cms1t21dg00p9nr6bgdmg1n6z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89130	11800	0	11800	COMPLETED	\N	2026-06-09 13:19:00
cms1t21dj00pfnr6bhwvfrbdy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89131	9600	0	9600	COMPLETED	\N	2026-06-09 13:56:00
cms1t21dl00plnr6bbu71uo2g	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89132	7600	0	7600	COMPLETED	\N	2026-06-09 14:33:00
cms1t21do00psnr6b0doj3zsd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89133	2900	0	2900	COMPLETED	\N	2026-06-09 15:10:00
cms1t21dq00pxnr6bx56uz32s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89134	3600	0	3600	COMPLETED	\N	2026-06-09 15:47:00
cms1t21ds00q3nr6bt1jem3vm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89135	8600	0	8600	COMPLETED	\N	2026-06-09 16:24:00
cms1t21dv00qanr6bw449e5zv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89136	5000	0	5000	COMPLETED	\N	2026-06-09 17:01:00
cms1t21dx00qfnr6bmj7ic24t	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89137	1500	0	1500	COMPLETED	\N	2026-06-09 17:38:00
cms1t21dz00qknr6b6m1fed14	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89138	3000	0	3000	COMPLETED	\N	2026-06-10 09:00:00
cms1t21e200qqnr6b346gkjld	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89139	6100	0	6100	COMPLETED	\N	2026-06-10 09:37:00
cms1t21e400qwnr6bwnum2h94	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89140	4800	0	4800	COMPLETED	\N	2026-06-10 10:14:00
cms1t21e700r2nr6b27yq1fdk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89141	2200	0	2200	COMPLETED	\N	2026-06-10 10:51:00
cms1t21e900r7nr6bt8cuoloo	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89142	8400	0	8400	COMPLETED	\N	2026-06-10 11:28:00
cms1t21eb00renr6b0hcux5k7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89143	2100	0	2100	COMPLETED	\N	2026-06-10 12:05:00
cms1t21ee00rjnr6bpt9v3xld	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89144	5500	0	5500	COMPLETED	\N	2026-06-10 12:42:00
cms1t21eg00rpnr6bx7ro9hdu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89145	4800	0	4800	COMPLETED	\N	2026-06-10 13:19:00
cms1t21ej00rvnr6bre43tkfy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89146	6000	0	6000	COMPLETED	\N	2026-06-10 13:56:00
cms1t21el00s2nr6bnew6jm5x	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89147	4600	0	4600	COMPLETED	\N	2026-06-10 14:33:00
cms1t21eo00s7nr6bilyp3esk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89148	10200	0	10200	COMPLETED	\N	2026-06-10 15:10:00
cms1t21er00senr6ba5nh5nf8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89149	7800	0	7800	COMPLETED	\N	2026-06-10 15:47:00
cms1t21eu00sknr6bkdwajpii	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89150	5100	0	5100	COMPLETED	\N	2026-06-10 16:24:00
cms1t21ew00srnr6b4louos0w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89151	700	0	700	COMPLETED	\N	2026-06-10 17:01:00
cms1t21ez00swnr6b8en21m0w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89152	6800	0	6800	COMPLETED	\N	2026-06-10 17:38:00
cms1t21f100t3nr6bzzp1q38l	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89153	2100	0	2100	COMPLETED	\N	2026-06-11 09:00:00
cms1t21f300t8nr6bu4bcxvfg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89154	14000	0	14000	COMPLETED	\N	2026-06-11 09:37:00
cms1t21f600tfnr6b4cr0f7gm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89155	8300	0	8300	COMPLETED	\N	2026-06-11 10:14:00
cms1t21f800tmnr6bkgw5t0if	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89156	8300	0	8300	COMPLETED	\N	2026-06-11 10:51:00
cms1t21fb00ttnr6bgonzdwz1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89157	7600	0	7600	COMPLETED	\N	2026-06-11 11:28:00
cms1t21fe00u0nr6bc21qvimu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89158	1800	0	1800	COMPLETED	\N	2026-06-11 12:05:00
cms1t21fg00u5nr6by9ts894h	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89159	7300	0	7300	COMPLETED	\N	2026-06-11 12:42:00
cms1t21fi00ucnr6bkxvue0z9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89160	5900	0	5900	COMPLETED	\N	2026-06-11 13:19:00
cms1t21fk00ujnr6but2q7xab	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89161	2900	0	2900	COMPLETED	\N	2026-06-11 13:56:00
cms1t21fm00uonr6bo4b4lu84	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89162	4700	0	4700	COMPLETED	\N	2026-06-11 14:33:00
cms1t21fo00uunr6b95xpw4fz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89163	1500	0	1500	COMPLETED	\N	2026-06-11 15:10:00
cms1t21fq00uznr6b8wdqj5xf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89164	4600	0	4600	COMPLETED	\N	2026-06-11 15:47:00
cms1t21fs00v4nr6btu2s5j20	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89165	6800	0	6800	COMPLETED	\N	2026-06-11 16:24:00
cms1t21fu00v9nr6bq5bh8i1c	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89166	7900	0	7900	COMPLETED	\N	2026-06-11 17:01:00
cms1t21fx00vgnr6b122qi9mk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89167	5200	0	5200	COMPLETED	\N	2026-06-12 09:00:00
cms1t21fz00vnnr6bu7to0r6z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89168	5900	0	5900	COMPLETED	\N	2026-06-12 09:37:00
cms1t21g200vtnr6bnscq2gnk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89169	8900	0	8900	COMPLETED	\N	2026-06-12 10:14:00
cms1t21g400w0nr6bqrpl27jm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89170	5800	0	5800	COMPLETED	\N	2026-06-12 10:51:00
cms1t21g600w5nr6b29tnqvk8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89171	4600	0	4600	COMPLETED	\N	2026-06-12 11:28:00
cms1t21g900wanr6bgspc3fx0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89172	5300	0	5300	COMPLETED	\N	2026-06-12 12:05:00
cms1t21gb00wgnr6bo7fksqxi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89173	5000	0	5000	COMPLETED	\N	2026-06-12 12:42:00
cms1t21gd00wlnr6bk6jvtq4y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89174	2500	0	2500	COMPLETED	\N	2026-06-12 13:19:00
cms1t21gg00wqnr6b3lq4noue	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89175	6600	0	6600	COMPLETED	\N	2026-06-13 09:00:00
cms1t21gi00wwnr6bht153dzm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89176	2600	0	2600	COMPLETED	\N	2026-06-13 09:37:00
cms1t21gl00x2nr6bgle6m1o1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89177	1400	0	1400	COMPLETED	\N	2026-06-13 10:14:00
cms1t21gn00x7nr6bs4lm2wit	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89178	12600	0	12600	COMPLETED	\N	2026-06-13 10:51:00
cms1t21gq00xenr6buivx9d0s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89179	4600	0	4600	COMPLETED	\N	2026-06-13 11:28:00
cms1t21gs00xjnr6bm5vck9cs	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89180	2200	0	2200	COMPLETED	\N	2026-06-13 12:05:00
cms1t21gu00xonr6bfqfx1u0m	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89181	7900	0	7900	COMPLETED	\N	2026-06-13 12:42:00
cms1t21gx00xvnr6b9xp258p5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89182	2100	0	2100	COMPLETED	\N	2026-06-13 13:19:00
cms1t21gz00y0nr6b4s6kz5eh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89183	7100	0	7100	COMPLETED	\N	2026-06-14 09:00:00
cms1t21h200y7nr6b9yu34bvf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89184	12200	0	12200	COMPLETED	\N	2026-06-14 09:37:00
cms1t21h500yenr6bxjrrxgnm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89185	1100	0	1100	COMPLETED	\N	2026-06-14 10:14:00
cms1t21h700yjnr6bmcvf7rrs	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89186	9100	0	9100	COMPLETED	\N	2026-06-14 10:51:00
cms1t21ha00yqnr6b3ifcejx6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89187	7450	0	7450	COMPLETED	\N	2026-06-14 11:28:00
cms1t21hc00yxnr6bt0jzcftr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89188	6850	0	6850	COMPLETED	\N	2026-06-15 09:00:00
cms1t21hf00z4nr6bml7nyjvu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89189	5800	0	5800	COMPLETED	\N	2026-06-15 09:37:00
cms1t21hh00z9nr6b7gnyzrvp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89190	11100	0	11100	COMPLETED	\N	2026-06-15 10:14:00
cms1t21hj00zgnr6b3d6rb0jp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89191	4450	0	4450	COMPLETED	\N	2026-06-15 10:51:00
cms1t21hm00znnr6b36ldufcw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89192	6700	0	6700	COMPLETED	\N	2026-06-15 11:28:00
cms1t21ho00ztnr6b290lu4ts	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89193	9700	0	9700	COMPLETED	\N	2026-06-15 12:05:00
cms1t21hr0100nr6b672wbsw1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89194	5700	0	5700	COMPLETED	\N	2026-06-15 12:42:00
cms1t21ht0106nr6bw823eghw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89195	2200	0	2200	COMPLETED	\N	2026-06-15 13:19:00
cms1t21hv010bnr6bs3sv5s5v	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89196	6800	0	6800	COMPLETED	\N	2026-06-15 13:56:00
cms1t21hx010gnr6bvb59eldp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89197	3200	0	3200	COMPLETED	\N	2026-06-15 14:33:00
cms1t21i0010mnr6b00vutqjx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89198	10500	0	10500	COMPLETED	\N	2026-06-15 15:10:00
cms1t21i2010tnr6b9rc0tep1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89199	6200	0	6200	COMPLETED	\N	2026-06-15 15:47:00
cms1t21i40110nr6b0lbhicne	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89200	7350	0	7350	COMPLETED	\N	2026-06-16 09:00:00
cms1t21i70117nr6bx4gm7ylk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89201	8900	0	8900	COMPLETED	\N	2026-06-16 09:37:00
cms1t21i9011enr6bvqv7w1ge	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89202	4400	0	4400	COMPLETED	\N	2026-06-16 10:14:00
cms1t21ib011knr6b0uwbzrob	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89203	9000	0	9000	COMPLETED	\N	2026-06-16 10:51:00
cms1t21id011qnr6bosyu3hq8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89204	10700	0	10700	COMPLETED	\N	2026-06-16 11:28:00
cms1t21ig011xnr6be2iec6kx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89205	700	0	700	COMPLETED	\N	2026-06-16 12:05:00
cms1t21ih0122nr6b12v44rid	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89206	1800	0	1800	COMPLETED	\N	2026-06-16 12:42:00
cms1t21ij0127nr6b5q8rr7j1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89207	6800	0	6800	COMPLETED	\N	2026-06-16 13:19:00
cms1t21im012dnr6b647v15yc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89208	4600	0	4600	COMPLETED	\N	2026-06-16 13:56:00
cms1t21io012inr6bwr4t1oym	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89209	2100	0	2100	COMPLETED	\N	2026-06-16 14:33:00
cms1t21iq012nnr6b33nfy9es	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89210	6800	0	6800	COMPLETED	\N	2026-06-17 09:00:00
cms1t21is012snr6bmjoeyhq0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89211	5100	0	5100	COMPLETED	\N	2026-06-17 09:37:00
cms1t21iu012znr6bwioqu3jx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89212	4200	0	4200	COMPLETED	\N	2026-06-17 10:14:00
cms1t21iw0134nr6b7sxqx0k3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89213	6900	0	6900	COMPLETED	\N	2026-06-17 10:51:00
cms1t21iy013anr6bep0qcefq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89214	7150	0	7150	COMPLETED	\N	2026-06-17 11:28:00
cms1t21j1013gnr6bfij6qx1k	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89215	8200	0	8200	COMPLETED	\N	2026-06-17 12:05:00
cms1t21j6013nnr6bimohuiwe	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89216	3000	0	3000	COMPLETED	\N	2026-06-17 12:42:00
cms1t21j9013snr6b11jfvt44	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89217	6400	0	6400	COMPLETED	\N	2026-06-17 13:19:00
cms1t21jc013znr6boqqmt3w8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89218	3400	0	3400	COMPLETED	\N	2026-06-17 13:56:00
cms1t21je0144nr6b36d1audi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89219	5800	0	5800	COMPLETED	\N	2026-06-17 14:33:00
cms1t21jg014anr6b5ks76ybr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89220	6600	0	6600	COMPLETED	\N	2026-06-17 15:10:00
cms1t21jj014hnr6bo8tyahe6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89221	700	0	700	COMPLETED	\N	2026-06-17 15:47:00
cms1t21jl014mnr6b6dx4m3qp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89222	3200	0	3200	COMPLETED	\N	2026-06-18 09:00:00
cms1t21jn014tnr6b40ctsh2f	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89223	10200	0	10200	COMPLETED	\N	2026-06-18 09:37:00
cms1t21jq0150nr6bsomeg2pe	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89224	7100	0	7100	COMPLETED	\N	2026-06-18 10:14:00
cms1t21js0156nr6bbxikvt54	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89225	5000	0	5000	COMPLETED	\N	2026-06-18 10:51:00
cms1t21ju015bnr6b4gkhcvcz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89226	3900	0	3900	COMPLETED	\N	2026-06-18 11:28:00
cms1t21jw015hnr6bkbvwi9z2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89227	5000	0	5000	COMPLETED	\N	2026-06-18 12:05:00
cms1t21jz015nnr6b433ro2es	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89228	3700	0	3700	COMPLETED	\N	2026-06-18 12:42:00
cms1t21k1015tnr6bupz4kxrl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89229	2850	0	2850	COMPLETED	\N	2026-06-18 13:19:00
cms1t21k40160nr6bk0zube5e	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89230	10500	0	10500	COMPLETED	\N	2026-06-18 13:56:00
cms1t21k70167nr6b3za04rro	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89231	5000	0	5000	COMPLETED	\N	2026-06-18 14:33:00
cms1t21ka016dnr6bc1kau2ru	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89232	6250	0	6250	COMPLETED	\N	2026-06-18 15:10:00
cms1t21kd016knr6bynw4qvhn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89233	11800	0	11800	COMPLETED	\N	2026-06-18 15:47:00
cms1t21kh016qnr6b8edt2eug	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89234	3200	0	3200	COMPLETED	\N	2026-06-18 16:24:00
cms1t21kl016wnr6bpyqt49qr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89235	4200	0	4200	COMPLETED	\N	2026-06-19 09:00:00
cms1t21kp0171nr6bxwu9clt0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89236	10600	0	10600	COMPLETED	\N	2026-06-19 09:37:00
cms1t21ks0178nr6b1yejxftr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89237	8400	0	8400	COMPLETED	\N	2026-06-19 10:14:00
cms1t21kv017enr6by48fe9gg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89238	6300	0	6300	COMPLETED	\N	2026-06-19 10:51:00
cms1t21ky017lnr6bonti9qqm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89239	2850	0	2850	COMPLETED	\N	2026-06-19 11:28:00
cms1t21l1017rnr6b1d5t7hwn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89240	6000	0	6000	COMPLETED	\N	2026-06-19 12:05:00
cms1t21l5017xnr6bjy8z0zpi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89241	2300	0	2300	COMPLETED	\N	2026-06-19 12:42:00
cms1t21l90182nr6bxfa5dnm0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89242	6500	0	6500	COMPLETED	\N	2026-06-19 13:19:00
cms1t21lc0188nr6b1kk8hhtl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89243	2450	0	2450	COMPLETED	\N	2026-06-19 13:56:00
cms1t21lw018enr6b7e0dw4f8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89244	3400	0	3400	COMPLETED	\N	2026-06-19 14:33:00
cms1t21m3018knr6buw28gvm1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89245	2100	0	2100	COMPLETED	\N	2026-06-19 15:10:00
cms1t21m6018pnr6bx376rwob	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89246	5500	0	5500	COMPLETED	\N	2026-06-19 15:47:00
cms1t21m9018wnr6b9gpzkcg1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89247	9100	0	9100	COMPLETED	\N	2026-06-19 16:24:00
cms1t21mc0192nr6b8pfo5trf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89248	3000	0	3000	COMPLETED	\N	2026-06-20 09:00:00
cms1t21mf0197nr6b88c47l9u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89249	7100	0	7100	COMPLETED	\N	2026-06-20 09:37:00
cms1t21mi019dnr6br4c7mmpi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89250	8100	0	8100	COMPLETED	\N	2026-06-20 10:14:00
cms1t21mk019knr6bpqs0866s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89251	3200	0	3200	COMPLETED	\N	2026-06-20 10:51:00
cms1t21mn019qnr6bzusa5h4s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89252	8800	0	8800	COMPLETED	\N	2026-06-20 11:28:00
cms1t21mp019wnr6b3mf06eec	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89253	6800	0	6800	COMPLETED	\N	2026-06-20 12:05:00
cms1t21mr01a3nr6bdrh3l8p4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89254	4000	0	4000	COMPLETED	\N	2026-06-20 12:42:00
cms1t21mu01a9nr6bi6gvhewi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89255	5800	0	5800	COMPLETED	\N	2026-06-20 13:19:00
cms1t21mw01aenr6brw2jjku8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89256	5800	0	5800	COMPLETED	\N	2026-06-20 13:56:00
cms1t21mz01ajnr6bqxl94cbi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89257	11000	0	11000	COMPLETED	\N	2026-06-20 14:33:00
cms1t21n101apnr6bo4zgr2xa	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89258	3000	0	3000	COMPLETED	\N	2026-06-20 15:10:00
cms1t21n401aunr6bgtjhlmzg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89259	7200	0	7200	COMPLETED	\N	2026-06-20 15:47:00
cms1t21na01b0nr6bp2q82rfu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89260	3600	0	3600	COMPLETED	\N	2026-06-21 09:00:00
cms1t21nd01b5nr6bywia663s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89261	5000	0	5000	COMPLETED	\N	2026-06-21 09:37:00
cms1t21nf01banr6bz3tw4ujr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89262	5200	0	5200	COMPLETED	\N	2026-06-21 10:14:00
cms1t21nh01bhnr6bj1vulbz7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89263	5800	0	5800	COMPLETED	\N	2026-06-21 10:51:00
cms1t21nj01bmnr6bc3rufpj6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89264	4300	0	4300	COMPLETED	\N	2026-06-21 11:28:00
cms1t21nm01bsnr6bbyntqzbd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89265	7800	0	7800	COMPLETED	\N	2026-06-22 09:00:00
cms1t21np01bznr6bmsgxix2r	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89266	5400	0	5400	COMPLETED	\N	2026-06-22 09:37:00
cms1t21nr01c6nr6baqrhnzif	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89267	8000	0	8000	COMPLETED	\N	2026-06-22 10:14:00
cms1t21nu01cdnr6bnk7t3xjq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89268	3700	0	3700	COMPLETED	\N	2026-06-22 10:51:00
cms1t21nw01cjnr6bd2sgtleh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89269	2500	0	2500	COMPLETED	\N	2026-06-22 11:28:00
cms1t21nz01conr6b1tq8bfss	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89270	11600	0	11600	COMPLETED	\N	2026-06-22 12:05:00
cms1t21o101cvnr6b2nlbu2y8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89271	2850	0	2850	COMPLETED	\N	2026-06-22 12:42:00
cms1t21o501d1nr6bh0jqxkkt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89272	8000	0	8000	COMPLETED	\N	2026-06-22 13:19:00
cms1t21o801d8nr6blyjjjn61	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89273	4950	0	4950	COMPLETED	\N	2026-06-22 13:56:00
cms1t21oa01denr6bnzh82u99	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89274	3500	0	3500	COMPLETED	\N	2026-06-22 14:33:00
cms1t21od01dknr6bflzw13d4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89275	6100	0	6100	COMPLETED	\N	2026-06-22 15:10:00
cms1t21of01dqnr6b048d2cn2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89276	13200	0	13200	COMPLETED	\N	2026-06-22 15:47:00
cms1t21oi01dxnr6bfyxho4ij	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89277	9000	0	9000	COMPLETED	\N	2026-06-22 16:24:00
cms1t21ok01e4nr6bxqdp0t1n	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89278	7900	0	7900	COMPLETED	\N	2026-06-22 17:01:00
cms1t21on01ebnr6blbs40dol	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89279	7100	0	7100	COMPLETED	\N	2026-06-23 09:00:00
cms1t21op01einr6boyo17w88	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89280	5800	0	5800	COMPLETED	\N	2026-06-23 09:37:00
cms1t21or01ennr6bnk48dmr5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89281	6800	0	6800	COMPLETED	\N	2026-06-23 10:14:00
cms1t21ou01eunr6bu7r05v5u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89282	1400	0	1400	COMPLETED	\N	2026-06-23 10:51:00
cms1t21ox01eznr6bwx77v6kr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89283	8000	0	8000	COMPLETED	\N	2026-06-23 11:28:00
cms1t21oz01f6nr6bzibjpsdc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89284	4850	0	4850	COMPLETED	\N	2026-06-23 12:05:00
cms1t21p201fdnr6b17gfrlc1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89285	3600	0	3600	COMPLETED	\N	2026-06-23 12:42:00
cms1t21p401fjnr6b5vjyw52m	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89286	7200	0	7200	COMPLETED	\N	2026-06-23 13:19:00
cms1t21p701fqnr6bftgxdu8b	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89287	11800	0	11800	COMPLETED	\N	2026-06-23 13:56:00
cms1t21p901fxnr6b6r26saw9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89288	3700	0	3700	COMPLETED	\N	2026-06-23 14:33:00
cms1t21pc01g3nr6bgqlayrhw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89289	1500	0	1500	COMPLETED	\N	2026-06-23 15:10:00
cms1t21pe01g8nr6b762lvarh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89290	6800	0	6800	COMPLETED	\N	2026-06-23 15:47:00
cms1t21pg01gdnr6brinwn2ea	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89291	5850	0	5850	COMPLETED	\N	2026-06-24 09:00:00
cms1t21pj01gknr6bcyf911kk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89292	2500	0	2500	COMPLETED	\N	2026-06-24 09:37:00
cms1t21pl01gpnr6boe5pazdq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89293	14400	0	14400	COMPLETED	\N	2026-06-24 10:14:00
cms1t21po01gwnr6bwt0585ve	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89294	12600	0	12600	COMPLETED	\N	2026-06-24 10:51:00
cms1t21pr01h3nr6buzqckh7j	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89295	4200	0	4200	COMPLETED	\N	2026-06-24 11:28:00
cms1t21pt01h8nr6bb1789ohc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89296	5800	0	5800	COMPLETED	\N	2026-06-24 12:05:00
cms1t21pw01hdnr6bpk78v3da	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89297	3600	0	3600	COMPLETED	\N	2026-06-24 12:42:00
cms1t21py01hinr6bas7ddxu0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89298	1100	0	1100	COMPLETED	\N	2026-06-24 13:19:00
cms1t21q001hnnr6bgugtfpsx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89299	9000	0	9000	COMPLETED	\N	2026-06-24 13:56:00
cms1t21q301hunr6bjjnucpzs	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89300	700	0	700	COMPLETED	\N	2026-06-24 14:33:00
cms1t21q501hznr6b8se6hy21	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89301	4950	0	4950	COMPLETED	\N	2026-06-24 15:10:00
cms1t21q701i6nr6bfowewc32	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89302	4900	0	4900	COMPLETED	\N	2026-06-24 15:47:00
cms1t21qa01icnr6bha6e0itf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89303	5500	0	5500	COMPLETED	\N	2026-06-24 16:24:00
cms1t21qc01iinr6btndf8jlw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89304	4000	0	4000	COMPLETED	\N	2026-06-25 09:00:00
cms1t21qe01ionr6br9l4jli1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89305	4100	0	4100	COMPLETED	\N	2026-06-25 09:37:00
cms1t21qh01iunr6b5aeo3bay	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89306	1500	0	1500	COMPLETED	\N	2026-06-25 10:14:00
cms1t21qj01iznr6bpaysrfgy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89307	3900	0	3900	COMPLETED	\N	2026-06-25 10:51:00
cms1t21qm01j6nr6b2wokanmo	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89308	6800	0	6800	COMPLETED	\N	2026-06-25 11:28:00
cms1t21qo01jbnr6bvutbbrz6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89309	10600	0	10600	COMPLETED	\N	2026-06-25 12:05:00
cms1t21qq01jinr6b0falh4pm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89310	9200	0	9200	COMPLETED	\N	2026-06-25 12:42:00
cms1t21qt01jonr6b61cufjsk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89311	12900	0	12900	COMPLETED	\N	2026-06-25 13:19:00
cms1t21qv01jvnr6bsreh7qbl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89312	6200	0	6200	COMPLETED	\N	2026-06-25 13:56:00
cms1t21qx01k2nr6boofc333a	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89313	700	0	700	COMPLETED	\N	2026-06-26 09:00:00
cms1t21qz01k7nr6b9d6xnj0s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89314	3250	0	3250	COMPLETED	\N	2026-06-26 09:37:00
cms1t21r201kdnr6bme9f7gz2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89315	4600	0	4600	COMPLETED	\N	2026-06-26 10:14:00
cms1t21r301kinr6by2ccr6hj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89316	11800	0	11800	COMPLETED	\N	2026-06-26 10:51:00
cms1t21r601konr6b08cpv61m	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89317	6800	0	6800	COMPLETED	\N	2026-06-26 11:28:00
cms1t21r801kvnr6brwyuvaqb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89318	7000	0	7000	COMPLETED	\N	2026-06-26 12:05:00
cms1t21ra01l2nr6bltgzzsx3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89319	2300	0	2300	COMPLETED	\N	2026-06-26 12:42:00
cms1t21rc01l7nr6b5nvne3at	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89320	5900	0	5900	COMPLETED	\N	2026-06-26 13:19:00
cms1t21rf01ldnr6bvjisa8ib	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89321	5000	0	5000	COMPLETED	\N	2026-06-26 13:56:00
cms1t21rh01linr6bd61bidpa	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89322	10200	0	10200	COMPLETED	\N	2026-06-26 14:33:00
cms1t21rk01lpnr6brd79qkzc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89323	6500	0	6500	COMPLETED	\N	2026-06-26 15:10:00
cms1t21rm01lvnr6bosudv5f2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89324	5700	0	5700	COMPLETED	\N	2026-06-27 09:00:00
cms1t21ro01m1nr6b1r6yoexv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89325	4300	0	4300	COMPLETED	\N	2026-06-27 09:37:00
cms1t21rr01m7nr6bqru6sgtf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89326	1100	0	1100	COMPLETED	\N	2026-06-27 10:14:00
cms1t21rt01mcnr6bx6ezv5cq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89327	3000	0	3000	COMPLETED	\N	2026-06-27 10:51:00
cms1t21rv01mhnr6bhedjoaup	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89328	10000	0	10000	COMPLETED	\N	2026-06-27 11:28:00
cms1t21rx01mnnr6bc6c3ra5w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89329	6500	0	6500	COMPLETED	\N	2026-06-27 12:05:00
cms1t21rz01munr6bu3vo8w63	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89330	5900	0	5900	COMPLETED	\N	2026-06-27 12:42:00
cms1t21s201n1nr6b190lovdq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89331	5700	0	5700	COMPLETED	\N	2026-06-27 13:19:00
cms1t21s401n7nr6b6j0n2wmg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89332	4800	0	4800	COMPLETED	\N	2026-06-27 13:56:00
cms1t21s601ndnr6bhzy9owuw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89333	4600	0	4600	COMPLETED	\N	2026-06-27 14:33:00
cms1t21s901njnr6b1bvxk09t	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89334	2100	0	2100	COMPLETED	\N	2026-06-27 15:10:00
cms1t21sb01npnr6bcibrja3y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89335	6500	0	6500	COMPLETED	\N	2026-06-27 15:47:00
cms1t21sd01nvnr6bmbil8szw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89336	10600	0	10600	COMPLETED	\N	2026-06-27 16:24:00
cms1t21sf01o2nr6bb902fqmi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89337	2100	0	2100	COMPLETED	\N	2026-06-28 09:00:00
cms1t21sh01o7nr6b0oseoyaq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89338	3600	0	3600	COMPLETED	\N	2026-06-28 09:37:00
cms1t21sj01ocnr6ba3hlg71z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89339	3600	0	3600	COMPLETED	\N	2026-06-28 10:14:00
cms1t21sl01oinr6bt23vciq6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89340	6800	0	6800	COMPLETED	\N	2026-06-28 10:51:00
cms1t21so01opnr6bkn7iwk9u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89341	2500	0	2500	COMPLETED	\N	2026-06-28 11:28:00
cms1t21sq01ounr6b5yl2vfuq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89342	4300	0	4300	COMPLETED	\N	2026-06-28 12:05:00
cms1t21ss01p0nr6b2fbekyn9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89343	5400	0	5400	COMPLETED	\N	2026-06-28 12:42:00
cms1t21su01p7nr6bfr3zersm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89344	1100	0	1100	COMPLETED	\N	2026-06-29 09:00:00
cms1t21sx01pcnr6b7u2sqbxv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89345	11200	0	11200	COMPLETED	\N	2026-06-29 09:37:00
cms1t21sz01pjnr6bvfqmd77z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89346	6500	0	6500	COMPLETED	\N	2026-06-29 10:14:00
cms1t21t101ppnr6bwaiyhqoh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89347	6700	0	6700	COMPLETED	\N	2026-06-29 10:51:00
cms1t21t301pvnr6b2bqiap6p	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89348	11800	0	11800	COMPLETED	\N	2026-06-29 11:28:00
cms1t21t601q1nr6b97y7kcwm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89349	6200	0	6200	COMPLETED	\N	2026-06-29 12:05:00
cms1t21t801q8nr6bzolyuxeh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89350	1400	0	1400	COMPLETED	\N	2026-06-29 12:42:00
cms1t21ta01qdnr6bxxfp5luz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89351	7600	0	7600	COMPLETED	\N	2026-06-29 13:19:00
cms1t21tc01qknr6bwxv65i4w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89352	9400	0	9400	COMPLETED	\N	2026-06-29 13:56:00
cms1t21tf01qqnr6bhhpfdgv1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89353	3500	0	3500	COMPLETED	\N	2026-06-29 14:33:00
cms1t21th01qwnr6busw2w6ao	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89354	6400	0	6400	COMPLETED	\N	2026-06-29 15:10:00
cms1t21tj01r3nr6b94nlgiu1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89355	4500	0	4500	COMPLETED	\N	2026-06-30 09:00:00
cms1t21tm01r9nr6brhb0p3ms	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89356	6750	0	6750	COMPLETED	\N	2026-06-30 09:37:00
cms1t21tp01rgnr6bludblckr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89357	8100	0	8100	COMPLETED	\N	2026-06-30 10:14:00
cms1t21tr01rnnr6b602e4agp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89358	14000	0	14000	COMPLETED	\N	2026-06-30 10:51:00
cms1t21tt01runr6bc2znncfm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89359	8200	0	8200	COMPLETED	\N	2026-06-30 11:28:00
cms1t21tv01s1nr6b0tg1qyv5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89360	2850	0	2850	COMPLETED	\N	2026-06-30 12:05:00
cms1t21ty01s7nr6bmnweyatp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89361	3400	0	3400	COMPLETED	\N	2026-06-30 12:42:00
cms1t21u001scnr6bn27zb2rf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89362	10000	0	10000	COMPLETED	\N	2026-06-30 13:19:00
cms1t21u301sjnr6bs18pkxs9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89363	4000	0	4000	COMPLETED	\N	2026-06-30 13:56:00
cms1t21u501spnr6bx168hegu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89364	7200	0	7200	COMPLETED	\N	2026-06-30 14:33:00
cms1t21u701svnr6b35c96s49	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89365	3000	0	3000	COMPLETED	\N	2026-06-30 15:10:00
cms1t21u901t0nr6bffnbmrfq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89366	3500	0	3500	COMPLETED	\N	2026-06-30 15:47:00
cms1t21ub01t6nr6b80mcq4xg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89367	2900	0	2900	COMPLETED	\N	2026-06-30 16:24:00
cms1t21ud01tbnr6b1jz17c0m	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89368	4200	0	4200	COMPLETED	\N	2026-06-30 17:01:00
cms1t21uf01tgnr6bjyxgr2tb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89369	6100	0	6100	COMPLETED	\N	2026-06-30 17:38:00
cms1t21uh01tmnr6bb2za7otu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89370	5000	0	5000	COMPLETED	\N	2026-07-01 09:00:00
cms1t21uk01trnr6b7rwtixr3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89371	5400	0	5400	COMPLETED	\N	2026-07-01 09:37:00
cms1t21um01tynr6b7a6uykgz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89372	4400	0	4400	COMPLETED	\N	2026-07-01 10:14:00
cms1t21uo01u5nr6be7ielynx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89373	9200	0	9200	COMPLETED	\N	2026-07-01 10:51:00
cms1t21ur01ubnr6bgzd1z9xi	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89374	7600	0	7600	COMPLETED	\N	2026-07-01 11:28:00
cms1t21ut01uhnr6bcbaz4n7g	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89375	14700	0	14700	COMPLETED	\N	2026-07-01 12:05:00
cms1t21uv01uonr6bn9qz36hm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89376	5000	0	5000	COMPLETED	\N	2026-07-01 12:42:00
cms1t21ux01utnr6bvw3mtbfl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89377	4700	0	4700	COMPLETED	\N	2026-07-01 13:19:00
cms1t21uz01v0nr6bshdro7is	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89378	5700	0	5700	COMPLETED	\N	2026-07-01 13:56:00
cms1t21v101v6nr6boief2ezz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89379	10200	0	10200	COMPLETED	\N	2026-07-01 14:33:00
cms1t21v401vdnr6byy9t8rvu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89380	7200	0	7200	COMPLETED	\N	2026-07-01 15:10:00
cms1t21v601vknr6br26skgpc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89381	10600	0	10600	COMPLETED	\N	2026-07-01 15:47:00
cms1t21v901vrnr6bpem2f7e3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89382	12100	0	12100	COMPLETED	\N	2026-07-01 16:24:00
cms1t21vb01vynr6bkbnq3bf8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89383	2900	0	2900	COMPLETED	\N	2026-07-01 17:01:00
cms1t21vd01w3nr6bsnkpmrgq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89384	7400	0	7400	COMPLETED	\N	2026-07-02 09:00:00
cms1t21vg01wanr6b9aqlwkqk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89385	2500	0	2500	COMPLETED	\N	2026-07-02 09:37:00
cms1t21vi01wfnr6bs1wv467r	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89386	3600	0	3600	COMPLETED	\N	2026-07-02 10:14:00
cms1t21vl01wlnr6b8hv21a9l	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89387	13800	0	13800	COMPLETED	\N	2026-07-02 10:51:00
cms1t21vn01wsnr6biafl5bje	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89388	7600	0	7600	COMPLETED	\N	2026-07-02 11:28:00
cms1t21vp01wynr6bbkaak3il	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89389	4200	0	4200	COMPLETED	\N	2026-07-02 12:05:00
cms1t21vs01x3nr6b82e3t9te	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89390	9500	0	9500	COMPLETED	\N	2026-07-02 12:42:00
cms1t21vu01xanr6b42eh15eq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89391	9800	0	9800	COMPLETED	\N	2026-07-02 13:19:00
cms1t21vw01xhnr6boxew51e0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89392	9800	0	9800	COMPLETED	\N	2026-07-03 09:00:00
cms1t21vz01xonr6b2uzv6gls	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89393	1800	0	1800	COMPLETED	\N	2026-07-03 09:37:00
cms1t21w101xunr6bf1nnmxql	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89394	7200	0	7200	COMPLETED	\N	2026-07-03 10:14:00
cms1t21w301y0nr6bc0ys7yq1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89395	6500	0	6500	COMPLETED	\N	2026-07-03 10:51:00
cms1t21w501y6nr6b2g7c5oqc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89396	4300	0	4300	COMPLETED	\N	2026-07-03 11:28:00
cms1t21w901ycnr6b7of9633t	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89397	11000	0	11000	COMPLETED	\N	2026-07-03 12:05:00
cms1t21wb01yinr6bdkoowsc9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89398	3000	0	3000	COMPLETED	\N	2026-07-03 12:42:00
cms1t21we01ynnr6b4uv8v1sf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89399	15600	0	15600	COMPLETED	\N	2026-07-03 13:19:00
cms1t21wg01yunr6bdqkma7ih	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89400	9200	0	9200	COMPLETED	\N	2026-07-04 09:00:00
cms1t21wj01z1nr6bbllligcf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89401	5000	0	5000	COMPLETED	\N	2026-07-04 09:37:00
cms1t21wl01z6nr6byftoc2jy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89402	7400	0	7400	COMPLETED	\N	2026-07-04 10:14:00
cms1t21wo01zdnr6beq0kt0ph	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89403	6300	0	6300	COMPLETED	\N	2026-07-04 10:51:00
cms1t21wq01zknr6bpsp1rd1l	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89404	5000	0	5000	COMPLETED	\N	2026-07-04 11:28:00
cms1t21wt01zpnr6bu2t9pqyu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89405	5000	0	5000	COMPLETED	\N	2026-07-04 12:05:00
cms1t21wv01zunr6b3qiwswih	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89406	4100	0	4100	COMPLETED	\N	2026-07-04 12:42:00
cms1t21wy0200nr6berv5n2qm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89407	9000	0	9000	COMPLETED	\N	2026-07-04 13:19:00
cms1t21x00206nr6bnszfmyev	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89408	4200	0	4200	COMPLETED	\N	2026-07-04 13:56:00
cms1t21x3020bnr6bhwcv23y1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89409	13400	0	13400	COMPLETED	\N	2026-07-04 14:33:00
cms1t21x5020inr6beca5wvna	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89410	4900	0	4900	COMPLETED	\N	2026-07-04 15:10:00
cms1t21x8020onr6b0nmct3eb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89411	8100	0	8100	COMPLETED	\N	2026-07-04 15:47:00
cms1t21xa020vnr6bxp2i5qhm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89412	2900	0	2900	COMPLETED	\N	2026-07-04 16:24:00
cms1t21xd0211nr6bpm72nuol	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89413	3600	0	3600	COMPLETED	\N	2026-07-04 17:01:00
cms1t21xf0217nr6bx9m74wdj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89414	3400	0	3400	COMPLETED	\N	2026-07-04 17:38:00
cms1t21xh021cnr6boyswuk2s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89415	3600	0	3600	COMPLETED	\N	2026-07-05 09:00:00
cms1t21xj021hnr6be1t6zl7h	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89416	7200	0	7200	COMPLETED	\N	2026-07-05 09:37:00
cms1t21xm021onr6b5p1kctaw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89417	5400	0	5400	COMPLETED	\N	2026-07-05 10:14:00
cms1t21xp021unr6bhp5vlpst	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89418	5800	0	5800	COMPLETED	\N	2026-07-05 10:51:00
cms1t21xr021znr6bbw2nh180	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89419	9200	0	9200	COMPLETED	\N	2026-07-06 09:00:00
cms1t21xu0226nr6b5k2nkrwt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89420	1400	0	1400	COMPLETED	\N	2026-07-06 09:37:00
cms1t21xw022bnr6bnjv8oqf5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89421	4600	0	4600	COMPLETED	\N	2026-07-06 10:14:00
cms1t21xy022hnr6b32mg6qyd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89422	9300	0	9300	COMPLETED	\N	2026-07-06 10:51:00
cms1t21y1022onr6b363vwzod	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89423	5700	0	5700	COMPLETED	\N	2026-07-06 11:28:00
cms1t21y3022vnr6bv9zh17ni	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89424	10700	0	10700	COMPLETED	\N	2026-07-06 12:05:00
cms1t21y60232nr6b4hg6h111	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89425	7300	0	7300	COMPLETED	\N	2026-07-06 12:42:00
cms1t21y80239nr6b26ha24u2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89426	2900	0	2900	COMPLETED	\N	2026-07-06 13:19:00
cms1t21yb023fnr6b7d1v5dti	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89427	8000	0	8000	COMPLETED	\N	2026-07-06 13:56:00
cms1t21ye023lnr6bx94ei8fm	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89428	1050	0	1050	COMPLETED	\N	2026-07-06 14:33:00
cms1t21yg023rnr6bg8uemk8x	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89429	6800	0	6800	COMPLETED	\N	2026-07-06 15:10:00
cms1t21yi023wnr6bbstg1s58	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89430	7800	0	7800	COMPLETED	\N	2026-07-06 15:47:00
cms1t21yl0243nr6bnylwbnj7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89431	2100	0	2100	COMPLETED	\N	2026-07-06 16:24:00
cms1t21yn0248nr6bxhsatslw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89432	2150	0	2150	COMPLETED	\N	2026-07-07 09:00:00
cms1t21yp024enr6bdx7t5pfw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89433	7800	0	7800	COMPLETED	\N	2026-07-07 09:37:00
cms1t21ys024lnr6b5cajsig4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89434	9500	0	9500	COMPLETED	\N	2026-07-07 10:14:00
cms1t21yu024snr6bd5vzx0zb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89435	5000	0	5000	COMPLETED	\N	2026-07-07 10:51:00
cms1t21yx024znr6bf8bhgmh1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89436	2200	0	2200	COMPLETED	\N	2026-07-07 11:28:00
cms1t21yz0254nr6bhc328g6v	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89437	1450	0	1450	COMPLETED	\N	2026-07-07 12:05:00
cms1t21z1025anr6bp5buu03w	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89438	7200	0	7200	COMPLETED	\N	2026-07-07 12:42:00
cms1t21z3025gnr6b13jjdn74	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89439	2500	0	2500	COMPLETED	\N	2026-07-07 13:19:00
cms1t21z5025lnr6b6dihz8dg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89440	13800	0	13800	COMPLETED	\N	2026-07-08 09:00:00
cms1t21z7025snr6bkbts19pq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89441	5000	0	5000	COMPLETED	\N	2026-07-08 09:37:00
cms1t21z9025xnr6biagbng16	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89442	10000	0	10000	COMPLETED	\N	2026-07-08 10:14:00
cms1t21zb0263nr6b2ql97ka7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89443	3350	0	3350	COMPLETED	\N	2026-07-08 10:51:00
cms1t21zd0269nr6bnrw3ahw6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89444	6100	0	6100	COMPLETED	\N	2026-07-08 11:28:00
cms1t21zg026gnr6b7bu26emk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89445	10300	0	10300	COMPLETED	\N	2026-07-08 12:05:00
cms1t21zi026nnr6b746trdex	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89446	4800	0	4800	COMPLETED	\N	2026-07-08 12:42:00
cms1t21zl026tnr6bupeywp0g	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89447	6100	0	6100	COMPLETED	\N	2026-07-08 13:19:00
cms1t21zo026znr6bpqvhlarv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89448	14100	0	14100	COMPLETED	\N	2026-07-08 13:56:00
cms1t21zr0276nr6bkpt1tgwu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89449	11500	0	11500	COMPLETED	\N	2026-07-08 14:33:00
cms1t21zu027dnr6bug5dei70	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89450	3600	0	3600	COMPLETED	\N	2026-07-08 15:10:00
cms1t21zw027inr6b7vtz7fbn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89451	4650	0	4650	COMPLETED	\N	2026-07-08 15:47:00
cms1t21zz027pnr6b78o0yyef	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89452	700	0	700	COMPLETED	\N	2026-07-08 16:24:00
cms1t2201027unr6bslu05946	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89453	5700	0	5700	COMPLETED	\N	2026-07-08 17:01:00
cms1t22030280nr6bql633yyh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89454	700	0	700	COMPLETED	\N	2026-07-08 17:38:00
cms1t22060285nr6bpb0yvcl3	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89455	6050	0	6050	COMPLETED	\N	2026-07-09 09:00:00
cms1t2208028cnr6bh83e3ex7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89456	7300	0	7300	COMPLETED	\N	2026-07-09 09:37:00
cms1t220b028jnr6byptjhhej	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89457	5500	0	5500	COMPLETED	\N	2026-07-09 10:14:00
cms1t220d028pnr6bisn4v8d6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89458	9300	0	9300	COMPLETED	\N	2026-07-09 10:51:00
cms1t220g028vnr6bghwigx78	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89459	5650	0	5650	COMPLETED	\N	2026-07-09 11:28:00
cms1t220j0292nr6byht70eht	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89460	4500	0	4500	COMPLETED	\N	2026-07-09 12:05:00
cms1t220l0298nr6b60ukxswy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89461	9000	0	9000	COMPLETED	\N	2026-07-09 12:42:00
cms1t220o029fnr6bvwos42qg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89462	3400	0	3400	COMPLETED	\N	2026-07-09 13:19:00
cms1t220q029knr6bf5bjjqc8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89463	1800	0	1800	COMPLETED	\N	2026-07-09 13:56:00
cms1t220s029pnr6b9vrry3kn	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89464	9700	0	9700	COMPLETED	\N	2026-07-09 14:33:00
cms1t220v029wnr6b2a56q29e	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89465	6200	0	6200	COMPLETED	\N	2026-07-09 15:10:00
cms1t220x02a3nr6bbvr7c7f1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89466	2100	0	2100	COMPLETED	\N	2026-07-10 09:00:00
cms1t220z02a8nr6bhmi0ki97	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89467	3400	0	3400	COMPLETED	\N	2026-07-10 09:37:00
cms1t221202aenr6byoxua6q7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89468	350	0	350	COMPLETED	\N	2026-07-10 10:14:00
cms1t221402ajnr6bqjbzz2s4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89469	4200	0	4200	COMPLETED	\N	2026-07-10 10:51:00
cms1t221602aonr6bph5478rt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89470	5400	0	5400	COMPLETED	\N	2026-07-10 11:28:00
cms1t221802aunr6b3yb4zcmv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89471	1800	0	1800	COMPLETED	\N	2026-07-10 12:05:00
cms1t221b02b0nr6b7bd8s431	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89472	14400	0	14400	COMPLETED	\N	2026-07-10 12:42:00
cms1t221d02b7nr6bsjappy0z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89473	5550	0	5550	COMPLETED	\N	2026-07-10 13:19:00
cms1t221f02benr6bit6jy98p	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89474	11900	0	11900	COMPLETED	\N	2026-07-10 13:56:00
cms1t221h02blnr6bjur0vmyq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89475	1500	0	1500	COMPLETED	\N	2026-07-11 09:00:00
cms1t221j02bqnr6bcbeh8xep	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89476	6100	0	6100	COMPLETED	\N	2026-07-11 09:37:00
cms1t221m02bwnr6bgu8fipmg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89477	1100	0	1100	COMPLETED	\N	2026-07-11 10:14:00
cms1t221o02c1nr6bztb4120j	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89478	1100	0	1100	COMPLETED	\N	2026-07-11 10:51:00
cms1t221q02c6nr6bsc04yuph	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89479	2900	0	2900	COMPLETED	\N	2026-07-11 11:28:00
cms1t221s02ccnr6b9mmq2h4s	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89480	11500	0	11500	COMPLETED	\N	2026-07-11 12:05:00
cms1t221u02cjnr6bv6b128nq	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89481	7200	0	7200	COMPLETED	\N	2026-07-11 12:42:00
cms1t221x02cqnr6balo08b04	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89482	7200	0	7200	COMPLETED	\N	2026-07-11 13:19:00
cms1t222002cwnr6brd2hn3oh	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89483	6000	0	6000	COMPLETED	\N	2026-07-11 13:56:00
cms1t222202d2nr6b6h1vr1of	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89484	8800	0	8800	COMPLETED	\N	2026-07-11 14:33:00
cms1t222502d8nr6bv53y0q5a	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89485	9400	0	9400	COMPLETED	\N	2026-07-11 15:10:00
cms1t222702dfnr6bzudl2p7o	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89486	7500	0	7500	COMPLETED	\N	2026-07-12 09:00:00
cms1t222a02dmnr6bj3bdllmw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89487	3950	0	3950	COMPLETED	\N	2026-07-12 09:37:00
cms1t222d02dtnr6bt2h0bnz0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89488	1800	0	1800	COMPLETED	\N	2026-07-12 10:14:00
cms1t222f02dynr6bkumapl0i	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89489	11000	0	11000	COMPLETED	\N	2026-07-12 10:51:00
cms1t222h02e5nr6br5dzeoum	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89490	1800	0	1800	COMPLETED	\N	2026-07-12 11:28:00
cms1t222j02eanr6bro2yoezr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89491	8300	0	8300	COMPLETED	\N	2026-07-12 12:05:00
cms1t222m02ehnr6b0k1vytbf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89492	2500	0	2500	COMPLETED	\N	2026-07-12 12:42:00
cms1t222o02emnr6bkmdr8c0u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89493	3600	0	3600	COMPLETED	\N	2026-07-13 09:00:00
cms1t222q02ernr6bv98y6jui	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89494	12600	0	12600	COMPLETED	\N	2026-07-13 09:37:00
cms1t222u02exnr6but4tupya	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89495	1800	0	1800	COMPLETED	\N	2026-07-13 10:14:00
cms1t222w02f2nr6bpm07gvyo	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89496	1800	0	1800	COMPLETED	\N	2026-07-13 10:51:00
cms1t222y02f7nr6bq0tbzuuc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89497	3600	0	3600	COMPLETED	\N	2026-07-13 11:28:00
cms1t223102fdnr6b9adxoeny	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89498	350	0	350	COMPLETED	\N	2026-07-13 12:05:00
cms1t223302finr6b3xh7k3m0	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89499	6800	0	6800	COMPLETED	\N	2026-07-13 12:42:00
cms1t223602fpnr6buqkkme02	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89500	4800	0	4800	COMPLETED	\N	2026-07-13 13:19:00
cms1t223802fvnr6b52ytvdfl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89501	1100	0	1100	COMPLETED	\N	2026-07-13 13:56:00
cms1t223a02g0nr6bpqgd3h1m	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89502	3900	0	3900	COMPLETED	\N	2026-07-14 09:00:00
cms1t223d02g6nr6bh84diasr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89503	5800	0	5800	COMPLETED	\N	2026-07-14 09:37:00
cms1t223f02gbnr6bwomvn0u2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89504	6350	0	6350	COMPLETED	\N	2026-07-14 10:14:00
cms1t223h02ginr6bis975pq7	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89505	4600	0	4600	COMPLETED	\N	2026-07-14 10:51:00
cms1t223k02gnnr6b76r2a5kv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89506	2900	0	2900	COMPLETED	\N	2026-07-14 11:28:00
cms1t223m02gtnr6b0v6di209	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89507	1500	0	1500	COMPLETED	\N	2026-07-14 12:05:00
cms1t223o02gynr6bkskkmy48	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89508	5000	0	5000	COMPLETED	\N	2026-07-14 12:42:00
cms1t223r02h3nr6bwlay4116	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89509	4200	0	4200	COMPLETED	\N	2026-07-14 13:19:00
cms1t223t02h8nr6bnaxacrqa	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89510	12900	0	12900	COMPLETED	\N	2026-07-14 13:56:00
cms1t223v02hfnr6badmgehlc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89511	2800	0	2800	COMPLETED	\N	2026-07-14 14:33:00
cms1t223y02hlnr6bwvp86ns6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89512	9700	0	9700	COMPLETED	\N	2026-07-14 15:10:00
cms1t224002hsnr6bg01ojweb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89513	10700	0	10700	COMPLETED	\N	2026-07-14 15:47:00
cms1t224302hznr6brrsiqqfo	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89514	9400	0	9400	COMPLETED	\N	2026-07-15 09:00:00
cms1t224502i6nr6brxhtizdv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89515	9300	0	9300	COMPLETED	\N	2026-07-15 09:37:00
cms1t224802idnr6bqs3t7wvx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89516	10350	0	10350	COMPLETED	\N	2026-07-15 10:14:00
cms1t224a02iknr6bfxha6mov	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89517	7100	0	7100	COMPLETED	\N	2026-07-15 10:51:00
cms1t224d02iqnr6ba4n4sa2k	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89518	7000	0	7000	COMPLETED	\N	2026-07-15 11:28:00
cms1t224f02iwnr6bc9zu2px4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89519	8300	0	8300	COMPLETED	\N	2026-07-15 12:05:00
cms1t224h02j2nr6b7waj437e	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89520	2200	0	2200	COMPLETED	\N	2026-07-15 12:42:00
cms1t224j02j7nr6bm9armtw9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89521	9200	0	9200	COMPLETED	\N	2026-07-15 13:19:00
cms1t224m02jdnr6b46aak3o4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89522	9500	0	9500	COMPLETED	\N	2026-07-15 13:56:00
cms1t224o02jknr6bgvfvvpfy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89523	1100	0	1100	COMPLETED	\N	2026-07-15 14:33:00
cms1t224q02jpnr6bon505417	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89524	8900	0	8900	COMPLETED	\N	2026-07-15 15:10:00
cms1t224t02jwnr6b2pxp6mdd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89525	6000	0	6000	COMPLETED	\N	2026-07-15 15:47:00
cms1t224v02k2nr6br2fhd99u	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89526	8800	0	8800	COMPLETED	\N	2026-07-15 16:24:00
cms1t224x02k9nr6bprnxrvvc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89527	1800	0	1800	COMPLETED	\N	2026-07-15 17:01:00
cms1t224z02kenr6bo4i19yh1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89528	6600	0	6600	COMPLETED	\N	2026-07-15 17:38:00
cms1t225202klnr6b1oz60pt9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89529	7300	0	7300	COMPLETED	\N	2026-07-16 09:00:00
cms1t225402krnr6borcll07q	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89530	7100	0	7100	COMPLETED	\N	2026-07-16 09:37:00
cms1t225702kxnr6bh70cu7sz	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89531	5500	0	5500	COMPLETED	\N	2026-07-16 10:14:00
cms1t225a02l3nr6bdschqnfw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89532	7900	0	7900	COMPLETED	\N	2026-07-16 10:51:00
cms1t225c02l9nr6brq6gfhai	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89533	6800	0	6800	COMPLETED	\N	2026-07-16 11:28:00
cms1t225e02lenr6b585l08yf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89534	3350	0	3350	COMPLETED	\N	2026-07-16 12:05:00
cms1t225h02lknr6b6v8w51qw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89535	5850	0	5850	COMPLETED	\N	2026-07-16 12:42:00
cms1t225j02lrnr6bl2n9qafd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89536	4300	0	4300	COMPLETED	\N	2026-07-16 13:19:00
cms1t225m02lxnr6b9oqewjll	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89537	5100	0	5100	COMPLETED	\N	2026-07-16 13:56:00
cms1t225o02m3nr6btoqsrv5t	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89538	1400	0	1400	COMPLETED	\N	2026-07-17 09:00:00
cms1t225q02m8nr6b78n0oyby	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89539	10700	0	10700	COMPLETED	\N	2026-07-17 09:37:00
cms1t225t02mfnr6bzh1kwtou	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89540	2500	0	2500	COMPLETED	\N	2026-07-17 10:14:00
cms1t225v02mknr6bq99vyi1o	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89541	8000	0	8000	COMPLETED	\N	2026-07-17 10:51:00
cms1t225y02mrnr6bbepb6hr6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89542	11100	0	11100	COMPLETED	\N	2026-07-17 11:28:00
cms1t226002mynr6b2j60dedk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89543	7100	0	7100	COMPLETED	\N	2026-07-17 12:05:00
cms1t226202n4nr6bhbkawypy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89544	8000	0	8000	COMPLETED	\N	2026-07-17 12:42:00
cms1t226502nanr6b5n7hebto	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89545	9400	0	9400	COMPLETED	\N	2026-07-17 13:19:00
cms1t226702nhnr6b9q59ieu4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89546	7200	0	7200	COMPLETED	\N	2026-07-17 13:56:00
cms1t226a02nonr6biay4xsde	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89547	5000	0	5000	COMPLETED	\N	2026-07-17 14:33:00
cms1t226c02ntnr6bxxzb8d0p	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89548	8700	0	8700	COMPLETED	\N	2026-07-17 15:10:00
cms1t226e02o0nr6bwkdrwbno	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89549	2100	0	2100	COMPLETED	\N	2026-07-17 15:47:00
cms1t226g02o5nr6bv787wy19	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89550	5500	0	5500	COMPLETED	\N	2026-07-17 16:24:00
cms1t226j02ocnr6bl7f5ga3h	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89551	5700	0	5700	COMPLETED	\N	2026-07-18 09:00:00
cms1t226l02ojnr6b1eyuepgw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89552	7500	0	7500	COMPLETED	\N	2026-07-18 09:37:00
cms1t226n02oqnr6bv2vflf3g	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89553	12600	0	12600	COMPLETED	\N	2026-07-18 10:14:00
cms1t226p02ownr6bypprzylf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89554	7500	0	7500	COMPLETED	\N	2026-07-18 10:51:00
cms1t226s02p2nr6bru35ckl8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89555	700	0	700	COMPLETED	\N	2026-07-18 11:28:00
cms1t226v02p7nr6bzslcoqfx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89556	1800	0	1800	COMPLETED	\N	2026-07-18 12:05:00
cms1t226x02pdnr6biuibatdf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89557	4900	0	4900	COMPLETED	\N	2026-07-18 12:42:00
cms1t226z02pjnr6b9wzpcn61	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89558	9600	0	9600	COMPLETED	\N	2026-07-18 13:19:00
cms1t227202pqnr6bg9ueytd1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89559	5100	0	5100	COMPLETED	\N	2026-07-19 09:00:00
cms1t227402pwnr6brn24yx0z	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89560	7100	0	7100	COMPLETED	\N	2026-07-19 09:37:00
cms1t227702q2nr6bz5hisrvl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89561	5050	0	5050	COMPLETED	\N	2026-07-19 10:14:00
cms1t227902q9nr6bvd33v2bj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89562	2500	0	2500	COMPLETED	\N	2026-07-19 10:51:00
cms1t227b02qenr6b4h1afiqv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89563	4300	0	4300	COMPLETED	\N	2026-07-19 11:28:00
cms1t227e02qknr6bl0x6e8k4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89564	5700	0	5700	COMPLETED	\N	2026-07-20 09:00:00
cms1t227g02qqnr6bgx38qmt9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89565	6400	0	6400	COMPLETED	\N	2026-07-20 09:37:00
cms1t227i02qxnr6bg8spg54q	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89566	4800	0	4800	COMPLETED	\N	2026-07-20 10:14:00
cms1t227l02r3nr6bhb4un4a6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89567	2200	0	2200	COMPLETED	\N	2026-07-20 10:51:00
cms1t227n02r8nr6bnclgw7nb	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89568	5900	0	5900	COMPLETED	\N	2026-07-20 11:28:00
cms1t227p02rfnr6bzo6316rl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89569	6600	0	6600	COMPLETED	\N	2026-07-20 12:05:00
cms1t227r02rmnr6bj6yzjxoc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89570	2100	0	2100	COMPLETED	\N	2026-07-20 12:42:00
cms1t227t02rrnr6bfndlmgui	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89571	4600	0	4600	COMPLETED	\N	2026-07-20 13:19:00
cms1t227w02rxnr6bdzhqsx65	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89572	3500	0	3500	COMPLETED	\N	2026-07-20 13:56:00
cms1t227z02s3nr6bhpo8hwc9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89573	2300	0	2300	COMPLETED	\N	2026-07-20 14:33:00
cms1t228102s8nr6b0ina1nbk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89574	5300	0	5300	COMPLETED	\N	2026-07-20 15:10:00
cms1t228402senr6bwcrvwwt4	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89575	2100	0	2100	COMPLETED	\N	2026-07-20 15:47:00
cms1t228602sjnr6b4j6tmvzf	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89576	11400	0	11400	COMPLETED	\N	2026-07-21 09:00:00
cms1t228902sqnr6bb2ckagfx	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89577	5000	0	5000	COMPLETED	\N	2026-07-21 09:37:00
cms1t228b02svnr6b2ff8x16y	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89578	7900	0	7900	COMPLETED	\N	2026-07-21 10:14:00
cms1t228d02t1nr6b6mz95x1f	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89579	2900	0	2900	COMPLETED	\N	2026-07-21 10:51:00
cms1t228f02t7nr6bbp69fszj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89580	1500	0	1500	COMPLETED	\N	2026-07-21 11:28:00
cms1t228h02tcnr6bpxv5wqe2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89581	5000	0	5000	COMPLETED	\N	2026-07-21 12:05:00
cms1t228j02thnr6b1tscpsmp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89582	2500	0	2500	COMPLETED	\N	2026-07-21 12:42:00
cms1t228l02tmnr6bavk8l7l1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89583	4800	0	4800	COMPLETED	\N	2026-07-21 13:19:00
cms1t228o02tsnr6bv4077z85	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89584	12500	0	12500	COMPLETED	\N	2026-07-21 13:56:00
cms1t228q02tznr6bdxrnt6xv	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89585	5350	0	5350	COMPLETED	\N	2026-07-21 14:33:00
cms1t228t02u5nr6bhwaaxny8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89586	3600	0	3600	COMPLETED	\N	2026-07-21 15:10:00
cms1t228v02uanr6bl7vhr9l9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89587	2100	0	2100	COMPLETED	\N	2026-07-21 15:47:00
cms1t228y02ufnr6bprl99jvk	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89588	9600	0	9600	COMPLETED	\N	2026-07-22 09:00:00
cms1t229102ulnr6bu4fqybdj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89589	5650	0	5650	COMPLETED	\N	2026-07-22 09:37:00
cms1t229402usnr6bcy7whe2f	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89590	2900	0	2900	COMPLETED	\N	2026-07-22 10:14:00
cms1t229602uxnr6b8lk8ui1r	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89591	2900	0	2900	COMPLETED	\N	2026-07-22 10:51:00
cms1t229902v3nr6bfjsflci1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89592	1400	0	1400	COMPLETED	\N	2026-07-22 11:28:00
cms1t229b02v8nr6bbkylbyht	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89593	12500	0	12500	COMPLETED	\N	2026-07-22 12:05:00
cms1t229d02vfnr6bs9b0l6gt	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89594	4500	0	4500	COMPLETED	\N	2026-07-22 12:42:00
cms1t229g02vlnr6b076qbxsj	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89595	5000	0	5000	COMPLETED	\N	2026-07-22 13:19:00
cms1t229i02vqnr6b3k9n5ew9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89596	7800	0	7800	COMPLETED	\N	2026-07-22 13:56:00
cms1t229l02vwnr6b0dbx3fc9	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89597	2100	0	2100	COMPLETED	\N	2026-07-22 14:33:00
cms1t229n02w1nr6bqeva2xzl	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89598	7500	0	7500	COMPLETED	\N	2026-07-23 09:00:00
cms1t229p02w8nr6boyhqmvt1	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89599	8400	0	8400	COMPLETED	\N	2026-07-23 09:37:00
cms1t229s02wfnr6bkxo8u5pc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89600	7000	0	7000	COMPLETED	\N	2026-07-23 10:14:00
cms1t229u02wmnr6bmnkx1qxe	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89601	6000	0	6000	COMPLETED	\N	2026-07-23 10:51:00
cms1t229x02wtnr6bq3yhryle	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89602	2500	0	2500	COMPLETED	\N	2026-07-23 11:28:00
cms1t229z02wynr6b2uamn2bp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89603	700	0	700	COMPLETED	\N	2026-07-23 12:05:00
cms1t22a102x3nr6blwwpzkfr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89604	9200	0	9200	COMPLETED	\N	2026-07-23 12:42:00
cms1t22a302x9nr6bbx3kxgrd	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89605	5400	0	5400	COMPLETED	\N	2026-07-23 13:19:00
cms1t22a502xgnr6bauvulkif	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89606	7200	0	7200	COMPLETED	\N	2026-07-23 13:56:00
cms1t22a802xmnr6br5782tjy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89607	12900	0	12900	COMPLETED	\N	2026-07-23 14:33:00
cms1t22aa02xtnr6b1o67aysy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89608	3000	0	3000	COMPLETED	\N	2026-07-23 15:10:00
cms1t22ac02xynr6bwwozssso	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214r0037nr6bm73szalf	\N	TK-89609	2500	0	2500	COMPLETED	\N	2026-07-23 15:47:00
cms1t22ae02y3nr6b8kczhjwu	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89610	2300	0	2300	COMPLETED	\N	2026-07-23 16:24:00
cms1t22ag02y8nr6bilfutb4v	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89611	6400	0	6400	COMPLETED	\N	2026-07-23 17:01:00
cms1t22ai02yenr6brz82ilxr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89612	12500	0	12500	COMPLETED	\N	2026-07-23 17:38:00
cms1t22ak02ylnr6bk90dg8sw	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89613	2150	0	2150	COMPLETED	\N	2026-07-24 09:00:00
cms1t22an02yrnr6bvyyufx1d	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89614	5800	0	5800	COMPLETED	\N	2026-07-24 09:37:00
cms1t22ap02ywnr6brv8ohmvc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89615	4700	0	4700	COMPLETED	\N	2026-07-24 10:14:00
cms1t22as02z3nr6bj5qzpyan	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89616	5200	0	5200	COMPLETED	\N	2026-07-24 10:51:00
cms1t22au02z9nr6bf35aqmde	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89617	9500	0	9500	COMPLETED	\N	2026-07-24 11:28:00
cms1t22ax02zgnr6bbryg9mz8	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89618	6400	0	6400	COMPLETED	\N	2026-07-24 12:05:00
cms1t22az02znnr6b6zvevx5e	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89619	7600	0	7600	COMPLETED	\N	2026-07-24 12:42:00
cms1t22b202zunr6b8y697sqr	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89620	4200	0	4200	COMPLETED	\N	2026-07-24 13:19:00
cms1t22b302zznr6b32cnuav5	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89621	1100	0	1100	COMPLETED	\N	2026-07-25 09:00:00
cms1t22b50304nr6bt65b1joo	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89622	9500	0	9500	COMPLETED	\N	2026-07-25 09:37:00
cms1t22b7030bnr6b94dns7hy	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89623	6100	0	6100	COMPLETED	\N	2026-07-25 10:14:00
cms1t22b9030hnr6b0oyb8hil	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89624	7100	0	7100	COMPLETED	\N	2026-07-25 10:51:00
cms1t22bc030nnr6bhne7rt5j	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214q0035nr6bxwke21xg	\N	TK-89625	7450	0	7450	COMPLETED	\N	2026-07-25 11:28:00
cms1t22be030unr6bgbl9surg	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89626	2200	0	2200	COMPLETED	\N	2026-07-25 12:05:00
cms1t22bg030znr6b1miqcsih	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214t003bnr6b0vm5hxl9	\N	TK-89627	5800	0	5800	COMPLETED	\N	2026-07-25 12:42:00
cms1t22bi0314nr6b783wxeor	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89628	7300	0	7300	COMPLETED	\N	2026-07-25 13:19:00
cms1t22bk031anr6byhq4o6us	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89629	5000	0	5000	COMPLETED	\N	2026-07-25 13:56:00
cms1t22bn031hnr6b9rccdjw2	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89630	2500	0	2500	COMPLETED	\N	2026-07-25 14:33:00
cms1t22bp031mnr6b1eh0glbp	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89631	8200	0	8200	COMPLETED	\N	2026-07-25 15:10:00
cms1t22br031snr6boqnjbuz6	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214u003dnr6blfrkvove	\N	TK-89632	2500	0	2500	COMPLETED	\N	2026-07-25 15:47:00
cms1t22bt031xnr6b6ukq045p	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89633	5500	0	5500	COMPLETED	\N	2026-07-25 16:24:00
cms1t22bw0324nr6b512b5g0i	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89634	2300	0	2300	COMPLETED	\N	2026-07-26 09:00:00
cms1t22by0329nr6bnj6tuq7l	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89635	7200	0	7200	COMPLETED	\N	2026-07-26 09:37:00
cms1t22c1032fnr6b4qa0s1cs	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	\N	\N	TK-89636	6000	0	6000	COMPLETED	\N	2026-07-26 10:14:00
cms1t22c3032mnr6be36eq99a	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89637	6600	0	6600	COMPLETED	\N	2026-07-26 10:51:00
cms1t22c5032snr6bkk9urxlc	cms1t20wv000onr6b55iy581v	cms1t211z000ynr6b1czgd91f	cms1t214s0039nr6bqwp5oiay	\N	TK-89638	5000	0	5000	COMPLETED	\N	2026-07-26 11:28:00
\.


--
-- Data for Name: SaleItem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SaleItem" (id, "saleId", "productId", "batchId", quantity, "unitPrice", discount, "lineTotal") FROM stdin;
cms1t2152003qnr6b9fpc7z30	cms1t2151003onr6bnwud5kgb	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t2152003rnr6bdag02o6g	cms1t2151003onr6bnwud5kgb	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t2155003wnr6bqq17wtbu	cms1t2155003unr6bwpbbqzf7	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t2155003xnr6bh5bi0jk5	cms1t2155003unr6bwpbbqzf7	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21580042nr6bldg1cmk2	cms1t21580040nr6b5scrzqss	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t215a0047nr6buszlooat	cms1t215a0045nr6b481vzicb	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t215c004cnr6boz9q1fmp	cms1t215c004anr6b5911j9gk	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t215c004dnr6bs9awblkw	cms1t215c004anr6b5911j9gk	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t215c004enr6bodpeus5f	cms1t215c004anr6b5911j9gk	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t215f004jnr6b6splkokd	cms1t215f004hnr6beii3gk95	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t215f004knr6bhz49m0fx	cms1t215f004hnr6beii3gk95	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t215f004lnr6b3dflimx9	cms1t215f004hnr6beii3gk95	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t215i004qnr6by9uzgbdz	cms1t215i004onr6b9ch3u2hp	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t215i004rnr6bqxfejism	cms1t215i004onr6b9ch3u2hp	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t215k004wnr6b3dwkd6v4	cms1t215k004unr6bwgaa6v2u	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t215k004xnr6bfn2gn7an	cms1t215k004unr6bwgaa6v2u	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t215m0052nr6blq9t0n96	cms1t215m0050nr6bdgeu0b3y	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t215m0053nr6bc3afo78k	cms1t215m0050nr6bdgeu0b3y	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t215p0058nr6bk1php1c2	cms1t215p0056nr6b3fnbt8mb	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t215p0059nr6bqhx5uxk2	cms1t215p0056nr6b3fnbt8mb	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t215p005anr6b5f70x7ig	cms1t215p0056nr6b3fnbt8mb	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t215r005fnr6byzws1hib	cms1t215r005dnr6bzyz37pwu	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t215r005gnr6b42sjskfu	cms1t215r005dnr6bzyz37pwu	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t215r005hnr6bkrsh5srw	cms1t215r005dnr6bzyz37pwu	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t215u005mnr6bdlg88s0r	cms1t215u005knr6bnayndrpj	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t215u005nnr6bx4b0eai3	cms1t215u005knr6bnayndrpj	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t215w005snr6b062v5dqx	cms1t215w005qnr6bzqyr8w3d	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t215w005tnr6bnl284q8j	cms1t215w005qnr6bzqyr8w3d	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t215w005unr6bel05h1aq	cms1t215w005qnr6bzqyr8w3d	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t215y005znr6blcphfoln	cms1t215y005xnr6bwnipt8u2	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t215y0060nr6bybg8m1oj	cms1t215y005xnr6bwnipt8u2	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t215y0061nr6byoqanyuz	cms1t215y005xnr6bwnipt8u2	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21600066nr6b9s9evla8	cms1t21600064nr6b3nltdua5	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21600067nr6b6d3oxf3c	cms1t21600064nr6b3nltdua5	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21600068nr6bxgmq55ao	cms1t21600064nr6b3nltdua5	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t2163006dnr6bwlyzmc64	cms1t2163006bnr6belfz3r25	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t2163006enr6bq2zti8yi	cms1t2163006bnr6belfz3r25	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t2165006jnr6bok7e4ps1	cms1t2165006hnr6bsjgz3ixx	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t2167006onr6bqa1x30ng	cms1t2167006mnr6b09sbkypy	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t2167006pnr6bh6sf0u1b	cms1t2167006mnr6b09sbkypy	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t2169006unr6bpwqy18yz	cms1t2169006snr6b5xab38za	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t216b006znr6bhgnsfps0	cms1t216b006xnr6bstwm89g4	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t216b0070nr6b7ehs20js	cms1t216b006xnr6bstwm89g4	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t216b0071nr6bkw4l3xi2	cms1t216b006xnr6bstwm89g4	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t216d0076nr6bf7yek7bw	cms1t216d0074nr6bk7jvr0rp	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t216d0077nr6bdlw73slj	cms1t216d0074nr6bk7jvr0rp	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t216d0078nr6bjc8ri5rv	cms1t216d0074nr6bk7jvr0rp	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t216f007dnr6bvwip4um5	cms1t216f007bnr6bq7x7b7uv	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t216f007enr6bnq1wg1e8	cms1t216f007bnr6bq7x7b7uv	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t216f007fnr6bvulrk5fs	cms1t216f007bnr6bq7x7b7uv	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t216i007knr6bgppl2eo9	cms1t216h007inr6bn3gfco94	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t216i007lnr6bme4x3g2f	cms1t216h007inr6bn3gfco94	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t216k007qnr6b94ok1e02	cms1t216k007onr6brl74o6wt	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t216k007rnr6bkcc1e83r	cms1t216k007onr6brl74o6wt	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t216m007wnr6bb0eqzvp3	cms1t216m007unr6byizw8nsl	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t216p0081nr6bnwd201ve	cms1t216p007znr6bwqu6d39y	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t216p0082nr6bzkjm3rvp	cms1t216p007znr6bwqu6d39y	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t216p0083nr6b8wg574nu	cms1t216p007znr6bwqu6d39y	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t216s0088nr6bt30qjjus	cms1t216s0086nr6bx4720lro	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t216s0089nr6b7vwwvdl2	cms1t216s0086nr6bx4720lro	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t216s008anr6bk8igv2rd	cms1t216s0086nr6bx4720lro	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t216u008fnr6bohmkiqcd	cms1t216u008dnr6bn9s3vuya	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t216x008knr6byda25rn4	cms1t216x008inr6b6h5b6rh6	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t216x008lnr6b36v6z3uu	cms1t216x008inr6b6h5b6rh6	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t216z008qnr6bb6nlhoyn	cms1t216z008onr6bzfy17owe	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t2171008vnr6bt6ih6bro	cms1t2171008tnr6bzap4zhsw	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t2171008wnr6br5j9jils	cms1t2171008tnr6bzap4zhsw	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21730091nr6bc0145vvu	cms1t2173008znr6beylz8jbb	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21730092nr6b3mdj4c3g	cms1t2173008znr6beylz8jbb	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21730093nr6bvke4ht3g	cms1t2173008znr6beylz8jbb	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21750098nr6be8zuyej0	cms1t21750096nr6bt2n0o6ka	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t2177009dnr6b8o8ktwbs	cms1t2177009bnr6bksa4etu6	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t2177009enr6bhvh7hww3	cms1t2177009bnr6bksa4etu6	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t2177009fnr6bxrntfk6t	cms1t2177009bnr6bksa4etu6	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t217a009knr6bpiibx8e7	cms1t217a009inr6bdkt8dnpi	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t217c009pnr6bgm4yyljv	cms1t217c009nnr6bqc2x5znn	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t217e009unr6brjmdxe5y	cms1t217e009snr6bybqsm0zn	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t217e009vnr6bfc6mc7tj	cms1t217e009snr6bybqsm0zn	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t217g00a0nr6b3exnga22	cms1t217g009ynr6bhq08w3mr	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t217i00a5nr6boq1d1nvc	cms1t217i00a3nr6bdv1w4g3x	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t217i00a6nr6bgxzzrg9x	cms1t217i00a3nr6bdv1w4g3x	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t217i00a7nr6bok8ox531	cms1t217i00a3nr6bdv1w4g3x	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t217k00acnr6b2gktzbl1	cms1t217k00aanr6bordo3p36	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t217k00adnr6bfdf80281	cms1t217k00aanr6bordo3p36	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t217m00ainr6bx1v64lgp	cms1t217m00agnr6bansb3jqi	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t217m00ajnr6beac00eus	cms1t217m00agnr6bansb3jqi	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t217o00aonr6b9jfzzzn1	cms1t217o00amnr6bk63hroay	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t217o00apnr6bhijsnxi4	cms1t217o00amnr6bk63hroay	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t217r00aunr6b2n2o71oc	cms1t217r00asnr6bdoxs0870	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t217r00avnr6bg158yj9y	cms1t217r00asnr6bdoxs0870	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t217r00awnr6bds6lto6s	cms1t217r00asnr6bdoxs0870	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t217u00b1nr6bslyprt25	cms1t217u00aznr6bv7n9ypuy	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t217u00b2nr6b7omh1uzs	cms1t217u00aznr6bv7n9ypuy	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t217u00b3nr6bbgbznqtu	cms1t217u00aznr6bv7n9ypuy	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t217w00b8nr6b94mwuoiu	cms1t217w00b6nr6bvk7updgz	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t217y00bdnr6b74cq5o93	cms1t217y00bbnr6b37iqve1e	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t217y00benr6bre85u0ww	cms1t217y00bbnr6b37iqve1e	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t217y00bfnr6b8352qza3	cms1t217y00bbnr6b37iqve1e	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t218100bknr6bwj8gg225	cms1t218100binr6bwlbzf5hj	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t218100blnr6b560s993f	cms1t218100binr6bwlbzf5hj	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t218300bqnr6blibu3ska	cms1t218300bonr6blqzsqkb9	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t218500bvnr6bxsc3b3hp	cms1t218500btnr6bul7u1g6t	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t218500bwnr6bp46v51a5	cms1t218500btnr6bul7u1g6t	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t218500bxnr6b2pwlm807	cms1t218500btnr6bul7u1g6t	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t218700c2nr6b453dxt9p	cms1t218700c0nr6bglis7yfv	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t218900c7nr6bt1gwo6pb	cms1t218900c5nr6b6lihneyp	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t218a00c8nr6b3vizevf1	cms1t218900c5nr6b6lihneyp	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t218a00c9nr6bbrj7nrok	cms1t218900c5nr6b6lihneyp	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t218c00cenr6bc1afwmfh	cms1t218c00ccnr6bplz20onj	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t218c00cfnr6bfgezahxp	cms1t218c00ccnr6bplz20onj	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t218c00cgnr6byy32wrg1	cms1t218c00ccnr6bplz20onj	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t218f00clnr6bb8fmp53v	cms1t218f00cjnr6b65wmbmak	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t218f00cmnr6bzh7ts6t9	cms1t218f00cjnr6b65wmbmak	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t218f00cnnr6bt77jx1zp	cms1t218f00cjnr6b65wmbmak	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t218h00csnr6b921gelhf	cms1t218h00cqnr6btpzzetph	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t218h00ctnr6bhruzynsw	cms1t218h00cqnr6btpzzetph	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t218j00cynr6bowz33qsm	cms1t218j00cwnr6b3enubeil	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t218j00cznr6ba59htj0l	cms1t218j00cwnr6b3enubeil	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t218m00d4nr6bc2i03uuf	cms1t218m00d2nr6bkru5pgq7	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t218m00d5nr6bbqsfox2t	cms1t218m00d2nr6bkru5pgq7	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t218m00d6nr6bmr0lpgj1	cms1t218m00d2nr6bkru5pgq7	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t218o00dbnr6bhnp4qymt	cms1t218o00d9nr6b15gipjzg	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t218o00dcnr6bacj1r15t	cms1t218o00d9nr6b15gipjzg	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t218o00ddnr6bq93szpkh	cms1t218o00d9nr6b15gipjzg	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t218r00dinr6b9abab6x4	cms1t218q00dgnr6bk2wnw6ul	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t218t00dnnr6bzc37rfe3	cms1t218t00dlnr6b0za9pmxt	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t218t00donr6bslha4440	cms1t218t00dlnr6b0za9pmxt	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t218v00dtnr6b3d518bi3	cms1t218v00drnr6b6gce71y9	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t218v00dunr6bv24ce3my	cms1t218v00drnr6b6gce71y9	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t218v00dvnr6bnnbafdd3	cms1t218v00drnr6b6gce71y9	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t218x00e0nr6bxyq6m2aa	cms1t218x00dynr6bq3fpzlos	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t218x00e1nr6btn7ju454	cms1t218x00dynr6bq3fpzlos	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t219000e6nr6bjzdv9emh	cms1t219000e4nr6becokoyol	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t219200ebnr6buoafattw	cms1t219200e9nr6bhhzygs5o	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t219200ecnr6bw3j9ojzp	cms1t219200e9nr6bhhzygs5o	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t219200ednr6bxr2580uy	cms1t219200e9nr6bhhzygs5o	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t219400einr6bwrm6l1cj	cms1t219400egnr6bwcargq9a	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t219600ennr6blkf90fox	cms1t219600elnr6bje0qmhjr	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t219800esnr6bha3ivgb6	cms1t219800eqnr6bo1dilwka	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t219800etnr6btuybtqe7	cms1t219800eqnr6bo1dilwka	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t219800eunr6bhjo1i4tw	cms1t219800eqnr6bo1dilwka	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t219b00eznr6biw76dxbp	cms1t219b00exnr6bx4n4xdwp	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t219c00f4nr6b1szpdtjm	cms1t219c00f2nr6b3wn4ipgz	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t219c00f5nr6bddw91qep	cms1t219c00f2nr6b3wn4ipgz	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t219f00fanr6bzxzicanz	cms1t219f00f8nr6bex0cqw68	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t219g00ffnr6bq091jqfu	cms1t219g00fdnr6buib92k4l	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t219j00fknr6bu0r8n9wb	cms1t219j00finr6bxiiqtaoq	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t219j00flnr6btfamosla	cms1t219j00finr6bxiiqtaoq	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t219j00fmnr6br2sed47v	cms1t219j00finr6bxiiqtaoq	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t219m00frnr6bzjdvkbbd	cms1t219m00fpnr6b6qmd6hdj	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t219o00fwnr6bwtcrsu6n	cms1t219o00funr6bmnslwms5	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t219o00fxnr6blqew2q4x	cms1t219o00funr6bmnslwms5	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t219q00g2nr6bqb0i42er	cms1t219q00g0nr6b7rly0p6j	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t219q00g3nr6bqoz3zcby	cms1t219q00g0nr6b7rly0p6j	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t219t00g8nr6brd49r56t	cms1t219t00g6nr6b3j98x563	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t219t00g9nr6be15zeh2x	cms1t219t00g6nr6b3j98x563	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t219v00genr6b1jvyud7l	cms1t219v00gcnr6btkyka0t3	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t219v00gfnr6bt0kcz9v6	cms1t219v00gcnr6btkyka0t3	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t219v00ggnr6bqiv2b9n7	cms1t219v00gcnr6btkyka0t3	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t219x00glnr6bm15w49n2	cms1t219x00gjnr6bo9xmxv2z	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t219z00gqnr6bj9uov6kx	cms1t219z00gonr6bm40otior	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t219z00grnr6bwd63zctx	cms1t219z00gonr6bm40otior	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21a200gwnr6b52vg9cu0	cms1t21a200gunr6b41fn4mul	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21a200gxnr6bo94snati	cms1t21a200gunr6b41fn4mul	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21a200gynr6b7dn0nig5	cms1t21a200gunr6b41fn4mul	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21a500h3nr6b6b0m04d5	cms1t21a500h1nr6bw6gremyx	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21a500h4nr6bnszaq9mu	cms1t21a500h1nr6bw6gremyx	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21a500h5nr6bspn9xoh6	cms1t21a500h1nr6bw6gremyx	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21a800hanr6b0senuokm	cms1t21a800h8nr6bov9dndzv	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21a800hbnr6b2huhkeyr	cms1t21a800h8nr6bov9dndzv	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ab00hgnr6bkhdv24sr	cms1t21ab00henr6bu8c8z3nb	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ab00hhnr6b4tgsx18r	cms1t21ab00henr6bu8c8z3nb	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21ad00hmnr6b1u95x1l9	cms1t21ad00hknr6bhp6woaws	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21af00hrnr6b83ajso4h	cms1t21af00hpnr6b9wcuo47y	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21af00hsnr6b679rhlva	cms1t21af00hpnr6b9wcuo47y	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ai00hxnr6bpmma708v	cms1t21ah00hvnr6bwuk0sll6	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21ai00hynr6bma30z46f	cms1t21ah00hvnr6bwuk0sll6	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ak00i3nr6b5hnhmc12	cms1t21ak00i1nr6b0hcbcs8o	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21am00i8nr6b8pdcmqr7	cms1t21am00i6nr6bqyso4gxj	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ao00idnr6b699rtrxz	cms1t21ao00ibnr6bke4cg7jt	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ao00ienr6b93p65nzx	cms1t21ao00ibnr6bke4cg7jt	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ao00ifnr6b0ujq9ul3	cms1t21ao00ibnr6bke4cg7jt	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21ar00iknr6bopqaocgj	cms1t21aq00iinr6baqrpeykl	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21at00ipnr6bupkdq0f2	cms1t21at00innr6blzf5jv9z	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21av00iunr6b7mp1fqsu	cms1t21av00isnr6burclbzuv	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21av00ivnr6bzwwvmppr	cms1t21av00isnr6burclbzuv	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21ax00j0nr6bd5vavw0o	cms1t21ax00iynr6bftwb1x3r	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ax00j1nr6beddpvktn	cms1t21ax00iynr6bftwb1x3r	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21az00j6nr6b3uutmccp	cms1t21az00j4nr6bu5sw442i	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21az00j7nr6bhz264k0p	cms1t21az00j4nr6bu5sw442i	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21b200jcnr6bc0goyro5	cms1t21b200janr6b7kpvkrh4	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21b200jdnr6byuajk2mn	cms1t21b200janr6b7kpvkrh4	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21b500jinr6bou3bpklp	cms1t21b400jgnr6bmtietzdu	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21b500jjnr6b4vwj7547	cms1t21b400jgnr6bmtietzdu	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21b700jonr6b3eyd6p1n	cms1t21b700jmnr6b84qzjrch	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21b700jpnr6btos338xe	cms1t21b700jmnr6b84qzjrch	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21b700jqnr6bb6rfl5y8	cms1t21b700jmnr6b84qzjrch	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21ba00jvnr6ba4pxflf1	cms1t21ba00jtnr6bqiiaxycz	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21ba00jwnr6bkpmcjogs	cms1t21ba00jtnr6bqiiaxycz	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21bd00k1nr6b9cua3xzc	cms1t21bd00jznr6brudgtyec	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21bd00k2nr6b5b95qwz2	cms1t21bd00jznr6brudgtyec	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21bd00k3nr6b2a5xw9fk	cms1t21bd00jznr6brudgtyec	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21bf00k8nr6bm5cjgezc	cms1t21bf00k6nr6b9m3us5aq	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21bf00k9nr6bgg52piea	cms1t21bf00k6nr6b9m3us5aq	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21bi00kenr6bfgyfifho	cms1t21bi00kcnr6btswmnc8w	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21bi00kfnr6bzd1epfqr	cms1t21bi00kcnr6btswmnc8w	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21bi00kgnr6b178ocxzy	cms1t21bi00kcnr6btswmnc8w	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21bk00klnr6bxpkrg0fn	cms1t21bk00kjnr6bhyo4fru2	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21bk00kmnr6bt4f6zwdn	cms1t21bk00kjnr6bhyo4fru2	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21bk00knnr6bzexfpb0d	cms1t21bk00kjnr6bhyo4fru2	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21bn00ksnr6byj3nedyu	cms1t21bn00kqnr6b5e07es4r	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21bp00kxnr6bhkzsucl2	cms1t21bp00kvnr6baim031ps	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21bp00kynr6b4eu5646q	cms1t21bp00kvnr6baim031ps	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21bp00kznr6bzvtytddf	cms1t21bp00kvnr6baim031ps	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21bs00l4nr6bbwsuuer6	cms1t21bs00l2nr6b8whu69u9	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21bs00l5nr6bm32elhql	cms1t21bs00l2nr6b8whu69u9	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21bs00l6nr6bwl9zpqya	cms1t21bs00l2nr6b8whu69u9	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21bv00lbnr6bj618mmw8	cms1t21bu00l9nr6bjr0j79bs	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21bv00lcnr6b1j1dvclv	cms1t21bu00l9nr6bjr0j79bs	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21bv00ldnr6bvcm9gij8	cms1t21bu00l9nr6bjr0j79bs	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21bx00linr6bz7q2wjos	cms1t21bx00lgnr6b5p71e320	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21bz00lnnr6b65c9atvi	cms1t21bz00llnr6bmamgdq0v	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21bz00lonr6b68vpd6ut	cms1t21bz00llnr6bmamgdq0v	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21bz00lpnr6bkonw7teh	cms1t21bz00llnr6bmamgdq0v	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21c200lunr6b9oqa213o	cms1t21c200lsnr6b76pubzh4	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21c200lvnr6b56ddmx61	cms1t21c200lsnr6b76pubzh4	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21c400m0nr6b2onqx3x8	cms1t21c400lynr6br9yvnhca	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21c400m1nr6b7kiz6zag	cms1t21c400lynr6br9yvnhca	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21c700m6nr6bsbfsaq6i	cms1t21c700m4nr6bei29qv5w	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21c700m7nr6bgroq4i4p	cms1t21c700m4nr6bei29qv5w	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21c900mcnr6b7yb6nsnc	cms1t21c900manr6bzbebgnzp	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21cb00mhnr6brcprm1a4	cms1t21cb00mfnr6bthg1yywh	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21cd00mmnr6b1na0qmql	cms1t21cd00mknr6bzau6mwc7	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21cd00mnnr6bezwanulj	cms1t21cd00mknr6bzau6mwc7	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21cf00msnr6ba2d7029g	cms1t21cf00mqnr6b9c55rw3o	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21cf00mtnr6bgqx41ix8	cms1t21cf00mqnr6b9c55rw3o	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21ci00mynr6bw7rvzcau	cms1t21ci00mwnr6be0xu0q7q	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21ck00n3nr6bl48jc8yn	cms1t21ck00n1nr6bhj21i97u	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21cm00n8nr6b037kzo2f	cms1t21cm00n6nr6bawpzjbfi	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21co00ndnr6bdwq3u2mj	cms1t21co00nbnr6b27ez4uyu	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21co00nenr6bu6ilazsv	cms1t21co00nbnr6b27ez4uyu	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21cr00njnr6b2eloi4pa	cms1t21cr00nhnr6bpix9gjcq	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21cr00nknr6brydhfca8	cms1t21cr00nhnr6bpix9gjcq	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21ct00npnr6b9o6oipd5	cms1t21ct00nnnr6byin90bde	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21ct00nqnr6bpjoo6d72	cms1t21ct00nnnr6byin90bde	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21ct00nrnr6b5ibt5ng2	cms1t21ct00nnnr6byin90bde	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21cw00nwnr6bq88iwf03	cms1t21cw00nunr6bweax036u	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21cw00nxnr6bl0gl8ms0	cms1t21cw00nunr6bweax036u	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21cy00o2nr6b7bu1jf2o	cms1t21cy00o0nr6b0a1vsv95	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21cy00o3nr6bvcm8q2ju	cms1t21cy00o0nr6b0a1vsv95	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21d100o8nr6b8r02w9pv	cms1t21d000o6nr6bg0mcmwzn	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21d300odnr6b1t8n5uy8	cms1t21d300obnr6bxx10mfz4	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21d300oenr6by39p2y6g	cms1t21d300obnr6bxx10mfz4	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21d500ojnr6bm6i18imp	cms1t21d500ohnr6bby1ysuf9	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21d700oonr6b50zr09hr	cms1t21d700omnr6bbu1zvs2n	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21d900otnr6bgucgf7up	cms1t21d900ornr6b7opnpj28	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21d900ounr6bejf2yhv0	cms1t21d900ornr6b7opnpj28	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21d900ovnr6bh9vfkcac	cms1t21d900ornr6b7opnpj28	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21dc00p0nr6bdifqzo3c	cms1t21dc00oynr6bclcb5yea	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21de00p5nr6bf6gs8e4s	cms1t21de00p3nr6biawd5o48	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21de00p6nr6bqinb7i9u	cms1t21de00p3nr6biawd5o48	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21dg00pbnr6bcd47ffyr	cms1t21dg00p9nr6bgdmg1n6z	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21dg00pcnr6bkp35w0or	cms1t21dg00p9nr6bgdmg1n6z	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21dj00phnr6b3p291uh6	cms1t21dj00pfnr6bhwvfrbdy	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21dj00pinr6btpr41ou4	cms1t21dj00pfnr6bhwvfrbdy	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21dl00pnnr6brzbocu65	cms1t21dl00plnr6bbu71uo2g	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21dl00ponr6bl289d3sl	cms1t21dl00plnr6bbu71uo2g	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21dl00ppnr6bdppem71w	cms1t21dl00plnr6bbu71uo2g	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21do00punr6bxy9h6bga	cms1t21do00psnr6b0doj3zsd	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21dq00pznr6bop41ntaa	cms1t21dq00pxnr6bx56uz32s	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21dq00q0nr6buq58h0rp	cms1t21dq00pxnr6bx56uz32s	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ds00q5nr6bpx3sb1jk	cms1t21ds00q3nr6bt1jem3vm	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ds00q6nr6b66e1en90	cms1t21ds00q3nr6bt1jem3vm	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21ds00q7nr6b9vtgh7wz	cms1t21ds00q3nr6bt1jem3vm	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21dv00qcnr6b4tfo1nv6	cms1t21dv00qanr6bw449e5zv	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21dx00qhnr6b6udxmbwa	cms1t21dx00qfnr6bmj7ic24t	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21dz00qmnr6by7uqp4dt	cms1t21dz00qknr6b6m1fed14	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21dz00qnnr6bnijl4wwl	cms1t21dz00qknr6b6m1fed14	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21e200qsnr6b6a6oys6c	cms1t21e200qqnr6b346gkjld	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21e200qtnr6b4575y830	cms1t21e200qqnr6b346gkjld	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21e400qynr6bhotf05e7	cms1t21e400qwnr6bwnum2h94	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21e400qznr6b3tich9yg	cms1t21e400qwnr6bwnum2h94	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21e700r4nr6b98zh2x3y	cms1t21e700r2nr6b27yq1fdk	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21e900r9nr6blsbbafyo	cms1t21e900r7nr6bt8cuoloo	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21e900ranr6b6eyz3vsq	cms1t21e900r7nr6bt8cuoloo	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21e900rbnr6bshsz4m9s	cms1t21e900r7nr6bt8cuoloo	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21eb00rgnr6bwegwoz6d	cms1t21eb00renr6b0hcux5k7	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ee00rlnr6bkux8ouh9	cms1t21ee00rjnr6bpt9v3xld	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ee00rmnr6bmnuag2q1	cms1t21ee00rjnr6bpt9v3xld	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21eg00rrnr6barzd0oi6	cms1t21eg00rpnr6bx7ro9hdu	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21eg00rsnr6b4gjlvspl	cms1t21eg00rpnr6bx7ro9hdu	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21ej00rxnr6bic1y3iog	cms1t21ej00rvnr6bre43tkfy	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21ej00rynr6bl0jxydec	cms1t21ej00rvnr6bre43tkfy	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ej00rznr6bg0kyyb0f	cms1t21ej00rvnr6bre43tkfy	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21el00s4nr6bws4i9vfj	cms1t21el00s2nr6bnew6jm5x	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21eo00s9nr6b5bv15ql4	cms1t21eo00s7nr6bilyp3esk	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21eo00sanr6bheafo5rs	cms1t21eo00s7nr6bilyp3esk	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21eo00sbnr6b9tk121d7	cms1t21eo00s7nr6bilyp3esk	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21er00sgnr6b2e2po8d1	cms1t21er00senr6ba5nh5nf8	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21er00shnr6by2vstxw9	cms1t21er00senr6ba5nh5nf8	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21eu00smnr6buoilyhxy	cms1t21eu00sknr6bkdwajpii	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21eu00snnr6b131b6qgv	cms1t21eu00sknr6bkdwajpii	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21eu00sonr6bw0y3927m	cms1t21eu00sknr6bkdwajpii	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21ew00stnr6ba90tg6a7	cms1t21ew00srnr6b4louos0w	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21ez00synr6bquyqhj9f	cms1t21ez00swnr6b8en21m0w	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21ez00sznr6bfusyl9ra	cms1t21ez00swnr6b8en21m0w	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ez00t0nr6blsb7lnjl	cms1t21ez00swnr6b8en21m0w	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21f100t5nr6bxb66chi1	cms1t21f100t3nr6bzzp1q38l	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21f300tanr6b56fseol8	cms1t21f300t8nr6bu4bcxvfg	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21f300tbnr6bziogawdv	cms1t21f300t8nr6bu4bcxvfg	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21f300tcnr6b3amcawmd	cms1t21f300t8nr6bu4bcxvfg	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21f600thnr6blqxu04g7	cms1t21f600tfnr6b4cr0f7gm	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21f600tinr6bj7o3zv21	cms1t21f600tfnr6b4cr0f7gm	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21f600tjnr6bd012go2u	cms1t21f600tfnr6b4cr0f7gm	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21f800tonr6br97ld858	cms1t21f800tmnr6bkgw5t0if	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21f800tpnr6bwkegpxke	cms1t21f800tmnr6bkgw5t0if	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21f800tqnr6b86g9ldy4	cms1t21f800tmnr6bkgw5t0if	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21fb00tvnr6bcs073se9	cms1t21fb00ttnr6bgonzdwz1	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21fb00twnr6bkdxzxjhw	cms1t21fb00ttnr6bgonzdwz1	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21fb00txnr6bcxbt3w8a	cms1t21fb00ttnr6bgonzdwz1	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21fe00u2nr6bi6u3kt9s	cms1t21fe00u0nr6bc21qvimu	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21fg00u7nr6bqk4lxgc1	cms1t21fg00u5nr6by9ts894h	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21fg00u8nr6b3rnh9b3i	cms1t21fg00u5nr6by9ts894h	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21fg00u9nr6bepk8ewfi	cms1t21fg00u5nr6by9ts894h	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21fi00uenr6bgv4lz3qw	cms1t21fi00ucnr6bkxvue0z9	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21fi00ufnr6bmcefqvod	cms1t21fi00ucnr6bkxvue0z9	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21fi00ugnr6b764bbd2w	cms1t21fi00ucnr6bkxvue0z9	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21fk00ulnr6b7k7v30do	cms1t21fk00ujnr6but2q7xab	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21fm00uqnr6blvcgxf57	cms1t21fm00uonr6bo4b4lu84	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21fm00urnr6b0y3cacxi	cms1t21fm00uonr6bo4b4lu84	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21fo00uwnr6byxbz130g	cms1t21fo00uunr6b95xpw4fz	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21fq00v1nr6baj5jn0m0	cms1t21fq00uznr6b8wdqj5xf	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21fs00v6nr6bnwnbx7vq	cms1t21fs00v4nr6btu2s5j20	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21fu00vbnr6b64lw3lyg	cms1t21fu00v9nr6bq5bh8i1c	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21fu00vcnr6btcpormr8	cms1t21fu00v9nr6bq5bh8i1c	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21fu00vdnr6bnt4psrax	cms1t21fu00v9nr6bq5bh8i1c	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21fx00vinr6blkfzktcc	cms1t21fx00vgnr6b122qi9mk	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21fx00vjnr6br9fgafqq	cms1t21fx00vgnr6b122qi9mk	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21fx00vknr6blabqdzei	cms1t21fx00vgnr6b122qi9mk	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21fz00vpnr6bvp82hen4	cms1t21fz00vnnr6bu7to0r6z	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21fz00vqnr6b49pisr1l	cms1t21fz00vnnr6bu7to0r6z	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21g200vvnr6bmotgrreu	cms1t21g200vtnr6bnscq2gnk	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21g200vwnr6bnpgq0gqg	cms1t21g200vtnr6bnscq2gnk	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21g200vxnr6b7c3igm97	cms1t21g200vtnr6bnscq2gnk	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21g400w2nr6bg4djsrs6	cms1t21g400w0nr6bqrpl27jm	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21g600w7nr6b9dgxi5oc	cms1t21g600w5nr6b29tnqvk8	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21g900wcnr6bu9cdg1d1	cms1t21g900wanr6bgspc3fx0	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21g900wdnr6bppzoppxj	cms1t21g900wanr6bgspc3fx0	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21gb00winr6b71jzor5v	cms1t21gb00wgnr6bo7fksqxi	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21gd00wnnr6b973ndikt	cms1t21gd00wlnr6bk6jvtq4y	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21gg00wsnr6bp9yhioy6	cms1t21gg00wqnr6b3lq4noue	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21gg00wtnr6bczccrdyr	cms1t21gg00wqnr6b3lq4noue	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21gj00wynr6bwlgxohgc	cms1t21gi00wwnr6bht153dzm	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21gj00wznr6bvruyf9lk	cms1t21gi00wwnr6bht153dzm	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21gl00x4nr6b7c2q533g	cms1t21gl00x2nr6bgle6m1o1	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21gn00x9nr6blde4l2vf	cms1t21gn00x7nr6bs4lm2wit	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21gn00xanr6by6t5itfr	cms1t21gn00x7nr6bs4lm2wit	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21gn00xbnr6b6v99qpoc	cms1t21gn00x7nr6bs4lm2wit	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21gq00xgnr6bsibfphpx	cms1t21gq00xenr6buivx9d0s	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21gs00xlnr6b0ka2vs7m	cms1t21gs00xjnr6bm5vck9cs	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21gu00xqnr6bvcaa3mi1	cms1t21gu00xonr6bfqfx1u0m	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21gu00xrnr6bjjwv62if	cms1t21gu00xonr6bfqfx1u0m	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21gu00xsnr6bv9frfq64	cms1t21gu00xonr6bfqfx1u0m	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21gx00xxnr6befrdelnq	cms1t21gx00xvnr6b9xp258p5	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21gz00y2nr6bw1qxc3vo	cms1t21gz00y0nr6b4s6kz5eh	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21gz00y3nr6b33ben3rs	cms1t21gz00y0nr6b4s6kz5eh	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21gz00y4nr6be5fyy0pr	cms1t21gz00y0nr6b4s6kz5eh	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21h200y9nr6b4vout49k	cms1t21h200y7nr6b9yu34bvf	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21h200yanr6bg9isqgc5	cms1t21h200y7nr6b9yu34bvf	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21h200ybnr6bmpu32b7a	cms1t21h200y7nr6b9yu34bvf	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21h500ygnr6bx3tol8r7	cms1t21h500yenr6bxjrrxgnm	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21h700ylnr6b8c732kis	cms1t21h700yjnr6bmcvf7rrs	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21h700ymnr6b7jlgj6ss	cms1t21h700yjnr6bmcvf7rrs	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21h700ynnr6b1zp18awj	cms1t21h700yjnr6bmcvf7rrs	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21ha00ysnr6bezu7zuu1	cms1t21ha00yqnr6b3ifcejx6	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21ha00ytnr6b9uovxlyq	cms1t21ha00yqnr6b3ifcejx6	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ha00yunr6bmzemqaye	cms1t21ha00yqnr6b3ifcejx6	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21hc00yznr6bcn0j012k	cms1t21hc00yxnr6bt0jzcftr	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21hc00z0nr6bb1ski29j	cms1t21hc00yxnr6bt0jzcftr	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21hc00z1nr6b5banungi	cms1t21hc00yxnr6bt0jzcftr	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21hf00z6nr6bj88j9k2r	cms1t21hf00z4nr6bml7nyjvu	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21hh00zbnr6bnmyc43qc	cms1t21hh00z9nr6b7gnyzrvp	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21hh00zcnr6biz9kbedb	cms1t21hh00z9nr6b7gnyzrvp	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21hh00zdnr6bv7cpla1j	cms1t21hh00z9nr6b7gnyzrvp	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21hj00zinr6b7b9fcfq7	cms1t21hj00zgnr6b3d6rb0jp	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21hj00zjnr6bfc0c6n42	cms1t21hj00zgnr6b3d6rb0jp	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21hj00zknr6bhs7m2v4f	cms1t21hj00zgnr6b3d6rb0jp	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21hm00zpnr6bi7tn92ob	cms1t21hm00znnr6b36ldufcw	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21hm00zqnr6bcudnxwt4	cms1t21hm00znnr6b36ldufcw	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ho00zvnr6blyrrna7a	cms1t21ho00ztnr6b290lu4ts	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ho00zwnr6blczacnsp	cms1t21ho00ztnr6b290lu4ts	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21ho00zxnr6bw5dlocat	cms1t21ho00ztnr6b290lu4ts	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21hr0102nr6brs85hiw0	cms1t21hr0100nr6b672wbsw1	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21hr0103nr6bwl7tskbs	cms1t21hr0100nr6b672wbsw1	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ht0108nr6bziogmser	cms1t21ht0106nr6bw823eghw	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21hv010dnr6bq29shvg0	cms1t21hv010bnr6bs3sv5s5v	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21hx010inr6byipssu4g	cms1t21hx010gnr6bvb59eldp	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21hx010jnr6b56iz21jx	cms1t21hx010gnr6bvb59eldp	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21i0010onr6bjow9ppwk	cms1t21i0010mnr6b00vutqjx	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21i0010pnr6bj51ijb8p	cms1t21i0010mnr6b00vutqjx	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21i0010qnr6b6kayyfvs	cms1t21i0010mnr6b00vutqjx	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21i2010vnr6bc1kuzrhm	cms1t21i2010tnr6b9rc0tep1	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21i2010wnr6bhlxl4x8c	cms1t21i2010tnr6b9rc0tep1	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21i2010xnr6bypnnxjll	cms1t21i2010tnr6b9rc0tep1	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21i40112nr6bhu7coug1	cms1t21i40110nr6b0lbhicne	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21i40113nr6b6mh4zq95	cms1t21i40110nr6b0lbhicne	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21i40114nr6bouyg3gsy	cms1t21i40110nr6b0lbhicne	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21i70119nr6bv63ae0jf	cms1t21i70117nr6bx4gm7ylk	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21i7011anr6bwhk9rblc	cms1t21i70117nr6bx4gm7ylk	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21i7011bnr6brciojtle	cms1t21i70117nr6bx4gm7ylk	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21i9011gnr6bbh993vhp	cms1t21i9011enr6bvqv7w1ge	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21i9011hnr6bdpph7u2f	cms1t21i9011enr6bvqv7w1ge	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21ib011mnr6bbolc96wf	cms1t21ib011knr6b0uwbzrob	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21ib011nnr6b1ymdgapn	cms1t21ib011knr6b0uwbzrob	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21id011snr6bpgzh8uux	cms1t21id011qnr6bosyu3hq8	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21id011tnr6b1l3twdod	cms1t21id011qnr6bosyu3hq8	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21id011unr6b347etgxk	cms1t21id011qnr6bosyu3hq8	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ig011znr6bfrdo591u	cms1t21ig011xnr6be2iec6kx	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21ii0124nr6bfcl0l8fw	cms1t21ih0122nr6b12v44rid	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21ij0129nr6b5f1ku071	cms1t21ij0127nr6b5q8rr7j1	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ij012anr6bcmxsd9qw	cms1t21ij0127nr6b5q8rr7j1	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21im012fnr6b3eaozv3g	cms1t21im012dnr6b647v15yc	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21io012knr6bxlvxao82	cms1t21io012inr6bwr4t1oym	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21iq012pnr6bg26ji9p7	cms1t21iq012nnr6b33nfy9es	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21is012unr6b5g0uvebt	cms1t21is012snr6bmjoeyhq0	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21is012vnr6bgab3n6ow	cms1t21is012snr6bmjoeyhq0	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21is012wnr6bdd30pngn	cms1t21is012snr6bmjoeyhq0	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21iu0131nr6bx11v2gco	cms1t21iu012znr6bwioqu3jx	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21iw0136nr6b40ct661z	cms1t21iw0134nr6b7sxqx0k3	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21iw0137nr6bx565v6nt	cms1t21iw0134nr6b7sxqx0k3	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21iy013cnr6bgmx3n5w5	cms1t21iy013anr6bep0qcefq	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21iy013dnr6bjlig56qo	cms1t21iy013anr6bep0qcefq	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21j2013inr6bjw5fkc2k	cms1t21j1013gnr6bfij6qx1k	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21j2013jnr6bvge3jgw0	cms1t21j1013gnr6bfij6qx1k	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21j2013knr6bbkkut0g6	cms1t21j1013gnr6bfij6qx1k	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21j6013pnr6bfqbsh2xo	cms1t21j6013nnr6bimohuiwe	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21j9013unr6b7j6njsho	cms1t21j9013snr6b11jfvt44	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21j9013vnr6bq9puq33o	cms1t21j9013snr6b11jfvt44	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21j9013wnr6bp4ftqpox	cms1t21j9013snr6b11jfvt44	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21jc0141nr6bniifvxpn	cms1t21jc013znr6boqqmt3w8	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21je0146nr6b6x9dann5	cms1t21je0144nr6b36d1audi	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21je0147nr6b911rz2w3	cms1t21je0144nr6b36d1audi	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21jg014cnr6b7ddfc6d2	cms1t21jg014anr6b5ks76ybr	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21jg014dnr6b5wpixwmk	cms1t21jg014anr6b5ks76ybr	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21jg014enr6bd6wtqg4l	cms1t21jg014anr6b5ks76ybr	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21jj014jnr6b7teyhls2	cms1t21jj014hnr6bo8tyahe6	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21jl014onr6b6reuanpe	cms1t21jl014mnr6b6dx4m3qp	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21jl014pnr6buo8fdt3r	cms1t21jl014mnr6b6dx4m3qp	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21jl014qnr6bltpznqyu	cms1t21jl014mnr6b6dx4m3qp	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21jn014vnr6bbyeepu6j	cms1t21jn014tnr6b40ctsh2f	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21jn014wnr6bjxlnw4g1	cms1t21jn014tnr6b40ctsh2f	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21jn014xnr6bwo3v42mh	cms1t21jn014tnr6b40ctsh2f	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21jq0152nr6b9j7ood5i	cms1t21jq0150nr6bsomeg2pe	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21jq0153nr6bffs0qi6z	cms1t21jq0150nr6bsomeg2pe	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21js0158nr6b8ch1y89d	cms1t21js0156nr6bbxikvt54	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ju015dnr6b0x1kksvh	cms1t21ju015bnr6b4gkhcvcz	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ju015enr6b0m3n8934	cms1t21ju015bnr6b4gkhcvcz	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21jw015jnr6bbxrgmhg1	cms1t21jw015hnr6bkbvwi9z2	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21jw015knr6b0s4sxmxq	cms1t21jw015hnr6bkbvwi9z2	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21jz015pnr6b2h3m5kn1	cms1t21jz015nnr6b433ro2es	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21jz015qnr6bk17cafxz	cms1t21jz015nnr6b433ro2es	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21k1015vnr6bk3r1q380	cms1t21k1015tnr6bupz4kxrl	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21k1015wnr6b2p787477	cms1t21k1015tnr6bupz4kxrl	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21k1015xnr6bvxwlp3wx	cms1t21k1015tnr6bupz4kxrl	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21k40162nr6b19jf29p4	cms1t21k40160nr6bk0zube5e	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21k40163nr6btqdr4ow4	cms1t21k40160nr6bk0zube5e	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21k40164nr6bi0bhbpgl	cms1t21k40160nr6bk0zube5e	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21k70169nr6b8vhyhkt3	cms1t21k70167nr6b3za04rro	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21k7016anr6bhobm5oy2	cms1t21k70167nr6b3za04rro	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ka016fnr6boct1whxd	cms1t21ka016dnr6bc1kau2ru	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21ka016gnr6bze4hplhh	cms1t21ka016dnr6bc1kau2ru	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21ka016hnr6b5s7a4st7	cms1t21ka016dnr6bc1kau2ru	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21kd016mnr6bdy4lixv6	cms1t21kd016knr6bynw4qvhn	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21kd016nnr6bpoqrkjng	cms1t21kd016knr6bynw4qvhn	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21kh016snr6bbidyzu3c	cms1t21kh016qnr6b8edt2eug	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21kh016tnr6b9u8pwdl5	cms1t21kh016qnr6b8edt2eug	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21kl016ynr6b6f2wlpja	cms1t21kl016wnr6bpyqt49qr	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21kp0173nr6b8mxlmwh6	cms1t21kp0171nr6bxwu9clt0	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21kp0174nr6bhnzl0obq	cms1t21kp0171nr6bxwu9clt0	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21kp0175nr6bjd13ksbj	cms1t21kp0171nr6bxwu9clt0	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21ks017anr6b480a99xe	cms1t21ks0178nr6b1yejxftr	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21ks017bnr6b7usfkjbj	cms1t21ks0178nr6b1yejxftr	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21kv017gnr6bi3doabrm	cms1t21kv017enr6by48fe9gg	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21kv017hnr6b6l02vjpv	cms1t21kv017enr6by48fe9gg	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21kv017inr6b89ube5tf	cms1t21kv017enr6by48fe9gg	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21ky017nnr6bnsbi1tn8	cms1t21ky017lnr6bonti9qqm	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ky017onr6blenzm227	cms1t21ky017lnr6bonti9qqm	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21l1017tnr6bmn1kfm3v	cms1t21l1017rnr6b1d5t7hwn	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21l1017unr6bte6qwvk7	cms1t21l1017rnr6b1d5t7hwn	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21l5017znr6b0oo5uaci	cms1t21l5017xnr6bjy8z0zpi	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21l90184nr6bvhghoyza	cms1t21l90182nr6bxfa5dnm0	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21l90185nr6b9upzcsly	cms1t21l90182nr6bxfa5dnm0	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21lc018anr6bt1derqf6	cms1t21lc0188nr6b1kk8hhtl	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21lc018bnr6byip8kct1	cms1t21lc0188nr6b1kk8hhtl	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21lw018gnr6bbcp2ww3e	cms1t21lw018enr6b7e0dw4f8	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21lw018hnr6bc41lado6	cms1t21lw018enr6b7e0dw4f8	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21m3018mnr6b0ykgyaa5	cms1t21m3018knr6buw28gvm1	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21m6018rnr6b6ru06m2m	cms1t21m6018pnr6bx376rwob	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21m6018snr6b71kjp9ec	cms1t21m6018pnr6bx376rwob	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21m6018tnr6b7u05itme	cms1t21m6018pnr6bx376rwob	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21m9018ynr6bmi3om28k	cms1t21m9018wnr6b9gpzkcg1	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21ma018znr6b7sqmy888	cms1t21m9018wnr6b9gpzkcg1	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21mc0194nr6bvyx2gyzc	cms1t21mc0192nr6b8pfo5trf	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21mf0199nr6b7d7dzuxs	cms1t21mf0197nr6b88c47l9u	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21mf019anr6b03znkri1	cms1t21mf0197nr6b88c47l9u	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21mi019fnr6b1g30vloj	cms1t21mi019dnr6br4c7mmpi	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21mi019gnr6b25psafk0	cms1t21mi019dnr6br4c7mmpi	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21mi019hnr6bx6015g19	cms1t21mi019dnr6br4c7mmpi	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21mk019mnr6bbubfowht	cms1t21mk019knr6bpqs0866s	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21mk019nnr6biyjum4l8	cms1t21mk019knr6bpqs0866s	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21mn019snr6boum94ioq	cms1t21mn019qnr6bzusa5h4s	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21mn019tnr6b4fdbtnmd	cms1t21mn019qnr6bzusa5h4s	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21mp019ynr6bbhbuco12	cms1t21mp019wnr6b3mf06eec	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21mp019znr6b7nojpkl3	cms1t21mp019wnr6b3mf06eec	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21mp01a0nr6b8166iyjb	cms1t21mp019wnr6b3mf06eec	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21mr01a5nr6bt240cqs6	cms1t21mr01a3nr6bdrh3l8p4	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21mr01a6nr6bwip03el3	cms1t21mr01a3nr6bdrh3l8p4	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21mu01abnr6b8v77m6vg	cms1t21mu01a9nr6bi6gvhewi	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21mw01agnr6btnjr7171	cms1t21mw01aenr6brw2jjku8	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21mz01alnr6brqk559n7	cms1t21mz01ajnr6bqxl94cbi	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21mz01amnr6b8x3t6s43	cms1t21mz01ajnr6bqxl94cbi	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21n101arnr6bekqlxyd8	cms1t21n101apnr6bo4zgr2xa	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21n401awnr6bu93tqjta	cms1t21n401aunr6bgtjhlmzg	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21n401axnr6bj0aru7kr	cms1t21n401aunr6bgtjhlmzg	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21na01b2nr6blh3k8hul	cms1t21na01b0nr6bp2q82rfu	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21nd01b7nr6brrzyllxi	cms1t21nd01b5nr6bywia663s	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21nf01bcnr6bn2cvc5sm	cms1t21nf01banr6bz3tw4ujr	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21nf01bdnr6bphllmugo	cms1t21nf01banr6bz3tw4ujr	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21nf01benr6b5mpzpxj1	cms1t21nf01banr6bz3tw4ujr	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21nh01bjnr6b9hmr05vw	cms1t21nh01bhnr6bj1vulbz7	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21nj01bonr6bhd6jm2v2	cms1t21nj01bmnr6bc3rufpj6	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21nj01bpnr6bfwfiuu3o	cms1t21nj01bmnr6bc3rufpj6	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21nm01bunr6bmkuxqjum	cms1t21nm01bsnr6bbyntqzbd	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21nm01bvnr6buhywxu49	cms1t21nm01bsnr6bbyntqzbd	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21nm01bwnr6bi5l4719v	cms1t21nm01bsnr6bbyntqzbd	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21np01c1nr6by4813om8	cms1t21np01bznr6bmsgxix2r	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21np01c2nr6ba4g8u3kv	cms1t21np01bznr6bmsgxix2r	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21np01c3nr6bbz489dyn	cms1t21np01bznr6bmsgxix2r	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21nr01c8nr6brwyy9i8v	cms1t21nr01c6nr6baqrhnzif	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21nr01c9nr6ba6x1rrp7	cms1t21nr01c6nr6baqrhnzif	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21nr01canr6b4kx3yi69	cms1t21nr01c6nr6baqrhnzif	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21nu01cfnr6bzj18iu4y	cms1t21nu01cdnr6bnk7t3xjq	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21nu01cgnr6b1gsngstq	cms1t21nu01cdnr6bnk7t3xjq	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21nw01clnr6b2rwolsyb	cms1t21nw01cjnr6bd2sgtleh	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21nz01cqnr6bp6xu093o	cms1t21nz01conr6b1tq8bfss	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21nz01crnr6bw1ulr4w6	cms1t21nz01conr6b1tq8bfss	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21nz01csnr6bm1res8bp	cms1t21nz01conr6b1tq8bfss	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21o101cxnr6bs2ucdc6c	cms1t21o101cvnr6b2nlbu2y8	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21o201cynr6bkz645krs	cms1t21o101cvnr6b2nlbu2y8	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21o501d3nr6b5yz4cprf	cms1t21o501d1nr6bh0jqxkkt	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21o501d4nr6bdkiuhrh3	cms1t21o501d1nr6bh0jqxkkt	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21o501d5nr6bwf36mwws	cms1t21o501d1nr6bh0jqxkkt	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21o801danr6bg5tjjfgw	cms1t21o801d8nr6blyjjjn61	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21o801dbnr6btj4h0x98	cms1t21o801d8nr6blyjjjn61	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21oa01dgnr6bytsoecyf	cms1t21oa01denr6bnzh82u99	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21oa01dhnr6bbmzwsnzh	cms1t21oa01denr6bnzh82u99	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21od01dmnr6bp5yux7zn	cms1t21od01dknr6bflzw13d4	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21od01dnnr6ba29i5moe	cms1t21od01dknr6bflzw13d4	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21og01dsnr6b74wl6dk8	cms1t21of01dqnr6b048d2cn2	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21og01dtnr6bj9a93hvu	cms1t21of01dqnr6b048d2cn2	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21og01dunr6biv66z8dt	cms1t21of01dqnr6b048d2cn2	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21oi01dznr6bdv72qzsn	cms1t21oi01dxnr6bfyxho4ij	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21oi01e0nr6bed23sh5k	cms1t21oi01dxnr6bfyxho4ij	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21oi01e1nr6bqfle76zv	cms1t21oi01dxnr6bfyxho4ij	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ok01e6nr6bulzh3cdd	cms1t21ok01e4nr6bxqdp0t1n	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21ok01e7nr6b9ucfnpd8	cms1t21ok01e4nr6bxqdp0t1n	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21ok01e8nr6b80285fel	cms1t21ok01e4nr6bxqdp0t1n	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21on01ednr6bzz4u4we7	cms1t21on01ebnr6blbs40dol	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21on01eenr6bly2l2htz	cms1t21on01ebnr6blbs40dol	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21on01efnr6b3f8xd4qo	cms1t21on01ebnr6blbs40dol	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21op01eknr6bzjrq75el	cms1t21op01einr6boyo17w88	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21or01epnr6bal9lsrqt	cms1t21or01ennr6bnk48dmr5	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21or01eqnr6bd97badty	cms1t21or01ennr6bnk48dmr5	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21or01ernr6bcha68scr	cms1t21or01ennr6bnk48dmr5	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ou01ewnr6bg0dge2vs	cms1t21ou01eunr6bu7r05v5u	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ox01f1nr6bfo4tcgzc	cms1t21ox01eznr6bwx77v6kr	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ox01f2nr6bmmqi3mt3	cms1t21ox01eznr6bwx77v6kr	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ox01f3nr6bs774qgby	cms1t21ox01eznr6bwx77v6kr	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21oz01f8nr6bbo54gl1t	cms1t21oz01f6nr6bzibjpsdc	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21oz01f9nr6ba1b2yk7b	cms1t21oz01f6nr6bzibjpsdc	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21oz01fanr6b526mmasa	cms1t21oz01f6nr6bzibjpsdc	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21p201ffnr6bigyygl5j	cms1t21p201fdnr6b17gfrlc1	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21p201fgnr6by4y5xlon	cms1t21p201fdnr6b17gfrlc1	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21p401flnr6bmzg63cfh	cms1t21p401fjnr6b5vjyw52m	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21p401fmnr6b57yxc291	cms1t21p401fjnr6b5vjyw52m	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21p401fnnr6b2u6r1fb9	cms1t21p401fjnr6b5vjyw52m	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21p701fsnr6bcwspit4p	cms1t21p701fqnr6bftgxdu8b	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21p701ftnr6bdtn6qq58	cms1t21p701fqnr6bftgxdu8b	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21p701funr6bbjwf47th	cms1t21p701fqnr6bftgxdu8b	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21p901fznr6bypcvi0c1	cms1t21p901fxnr6b6r26saw9	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21p901g0nr6bvpgvtw94	cms1t21p901fxnr6b6r26saw9	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21pc01g5nr6bhnv0erd0	cms1t21pc01g3nr6bgqlayrhw	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21pe01ganr6bxtiikzi2	cms1t21pe01g8nr6b762lvarh	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21pg01gfnr6bpa9pdjch	cms1t21pg01gdnr6brinwn2ea	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21pg01ggnr6bw5tts8k3	cms1t21pg01gdnr6brinwn2ea	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21pg01ghnr6b9yh627dt	cms1t21pg01gdnr6brinwn2ea	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21pj01gmnr6bp9ap2321	cms1t21pj01gknr6bcyf911kk	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21pl01grnr6b9gyd7fgd	cms1t21pl01gpnr6boe5pazdq	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21pl01gsnr6bbe2t1jvf	cms1t21pl01gpnr6boe5pazdq	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21pl01gtnr6b2jejzdtz	cms1t21pl01gpnr6boe5pazdq	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21po01gynr6bh5sqz9zw	cms1t21po01gwnr6bwt0585ve	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21po01gznr6bgznr31v0	cms1t21po01gwnr6bwt0585ve	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21po01h0nr6b4avoskoz	cms1t21po01gwnr6bwt0585ve	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21pr01h5nr6bq7to1wb5	cms1t21pr01h3nr6buzqckh7j	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21pu01hanr6bojuv754v	cms1t21pt01h8nr6bb1789ohc	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21pw01hfnr6bbve5ylfv	cms1t21pw01hdnr6bpk78v3da	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21py01hknr6by438vpu8	cms1t21py01hinr6bas7ddxu0	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21q001hpnr6b1q189e9b	cms1t21q001hnnr6bgugtfpsx	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21q001hqnr6b8orednjn	cms1t21q001hnnr6bgugtfpsx	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21q001hrnr6b0n494mva	cms1t21q001hnnr6bgugtfpsx	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21q301hwnr6bj8my9t17	cms1t21q301hunr6bjjnucpzs	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21q501i1nr6bxx4wp9tv	cms1t21q501hznr6b8se6hy21	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21q501i2nr6bmtnn4dec	cms1t21q501hznr6b8se6hy21	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21q501i3nr6byiuuifsy	cms1t21q501hznr6b8se6hy21	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21q701i8nr6bk7sslytg	cms1t21q701i6nr6bfowewc32	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21q701i9nr6bvo9p1a3y	cms1t21q701i6nr6bfowewc32	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21qa01ienr6bvxosicby	cms1t21qa01icnr6bha6e0itf	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21qa01ifnr6bukmj1dku	cms1t21qa01icnr6bha6e0itf	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21qc01iknr6bi4q0dbbx	cms1t21qc01iinr6btndf8jlw	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21qc01ilnr6bfal76j5v	cms1t21qc01iinr6btndf8jlw	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21qe01iqnr6btiecrt9u	cms1t21qe01ionr6br9l4jli1	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21qe01irnr6bftzkwmva	cms1t21qe01ionr6br9l4jli1	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21qh01iwnr6bpctk99ni	cms1t21qh01iunr6b5aeo3bay	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21qj01j1nr6byi6pgk6p	cms1t21qj01iznr6bpaysrfgy	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21qj01j2nr6b6ukjldr7	cms1t21qj01iznr6bpaysrfgy	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21qj01j3nr6b638w83c7	cms1t21qj01iznr6bpaysrfgy	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21qm01j8nr6bdysddswk	cms1t21qm01j6nr6b2wokanmo	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21qo01jdnr6buqc1m5le	cms1t21qo01jbnr6bvutbbrz6	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21qo01jenr6b346lmvzk	cms1t21qo01jbnr6bvutbbrz6	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21qo01jfnr6bovk8g5ed	cms1t21qo01jbnr6bvutbbrz6	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21qq01jknr6bv57h2frp	cms1t21qq01jinr6b0falh4pm	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21qq01jlnr6brjz727c6	cms1t21qq01jinr6b0falh4pm	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21qt01jqnr6bckfvcxuz	cms1t21qt01jonr6b61cufjsk	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21qt01jrnr6by62dmtqf	cms1t21qt01jonr6b61cufjsk	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21qt01jsnr6b7byvn4ej	cms1t21qt01jonr6b61cufjsk	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21qv01jxnr6bclsi0p2w	cms1t21qv01jvnr6bsreh7qbl	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21qv01jynr6bs3p6f92t	cms1t21qv01jvnr6bsreh7qbl	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21qv01jznr6bb9vu4tde	cms1t21qv01jvnr6bsreh7qbl	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21qx01k4nr6bwvlnhhd2	cms1t21qx01k2nr6boofc333a	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21qz01k9nr6bkcltpu6g	cms1t21qz01k7nr6b9d6xnj0s	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21qz01kanr6bfnn62oaa	cms1t21qz01k7nr6b9d6xnj0s	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21r201kfnr6b8fdo95td	cms1t21r201kdnr6bme9f7gz2	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21r301kknr6b6tspy9u2	cms1t21r301kinr6by2ccr6hj	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21r401klnr6b6qn8s25i	cms1t21r301kinr6by2ccr6hj	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21r601kqnr6bedn90h17	cms1t21r601konr6b08cpv61m	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21r601krnr6bs1crvuv1	cms1t21r601konr6b08cpv61m	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21r601ksnr6b6okmuws9	cms1t21r601konr6b08cpv61m	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21r801kxnr6bnj0v6eib	cms1t21r801kvnr6brwyuvaqb	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21r801kynr6brg1k18w1	cms1t21r801kvnr6brwyuvaqb	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21r801kznr6bhuct1rwj	cms1t21r801kvnr6brwyuvaqb	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ra01l4nr6bcro2pupa	cms1t21ra01l2nr6bltgzzsx3	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21rc01l9nr6byzbwgtw3	cms1t21rc01l7nr6b5nvne3at	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21rc01lanr6b77s9c2rp	cms1t21rc01l7nr6b5nvne3at	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21rf01lfnr6bnoyku2g4	cms1t21rf01ldnr6bvjisa8ib	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ri01lknr6bk960vhnt	cms1t21rh01linr6bd61bidpa	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21ri01llnr6b8le8g5b7	cms1t21rh01linr6bd61bidpa	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21ri01lmnr6bat4t6ann	cms1t21rh01linr6bd61bidpa	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21rk01lrnr6bgof9k6z0	cms1t21rk01lpnr6brd79qkzc	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21rk01lsnr6bid3o1yic	cms1t21rk01lpnr6brd79qkzc	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21rm01lxnr6b3anpdlbx	cms1t21rm01lvnr6bosudv5f2	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21rm01lynr6bg0eda2yk	cms1t21rm01lvnr6bosudv5f2	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ro01m3nr6bxfezmpf6	cms1t21ro01m1nr6b1r6yoexv	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21ro01m4nr6bgghczgbe	cms1t21ro01m1nr6b1r6yoexv	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21rr01m9nr6b4ji5lty8	cms1t21rr01m7nr6bqru6sgtf	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21rt01menr6b90l9oul1	cms1t21rt01mcnr6bx6ezv5cq	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21rv01mjnr6bl3j6gviq	cms1t21rv01mhnr6bhedjoaup	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21rv01mknr6bdq5dq7px	cms1t21rv01mhnr6bhedjoaup	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21rx01mpnr6btmce9tps	cms1t21rx01mnnr6bc6c3ra5w	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21rx01mqnr6bfmbbwilj	cms1t21rx01mnnr6bc6c3ra5w	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21rx01mrnr6btck96gjx	cms1t21rx01mnnr6bc6c3ra5w	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21rz01mwnr6bbvsl6917	cms1t21rz01munr6bu3vo8w63	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21rz01mxnr6b86r5usrm	cms1t21rz01munr6bu3vo8w63	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21rz01mynr6b8oq8by4o	cms1t21rz01munr6bu3vo8w63	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21s201n3nr6b73ubk8p1	cms1t21s201n1nr6b190lovdq	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21s201n4nr6b2pme8a6k	cms1t21s201n1nr6b190lovdq	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21s401n9nr6bttgph3fg	cms1t21s401n7nr6b6j0n2wmg	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21s401nanr6bttggki3j	cms1t21s401n7nr6b6j0n2wmg	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21s601nfnr6br8l8rus1	cms1t21s601ndnr6bhzy9owuw	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21s601ngnr6bmedpo8q7	cms1t21s601ndnr6bhzy9owuw	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21s901nlnr6b80faqexi	cms1t21s901njnr6b1bvxk09t	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21s901nmnr6bz2w5fjg3	cms1t21s901njnr6b1bvxk09t	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21sb01nrnr6bs4dz5yxx	cms1t21sb01npnr6bcibrja3y	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21sb01nsnr6b8fwnv0u0	cms1t21sb01npnr6bcibrja3y	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21sd01nxnr6b896g94pu	cms1t21sd01nvnr6bmbil8szw	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21sd01nynr6bgmq8rlf0	cms1t21sd01nvnr6bmbil8szw	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21sd01nznr6b8j89j5ni	cms1t21sd01nvnr6bmbil8szw	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21sf01o4nr6bakny6vff	cms1t21sf01o2nr6bb902fqmi	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21sh01o9nr6bkj3u4v3n	cms1t21sh01o7nr6b0oseoyaq	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21sj01oenr6bwmcl9aru	cms1t21sj01ocnr6ba3hlg71z	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21sj01ofnr6b6h8qtkgx	cms1t21sj01ocnr6ba3hlg71z	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21sm01oknr6bsonmybge	cms1t21sl01oinr6bt23vciq6	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21sm01olnr6bnw8jqrbd	cms1t21sl01oinr6bt23vciq6	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21sm01omnr6bvgy5wuoa	cms1t21sl01oinr6bt23vciq6	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21so01ornr6be4aflx1g	cms1t21so01opnr6bkn7iwk9u	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21sq01ownr6b3xo9a8op	cms1t21sq01ounr6b5yl2vfuq	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21sq01oxnr6bz4cz901m	cms1t21sq01ounr6b5yl2vfuq	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ss01p2nr6btw9v0z1w	cms1t21ss01p0nr6b2fbekyn9	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ss01p3nr6b1q3oxk2t	cms1t21ss01p0nr6b2fbekyn9	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21ss01p4nr6bppc035s6	cms1t21ss01p0nr6b2fbekyn9	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21su01p9nr6bzvbv02a4	cms1t21su01p7nr6bfr3zersm	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21sx01penr6bi6u0b5d2	cms1t21sx01pcnr6b7u2sqbxv	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21sx01pfnr6breowo36t	cms1t21sx01pcnr6b7u2sqbxv	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21sx01pgnr6bje47ctxb	cms1t21sx01pcnr6b7u2sqbxv	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21sz01plnr6bjs866l4c	cms1t21sz01pjnr6bvfqmd77z	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21sz01pmnr6bdpp2cgwa	cms1t21sz01pjnr6bvfqmd77z	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21t101prnr6bshtxjv5s	cms1t21t101ppnr6bwaiyhqoh	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21t101psnr6bzyh4u8hu	cms1t21t101ppnr6bwaiyhqoh	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21t301pxnr6belp9pi5p	cms1t21t301pvnr6b2bqiap6p	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21t301pynr6b9inouovv	cms1t21t301pvnr6b2bqiap6p	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21t601q3nr6bq7dppe00	cms1t21t601q1nr6b97y7kcwm	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21t601q4nr6b13r76j49	cms1t21t601q1nr6b97y7kcwm	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21t601q5nr6bdknkoycw	cms1t21t601q1nr6b97y7kcwm	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21t801qanr6b2rdbiuhn	cms1t21t801q8nr6bzolyuxeh	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21ta01qfnr6box87les2	cms1t21ta01qdnr6bxxfp5luz	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21ta01qgnr6bk73z6r5r	cms1t21ta01qdnr6bxxfp5luz	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21ta01qhnr6bp2u3zbj6	cms1t21ta01qdnr6bxxfp5luz	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21tc01qmnr6ba71fo84h	cms1t21tc01qknr6bwxv65i4w	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21tc01qnnr6b8akdd152	cms1t21tc01qknr6bwxv65i4w	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21tf01qsnr6b6k9iqu8m	cms1t21tf01qqnr6bhhpfdgv1	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21tf01qtnr6b5bebh77x	cms1t21tf01qqnr6bhhpfdgv1	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21th01qynr6bvmujeefs	cms1t21th01qwnr6busw2w6ao	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21th01qznr6b042lcapj	cms1t21th01qwnr6busw2w6ao	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21th01r0nr6bdigdposb	cms1t21th01qwnr6busw2w6ao	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21tj01r5nr6b2ax4h0ar	cms1t21tj01r3nr6b94nlgiu1	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21tj01r6nr6bhpwzidj9	cms1t21tj01r3nr6b94nlgiu1	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21tm01rbnr6bv1rgx0ur	cms1t21tm01r9nr6brhb0p3ms	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21tm01rcnr6bgcm11qqn	cms1t21tm01r9nr6brhb0p3ms	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21tm01rdnr6bqvkmlga2	cms1t21tm01r9nr6brhb0p3ms	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21tp01rinr6b21wg9dhs	cms1t21tp01rgnr6bludblckr	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21tp01rjnr6bpacb0fpp	cms1t21tp01rgnr6bludblckr	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21tp01rknr6bdfw5y6yz	cms1t21tp01rgnr6bludblckr	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21tr01rpnr6b5nk7gl1b	cms1t21tr01rnnr6b602e4agp	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21tr01rqnr6bt42hd5qu	cms1t21tr01rnnr6b602e4agp	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21tr01rrnr6b3qvnwjun	cms1t21tr01rnnr6b602e4agp	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21tt01rwnr6bekf32lod	cms1t21tt01runr6bc2znncfm	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21tt01rxnr6bzse0haiu	cms1t21tt01runr6bc2znncfm	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21tt01rynr6b3vdr9gb6	cms1t21tt01runr6bc2znncfm	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21tv01s3nr6bhoqcu5p0	cms1t21tv01s1nr6b0tg1qyv5	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21tv01s4nr6bs8o7rr54	cms1t21tv01s1nr6b0tg1qyv5	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21ty01s9nr6bj5qisc66	cms1t21ty01s7nr6bmnweyatp	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21u001senr6bqbm5wvfr	cms1t21u001scnr6bn27zb2rf	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21u001sfnr6bqmp3cdmq	cms1t21u001scnr6bn27zb2rf	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21u001sgnr6bml69imbr	cms1t21u001scnr6bn27zb2rf	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21u301slnr6bzhlyn9gf	cms1t21u301sjnr6bs18pkxs9	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21u301smnr6b8g1s4p5z	cms1t21u301sjnr6bs18pkxs9	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21u501srnr6bfzqs1mhg	cms1t21u501spnr6bx168hegu	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21u501ssnr6b81t0vrmd	cms1t21u501spnr6bx168hegu	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21u701sxnr6bzjsmecyu	cms1t21u701svnr6b35c96s49	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21u901t2nr6bj94b0bup	cms1t21u901t0nr6bffnbmrfq	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21u901t3nr6bi3cd3797	cms1t21u901t0nr6bffnbmrfq	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21ub01t8nr6bme0rzj03	cms1t21ub01t6nr6b80mcq4xg	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ud01tdnr6bp6uedray	cms1t21ud01tbnr6b1jz17c0m	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21uf01tinr6b9qdh4u20	cms1t21uf01tgnr6bjyxgr2tb	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21uf01tjnr6bpailmauk	cms1t21uf01tgnr6bjyxgr2tb	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21uh01tonr6bzm76r50p	cms1t21uh01tmnr6bb2za7otu	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21uk01ttnr6bkxf49imz	cms1t21uk01trnr6b7rwtixr3	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21uk01tunr6bykmuabme	cms1t21uk01trnr6b7rwtixr3	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21uk01tvnr6b86o4xtwl	cms1t21uk01trnr6b7rwtixr3	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21um01u0nr6bh6jxu9e5	cms1t21um01tynr6b7a6uykgz	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21um01u1nr6bs1j036q4	cms1t21um01tynr6b7a6uykgz	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21um01u2nr6b14ptq9e3	cms1t21um01tynr6b7a6uykgz	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21uo01u7nr6bog1apgyd	cms1t21uo01u5nr6be7ielynx	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21uo01u8nr6bqnlneqp4	cms1t21uo01u5nr6be7ielynx	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ur01udnr6bbigs3qzg	cms1t21ur01ubnr6bgzd1z9xi	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21ur01uenr6bbh0nnqju	cms1t21ur01ubnr6bgzd1z9xi	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21ut01ujnr6b7dz4is4m	cms1t21ut01uhnr6bcbaz4n7g	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ut01uknr6b3tawkxa0	cms1t21ut01uhnr6bcbaz4n7g	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ut01ulnr6bmvafuhz9	cms1t21ut01uhnr6bcbaz4n7g	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21uv01uqnr6bw9c77do8	cms1t21uv01uonr6bn9qz36hm	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ux01uvnr6bqidb1uve	cms1t21ux01utnr6bvw3mtbfl	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21ux01uwnr6bsjv4e9zu	cms1t21ux01utnr6bvw3mtbfl	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ux01uxnr6b9aq858k2	cms1t21ux01utnr6bvw3mtbfl	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21uz01v2nr6bblb81k1p	cms1t21uz01v0nr6bshdro7is	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21uz01v3nr6bcb2vbnki	cms1t21uz01v0nr6bshdro7is	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21v101v8nr6bdbz6ldam	cms1t21v101v6nr6boief2ezz	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21v101v9nr6bc93udsyt	cms1t21v101v6nr6boief2ezz	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21v101vanr6bv3jcy7r3	cms1t21v101v6nr6boief2ezz	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21v401vfnr6b2ytmnov5	cms1t21v401vdnr6byy9t8rvu	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21v401vgnr6bokak9ps9	cms1t21v401vdnr6byy9t8rvu	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21v401vhnr6bvwo5rbjm	cms1t21v401vdnr6byy9t8rvu	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21v601vmnr6b0m87s9qh	cms1t21v601vknr6br26skgpc	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21v601vnnr6bm1qa5r9s	cms1t21v601vknr6br26skgpc	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21v601vonr6b267zqt0k	cms1t21v601vknr6br26skgpc	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21v901vtnr6brmw536sa	cms1t21v901vrnr6bpem2f7e3	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21v901vunr6bz8dkv1bi	cms1t21v901vrnr6bpem2f7e3	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21v901vvnr6bj5uhwqfx	cms1t21v901vrnr6bpem2f7e3	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21vb01w0nr6b07cs74vo	cms1t21vb01vynr6bkbnq3bf8	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21vd01w5nr6bjdncpjuz	cms1t21vd01w3nr6bsnkpmrgq	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21vd01w6nr6b4aakp136	cms1t21vd01w3nr6bsnkpmrgq	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21vd01w7nr6brjgwol6z	cms1t21vd01w3nr6bsnkpmrgq	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21vg01wcnr6biwpeq6jo	cms1t21vg01wanr6b9aqlwkqk	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21vi01whnr6b7s1kdj6n	cms1t21vi01wfnr6bs1wv467r	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21vi01winr6b5volfj3h	cms1t21vi01wfnr6bs1wv467r	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21vl01wnnr6b0flmks2j	cms1t21vl01wlnr6b8hv21a9l	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21vl01wonr6bxk31n9iq	cms1t21vl01wlnr6b8hv21a9l	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21vl01wpnr6bhstsyzq2	cms1t21vl01wlnr6b8hv21a9l	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21vn01wunr6b391um6bl	cms1t21vn01wsnr6biafl5bje	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21vn01wvnr6byinr0485	cms1t21vn01wsnr6biafl5bje	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21vq01x0nr6bwzb4b77k	cms1t21vp01wynr6bbkaak3il	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21vs01x5nr6b04d5p5sy	cms1t21vs01x3nr6b82e3t9te	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21vs01x6nr6b76vuirtw	cms1t21vs01x3nr6b82e3t9te	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21vs01x7nr6bwslljw79	cms1t21vs01x3nr6b82e3t9te	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21vu01xcnr6bv6qiicyh	cms1t21vu01xanr6b42eh15eq	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21vu01xdnr6bi5ekayee	cms1t21vu01xanr6b42eh15eq	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21vu01xenr6bfgtrhjzd	cms1t21vu01xanr6b42eh15eq	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21vx01xjnr6byzrdo0oj	cms1t21vw01xhnr6boxew51e0	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21vx01xknr6bqeb18lv5	cms1t21vw01xhnr6boxew51e0	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21vx01xlnr6bow29lzhw	cms1t21vw01xhnr6boxew51e0	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21vz01xqnr6b422iimu1	cms1t21vz01xonr6b2uzv6gls	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21vz01xrnr6buj8n71f1	cms1t21vz01xonr6b2uzv6gls	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21w101xwnr6byb5rcjjb	cms1t21w101xunr6bf1nnmxql	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21w101xxnr6b8z5n7hcw	cms1t21w101xunr6bf1nnmxql	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21w301y2nr6bxaexicmy	cms1t21w301y0nr6bc0ys7yq1	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21w301y3nr6bvgja3ojq	cms1t21w301y0nr6bc0ys7yq1	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21w601y8nr6bl06ed9th	cms1t21w501y6nr6b2g7c5oqc	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21w601y9nr6bhzv6617p	cms1t21w501y6nr6b2g7c5oqc	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21w901yenr6byjt4u4r8	cms1t21w901ycnr6b7of9633t	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21w901yfnr6bof6314pb	cms1t21w901ycnr6b7of9633t	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21wb01yknr6bvsm9afq3	cms1t21wb01yinr6bdkoowsc9	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21we01ypnr6bccyevja1	cms1t21we01ynnr6b4uv8v1sf	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21we01yqnr6blhrupji9	cms1t21we01ynnr6b4uv8v1sf	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21we01yrnr6bifox8tx7	cms1t21we01ynnr6b4uv8v1sf	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21wg01ywnr6boibp5hhg	cms1t21wg01yunr6bdqkma7ih	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21wg01yxnr6btalgg05t	cms1t21wg01yunr6bdqkma7ih	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21wg01yynr6btbes3fr2	cms1t21wg01yunr6bdqkma7ih	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21wj01z3nr6btsifh80a	cms1t21wj01z1nr6bbllligcf	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21wl01z8nr6b38sse6o6	cms1t21wl01z6nr6byftoc2jy	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21wl01z9nr6bh19wwtqk	cms1t21wl01z6nr6byftoc2jy	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21wl01zanr6b7jitfrcm	cms1t21wl01z6nr6byftoc2jy	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21wo01zfnr6b1rgbz8ip	cms1t21wo01zdnr6beq0kt0ph	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21wo01zgnr6btv14bsyj	cms1t21wo01zdnr6beq0kt0ph	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21wo01zhnr6bcpmyu308	cms1t21wo01zdnr6beq0kt0ph	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21wq01zmnr6bhznfvnkp	cms1t21wq01zknr6bpsp1rd1l	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21wt01zrnr6b4e6sik32	cms1t21wt01zpnr6bu2t9pqyu	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21wv01zwnr6bp14el3gq	cms1t21wv01zunr6b3qiwswih	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21wv01zxnr6bkrccrkhh	cms1t21wv01zunr6b3qiwswih	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21wy0202nr6bjahn0wcj	cms1t21wy0200nr6berv5n2qm	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21wy0203nr6bkuhisner	cms1t21wy0200nr6berv5n2qm	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21x00208nr6bqtyccewf	cms1t21x00206nr6bnszfmyev	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21x3020dnr6bc8s95ceq	cms1t21x3020bnr6bhwcv23y1	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21x3020enr6b86aywp3e	cms1t21x3020bnr6bhwcv23y1	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21x3020fnr6bdkmmnfkj	cms1t21x3020bnr6bhwcv23y1	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21x5020knr6bp1439xbe	cms1t21x5020inr6beca5wvna	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21x5020lnr6bfugqdy19	cms1t21x5020inr6beca5wvna	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21x8020qnr6bvka8xee5	cms1t21x8020onr6b0nmct3eb	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21x8020rnr6bje4jal2z	cms1t21x8020onr6b0nmct3eb	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21x8020snr6bkf8qvd3x	cms1t21x8020onr6b0nmct3eb	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21xa020xnr6bsm8wwnp4	cms1t21xa020vnr6bxp2i5qhm	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21xa020ynr6b1ftx0is2	cms1t21xa020vnr6bxp2i5qhm	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21xd0213nr6bh9tog47b	cms1t21xd0211nr6bpm72nuol	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21xd0214nr6bbnbajgec	cms1t21xd0211nr6bpm72nuol	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21xf0219nr6bluk33axl	cms1t21xf0217nr6bx9m74wdj	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21xh021enr6bcdlzxqx7	cms1t21xh021cnr6boyswuk2s	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21xk021jnr6b0rr71in2	cms1t21xj021hnr6be1t6zl7h	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21xk021knr6bs87cdna1	cms1t21xj021hnr6be1t6zl7h	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21xk021lnr6bc9zo3qx8	cms1t21xj021hnr6be1t6zl7h	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21xm021qnr6bqvjqedf5	cms1t21xm021onr6b5p1kctaw	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21xm021rnr6bhmgozujk	cms1t21xm021onr6b5p1kctaw	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21xp021wnr6bu910khiq	cms1t21xp021unr6bhp5vlpst	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21xr0221nr6bhsnjwlgv	cms1t21xr021znr6bbw2nh180	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21xr0222nr6bfokz2fzc	cms1t21xr021znr6bbw2nh180	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21xr0223nr6bgz066l1n	cms1t21xr021znr6bbw2nh180	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21xu0228nr6blbhztm68	cms1t21xu0226nr6b5k2nkrwt	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21xw022dnr6bdkbqhve8	cms1t21xw022bnr6bnjv8oqf5	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21xw022enr6b7z31j68m	cms1t21xw022bnr6bnjv8oqf5	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21xy022jnr6bowi85d7h	cms1t21xy022hnr6b32mg6qyd	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21xy022knr6bld8avb92	cms1t21xy022hnr6b32mg6qyd	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21xy022lnr6bm4eqmobi	cms1t21xy022hnr6b32mg6qyd	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21y1022qnr6b830p3tbc	cms1t21y1022onr6b363vwzod	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t21y1022rnr6bqxzgr9j5	cms1t21y1022onr6b363vwzod	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21y1022snr6bl5y4temb	cms1t21y1022onr6b363vwzod	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21y3022xnr6bg3a5oyre	cms1t21y3022vnr6bv9zh17ni	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21y3022ynr6bvgqjn18i	cms1t21y3022vnr6bv9zh17ni	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21y3022znr6b3i6a4qmc	cms1t21y3022vnr6bv9zh17ni	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21y60234nr6br0ltkcux	cms1t21y60232nr6b4hg6h111	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21y60235nr6btsnulakq	cms1t21y60232nr6b4hg6h111	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t21y60236nr6brnil0dyp	cms1t21y60232nr6b4hg6h111	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21y9023bnr6btkcq8nki	cms1t21y80239nr6b26ha24u2	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21y9023cnr6bm0n19cuu	cms1t21y80239nr6b26ha24u2	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21yb023hnr6b67skrpv7	cms1t21yb023fnr6b7d1v5dti	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21yb023inr6bkap2iaaq	cms1t21yb023fnr6b7d1v5dti	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21ye023nnr6bca1xa4sq	cms1t21ye023lnr6bx94ei8fm	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21ye023onr6bpiifj3r3	cms1t21ye023lnr6bx94ei8fm	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21yg023tnr6bdylbxmtd	cms1t21yg023rnr6bg8uemk8x	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21yi023ynr6bz62o9pjq	cms1t21yi023wnr6bbstg1s58	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21yi023znr6btgpkkqkx	cms1t21yi023wnr6bbstg1s58	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21yi0240nr6bwjioz6vd	cms1t21yi023wnr6bbstg1s58	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21yl0245nr6b04yjcbrc	cms1t21yl0243nr6bnylwbnj7	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21yn024anr6b04q466xf	cms1t21yn0248nr6bxhsatslw	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21yn024bnr6baqwtrlgi	cms1t21yn0248nr6bxhsatslw	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21yp024gnr6bd6l7csri	cms1t21yp024enr6bdx7t5pfw	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21yp024hnr6bk93i48f4	cms1t21yp024enr6bdx7t5pfw	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t21yp024inr6b2sv3m219	cms1t21yp024enr6bdx7t5pfw	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21ys024nnr6b59us5z9j	cms1t21ys024lnr6b5cajsig4	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21ys024onr6b2x4rt4u5	cms1t21ys024lnr6b5cajsig4	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t21ys024pnr6bgy1ifybx	cms1t21ys024lnr6b5cajsig4	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t21yu024unr6b1s9ef0lx	cms1t21yu024snr6bd5vzx0zb	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21yu024vnr6bkkov4t51	cms1t21yu024snr6bd5vzx0zb	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t21yu024wnr6b41jjtd8r	cms1t21yu024snr6bd5vzx0zb	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21yx0251nr6bckuesp4c	cms1t21yx024znr6bf8bhgmh1	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21yz0256nr6b2bdw0g9b	cms1t21yz0254nr6bhc328g6v	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21yz0257nr6b61xb5wr0	cms1t21yz0254nr6bhc328g6v	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21z1025cnr6bk3qdq8cr	cms1t21z1025anr6bp5buu03w	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21z1025dnr6bmdv7cmj8	cms1t21z1025anr6bp5buu03w	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21z3025inr6byoo4wytn	cms1t21z3025gnr6b13jjdn74	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21z5025nnr6brx3rp460	cms1t21z5025lnr6b6dihz8dg	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21z5025onr6bxoapvhi2	cms1t21z5025lnr6b6dihz8dg	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21z5025pnr6b2cirqdhg	cms1t21z5025lnr6b6dihz8dg	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21z7025unr6b9363fh17	cms1t21z7025snr6bkbts19pq	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21z9025znr6brky28lb0	cms1t21z9025xnr6biagbng16	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21z90260nr6b5wus9j3l	cms1t21z9025xnr6biagbng16	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21zb0265nr6blnlmuetr	cms1t21zb0263nr6b2ql97ka7	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21zb0266nr6b9e4y5im2	cms1t21zb0263nr6b2ql97ka7	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21zd026bnr6bu1ovnccl	cms1t21zd0269nr6bnrw3ahw6	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21zd026cnr6byggpof5e	cms1t21zd0269nr6bnrw3ahw6	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21zd026dnr6bapoees20	cms1t21zd0269nr6bnrw3ahw6	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21zg026inr6bscw55asd	cms1t21zg026gnr6b7bu26emk	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21zg026jnr6bcfy8xsw0	cms1t21zg026gnr6b7bu26emk	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21zg026knr6b0ekr6giq	cms1t21zg026gnr6b7bu26emk	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t21zi026pnr6blyoqww1f	cms1t21zi026nnr6b746trdex	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t21zi026qnr6bx9ek3iz7	cms1t21zi026nnr6b746trdex	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t21zl026vnr6b8s894xfp	cms1t21zl026tnr6bupeywp0g	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t21zl026wnr6bcb0levg1	cms1t21zl026tnr6bupeywp0g	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21zo0271nr6brbsyipm0	cms1t21zo026znr6bpqvhlarv	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t21zo0272nr6b33o21yof	cms1t21zo026znr6bpqvhlarv	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t21zo0273nr6b9izg1loi	cms1t21zo026znr6bpqvhlarv	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t21zr0278nr6bo2dfjes2	cms1t21zr0276nr6bkpt1tgwu	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t21zr0279nr6bj88z7dhg	cms1t21zr0276nr6bkpt1tgwu	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t21zr027anr6bluslapt2	cms1t21zr0276nr6bkpt1tgwu	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t21zu027fnr6bvz4g6jid	cms1t21zu027dnr6bug5dei70	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t21zw027knr6bfzo4aplu	cms1t21zw027inr6b7vtz7fbn	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t21zw027lnr6b7qaotv2e	cms1t21zw027inr6b7vtz7fbn	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t21zw027mnr6blz5o83r0	cms1t21zw027inr6b7vtz7fbn	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t21zz027rnr6bqmw3ek3a	cms1t21zz027pnr6b78o0yyef	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t2201027wnr6bx8t2223o	cms1t2201027unr6bslu05946	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t2201027xnr6bpw3ciw6n	cms1t2201027unr6bslu05946	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t22030282nr6bvqlvm6dc	cms1t22030280nr6bql633yyh	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t22060287nr6b0g1q3ntt	cms1t22060285nr6bpb0yvcl3	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t22060288nr6bmkeh68up	cms1t22060285nr6bpb0yvcl3	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t22060289nr6bn6hf7p8f	cms1t22060285nr6bpb0yvcl3	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t2208028enr6blq4meyej	cms1t2208028cnr6bh83e3ex7	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t2208028fnr6bj35o216i	cms1t2208028cnr6bh83e3ex7	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t2208028gnr6bqv05ukt4	cms1t2208028cnr6bh83e3ex7	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t220b028lnr6boih3ypfy	cms1t220b028jnr6byptjhhej	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t220b028mnr6b5vjcuc4p	cms1t220b028jnr6byptjhhej	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t220e028rnr6b8uvr60j5	cms1t220d028pnr6bisn4v8d6	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t220e028snr6bd696eg60	cms1t220d028pnr6bisn4v8d6	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t220g028xnr6blx8mxouo	cms1t220g028vnr6bghwigx78	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t220g028ynr6bxmmd3dfs	cms1t220g028vnr6bghwigx78	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t220g028znr6bvi5zt42j	cms1t220g028vnr6bghwigx78	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t220j0294nr6b0tolbzhf	cms1t220j0292nr6byht70eht	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t220j0295nr6bbw91xdl0	cms1t220j0292nr6byht70eht	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t220l029anr6bzk1ohzpx	cms1t220l0298nr6b60ukxswy	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t220l029bnr6b7z86wkeb	cms1t220l0298nr6b60ukxswy	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t220l029cnr6bq5y5u9yi	cms1t220l0298nr6b60ukxswy	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t220o029hnr6b26z7a011	cms1t220o029fnr6bvwos42qg	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t220q029mnr6bn9d3nuab	cms1t220q029knr6bf5bjjqc8	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t220s029rnr6b0yf1boqp	cms1t220s029pnr6b9vrry3kn	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t220s029snr6b1o5xce10	cms1t220s029pnr6b9vrry3kn	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t220s029tnr6bwob9hda2	cms1t220s029pnr6b9vrry3kn	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t220v029ynr6b6c2mqirs	cms1t220v029wnr6b2a56q29e	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t220v029znr6b1xns7k5q	cms1t220v029wnr6b2a56q29e	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t220v02a0nr6buec5p15c	cms1t220v029wnr6b2a56q29e	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t220x02a5nr6blaikbpce	cms1t220x02a3nr6bbvr7c7f1	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t221002aanr6bbq6ncbyf	cms1t220z02a8nr6bhmi0ki97	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t221002abnr6b37ls8q5g	cms1t220z02a8nr6bhmi0ki97	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t221202agnr6bn93wal6j	cms1t221202aenr6byoxua6q7	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t221402alnr6bo2slhpul	cms1t221402ajnr6bqjbzz2s4	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t221602aqnr6boae5jwbk	cms1t221602aonr6bph5478rt	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t221602arnr6b9g0a9et3	cms1t221602aonr6bph5478rt	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t221802awnr6b9w7jnpsf	cms1t221802aunr6b3yb4zcmv	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t221802axnr6bn9afmjt3	cms1t221802aunr6b3yb4zcmv	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t221b02b2nr6brytlbgqt	cms1t221b02b0nr6b7bd8s431	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t221b02b3nr6bnfk7o9v2	cms1t221b02b0nr6b7bd8s431	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t221b02b4nr6bvns9xlwk	cms1t221b02b0nr6b7bd8s431	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t221d02b9nr6b3oxhr4sp	cms1t221d02b7nr6bsjappy0z	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t221d02banr6blrpecjg6	cms1t221d02b7nr6bsjappy0z	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t221d02bbnr6bzsobpwuz	cms1t221d02b7nr6bsjappy0z	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t221f02bgnr6bkrweg49d	cms1t221f02benr6bit6jy98p	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t221f02bhnr6bez664x7k	cms1t221f02benr6bit6jy98p	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t221f02binr6byc3ahm2j	cms1t221f02benr6bit6jy98p	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t221h02bnnr6b56f91u37	cms1t221h02blnr6bjur0vmyq	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t221j02bsnr6baq7vrciv	cms1t221j02bqnr6bcbeh8xep	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t221j02btnr6b7qlt2o3f	cms1t221j02bqnr6bcbeh8xep	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t221m02bynr6bfv76fngd	cms1t221m02bwnr6bgu8fipmg	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t221o02c3nr6bak289sia	cms1t221o02c1nr6bztb4120j	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t221q02c8nr6baxyflz2j	cms1t221q02c6nr6bsc04yuph	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t221q02c9nr6blkb0uhbi	cms1t221q02c6nr6bsc04yuph	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t221s02cenr6b7f10u9s3	cms1t221s02ccnr6b9mmq2h4s	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t221s02cfnr6bo2q3jy8a	cms1t221s02ccnr6b9mmq2h4s	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t221s02cgnr6bj63w9bsl	cms1t221s02ccnr6b9mmq2h4s	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t221v02clnr6b05kfly9j	cms1t221u02cjnr6bv6b128nq	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t221v02cmnr6bvoh3p2cc	cms1t221u02cjnr6bv6b128nq	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t221v02cnnr6bwckx0zel	cms1t221u02cjnr6bv6b128nq	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t221x02csnr6bmy440d4d	cms1t221x02cqnr6balo08b04	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t221x02ctnr6b1efo46gy	cms1t221x02cqnr6balo08b04	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t222002cynr6baw8a0yl9	cms1t222002cwnr6brd2hn3oh	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t222002cznr6bamuj9b7d	cms1t222002cwnr6brd2hn3oh	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222202d4nr6btibla9zi	cms1t222202d2nr6b6h1vr1of	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t222202d5nr6bwrx95c6x	cms1t222202d2nr6b6h1vr1of	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t222502danr6b3ux5ciry	cms1t222502d8nr6bv53y0q5a	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t222502dbnr6bpr0m8aqf	cms1t222502d8nr6bv53y0q5a	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222502dcnr6bp1or0i8n	cms1t222502d8nr6bv53y0q5a	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t222702dhnr6b9kzhjz0z	cms1t222702dfnr6bzudl2p7o	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t222702dinr6b48w5mx6g	cms1t222702dfnr6bzudl2p7o	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t222702djnr6bcru1h4u3	cms1t222702dfnr6bzudl2p7o	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t222a02donr6bdop6egai	cms1t222a02dmnr6bj3bdllmw	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t222a02dpnr6bx21q7dhb	cms1t222a02dmnr6bj3bdllmw	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t222a02dqnr6b3n91wbda	cms1t222a02dmnr6bj3bdllmw	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t222d02dvnr6bor5j19er	cms1t222d02dtnr6bt2h0bnz0	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222f02e0nr6be3sptjt0	cms1t222f02dynr6bkumapl0i	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t222f02e1nr6bjjb7d7ns	cms1t222f02dynr6bkumapl0i	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t222f02e2nr6bu0lipkqm	cms1t222f02dynr6bkumapl0i	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t222h02e7nr6baiw1mx48	cms1t222h02e5nr6br5dzeoum	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222k02ecnr6br5z226w1	cms1t222j02eanr6bro2yoezr	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t222k02ednr6bqxx1saux	cms1t222j02eanr6bro2yoezr	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t222k02eenr6bol8c1ot2	cms1t222j02eanr6bro2yoezr	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t222m02ejnr6bkj2ct1qm	cms1t222m02ehnr6b0k1vytbf	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t222o02eonr6bv11h5qt4	cms1t222o02emnr6bkmdr8c0u	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t222r02etnr6b7dojeg2m	cms1t222q02ernr6bv98y6jui	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t222r02eunr6bd16rl9nq	cms1t222q02ernr6bv98y6jui	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t222u02eznr6b7zcimow8	cms1t222u02exnr6but4tupya	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222w02f4nr6bewqn3ih4	cms1t222w02f2nr6bpm07gvyo	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t222y02f9nr6b78x6q7t7	cms1t222y02f7nr6bq0tbzuuc	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t222y02fanr6bj8qmb9qs	cms1t222y02f7nr6bq0tbzuuc	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t223102ffnr6bdlinnmvu	cms1t223102fdnr6b9adxoeny	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t223302fknr6bfynsexwn	cms1t223302finr6b3xh7k3m0	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t223302flnr6b4auqxzce	cms1t223302finr6b3xh7k3m0	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t223302fmnr6bz15a04xg	cms1t223302finr6b3xh7k3m0	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t223602frnr6bzkrnif8c	cms1t223602fpnr6buqkkme02	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t223602fsnr6b20g2zs5p	cms1t223602fpnr6buqkkme02	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t223802fxnr6b94mxdkzj	cms1t223802fvnr6b52ytvdfl	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t223a02g2nr6bug94e85b	cms1t223a02g0nr6bpqgd3h1m	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t223a02g3nr6b6ea4vsdo	cms1t223a02g0nr6bpqgd3h1m	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t223d02g8nr6ba3myqmn2	cms1t223d02g6nr6bh84diasr	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t223f02gdnr6b8ffdcqrx	cms1t223f02gbnr6bwomvn0u2	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t223f02genr6bznechjt2	cms1t223f02gbnr6bwomvn0u2	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t223f02gfnr6bq04d2qql	cms1t223f02gbnr6bwomvn0u2	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t223h02gknr6bjjauxmw0	cms1t223h02ginr6bis975pq7	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t223k02gpnr6bg87uznbi	cms1t223k02gnnr6b76r2a5kv	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t223k02gqnr6b19cqyny7	cms1t223k02gnnr6b76r2a5kv	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t223m02gvnr6btjnw12xw	cms1t223m02gtnr6b0v6di209	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t223o02h0nr6bzfwqtmnk	cms1t223o02gynr6bkskkmy48	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t223r02h5nr6bupfkadh6	cms1t223r02h3nr6bwlay4116	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t223t02hanr6bc3zl5cy3	cms1t223t02h8nr6bnaxacrqa	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t223t02hbnr6blwlkfdxo	cms1t223t02h8nr6bnaxacrqa	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t223t02hcnr6btxgjc40l	cms1t223t02h8nr6bnaxacrqa	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t223v02hhnr6bvfxpvgxd	cms1t223v02hfnr6badmgehlc	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t223v02hinr6bn4pqdey4	cms1t223v02hfnr6badmgehlc	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t223y02hnnr6bgeydk5zc	cms1t223y02hlnr6bwvp86ns6	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t223y02honr6b6ifbnlii	cms1t223y02hlnr6bwvp86ns6	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t223y02hpnr6bj46bv0mb	cms1t223y02hlnr6bwvp86ns6	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t224002hunr6bqf8srwhr	cms1t224002hsnr6bg01ojweb	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t224002hvnr6b7k6fm9hw	cms1t224002hsnr6bg01ojweb	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t224002hwnr6bag40bevo	cms1t224002hsnr6bg01ojweb	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t224302i1nr6bgtgg6xoy	cms1t224302hznr6brrsiqqfo	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t224302i2nr6b6kqtiuna	cms1t224302hznr6brrsiqqfo	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t224302i3nr6bgyuj91g0	cms1t224302hznr6brrsiqqfo	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t224502i8nr6bm1f76re5	cms1t224502i6nr6brxhtizdv	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t224502i9nr6b45ww25b4	cms1t224502i6nr6brxhtizdv	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t224502ianr6b8clifd9z	cms1t224502i6nr6brxhtizdv	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t224802ifnr6bdm61t085	cms1t224802idnr6bqs3t7wvx	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t224802ignr6bx18xj3aj	cms1t224802idnr6bqs3t7wvx	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t224802ihnr6bwn9rtvep	cms1t224802idnr6bqs3t7wvx	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t224a02imnr6b9ezjipb6	cms1t224a02iknr6bfxha6mov	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t224a02innr6bc47tks20	cms1t224a02iknr6bfxha6mov	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t224d02isnr6b1ycgbpwt	cms1t224d02iqnr6ba4n4sa2k	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t224d02itnr6bemti4v31	cms1t224d02iqnr6ba4n4sa2k	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t224f02iynr6bl1xi4an7	cms1t224f02iwnr6bc9zu2px4	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t224f02iznr6bkl5yevdf	cms1t224f02iwnr6bc9zu2px4	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t224h02j4nr6bvm6v4cak	cms1t224h02j2nr6b7waj437e	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t224j02j9nr6b0dzdytx2	cms1t224j02j7nr6bm9armtw9	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t224j02janr6bia0ab2t5	cms1t224j02j7nr6bm9armtw9	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t224m02jfnr6bic4jebw0	cms1t224m02jdnr6b46aak3o4	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t224m02jgnr6b3czfswph	cms1t224m02jdnr6b46aak3o4	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t224m02jhnr6brpxqkknz	cms1t224m02jdnr6b46aak3o4	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t224o02jmnr6b2gnkstco	cms1t224o02jknr6bgvfvvpfy	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t224q02jrnr6brmhvn6db	cms1t224q02jpnr6bon505417	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t224q02jsnr6b5of2fpel	cms1t224q02jpnr6bon505417	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t224q02jtnr6bhh4opft7	cms1t224q02jpnr6bon505417	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t224t02jynr6bv4y8fau8	cms1t224t02jwnr6b2pxp6mdd	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t224t02jznr6b17a8mu8z	cms1t224t02jwnr6b2pxp6mdd	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t224v02k4nr6br0kx3fl7	cms1t224v02k2nr6br2fhd99u	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t224v02k5nr6bf51pc1a5	cms1t224v02k2nr6br2fhd99u	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t224v02k6nr6b0l3c9emu	cms1t224v02k2nr6br2fhd99u	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t224x02kbnr6bm0zs1tdp	cms1t224x02k9nr6bprnxrvvc	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t224z02kgnr6bqrvm2ooq	cms1t224z02kenr6bo4i19yh1	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t224z02khnr6bvhlwopbc	cms1t224z02kenr6bo4i19yh1	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t224z02kinr6bmumbxnoz	cms1t224z02kenr6bo4i19yh1	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t225202knnr6bivrudum9	cms1t225202klnr6b1oz60pt9	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t225202konr6bx81jufjo	cms1t225202klnr6b1oz60pt9	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t225402ktnr6b7og91ksg	cms1t225402krnr6borcll07q	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t225402kunr6bllcabjsp	cms1t225402krnr6borcll07q	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t225702kznr6bi4xb79tn	cms1t225702kxnr6bh70cu7sz	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t225702l0nr6b5sutiuvr	cms1t225702kxnr6bh70cu7sz	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t225a02l5nr6bq0nmmq6d	cms1t225a02l3nr6bdschqnfw	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t225a02l6nr6bt9ryisax	cms1t225a02l3nr6bdschqnfw	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t225c02lbnr6bfyr4hshu	cms1t225c02l9nr6brq6gfhai	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t225e02lgnr6b8r0kkat3	cms1t225e02lenr6b585l08yf	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t225e02lhnr6bbekxzotc	cms1t225e02lenr6b585l08yf	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t225h02lmnr6bb93essws	cms1t225h02lknr6b6v8w51qw	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t225h02lnnr6bwcmiwaiv	cms1t225h02lknr6b6v8w51qw	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t225h02lonr6btf3t310f	cms1t225h02lknr6b6v8w51qw	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t225j02ltnr6bfenx1xm6	cms1t225j02lrnr6bl2n9qafd	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t225j02lunr6b4m7q3q2a	cms1t225j02lrnr6bl2n9qafd	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t225m02lznr6b7jj03w0y	cms1t225m02lxnr6b9oqewjll	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t225m02m0nr6b23v15zz8	cms1t225m02lxnr6b9oqewjll	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t225o02m5nr6begyrkij9	cms1t225o02m3nr6btoqsrv5t	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t225q02manr6bixp61p6b	cms1t225q02m8nr6b78n0oyby	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t225q02mbnr6bv6sl1nxt	cms1t225q02m8nr6b78n0oyby	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t225q02mcnr6bhg33ezze	cms1t225q02m8nr6b78n0oyby	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t225t02mhnr6b9no6givb	cms1t225t02mfnr6bzh1kwtou	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t225v02mmnr6bwes3u9m4	cms1t225v02mknr6bq99vyi1o	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t225v02mnnr6b3pkt1efb	cms1t225v02mknr6bq99vyi1o	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t225v02monr6btfpg1mte	cms1t225v02mknr6bq99vyi1o	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t225y02mtnr6b3jzrvg4o	cms1t225y02mrnr6bbepb6hr6	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t225y02munr6bs2va1g2m	cms1t225y02mrnr6bbepb6hr6	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t225y02mvnr6bonf44kbn	cms1t225y02mrnr6bbepb6hr6	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t226002n0nr6b96iq2tmg	cms1t226002mynr6b2j60dedk	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t226002n1nr6bb6ox5hd9	cms1t226002mynr6b2j60dedk	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t226202n6nr6b7k1kzshr	cms1t226202n4nr6bhbkawypy	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t226202n7nr6bg3hywoil	cms1t226202n4nr6bhbkawypy	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t226502ncnr6bxzp2yqoe	cms1t226502nanr6b5n7hebto	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t226502ndnr6b2chf05fy	cms1t226502nanr6b5n7hebto	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t226502nenr6bxaaeqh4f	cms1t226502nanr6b5n7hebto	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t226702njnr6bi4gvryl0	cms1t226702nhnr6b9q59ieu4	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t226702nknr6bk97wbyao	cms1t226702nhnr6b9q59ieu4	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t226702nlnr6byia2jjn9	cms1t226702nhnr6b9q59ieu4	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t226a02nqnr6btz8oq6a2	cms1t226a02nonr6biay4xsde	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t226c02nvnr6bbjnvxzt4	cms1t226c02ntnr6bxxzb8d0p	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t226c02nwnr6bns5gxm91	cms1t226c02ntnr6bxxzb8d0p	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t226c02nxnr6bogx1vo8q	cms1t226c02ntnr6bxxzb8d0p	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t226e02o2nr6bgp4496a1	cms1t226e02o0nr6bwkdrwbno	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t226g02o7nr6bdb49hjrk	cms1t226g02o5nr6bv787wy19	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t226g02o8nr6bktr0eoe5	cms1t226g02o5nr6bv787wy19	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t226g02o9nr6bsfx5lo81	cms1t226g02o5nr6bv787wy19	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t226j02oenr6bpd9fcic8	cms1t226j02ocnr6bl7f5ga3h	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t226j02ofnr6b0vh59rbl	cms1t226j02ocnr6bl7f5ga3h	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t226j02ognr6b1pw8z0ms	cms1t226j02ocnr6bl7f5ga3h	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t226l02olnr6bzlkoz12x	cms1t226l02ojnr6b1eyuepgw	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t226l02omnr6bgege0ws2	cms1t226l02ojnr6b1eyuepgw	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t226l02onnr6bso54p4fg	cms1t226l02ojnr6b1eyuepgw	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t226n02osnr6bwismti0f	cms1t226n02oqnr6bv2vflf3g	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t226n02otnr6b7z06td3b	cms1t226n02oqnr6bv2vflf3g	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t226q02oynr6buyvwgeqs	cms1t226p02ownr6bypprzylf	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t226q02oznr6b0dthiuec	cms1t226p02ownr6bypprzylf	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t226s02p4nr6b77jcch7n	cms1t226s02p2nr6bru35ckl8	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t226v02p9nr6bia4ik738	cms1t226v02p7nr6bzslcoqfx	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t226v02panr6b5wpmz8wm	cms1t226v02p7nr6bzslcoqfx	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t226x02pfnr6bg6805o0e	cms1t226x02pdnr6biuibatdf	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t226x02pgnr6borrmb6kk	cms1t226x02pdnr6biuibatdf	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t226z02plnr6bvhewj613	cms1t226z02pjnr6b9wzpcn61	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t226z02pmnr6b2oitl713	cms1t226z02pjnr6b9wzpcn61	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t226z02pnnr6bhegb5i46	cms1t226z02pjnr6b9wzpcn61	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t227202psnr6b9t1jrgp2	cms1t227202pqnr6bg9ueytd1	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t227202ptnr6bqdn6tsxq	cms1t227202pqnr6bg9ueytd1	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t227402pynr6bfv707ghc	cms1t227402pwnr6brn24yx0z	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t227402pznr6bpvdlg49o	cms1t227402pwnr6brn24yx0z	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t227702q4nr6bgen1b1wj	cms1t227702q2nr6bz5hisrvl	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t227702q5nr6bzwwt12e2	cms1t227702q2nr6bz5hisrvl	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t227702q6nr6bjgn8pwzm	cms1t227702q2nr6bz5hisrvl	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t227902qbnr6bx90ipsls	cms1t227902q9nr6bvd33v2bj	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t227b02qgnr6b8zk7phwf	cms1t227b02qenr6b4h1afiqv	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t227b02qhnr6b9g1we9za	cms1t227b02qenr6b4h1afiqv	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t227e02qmnr6blvjr5rgh	cms1t227e02qknr6bl0x6e8k4	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t227e02qnnr6b02pkrsa4	cms1t227e02qknr6bl0x6e8k4	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t227g02qsnr6bhi11mdn3	cms1t227g02qqnr6bgx38qmt9	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t227g02qtnr6bl2cqvo94	cms1t227g02qqnr6bgx38qmt9	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t227g02qunr6b81au5boa	cms1t227g02qqnr6bgx38qmt9	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t227i02qznr6bzv2z0azw	cms1t227i02qxnr6bg8spg54q	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t227i02r0nr6bb9ezetwq	cms1t227i02qxnr6bg8spg54q	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t227l02r5nr6bqf6j8qht	cms1t227l02r3nr6bhb4un4a6	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t227n02ranr6b7f8sh1ya	cms1t227n02r8nr6bnclgw7nb	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t227n02rbnr6bda1klv64	cms1t227n02r8nr6bnclgw7nb	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t227n02rcnr6b7lbr4jq8	cms1t227n02r8nr6bnclgw7nb	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t227p02rhnr6bwwvd1bnn	cms1t227p02rfnr6bzo6316rl	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t227p02rinr6bf7u9wgau	cms1t227p02rfnr6bzo6316rl	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t227p02rjnr6blv0cz38q	cms1t227p02rfnr6bzo6316rl	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t227r02ronr6bgx3pjxr9	cms1t227r02rmnr6bj6yzjxoc	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t227t02rtnr6b7fifr3og	cms1t227t02rrnr6bfndlmgui	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t227t02runr6b0iw5vh9k	cms1t227t02rrnr6bfndlmgui	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t227w02rznr6bwiq49f7d	cms1t227w02rxnr6bdzhqsx65	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t227w02s0nr6bsa2qwn6d	cms1t227w02rxnr6bdzhqsx65	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t227z02s5nr6b4oc6eqzq	cms1t227z02s3nr6bhpo8hwc9	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t228202sanr6bx9qrgpc3	cms1t228102s8nr6b0ina1nbk	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t228202sbnr6buhe75vod	cms1t228102s8nr6b0ina1nbk	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t228402sgnr6bpfwaxxqf	cms1t228402senr6bwcrvwwt4	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t228602slnr6bwhavt73u	cms1t228602sjnr6b4j6tmvzf	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t228602smnr6bxrkbnic6	cms1t228602sjnr6b4j6tmvzf	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t228602snnr6b5xus6jrh	cms1t228602sjnr6b4j6tmvzf	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t228902ssnr6bav3kenhq	cms1t228902sqnr6bb2ckagfx	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t228b02sxnr6b4z2o1dms	cms1t228b02svnr6b2ff8x16y	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t228b02synr6bv8ohea4z	cms1t228b02svnr6b2ff8x16y	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t228d02t3nr6bnlysdosy	cms1t228d02t1nr6b6mz95x1f	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t228d02t4nr6boznx7zbj	cms1t228d02t1nr6b6mz95x1f	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t228f02t9nr6bjj8m1u1d	cms1t228f02t7nr6bbp69fszj	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t228h02tenr6b3rg3h1uj	cms1t228h02tcnr6bpxv5wqe2	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t228j02tjnr6bnvb4rjz6	cms1t228j02thnr6b1tscpsmp	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t228l02tonr6bpoad8dix	cms1t228l02tmnr6bavk8l7l1	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t228l02tpnr6bbkz035wm	cms1t228l02tmnr6bavk8l7l1	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t228o02tunr6buogycz35	cms1t228o02tsnr6bv4077z85	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t228o02tvnr6buihg5kkw	cms1t228o02tsnr6bv4077z85	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t228o02twnr6bqrvq2g0e	cms1t228o02tsnr6bv4077z85	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t228q02u1nr6breycb8x2	cms1t228q02tznr6bdxrnt6xv	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t228q02u2nr6bdsfxwls3	cms1t228q02tznr6bdxrnt6xv	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t228t02u7nr6bday1rgi9	cms1t228t02u5nr6bhwaaxny8	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t228v02ucnr6b9jsrm82a	cms1t228v02uanr6bl7vhr9l9	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t228y02uhnr6bsxggom89	cms1t228y02ufnr6bprl99jvk	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t228y02uinr6bfx4vykge	cms1t228y02ufnr6bprl99jvk	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t229102unnr6bf523n425	cms1t229102ulnr6bu4fqybdj	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t229102uonr6bq8b0cvqv	cms1t229102ulnr6bu4fqybdj	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t229102upnr6big4alz03	cms1t229102ulnr6bu4fqybdj	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229402uunr6br44kr9tu	cms1t229402usnr6bcy7whe2f	cms1t213r001pnr6b1h8a1knk	\N	1	2900	0	2900
cms1t229602uznr6bv60iynjt	cms1t229602uxnr6b8lk8ui1r	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t229602v0nr6bz4kfnlgb	cms1t229602uxnr6b8lk8ui1r	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229902v5nr6bise1ihsa	cms1t229902v3nr6bfjsflci1	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t229b02vanr6bokddjwq3	cms1t229b02v8nr6bbkylbyht	cms1t214f002onr6b0nbz3phb	\N	2	3400	0	6800
cms1t229b02vbnr6bcl9qwxdt	cms1t229b02v8nr6bbkylbyht	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t229b02vcnr6bi341lcj8	cms1t229b02v8nr6bbkylbyht	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229e02vhnr6by01y5o7q	cms1t229d02vfnr6bs9b0l6gt	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t229e02vinr6bw9lhr0fr	cms1t229d02vfnr6bs9b0l6gt	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t229g02vnnr6bos0l94sa	cms1t229g02vlnr6b076qbxsj	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t229i02vsnr6bp4gxm5dl	cms1t229i02vqnr6b3k9n5ew9	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t229i02vtnr6bfnkcj3p8	cms1t229i02vqnr6b3k9n5ew9	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t229l02vynr6b4g16ad40	cms1t229l02vwnr6b0dbx3fc9	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t229n02w3nr6byou2qnc7	cms1t229n02w1nr6bqeva2xzl	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t229n02w4nr6b90xbc71q	cms1t229n02w1nr6bqeva2xzl	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t229n02w5nr6bnke0y4c4	cms1t229n02w1nr6bqeva2xzl	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229p02wanr6bc83923jb	cms1t229p02w8nr6boyhqmvt1	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t229p02wbnr6b266p0xh7	cms1t229p02w8nr6boyhqmvt1	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229p02wcnr6bcldwb3bj	cms1t229p02w8nr6boyhqmvt1	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t229s02whnr6bcg975gux	cms1t229s02wfnr6bkxo8u5pc	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t229s02winr6bzdahksn5	cms1t229s02wfnr6bkxo8u5pc	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t229s02wjnr6buo61o72c	cms1t229s02wfnr6bkxo8u5pc	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t229u02wonr6b4cfq2qqz	cms1t229u02wmnr6bmnkx1qxe	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t229u02wpnr6buxzavafs	cms1t229u02wmnr6bmnkx1qxe	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t229u02wqnr6b1ra5aq02	cms1t229u02wmnr6bmnkx1qxe	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t229x02wvnr6bdoivxgll	cms1t229x02wtnr6bq3yhryle	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t229z02x0nr6bw4dsc8ta	cms1t229z02wynr6b2uamn2bp	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t22a102x5nr6bdwshuh8g	cms1t22a102x3nr6blwwpzkfr	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22a102x6nr6bof7h7dw4	cms1t22a102x3nr6blwwpzkfr	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t22a302xbnr6bsl2ms3xx	cms1t22a302x9nr6bbx3kxgrd	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t22a302xcnr6b4hjqrjbg	cms1t22a302x9nr6bbx3kxgrd	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t22a302xdnr6bm8y17iep	cms1t22a302x9nr6bbx3kxgrd	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t22a502xinr6b95sde1fu	cms1t22a502xgnr6bauvulkif	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22a502xjnr6bqmir3riw	cms1t22a502xgnr6bauvulkif	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t22a802xonr6b96drfo0u	cms1t22a802xmnr6br5782tjy	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22a802xpnr6bnxv5vrqt	cms1t22a802xmnr6br5782tjy	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t22a802xqnr6bnth2qo5o	cms1t22a802xmnr6br5782tjy	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22aa02xvnr6bt24k60lb	cms1t22aa02xtnr6b1o67aysy	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t22ac02y0nr6bt8y13uer	cms1t22ac02xynr6bwwozssso	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22ae02y5nr6bjt26mepy	cms1t22ae02y3nr6b8kczhjwu	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t22ag02yanr6bsb83mbbl	cms1t22ag02y8nr6bilfutb4v	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22ag02ybnr6b05kuqid1	cms1t22ag02y8nr6bilfutb4v	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t22ai02ygnr6bfc374du2	cms1t22ai02yenr6brz82ilxr	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t22ai02yhnr6bfhisqqtc	cms1t22ai02yenr6brz82ilxr	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22ai02yinr6bqnszphi9	cms1t22ai02yenr6brz82ilxr	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t22ak02ynnr6bdvyh3mv8	cms1t22ak02ylnr6bk90dg8sw	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t22ak02yonr6besbgjgan	cms1t22ak02ylnr6bk90dg8sw	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t22an02ytnr6b5xg88nmw	cms1t22an02yrnr6bvyyufx1d	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22ap02yynr6byjdqtwtg	cms1t22ap02ywnr6brv8ohmvc	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t22ap02yznr6b4g5ffmgq	cms1t22ap02ywnr6brv8ohmvc	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t22ap02z0nr6bvxdymnsh	cms1t22ap02ywnr6brv8ohmvc	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t22as02z5nr6bwo1e1leg	cms1t22as02z3nr6bj5qzpyan	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t22as02z6nr6bt40flb9l	cms1t22as02z3nr6bj5qzpyan	cms1t21420024nr6bx6rfau6u	\N	1	1800	0	1800
cms1t22au02zbnr6bxa0hw6ti	cms1t22au02z9nr6bf35aqmde	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t22au02zcnr6bs3p0atcx	cms1t22au02z9nr6bf35aqmde	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t22av02zdnr6b66uqll04	cms1t22au02z9nr6bf35aqmde	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t22ax02zinr6bhh85hrm5	cms1t22ax02zgnr6bbryg9mz8	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t22ax02zjnr6bo2oxanee	cms1t22ax02zgnr6bbryg9mz8	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t22ax02zknr6b0t90b1o2	cms1t22ax02zgnr6bbryg9mz8	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t22az02zpnr6bwazr1mho	cms1t22az02znnr6b6zvevx5e	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22az02zqnr6biol3md69	cms1t22az02znnr6b6zvevx5e	cms1t213n001knr6bouk3a3tn	\N	1	700	0	700
cms1t22az02zrnr6bp0z2apwg	cms1t22az02znnr6b6zvevx5e	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t22b202zwnr6bh2fw8437	cms1t22b202zunr6b8y697sqr	cms1t213u001unr6bchir3jer	\N	2	2100	0	4200
cms1t22b30301nr6bsmim8cfy	cms1t22b302zznr6b32cnuav5	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t22b50306nr6bvschxqa5	cms1t22b50304nr6bt65b1joo	cms1t213y001znr6bn4g49x3z	\N	1	1500	0	1500
cms1t22b50307nr6blrwm499r	cms1t22b50304nr6bt65b1joo	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22b50308nr6b2ujsgucs	cms1t22b50304nr6bt65b1joo	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t22b7030dnr6b2tlht5gt	cms1t22b7030bnr6b94dns7hy	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t22b7030enr6bi6qc6dnk	cms1t22b7030bnr6b94dns7hy	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22b9030jnr6bkqtwdq2w	cms1t22b9030hnr6b0oyb8hil	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t22b9030knr6btjlzo6mm	cms1t22b9030hnr6b0oyb8hil	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22bc030pnr6b805m469c	cms1t22bc030nnr6bhne7rt5j	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t22bc030qnr6b9405f736	cms1t22bc030nnr6bhne7rt5j	cms1t214b002jnr6bleifzk78	\N	1	350	0	350
cms1t22bc030rnr6bwi9h7kfb	cms1t22bc030nnr6bhne7rt5j	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22be030wnr6bb7gs2r0b	cms1t22be030unr6bgbl9surg	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t22bg0311nr6bkms5s496	cms1t22bg030znr6b1miqcsih	cms1t213r001pnr6b1h8a1knk	\N	2	2900	0	5800
cms1t22bi0316nr6bpj0fg0jg	cms1t22bi0314nr6b783wxeor	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t22bi0317nr6brqnk17lv	cms1t22bi0314nr6b783wxeor	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22bk031cnr6b3kx7egq2	cms1t22bk031anr6byhq4o6us	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22bk031dnr6btbvkvrgd	cms1t22bk031anr6byhq4o6us	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t22bk031enr6bg1nle8bn	cms1t22bk031anr6byhq4o6us	cms1t21450029nr6bveyybk94	\N	1	1100	0	1100
cms1t22bn031jnr6bg40nwcmp	cms1t22bn031hnr6b9rccdjw2	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22bp031onr6br6zkzj9m	cms1t22bp031mnr6b1eh0glbp	cms1t2148002enr6bduz6y0pt	\N	2	2300	0	4600
cms1t22bp031pnr6bclgdbz22	cms1t22bp031mnr6b1eh0glbp	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t22br031unr6bzuaxplxv	cms1t22br031snr6boqnjbuz6	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22bt031znr6b71pby81b	cms1t22bt031xnr6b6ukq045p	cms1t214f002onr6b0nbz3phb	\N	1	3400	0	3400
cms1t22bt0320nr6bdx9xjtsm	cms1t22bt031xnr6b6ukq045p	cms1t214b002jnr6bleifzk78	\N	2	350	0	700
cms1t22bt0321nr6bgdq6mfgx	cms1t22bt031xnr6b6ukq045p	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t22bw0326nr6bx455p2nu	cms1t22bw0324nr6b512b5g0i	cms1t2148002enr6bduz6y0pt	\N	1	2300	0	2300
cms1t22by032bnr6bv7k0e79y	cms1t22by0329nr6bnj6tuq7l	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
cms1t22by032cnr6bwjcyzwoj	cms1t22by0329nr6bnj6tuq7l	cms1t21450029nr6bveyybk94	\N	2	1100	0	2200
cms1t22c1032hnr6bnt99npjw	cms1t22c1032fnr6b4qa0s1cs	cms1t213u001unr6bchir3jer	\N	1	2100	0	2100
cms1t22c1032inr6bipqpyxro	cms1t22c1032fnr6b4qa0s1cs	cms1t213j001fnr6bo0xtxete	\N	1	2500	0	2500
cms1t22c1032jnr6blbw7ln1m	cms1t22c1032fnr6b4qa0s1cs	cms1t213n001knr6bouk3a3tn	\N	2	700	0	1400
cms1t22c3032onr6b6ga37iec	cms1t22c3032mnr6be36eq99a	cms1t213y001znr6bn4g49x3z	\N	2	1500	0	3000
cms1t22c3032pnr6b54p6a9v0	cms1t22c3032mnr6be36eq99a	cms1t21420024nr6bx6rfau6u	\N	2	1800	0	3600
cms1t22c5032unr6blp2asoty	cms1t22c5032snr6bkk9urxlc	cms1t213j001fnr6bo0xtxete	\N	2	2500	0	5000
\.


--
-- Data for Name: StockMovement; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."StockMovement" (id, "pharmacyId", "productId", "batchId", type, quantity, reason, reference, "userId", "createdAt") FROM stdin;
cms1t213m001inr6bpy1taxat	cms1t20wv000onr6b55iy581v	cms1t213j001fnr6bo0xtxete	cms1t213j001gnr6brtago8y2	IN	126	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.298
cms1t213q001nnr6b1jqkdlhu	cms1t20wv000onr6b55iy581v	cms1t213n001knr6bouk3a3tn	cms1t213n001lnr6bx72860r3	IN	28	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.302
cms1t213t001snr6bu4wdl2sn	cms1t20wv000onr6b55iy581v	cms1t213r001pnr6b1h8a1knk	cms1t213r001qnr6bf8qb6nln	IN	15	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.305
cms1t213x001xnr6bdcbbxa2c	cms1t20wv000onr6b55iy581v	cms1t213u001unr6bchir3jer	cms1t213u001vnr6bpu7eo58c	IN	74	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.309
cms1t21410022nr6bmnk8pdvu	cms1t20wv000onr6b55iy581v	cms1t213y001znr6bn4g49x3z	cms1t213y0020nr6biutj5xzj	IN	9	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.313
cms1t21440027nr6b28qb5a6i	cms1t20wv000onr6b55iy581v	cms1t21420024nr6bx6rfau6u	cms1t21420025nr6b363i03ty	IN	58	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.316
cms1t2147002cnr6bpo4p0jqv	cms1t20wv000onr6b55iy581v	cms1t21450029nr6bveyybk94	cms1t2145002anr6bw6lpx9qz	IN	92	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.32
cms1t214a002hnr6b2anx798i	cms1t20wv000onr6b55iy581v	cms1t2148002enr6bduz6y0pt	cms1t2148002fnr6b1cxewyx1	IN	47	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.322
cms1t214d002mnr6b7mcvtyxw	cms1t20wv000onr6b55iy581v	cms1t214b002jnr6bleifzk78	cms1t214b002knr6b6wa50arx	IN	240	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.325
cms1t214h002rnr6bxdn5kn42	cms1t20wv000onr6b55iy581v	cms1t214f002onr6b0nbz3phb	cms1t214f002pnr6bi3f35xl1	IN	33	Stock initial (inventaire d'ouverture)	\N	cms1t20y6000pnr6bff7mdivr	2026-07-26 12:59:45.329
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Subscription" (id, "pharmacyId", plan, status, "billingCycle", amount, currency, "trialEndsAt", "renewsAt") FROM stdin;
cms1t213a0015nr6btyl74ey8	cms1t20wv000onr6b55iy581v	PRO	TRIALING	MONTHLY	39000	XOF	2026-08-06 12:59:45.285	\N
cms1t213c0017nr6b4odedqqh	cms1t213c0016nr6b2mn38qkv	STARTER	ACTIVE	MONTHLY	19000	XOF	\N	\N
\.


--
-- Data for Name: Supplier; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Supplier" (id, "pharmacyId", name, country, contact, email, phone, "leadTimeHours", balance, "isActive") FROM stdin;
cms1t213f0019nr6bd75ia6qv	cms1t20wv000onr6b55iy581v	UBIPHARM	BJ	\N	\N	+229 21 33 10 00	48	2450000	t
cms1t213g001bnr6bwddqp84x	cms1t20wv000onr6b55iy581v	CAMEG	TG	\N	\N	+228 22 21 40 00	72	890000	t
cms1t213h001dnr6bf4bapvdt	cms1t20wv000onr6b55iy581v	LABOREX	CI	\N	\N	+225 27 21 75 00	96	1120000	t
\.


--
-- Data for Name: TreatmentReminder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."TreatmentReminder" (id, "patientId", label, schedule, channel, "isActive") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, email, "passwordHash", "fullName", phone, "mfaSecret", "isActive", "lastLoginAt", "createdAt", "updatedAt") FROM stdin;
cms1t20y6000pnr6bff7mdivr	demo@pharmaflow.ai	scrypt$d8a296829f12f23c0328d4b007c74533$875b17df70c96b6d8683b6cb085b1b0b3c021b9a0bb65bcb5e187d815bc5606cf7101d560d890af5bada87e0f6b74cd7c33acaca0212b00f795ed71cb257694f	Dr. Léonie Ahouansou	\N	\N	t	\N	2026-07-26 12:59:45.102	2026-07-26 12:59:45.102
cms1t20zi000snr6bkwt2cefn	marc.dossou@pharmaflow.ai	scrypt$79a8ccfa12b0e56b1eb79c6b3c31d187$40ee44e511006ce9e649b383906a356d6d4643bd4c7ea52fbe42e79a7db4f4db0474c5bb8ba1eeb3c098b2fbdd73494d76c9fa10b87aedfb0d502655281efa97	Marc Dossou	\N	\N	t	\N	2026-07-26 12:59:45.15	2026-07-26 12:59:45.15
cms1t210q000vnr6b7r9y0xjl	grace.todjinou@pharmaflow.ai	scrypt$0f4f42257a745dbb10d1a436cfed35c0$d8917338ca4485a2cbd3c2dce297babed219df1425a545d0a2f4fdc15d8d51b4342ecde2972084a76b00b3cc6a8a5b13e318e5cdccb18b2063f7c8af100d0488	Grace Todjinou	\N	\N	t	\N	2026-07-26 12:59:45.195	2026-07-26 12:59:45.195
cms1t211z000ynr6b1czgd91f	ismael.koudjo@pharmaflow.ai	scrypt$841fb5ff8132f5946c7ec46abfd8a6f1$af677fd34f12861013a10a6103a3a1d03b0674f2a0a3eeb3f6c5bda8da496f1652ec6bd5d868b81862fb60a541ea75c2de4f7416d958ea73e5c9cc18d62cdca8	Ismaël Koudjo	\N	\N	t	\N	2026-07-26 12:59:45.239	2026-07-26 12:59:45.239
cms1t21370011nr6bgnfndxb4	cabinet.yekpon@pharmaflow.ai	scrypt$c2dc2dda0b8f5af49a2fc1898dd0b9de$1ff1dbd7ebc93d3147e6062d52ef6b9409008638ed003eadc5fecccc0b8927191cab148fe17bae3ba8d4b8826225e89b4503f6c3e71d4be02cc09abae14892d3	Cabinet Yèkpon	\N	\N	t	\N	2026-07-26 12:59:45.283	2026-07-26 12:59:45.283
\.


--
-- Data for Name: WhatsappConversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WhatsappConversation" (id, "pharmacyId", phone, status, "lastMessageAt") FROM stdin;
cms1t22ck033fnr6bh7azworc	cms1t20wv000onr6b55iy581v	+229 97 12 34 56	BOT	2026-07-26 12:59:46.917
\.


--
-- Data for Name: WhatsappMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."WhatsappMessage" (id, "conversationId", direction, sender, body, "providerId", "createdAt") FROM stdin;
cms1t22ck033gnr6bfmdm3srb	cms1t22ck033fnr6bh7azworc	IN	PATIENT	Bonjour, avez-vous de l'Amoxicilline 500 mg ?	\N	2026-07-26 12:59:46.917
cms1t22ck033hnr6bh19z7hsr	cms1t22ck033fnr6bh7azworc	OUT	BOT	Bonjour 👋 Oui, disponible. Prix : 2 500 FCFA la boîte de 12 gélules. Souhaitez-vous réserver ?	\N	2026-07-26 12:59:46.917
cms1t22ck033inr6bexh5wrv8	cms1t22ck033fnr6bh7azworc	IN	PATIENT	Oui	\N	2026-07-26 12:59:46.917
cms1t22ck033jnr6bix4x4r8t	cms1t22ck033fnr6bh7azworc	OUT	BOT	Réservation confirmée ✅ Référence R-8842, valable 2 heures à la Pharmacie Étoile, Gbégamey.	\N	2026-07-26 12:59:46.917
\.


--
-- Data for Name: _PermissionToRole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."_PermissionToRole" ("A", "B") FROM stdin;
cms1t20wc0000nr6bi6olduhx	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0001nr6bk1ywg4gb	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0002nr6bsgj8yvv0	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0003nr6bkntfh20x	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0004nr6blxo7mdy4	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0005nr6bq9qki098	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0006nr6b6kstk1ls	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0007nr6bbkybvywc	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0008nr6b1t6w9snr	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0009nr6bxc1m5qvw	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000anr6b28c3js5v	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000bnr6bq44remji	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000cnr6bw49b1w9e	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000dnr6b6ffem65y	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000enr6bnrd68z8l	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000fnr6b2lhl80r1	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000gnr6bb1yv4ks5	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000hnr6bjuxs1yts	cms1t20wf000jnr6b4v4fy08d
cms1t20wc000inr6bvdm909az	cms1t20wf000jnr6b4v4fy08d
cms1t20wc0000nr6bi6olduhx	cms1t20wk000knr6blaiu7gyh
cms1t20wc0001nr6bk1ywg4gb	cms1t20wk000knr6blaiu7gyh
cms1t20wc0002nr6bsgj8yvv0	cms1t20wk000knr6blaiu7gyh
cms1t20wc0003nr6bkntfh20x	cms1t20wk000knr6blaiu7gyh
cms1t20wc0004nr6blxo7mdy4	cms1t20wk000knr6blaiu7gyh
cms1t20wc0005nr6bq9qki098	cms1t20wk000knr6blaiu7gyh
cms1t20wc0006nr6b6kstk1ls	cms1t20wk000knr6blaiu7gyh
cms1t20wc0007nr6bbkybvywc	cms1t20wk000knr6blaiu7gyh
cms1t20wc0008nr6b1t6w9snr	cms1t20wk000knr6blaiu7gyh
cms1t20wc0009nr6bxc1m5qvw	cms1t20wk000knr6blaiu7gyh
cms1t20wc000anr6b28c3js5v	cms1t20wk000knr6blaiu7gyh
cms1t20wc000bnr6bq44remji	cms1t20wk000knr6blaiu7gyh
cms1t20wc000enr6bnrd68z8l	cms1t20wk000knr6blaiu7gyh
cms1t20wc000fnr6b2lhl80r1	cms1t20wk000knr6blaiu7gyh
cms1t20wc000gnr6bb1yv4ks5	cms1t20wk000knr6blaiu7gyh
cms1t20wc0000nr6bi6olduhx	cms1t20wn000lnr6bpzfl15gl
cms1t20wc0003nr6bkntfh20x	cms1t20wn000lnr6bpzfl15gl
cms1t20wc0005nr6bq9qki098	cms1t20wn000lnr6bpzfl15gl
cms1t20wc0006nr6b6kstk1ls	cms1t20wn000lnr6bpzfl15gl
cms1t20wc0008nr6b1t6w9snr	cms1t20wn000lnr6bpzfl15gl
cms1t20wc0000nr6bi6olduhx	cms1t20wq000mnr6b4ey11cjn
cms1t20wc0002nr6bsgj8yvv0	cms1t20wq000mnr6b4ey11cjn
cms1t20wc0003nr6bkntfh20x	cms1t20wq000mnr6b4ey11cjn
cms1t20wc0003nr6bkntfh20x	cms1t20ws000nnr6b79wxt179
cms1t20wc000anr6b28c3js5v	cms1t20ws000nnr6b79wxt179
cms1t20wc000cnr6bw49b1w9e	cms1t20ws000nnr6b79wxt179
cms1t20wc000dnr6b6ffem65y	cms1t20ws000nnr6b79wxt179
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
de2c9121-8ee3-44d2-8d4d-47b75e0d6d77	de5ca75a6263a8c3066220de2a18eed6fd5b596c8dfbd056b2fd4f25e3d5071a	2026-07-26 12:11:07.886294+00	20260726000000_init		\N	2026-07-26 12:11:07.886294+00	0
3b58dcd8-8781-4f61-b0a1-cc0539025139	301d0da0f318b089709d63388613cc50c2dbfe47547ef0208b0ac71c402679fb	2026-07-26 12:58:46.326801+00	20260726125846_espace_patient	\N	\N	2026-07-26 12:58:46.321965+00	1
0b4d5f86-cbe2-4a93-a395-c192371d9441	bace18567d567464dd6879cd9f316f28d37f4b442ea07097c1da25ea6ddc4fbe	2026-07-26 13:02:38.865366+00	20260726120000_unaccent		\N	2026-07-26 13:02:38.865366+00	0
\.


--
-- Name: AiRecommendation AiRecommendation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiRecommendation"
    ADD CONSTRAINT "AiRecommendation_pkey" PRIMARY KEY (id);


--
-- Name: AuditLog AuditLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pkey" PRIMARY KEY (id);


--
-- Name: Expense Expense_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_pkey" PRIMARY KEY (id);


--
-- Name: GuardSchedule GuardSchedule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GuardSchedule"
    ADD CONSTRAINT "GuardSchedule_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: Patient Patient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: Permission Permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Permission"
    ADD CONSTRAINT "Permission_pkey" PRIMARY KEY (id);


--
-- Name: PharmacyMember PharmacyMember_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PharmacyMember"
    ADD CONSTRAINT "PharmacyMember_pkey" PRIMARY KEY (id);


--
-- Name: Pharmacy Pharmacy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Pharmacy"
    ADD CONSTRAINT "Pharmacy_pkey" PRIMARY KEY (id);


--
-- Name: PrescriptionItem PrescriptionItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PrescriptionItem"
    ADD CONSTRAINT "PrescriptionItem_pkey" PRIMARY KEY (id);


--
-- Name: Prescription Prescription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_pkey" PRIMARY KEY (id);


--
-- Name: ProductBatch ProductBatch_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductBatch"
    ADD CONSTRAINT "ProductBatch_pkey" PRIMARY KEY (id);


--
-- Name: Product Product_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pkey" PRIMARY KEY (id);


--
-- Name: PurchaseOrderItem PurchaseOrderItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrderItem"
    ADD CONSTRAINT "PurchaseOrderItem_pkey" PRIMARY KEY (id);


--
-- Name: PurchaseOrder PurchaseOrder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrder"
    ADD CONSTRAINT "PurchaseOrder_pkey" PRIMARY KEY (id);


--
-- Name: Reservation Reservation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reservation"
    ADD CONSTRAINT "Reservation_pkey" PRIMARY KEY (id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (id);


--
-- Name: SaleItem SaleItem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_pkey" PRIMARY KEY (id);


--
-- Name: Sale Sale_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_pkey" PRIMARY KEY (id);


--
-- Name: StockMovement StockMovement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: Supplier Supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pkey" PRIMARY KEY (id);


--
-- Name: TreatmentReminder TreatmentReminder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TreatmentReminder"
    ADD CONSTRAINT "TreatmentReminder_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: WhatsappConversation WhatsappConversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WhatsappConversation"
    ADD CONSTRAINT "WhatsappConversation_pkey" PRIMARY KEY (id);


--
-- Name: WhatsappMessage WhatsappMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WhatsappMessage"
    ADD CONSTRAINT "WhatsappMessage_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: AiRecommendation_pharmacyId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AiRecommendation_pharmacyId_createdAt_idx" ON public."AiRecommendation" USING btree ("pharmacyId", "createdAt");


--
-- Name: AuditLog_pharmacyId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "AuditLog_pharmacyId_createdAt_idx" ON public."AuditLog" USING btree ("pharmacyId", "createdAt");


--
-- Name: Expense_pharmacyId_spentAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Expense_pharmacyId_spentAt_idx" ON public."Expense" USING btree ("pharmacyId", "spentAt");


--
-- Name: GuardSchedule_city_startsAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "GuardSchedule_city_startsAt_idx" ON public."GuardSchedule" USING btree (city, "startsAt");


--
-- Name: Invoice_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Invoice_reference_key" ON public."Invoice" USING btree (reference);


--
-- Name: Patient_pharmacyId_fullName_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Patient_pharmacyId_fullName_idx" ON public."Patient" USING btree ("pharmacyId", "fullName");


--
-- Name: Permission_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Permission_code_key" ON public."Permission" USING btree (code);


--
-- Name: PharmacyMember_userId_pharmacyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PharmacyMember_userId_pharmacyId_key" ON public."PharmacyMember" USING btree ("userId", "pharmacyId");


--
-- Name: Pharmacy_city_country_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Pharmacy_city_country_idx" ON public."Pharmacy" USING btree (city, country);


--
-- Name: ProductBatch_productId_expiryDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ProductBatch_productId_expiryDate_idx" ON public."ProductBatch" USING btree ("productId", "expiryDate");


--
-- Name: Product_pharmacyId_barcode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Product_pharmacyId_barcode_key" ON public."Product" USING btree ("pharmacyId", barcode);


--
-- Name: Product_pharmacyId_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Product_pharmacyId_name_idx" ON public."Product" USING btree ("pharmacyId", name);


--
-- Name: PurchaseOrder_pharmacyId_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PurchaseOrder_pharmacyId_reference_key" ON public."PurchaseOrder" USING btree ("pharmacyId", reference);


--
-- Name: Reservation_pharmacyId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Reservation_pharmacyId_status_idx" ON public."Reservation" USING btree ("pharmacyId", status);


--
-- Name: Reservation_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Reservation_reference_key" ON public."Reservation" USING btree (reference);


--
-- Name: Role_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Role_name_key" ON public."Role" USING btree (name);


--
-- Name: Sale_offlineUuid_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Sale_offlineUuid_key" ON public."Sale" USING btree ("offlineUuid");


--
-- Name: Sale_pharmacyId_reference_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Sale_pharmacyId_reference_key" ON public."Sale" USING btree ("pharmacyId", reference);


--
-- Name: Sale_pharmacyId_soldAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Sale_pharmacyId_soldAt_idx" ON public."Sale" USING btree ("pharmacyId", "soldAt");


--
-- Name: StockMovement_pharmacyId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "StockMovement_pharmacyId_createdAt_idx" ON public."StockMovement" USING btree ("pharmacyId", "createdAt");


--
-- Name: Subscription_pharmacyId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Subscription_pharmacyId_key" ON public."Subscription" USING btree ("pharmacyId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: WhatsappConversation_pharmacyId_lastMessageAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "WhatsappConversation_pharmacyId_lastMessageAt_idx" ON public."WhatsappConversation" USING btree ("pharmacyId", "lastMessageAt");


--
-- Name: _PermissionToRole_AB_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "_PermissionToRole_AB_unique" ON public."_PermissionToRole" USING btree ("A", "B");


--
-- Name: _PermissionToRole_B_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "_PermissionToRole_B_index" ON public."_PermissionToRole" USING btree ("B");


--
-- Name: AiRecommendation AiRecommendation_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiRecommendation"
    ADD CONSTRAINT "AiRecommendation_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AuditLog AuditLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AuditLog"
    ADD CONSTRAINT "AuditLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Expense Expense_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Expense"
    ADD CONSTRAINT "Expense_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GuardSchedule GuardSchedule_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."GuardSchedule"
    ADD CONSTRAINT "GuardSchedule_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public."Subscription"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Patient Patient_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Patient"
    ADD CONSTRAINT "Patient_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Payment Payment_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public."Sale"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PharmacyMember PharmacyMember_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PharmacyMember"
    ADD CONSTRAINT "PharmacyMember_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PharmacyMember PharmacyMember_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PharmacyMember"
    ADD CONSTRAINT "PharmacyMember_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PharmacyMember PharmacyMember_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PharmacyMember"
    ADD CONSTRAINT "PharmacyMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PrescriptionItem PrescriptionItem_prescriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PrescriptionItem"
    ADD CONSTRAINT "PrescriptionItem_prescriptionId_fkey" FOREIGN KEY ("prescriptionId") REFERENCES public."Prescription"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prescription Prescription_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Prescription Prescription_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Prescription"
    ADD CONSTRAINT "Prescription_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ProductBatch ProductBatch_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ProductBatch"
    ADD CONSTRAINT "ProductBatch_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Product Product_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Product Product_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Product"
    ADD CONSTRAINT "Product_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PurchaseOrderItem PurchaseOrderItem_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrderItem"
    ADD CONSTRAINT "PurchaseOrderItem_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public."PurchaseOrder"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchaseOrder PurchaseOrder_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrder"
    ADD CONSTRAINT "PurchaseOrder_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchaseOrder PurchaseOrder_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseOrder"
    ADD CONSTRAINT "PurchaseOrder_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public."Supplier"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reservation Reservation_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reservation"
    ADD CONSTRAINT "Reservation_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."WhatsappConversation"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Reservation Reservation_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reservation"
    ADD CONSTRAINT "Reservation_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SaleItem SaleItem_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SaleItem SaleItem_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SaleItem"
    ADD CONSTRAINT "SaleItem_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public."Sale"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Sale Sale_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Sale Sale_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Sale Sale_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Sale"
    ADD CONSTRAINT "Sale_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StockMovement StockMovement_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StockMovement StockMovement_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."StockMovement"
    ADD CONSTRAINT "StockMovement_productId_fkey" FOREIGN KEY ("productId") REFERENCES public."Product"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Subscription Subscription_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Supplier Supplier_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Supplier"
    ADD CONSTRAINT "Supplier_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TreatmentReminder TreatmentReminder_patientId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TreatmentReminder"
    ADD CONSTRAINT "TreatmentReminder_patientId_fkey" FOREIGN KEY ("patientId") REFERENCES public."Patient"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WhatsappConversation WhatsappConversation_pharmacyId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WhatsappConversation"
    ADD CONSTRAINT "WhatsappConversation_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES public."Pharmacy"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: WhatsappMessage WhatsappMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."WhatsappMessage"
    ADD CONSTRAINT "WhatsappMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."WhatsappConversation"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PermissionToRole _PermissionToRole_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_PermissionToRole"
    ADD CONSTRAINT "_PermissionToRole_A_fkey" FOREIGN KEY ("A") REFERENCES public."Permission"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _PermissionToRole _PermissionToRole_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."_PermissionToRole"
    ADD CONSTRAINT "_PermissionToRole_B_fkey" FOREIGN KEY ("B") REFERENCES public."Role"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Q9LUETWUf9XJco2gLNsIWqLlpImCiEeJXlFUboPhUqnE0yuVb9AYx6mBwcatfjh

