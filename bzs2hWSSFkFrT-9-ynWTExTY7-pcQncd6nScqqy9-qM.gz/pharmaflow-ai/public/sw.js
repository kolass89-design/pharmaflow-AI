/**
 * Service worker PharmaFlow AI.
 *
 * Objectif : le comptoir reste opérationnel quand le réseau tombe.
 * Deux stratégies distinctes selon la nature de la ressource :
 *  - assets immuables (/_next/static) → cache d'abord, ils ne changent jamais
 *  - pages et données                 → réseau d'abord, cache en filet de sécurité
 *
 * Les mutations (POST/PUT/DELETE) ne sont JAMAIS interceptées : elles passent
 * par la file IndexedDB gérée dans lib/offline.ts, qui garantit l'idempotence.
 */

const VERSION = "v2";
const CACHE_SHELL = `pharmaflow-shell-${VERSION}`;
const CACHE_PAGES = `pharmaflow-pages-${VERSION}`;
const CACHE_ASSETS = `pharmaflow-assets-${VERSION}`;

const SHELL = [
  "/dashboard",
  "/dashboard/ventes",
  "/dashboard/stock",
  "/dashboard/synchronisation",
  "/manifest.webmanifest",
  "/icon-192.png",
  "/icon-512.png",
  "/hors-ligne",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_SHELL)
      // addAll échoue en bloc si une seule URL manque : on tolère les absences.
      .then((c) => Promise.allSettled(SHELL.map((u) => c.add(u))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  const garder = [CACHE_SHELL, CACHE_PAGES, CACHE_ASSETS];
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => !garder.includes(k)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Permet à la page de forcer l'activation d'une nouvelle version.
self.addEventListener("message", (e) => {
  if (e.data === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;                     // mutations → file IndexedDB

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;      // ressources tierces : non gérées

  // 1. Assets versionnés : immuables, cache d'abord.
  if (url.pathname.startsWith("/_next/static") || /\.(png|svg|ico|woff2?)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then((hit) =>
        hit || fetch(req).then((res) => {
          if (res.ok) { const copy = res.clone(); caches.open(CACHE_ASSETS).then((c) => c.put(req, copy)); }
          return res;
        })
      )
    );
    return;
  }

  // 2. API : réseau uniquement. Servir une réponse périmée fausserait un stock ou un chiffre d'affaires.
  if (url.pathname.startsWith("/api/")) return;

  // 3. Pages : réseau d'abord, cache en repli, page dédiée en dernier recours.
  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE_PAGES).then((c) => c.put(req, copy)); }
        return res;
      })
      .catch(() =>
        caches.match(req).then((hit) =>
          hit || caches.match("/dashboard").then((d) => d || caches.match("/hors-ligne"))
        )
      )
  );
});

// Synchronisation en arrière-plan : la page prend le relais dès qu'elle est ouverte.
self.addEventListener("sync", (e) => {
  if (e.tag === "pharmaflow-sync") {
    e.waitUntil(
      self.clients.matchAll({ includeUncontrolled: true }).then((clients) =>
        clients.forEach((c) => c.postMessage({ type: "FLUSH_QUEUE" }))
      )
    );
  }
});
