# Déployer gratuitement — guide pas à pas

Objectif : PharmaFlow AI en ligne, accessible depuis n'importe quel téléphone,
**sans payer**. Comptez 30 à 45 minutes.

---

## Recommandation : Vercel + Neon

| Service | Rôle | Offre gratuite | Limite réelle |
|---|---|---|---|
| **Neon** | PostgreSQL | 0,5 Go, 1 projet | Se met en veille après 5 min d'inactivité — première requête ~2 s |
| **Vercel** | Application | 100 Go de trafic/mois | Fonctions limitées à 10 s (nos routes tiennent largement) |
| **Upstash** | Rate limiting | 10 000 requêtes/jour | Optionnel mais recommandé |

0,5 Go suffit largement : la base de démonstration avec 638 ventes pèse **moins de 5 Mo**.

---

## Étape 1 — La base de données (Neon)

1. Créez un compte sur **https://neon.tech** (connexion GitHub possible).
2. « Create project » → nom `pharmaflow`, région **Europe (Frankfurt)** — la plus proche de l'Afrique de l'Ouest.
3. Copiez la chaîne de connexion affichée. Elle ressemble à :
   ```
   postgresql://user:motdepasse@ep-xxx.eu-central-1.aws.neon.tech/neondb?sslmode=require
   ```

### Charger les données de démonstration (optionnel mais conseillé)

Depuis votre ordinateur, avec `psql` installé :

```bash
psql "VOTRE_CHAINE_NEON" -f deploiement/base-demonstration.sql
```

Vous obtenez 2 officines, 14 produits, 638 ventes sur 60 jours, patients,
ordonnances et conversations — de quoi montrer le produit immédiatement.

> **Sans `psql` ?** Sautez cette étape : les migrations créeront les tables au
> déploiement, et vous pourrez lancer `npm run db:seed` en local pointé sur Neon.

---

## Étape 2 — Générer vos secrets

Sur votre ordinateur :

```bash
node -e "console.log('SESSION_SECRET =', require('crypto').randomBytes(32).toString('base64url'))"
node -e "console.log('ENCRYPTION_KEY =', require('crypto').randomBytes(32).toString('hex'))"
```

> ⚠️ **Conservez `ENCRYPTION_KEY` en lieu sûr** (gestionnaire de mots de passe).
> Elle chiffre les téléphones des patients. Perdue, ces données sont
> définitivement illisibles — aucune récupération possible.

---

## Étape 3 — Publier le code sur GitHub

```bash
cd pharmaflow-ai
git init
git add .
git commit -m "PharmaFlow AI"
```

Créez un dépôt **privé** sur https://github.com/new, puis :

```bash
git remote add origin https://github.com/VOTRE-COMPTE/pharmaflow-ai.git
git branch -M main
git push -u origin main
```

Le `.gitignore` exclut déjà `.env`, `node_modules` et les sauvegardes.
**Vérifiez qu'aucun `.env` n'est parti** : `git ls-files | grep env` ne doit
renvoyer que `.env.example`.

---

## Étape 4 — Déployer sur Vercel

1. **https://vercel.com** → « Add New » → « Project » → importez votre dépôt.
2. Vercel détecte Next.js automatiquement. **Ne touchez pas** aux commandes :
   `vercel.json` s'en charge (génération Prisma + migrations + build).
3. Dans **Environment Variables**, ajoutez :

| Nom | Valeur |
|---|---|
| `DATABASE_URL` | la chaîne Neon, avec `?sslmode=require` |
| `SESSION_SECRET` | celui généré à l'étape 2 |
| `ENCRYPTION_KEY` | celui généré à l'étape 2 |
| `NEXT_PUBLIC_APP_URL` | `https://votre-projet.vercel.app` |
| `CRON_SECRET` | une chaîne aléatoire de votre choix |
| `WHATSAPP_VERIFY_TOKEN` | `pharmaflow-dev` (à changer plus tard) |

4. « Deploy ». Le premier build prend 2 à 3 minutes.

### Vérifier

- `https://votre-projet.vercel.app` → le site public s'affiche
- `https://votre-projet.vercel.app/api/health` → `"status": "ok"` ou `"degraded"`
- Connexion : `demo@pharmaflow.ai` / `demo1234`

> `degraded` signifie simplement que Redis n'est pas configuré. L'application
> fonctionne ; voir l'étape 5.

---

## Étape 5 — Rate limiting (5 minutes, recommandé)

Sans Redis, la limitation de débit vit en mémoire — inopérante sur Vercel, où
chaque requête peut atterrir sur une instance différente. Votre page de
connexion serait alors exposée aux attaques par force brute.

1. **https://upstash.com** → « Create Database » → Redis, région Frankfurt.
2. Onglet « REST API », copiez `UPSTASH_REDIS_REST_URL` et `UPSTASH_REDIS_REST_TOKEN`.
3. Ajoutez-les dans Vercel → Settings → Environment Variables → **Redeploy**.

`/api/health` doit alors afficher `"status": "ok"`.

---

## Alternative : tout sur votre propre serveur (Docker)

Si vous disposez d'un VPS (à partir de ~5 €/mois chez Hetzner, Contabo, Ikoula) :

```bash
# Sur le serveur
git clone https://github.com/VOTRE-COMPTE/pharmaflow-ai.git
cd pharmaflow-ai
cp .env.example .env
nano .env      # renseignez DB_PASSWORD, SESSION_SECRET, ENCRYPTION_KEY

docker compose up -d --build
docker compose exec app npx prisma migrate deploy
docker compose exec app npm run db:seed    # données de démonstration
```

L'application écoute sur le port 3000. Placez un Caddy ou Nginx devant pour le
HTTPS. La base n'expose aucun port vers l'extérieur — elle n'est joignable que
par le conteneur applicatif.

**Avantage** : données hébergées chez vous, pas de mise en veille, pas de limite
de trafic. **Inconvénient** : les sauvegardes et les mises à jour vous incombent.

---

## Après le déploiement

```bash
npm run preflight -- https://votre-projet.vercel.app
```

Ce contrôle vous dira ce qui manque encore. Il **bloque** si vos secrets
ressemblent à des valeurs d'exemple — c'est voulu.

### Ce qui reste inactif tant que vous n'avez pas fait les démarches

| Fonction | Démarche |
|---|---|
| Envoi WhatsApp | Validation du numéro par Meta (quelques jours) |
| Débit Mobile Money | Contrat avec un agrégateur régional |
| Emails | Compte Resend ou SMTP |

L'interface signale explicitement ces limites à l'utilisateur : un caissier qui
encaisse en Mobile Money voit *« Paiement NON débité par la plateforme »*.
Lisez `docs/ETAT-DE-LIVRAISON.md` avant toute promesse commerciale.

---

## Coût réel

| Poste | Gratuit | Quand payer |
|---|---|---|
| Neon | 0,5 Go | Au-delà de ~50 000 ventes |
| Vercel | 100 Go/mois | Trafic important |
| Upstash | 10 000 req/jour | Plusieurs officines actives |
| **Total pilote** | **0 €** | — |

Une officine seule tient confortablement dans les offres gratuites. Prévoyez
environ 25 €/mois à partir de cinq officines actives.

---

## Problèmes fréquents

| Symptôme | Cause | Solution |
|---|---|---|
| `@prisma/client did not initialize` | `postinstall` manquant | Déjà corrigé dans `package.json` |
| `Can't reach database server` | `sslmode=require` absent | Ajoutez-le à `DATABASE_URL` |
| Première requête très lente | Neon en veille | Normal en offre gratuite (~2 s) |
| `/api/health` renvoie `degraded` | Redis absent | Étape 5, ou ignorez en pilote |
| Build échoue en mémoire | Machine limitée | Utilisez `npm run build:lowmem` |
| Connexion refusée | Base vide | `npx prisma migrate deploy && npm run db:seed` |
