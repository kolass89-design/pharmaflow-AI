# Espace patient

Livrable n°13 du cahier des charges : rechercher un médicament, comparer les
officines, réserver, suivre. **Public, sans compte, gratuit.**

| Page | Rôle |
|---|---|
| `/trouver-un-medicament` | Recherche, comparaison, réservation |
| `/ma-reservation` | Suivi par référence |
| `/pharmacies-de-garde` | Calendrier de garde (déjà livré) |

## Décisions de conception

### La quantité exacte en stock n'est jamais publiée
Trois paliers seulement : **en stock**, **stock limité**, **épuisé**.

Un stock chiffré est une information commerciale sensible (les concurrents lisent
la même page) et facilite le repérage de produits détournables. Trois paliers
suffisent pour décider de se déplacer. Le prix d'achat et la marge ne sortent
évidemment jamais non plus.

### Une réservation ne décrémente pas le stock
C'est le choix le plus important. Si elle le faisait, n'importe qui pourrait vider
le stock affiché d'une officine depuis son téléphone, sans jamais se déplacer.

Le pharmacien met le produit de côté physiquement ; la vente reste encaissée au
comptoir par le circuit normal. La réservation est un **engagement de service**,
pas une transaction.

Garde-fous : validité 2 heures, 5 unités maximum, 5 réservations par heure et par
IP, et un contrôle que le cumul des réservations actives ne dépasse pas le stock réel.

### Les médicaments sous ordonnance ne sont pas réservables
`Product.requiresPrescription` les signale dans la recherche et l'API refuse la
réservation avec un message explicite. La délivrance exige un contrôle du
pharmacien qu'aucun formulaire web ne remplace.

### Recherche sans accent
Sur un clavier de téléphone, personne ne tape « Paracétamol ». L'extension
PostgreSQL `unaccent` normalise des deux côtés — avec repli automatique si
l'extension est absente. La recherche porte aussi sur la **DCI** : « artemether »
trouve « Coartem ».

### La référence tient lieu de secret
Format `R-ABCD1234`, **sans I ni O** — ces lettres se confondent avec 1 et 0 quand
on dicte au téléphone. Le suivi ne renvoie donc **aucune donnée personnelle** :
quiconque devinerait une référence n'apprendrait rien sur le réservataire.

Le téléphone du patient est chiffré en base (AES-256), comme les données patients.

## Côté pharmacien

Panneau « Réservations patients » dans le module WhatsApp : file des demandes
web et WhatsApp, minutes restantes, boutons *Retirée* / *Annuler*. Une réservation
déjà clôturée ne peut pas l'être deux fois (409), et une officine ne peut pas
toucher aux réservations d'une autre (404).

## Modèle de données

```prisma
Product.requiresPrescription  Boolean  // non réservable en ligne
Product.isPublic              Boolean  // visible dans la recherche patient

Reservation.source            "WEB" | "WHATSAPP"
Reservation.customerName      String?
Reservation.customerPhoneEnc  String?  // chiffré AES-256
Reservation.productLabel      String?  // libellé figé à la réservation
Reservation.unitPrice         Int?     // prix figé : il peut changer ensuite
```

Le libellé et le prix sont **figés au moment de la réservation** : si l'officine
modifie sa fiche produit entre-temps, le patient garde ce qui lui a été annoncé.

## API publiques

| Route | Limite | Notes |
|---|---|---|
| `GET /api/public/recherche` | 30/min par IP | `q`, `ville`, `lat`/`lon` |
| `GET /api/public/pharmacies` | — | Annuaire, cache 5 min |
| `POST /api/public/reservations` | 5/h par IP | Quota consommé **après** validation |
| `GET /api/public/reservations/[ref]` | — | Aucune donnée personnelle |
| `PATCH /api/reservations/[id]` | authentifié | `COLLECTED` / `CANCELLED` |

Détail : le quota de réservation est vérifié **après** la validation du formulaire.
Une faute de frappe ne doit pas priver le patient d'une de ses cinq réservations horaires.

## Couverture de tests

`tests/integration/patient.test.mjs` — 30 tests, dont :

- recherche sans accent, par DCI, comparaison entre officines ;
- **aucune fuite** : `stock`, `quantity`, `batches`, `purchasePrice` absents des réponses ;
- réservation refusée sur ordonnance, téléphone chiffré, stock intact ;
- suivi sans donnée personnelle, expiration signalée ;
- circuit complet : réservation → visible par l'officine → clôture → état vu par le patient ;
- cloisonnement : une officine ne clôture pas les réservations d'une autre.

**Total du projet : 96 unitaires + 79 intégration + test terrain.**
