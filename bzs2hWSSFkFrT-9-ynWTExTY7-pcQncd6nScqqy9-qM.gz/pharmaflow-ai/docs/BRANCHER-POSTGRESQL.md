# Brancher PostgreSQL et remplacer les données mockées

Guide de la migration **mock → base réelle**, telle qu'elle a été réalisée sur ce projet.
Chaque étape est reproductible en local comme en production.

---

## Vue d'ensemble : la méthode en 6 étapes

```
1. Faire tourner un PostgreSQL          → local (apt) ou managé (Neon/Railway/Supabase)
2. Connecter Prisma                     → DATABASE_URL + prisma db push
3. Remplir la base                      → script de seed avec des données réalistes
4. Créer une couche d'accès unique      → lib/queries.ts (jamais de Prisma dans un composant)
5. Convertir les pages une par une      → "use client" mocké → composant serveur async
6. Rendre les écritures réelles         → transactions, FEFO, idempotence, audit
```

Règle d'or : **on convertit un module à la fois, on teste, puis on passe au suivant.**
Le reste de l'application continue de fonctionner sur les mocks pendant la transition.

---

## Étape 1 — Faire tourner PostgreSQL

### Option A : local (ce qui a été fait ici)
```bash
sudo apt-get update && sudo apt-get install -y postgresql postgresql-contrib
sudo pg_ctlcluster 17 main start
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'pharmaflow';"
sudo -u postgres psql -c "CREATE DATABASE pharmaflow OWNER postgres;"
psql "postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow" -c "select version();"
```

### Option B : managé (recommandé en production)
Créez une instance chez **Neon**, **Railway** ou **Supabase**, région Europe de l'Ouest
(meilleure latence vers l'Afrique de l'Ouest), puis copiez la chaîne fournie.
Elle ressemble à `postgresql://user:pass@host/db?sslmode=require`.

---

## Étape 2 — Connecter Prisma

```bash
npm install @prisma/client
```

`.env` :
```
DATABASE_URL="postgresql://postgres:pharmaflow@127.0.0.1:5432/pharmaflow?schema=public"
```

> **Piège rencontré** : Prisma refuse la syntaxe compacte sur une ligne.
> `datasource db { provider = "postgresql"; url = env("DATABASE_URL") }` échoue avec 101 erreurs.
> Chaque bloc `generator`, `datasource` et `enum` doit être écrit sur plusieurs lignes.

Créer les tables et le client :
```bash
npx prisma validate          # toujours valider avant de pousser
npx prisma db push           # crée les 27 tables (dev)
npx prisma generate          # génère le client typé
```

En production, préférez les migrations versionnées :
```bash
npx prisma migrate dev --name init      # développement
npx prisma migrate deploy               # CI/CD et production
```

### Le singleton Prisma (`lib/db.ts`) — indispensable
En développement, Next.js recharge les modules à chaque édition. Sans cache global,
chaque rechargement ouvre un nouveau pool et PostgreSQL finit par répondre
« too many clients already ».

```ts
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
export const prisma = globalForPrisma.prisma ?? new PrismaClient();
if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
```

---

## Étape 3 — Remplir la base (`prisma/seed.ts`)

Le seed n'est pas un détail : c'est ce qui rend le développement crédible.
Ici il crée une officine complète de Cotonou :

| Données | Volume |
|---|---|
| Permissions / rôles | 19 permissions, 5 rôles avec matrice réelle |
| Équipe | 5 utilisateurs (titulaire, pharmacien, préparateur, caissier, comptable) |
| Catalogue | 10 produits avec DCI, codes-barres, lots et péremptions |
| **Ventes** | **643 ventes / 1 324 lignes sur 60 jours** |
| Reste | patients, ordonnances, fournisseurs, commandes, dépenses, WhatsApp, IA, audit |

```bash
npm run db:seed
```

Points de méthode :
- **Générer un historique long** (60 jours) : sans lui, aucun graphique ni prévision n'a de sens.
- **Faire varier le réalisme** : moins de ventes le dimanche, moyens de paiement aléatoires.
- **Montants en entiers** : le FCFA n'a pas de décimale, jamais de `float` sur de l'argent.
- **Nettoyer avant d'insérer** : le seed est rejouable à volonté.

---

## Étape 4 — Une couche d'accès unique (`lib/queries.ts`)

Toutes les lectures passent par ce fichier. Aucun composant n'appelle Prisma directement.

Trois raisons :
1. **Sécurité** — le filtre `pharmacyId` est appliqué à un seul endroit. Impossible de l'oublier.
2. **Performance** — les agrégations lourdes sont faites en SQL, pas en JavaScript.
3. **Testabilité** — la logique métier est isolée de l'affichage.

Exemple d'agrégation en SQL plutôt qu'en 7 requêtes :
```ts
const weekRows = await prisma.$queryRaw`
  SELECT date_trunc('day', "soldAt") AS day, SUM(total)::bigint AS total
  FROM "Sale"
  WHERE "pharmacyId" = ${pharmacyId} AND "soldAt" >= ${daysAgo(6)}
  GROUP BY 1 ORDER BY 1 ASC`;
```

> `$queryRaw` avec interpolation `${}` est **paramétré** : aucun risque d'injection SQL.
> Ne jamais construire la requête par concaténation de chaînes.

Le marqueur `import "server-only"` en tête du fichier fait échouer la compilation
si un composant client tente de l'importer — garde-fou contre la fuite de données.

---

## Étape 5 — Convertir les pages, une par une

C'est le cœur de la manœuvre. Le patron est toujours le même.

### Avant (mocké)
```tsx
"use client";
import { products } from "@/lib/mock";

export default function Page() {
  const [q, setQ] = useState("");
  return <table>{products.filter(...)}</table>;
}
```

### Après (données réelles)
On **coupe la page en deux** :

**a) La page = composant serveur async** — elle lit la base :
```tsx
import { getSession } from "@/lib/auth";
import { getStock } from "@/lib/queries";

export const dynamic = "force-dynamic";   // pas de cache : le stock change en continu

export default async function Page() {
  const s = getSession();
  if (!s) redirect("/connexion");
  const rows = await getStock(s.pharmacyId);
  return <StockTable rows={rows} />;
}
```

**b) Le composant client** — il ne garde que l'interactivité (recherche, filtres) et
reçoit les données en props :
```tsx
"use client";
export default function StockTable({ rows }: { rows: Row[] }) {
  const [q, setQ] = useState("");
  return <table>{rows.filter(...)}</table>;
}
```

### Pourquoi ce découpage
- Le HTML arrive déjà rempli : pas de spinner, pas d'aller-retour réseau.
- Les identifiants de base de données ne transitent jamais par le navigateur.
- Recharts reste dans un composant client (`components/dashboard/Charts.tsx`)
  car il a besoin du DOM.

### Ordre de conversion suivi
| # | Module | Ce qui change |
|---|---|---|
| 1 | Authentification | Vérification `scrypt` contre `User`, audit `LOGIN_SUCCESS` |
| 2 | Tableau de bord | KPI, série 7 jours, alertes calculés en SQL |
| 3 | Stock | Stock = somme des lots, marge calculée, mouvements réels |
| 4 | **Caisse** | Écriture transactionnelle (voir étape 6) |
| 5 | Ordonnances, patients, fournisseurs | Lectures avec relations |
| 6 | Comptabilité | Agrégation mensuelle SQL, répartition des paiements |
| 7 | IA | Prévision et rentabilité calculées sur l'historique réel |
| 8 | WhatsApp, paramètres | Conversations, équipe, audit, abonnement |
| 9 | Pharmacies de garde (public) | Lecture publique + repli sur mock si la base tombe |

Le fichier `lib/mock.ts` **reste utile** : il alimente encore le site vitrine
(démo interactive, témoignages, articles) et sert de repli.

---

## Étape 6 — Les écritures : là où tout se joue

Une lecture ratée affiche un mauvais chiffre. Une écriture ratée **casse le stock**.
`POST /api/sales` illustre les quatre garanties à respecter.

### 1. Transaction atomique
Vente + lignes + paiement + décrément des lots + mouvements + audit :
tout réussit ou rien n'est écrit.
```ts
const sale = await prisma.$transaction(async (tx) => { /* … */ });
```

### 2. Décrément FEFO
On puise d'abord dans le lot qui expire le plus tôt — la règle métier de toute officine :
```ts
for (const b of p.batches) {          // triés par expiryDate asc
  const pris = Math.min(b.quantity, reste);
  await tx.productBatch.update({ where: { id: b.id }, data: { quantity: { decrement: pris } } });
  reste -= pris;
}
```

### 3. Idempotence (indispensable pour le mode hors ligne)
Le client génère un `offlineUuid`. La colonne est `@unique` en base.
Si la requête est rejouée après une coupure réseau, la vente n'est pas dupliquée :
```ts
const existing = await prisma.sale.findUnique({ where: { offlineUuid } });
if (existing) return NextResponse.json({ ok: true, duplicate: true, sale: existing });
```

### 4. Erreurs métier explicites
Un stock insuffisant renvoie `409` avec un message lisible par le préparateur,
pas une erreur 500 opaque.

### Rafraîchir l'affichage après écriture
Côté client, après une vente réussie :
```ts
router.refresh();   // Next.js rejoue les composants serveur → KPI et stock à jour
```

---

## Vérification de bout en bout

Tests réellement passés sur ce projet :

```bash
# Connexion
curl -c c.txt -X POST localhost:3000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"demo@pharmaflow.ai","password":"demo1234"}'
# → {"ok":true}   ·   mauvais mot de passe → 401

# Vente de 3 unités avec 10 % de remise
curl -b c.txt -X POST localhost:3000/api/sales \
  -H 'Content-Type: application/json' \
  -d '{"items":[{"productId":"...","quantity":3}],"method":"MTN_MOMO","discountPercent":10,"offlineUuid":"..."}'
# → ref TK-89644 | sous-total 7500 | remise 750 | total 6750
```

| Vérification | Résultat |
|---|---|
| Stock avant → après | 126 → **123** |
| Mouvement créé | `OUT -3 (Vente comptoir)` |
| Rejeu du même `offlineUuid` | `duplicate = true`, stock inchangé |
| Vente de 99 999 unités | `409 — Stock insuffisant pour Amoxicilline 500 mg (123 restant)` |
| Appel sans session | `401` |
| Inscription d'une nouvelle officine | `201`, pharmacie + titulaire créés |
| Email déjà utilisé | `409` |
| 20 pages (10 dashboard + 10 publiques) | toutes `200` |

Assistant IA interrogé sur les données réelles :
> « Vos 5 produits les plus rentables ont généré **1 088 650 FCFA** de marge :
> 1. Amoxicilline 500 mg — 325 800 FCFA (362 unités)… »

---

## Commandes utiles

```bash
npm run db:push        # applique le schéma (dev)
npm run db:seed        # (re)remplit la base
npm run db:studio      # explorateur visuel des tables
npx prisma migrate dev --name ma_modification   # migration versionnée
```

Inspecter directement :
```bash
psql "$DATABASE_URL" -c '\dt'                          # lister les tables
psql "$DATABASE_URL" -c 'select count(*) from "Sale";' # compter les ventes
```

---

## Pièges à connaître

| Piège | Conséquence | Solution |
|---|---|---|
| `PrismaClient` instancié dans chaque fichier | « too many clients already » | Singleton `lib/db.ts` |
| Prisma importé dans un composant `"use client"` | Erreur de build | `import "server-only"` dans `queries.ts` |
| Oubli du filtre `pharmacyId` | **Fuite de données entre pharmacies** | Tout passe par `lib/queries.ts` |
| Page dashboard mise en cache | Chiffres figés | `export const dynamic = "force-dynamic"` |
| `bigint` renvoyé par `$queryRaw` | Erreur de sérialisation JSON | `Number(r.total)` |
| Montants en `float` | Erreurs d'arrondi sur l'argent | Entiers (le FCFA n'a pas de décimale) |
| Décrément de stock hors transaction | Stock incohérent si erreur | `prisma.$transaction` |
| Pas d'`offlineUuid` | Ventes dupliquées à la resynchronisation | Colonne `@unique` + contrôle préalable |

---

## Ce qui reste à faire

- [ ] Écritures pour stock (création produit, réception, inventaire), patients et ordonnances — même patron que `/api/sales`
- [ ] Import Excel du catalogue existant
- [ ] File IndexedDB côté navigateur pour alimenter `/api/sync` (l'API est prête)
- [ ] Rate limiting sur Redis (Upstash) plutôt qu'en mémoire du processus
- [ ] Chiffrement effectif du champ `phoneEnc` des patients (AES-256-GCM)
- [ ] Migrations versionnées `prisma migrate` au lieu de `db push`
- [ ] Sauvegardes automatiques + test de restauration documenté

---

# Partie 2 — Les écritures des modules restants

Suite de la migration : après les lectures, toutes les **mutations** sont désormais réelles.

## Le socle partagé (`lib/api.ts`)

Répéter la validation et le contrôle de permission dans chaque route est la garantie
d'en oublier une. Tout passe donc par un socle commun :

```ts
export async function POST(req: Request) {
  return handle(async () => {
    const s = requirePermission("stock.write");     // 401 / 403 automatiques
    const name = str(b.name, "Nom du produit", { min: 2 });   // 422 + message en français
    // …
    await audit(s, "PRODUCT_CREATE", "Product", product.id);
    return { product };
  });
}
```

- `handle()` traduit les exceptions en réponses HTTP propres, y compris les codes Prisma
  (`P2002` doublon → 409, `P2025` introuvable → 404). Aucune trace technique n'atteint le client.
- `requirePermission()` centralise le RBAC.
- `str/int/date/oneOf` valident **et** typent (surcharges TypeScript : `optional: true` renvoie `| null`).
- `assertOwnership()` bloque les attaques IDOR : impossible de lire ou modifier une ressource
  d'une autre officine, même en devinant son identifiant.
- `audit()` trace sans jamais faire échouer la requête métier.

## Routes créées

| Route | Méthode | Règles métier appliquées |
|---|---|---|
| `/api/products` | POST | Prix de vente ≥ prix d'achat, lot initial optionnel avec péremption obligatoire |
| `/api/products/[id]` | PATCH / DELETE | Suppression **logique** si le produit a un historique de ventes |
| `/api/stock/receive` | POST | Cumul si le lot existe déjà, refus d'un lot déjà périmé, mise à jour du bon de commande (partielle/totale) |
| `/api/stock/adjust` | POST | Motif obligatoire, retrait FEFO, refus si stock insuffisant |
| `/api/patients` | GET/POST | Téléphone **chiffré** à l'écriture, **masqué** en liste |
| `/api/patients/[id]` | GET/PATCH | Déchiffrement + journalisation `PATIENT_VIEW` à chaque consultation |
| `/api/prescriptions` | POST | **Croisement automatique avec les allergies du patient** |
| `/api/prescriptions/[id]` | PATCH | Changement de statut |
| `/api/suppliers` | GET/POST | — |
| `/api/purchase-orders` | POST | Mode `auto` : génère les bons depuis les alertes de stock, groupés par fournisseur |
| `/api/expenses` | GET/POST | — |

## Chiffrement des données patients (`lib/crypto.ts`)

AES-256-GCM, format `v1:<iv>:<tag>:<données>`. Même si la base est exfiltrée,
les numéros restent illisibles sans `ENCRYPTION_KEY`.

Deux niveaux d'exposition volontaires :
- **liste** → `maskPhone()` : `+22997 •• •• 12`
- **fiche ouverte** → déchiffrement complet **et** entrée `PATIENT_VIEW` au journal d'audit

Le préfixe `v1:` permet une rotation de clé future sans casser les données existantes.

## Contrôle des allergies à la prescription

À la création d'une ordonnance, chaque ligne est croisée avec les allergies déclarées
du patient (libellé saisi + nom commercial + DCI du produit) :

```json
{ "prescription": { "lignes": 2 },
  "alertes": ["⚠️ Amoxicilline 500 mg — allergie déclarée : amoxicilline"] }
```

L'ordonnance est **enregistrée** et l'alerte affichée au pharmacien, qui reste décisionnaire :
un logiciel n'a pas à bloquer une décision thérapeutique, il doit informer.

## Interface : modales et rafraîchissement

`components/ui/Modal.tsx` (fermeture par Échap, plein écran sur mobile) sert de base à :
`StockActions` (produit / réception / inventaire), `PatientForm`, `PrescriptionForm`, `AutoOrderButton`.

Après chaque écriture réussie : `router.refresh()` — Next.js rejoue les composants serveur,
les KPI et les tableaux se mettent à jour sans rechargement de page.

## Tests de bout en bout passés

```
Création produit + lot        → stock 40
Réception 60 (nouveau lot)    → stock 100
Ajustement −7 (casse)         → stock 93
Mouvements tracés             → IN 40 / IN 60 / LOSS 7
```

| Cas d'erreur | Réponse |
|---|---|
| Prix de vente < prix d'achat | `422 — Le prix de vente ne peut pas être inférieur au prix d'achat.` |
| Nom de produit manquant | `422 — Le champ « Nom du produit » est requis.` |
| Lot déjà périmé | `422 — La date de péremption est déjà dépassée.` |
| Ajustement sans motif | `422 — Le champ « Motif » est requis.` |
| Retrait > stock | `409 — Stock insuffisant : 93 unité(s) disponible(s).` |
| Patient d'une autre officine | `404 — Cette ressource n'appartient pas à votre officine.` |
| Caissier crée un produit | `403 — Votre rôle ne permet pas cette action.` |
| Caissier lit la comptabilité | `403` |
| Caissier encaisse une vente | `201` ✓ |

Chiffrement vérifié en base :
```
v1:T2zSRYz0So71uf-C:nWc6oZjhD-SAJgoVojQo-w:Q0OCshNTuTJb
liste : +22997 •• •• 12      fiche : +229 97 45 88 12
```

Commande automatique depuis les alertes : `BC-1202` (2 lignes, 136 740 FCFA)
et `BC-1204` (1 ligne, 157 500 FCFA), groupées par fournisseur.

État final : **44 routes**, 20 pages en `200`, 646 ventes, 16 mouvements de stock,
journal d'audit alimenté par toutes les actions sensibles.

---

# Partie 3 — Mise en production

Les quatre chantiers restants, plus une remise à niveau de sécurité imposée par l'audit.

## 0. Sécurité des dépendances (préalable)

`npm audit` signalait **12 vulnérabilités**, dont Next.js en critique.

| Paquet | Décision |
|---|---|
| `xlsx` | **Retiré** — prototype pollution + ReDoS, aucun correctif |
| `exceljs` | **Retiré** — chaîne `archiver`/`glob`/`minimatch` vulnérable |
| `next` 14.2.5 → **15.5.22** | 21 CVE corrigées (cache poisoning, SSRF, XSS, DoS) |
| `eslint-config-next` | Retiré (dev-only, tirait 14 vulnérabilités) |
| `sharp`, `brace-expansion`, `minimatch`, `glob`, `postcss` | Épinglés via `overrides` |

Résultat : **0 vulnérabilité**.

> Compromis assumé : plutôt que d'importer 40 paquets transitifs pour lire un tableau,
> l'import repose sur un parseur CSV maison. Pour un logiciel qui manipule des données
> de santé, la surface d'attaque prime sur le confort du format binaire.

### Migration Next 15
Deux ruptures d'API à traiter : `params` et `cookies()` deviennent asynchrones.
```ts
// Avant                          // Après
{ params }: { params: { id } }    { params }: { params: Promise<{ id: string }> }
cookies().get("pf_session")       (await cookies()).get("pf_session")
```
`getSession()` et `requirePermission()` sont devenues `async` — 20 fichiers ajustés.

---

## 1. Import / export du catalogue

`lib/import.ts` — parseur sans dépendance, pensé pour de vrais fichiers d'officine :

- **séparateur détecté** (`;` `,` tab `|`) — l'Excel francophone exporte en `;`
- **BOM UTF-8** retiré (Excel l'ajoute systématiquement)
- **en-têtes tolérants** : `Désignation`, `Produit`, `Libellé`, `Article` → `name` (11 champs, ~60 synonymes)
- **montants** : `2 450,00`, `1.234,56`, `2500 FCFA` → entier
- **dates** : `31/12/2027`, `2027-12-31`, `09/2027` (fin de mois)
- **guillemets** gérés, y compris `""` échappés

Deux temps obligatoires :
```
POST /api/stock/import  (dryRun=true)  → prévisualisation + anomalies
POST /api/stock/import                 → application réelle
```
On n'écrase jamais un catalogue de plusieurs centaines de références sans que
le pharmacien ait vu le résultat.

Résultat sur un fichier volontairement dégradé (9 lignes) :
```
colonnes reconnues : 11/11
{"lignesLues":9,"valides":7,"aCreer":7,"anomalies":4,"valeurStock":535000}
  L7  doublon      « Doliprane » en double — première occurrence conservée
  L8  prix d'achat illisible : « »
  L9  péremption   lot déjà périmé (2020-01-01) — stock ignoré
  L10 prix         PV (1200) < PA (5000) — à vérifier
```

| Comportement | Vérifié |
|---|---|
| Import initial | 7 créés, 6 lots, fournisseur `PHARMAGROS` créé à la volée |
| Réimport `create` | 7 ignorés (aucun doublon) |
| Réimport `upsert` | 7 mis à jour |
| Export CSV | même format que l'import — corrigeable dans Excel puis réinjectable |

Traitement par paquets de 100 en transaction : 5 000 lignes d'un bloc bloqueraient la base.

## 2. File hors ligne (IndexedDB)

`lib/offline.ts` — API native, aucune dépendance.

```
Vente → navigator.onLine ?
         ├── oui → POST /api/sales                    → ticket immédiat
         │          └── échec réseau en cours → bascule en file
         └── non → enqueue() dans IndexedDB           → ticket remis au patient
                    puis rejeu auto (retour réseau + toutes les 30 s)
```

Trois décisions structurantes :

1. **Le catalogue est répliqué localement** (`cacheCatalog`) — sans lui, on ne peut pas
   vendre hors ligne, seulement mettre en file à l'aveugle.
2. **Les erreurs 4xx sont définitives.** Un `409 stock insuffisant` ne sera jamais résolu
   par un nouvel essai : l'opération passe en `failed` et remonte au pharmacien.
   Seuls réseau et 5xx restent `pending`.
3. **L'idempotence tient sur `offlineUuid`** (`@unique` en base) : un rejeu renvoie
   `duplicate: true` sans créer de seconde vente.

`SyncBadge` affiche en permanence l'état — *En ligne · synchronisé* / *N à synchroniser* /
*Hors ligne · N en attente* — et permet la synchronisation manuelle.

## 3. Rate limiting (Upstash Redis + repli mémoire)

Un compteur en RAM ne limite rien sur Vercel : chaque instance serverless a sa propre mémoire.
`lib/ratelimit.ts` utilise Redis (sorted set, fenêtre glissante) dès que les variables existent,
et **dégrade en mémoire** si Redis tombe — une officine ne doit pas s'arrêter parce que le cache est indisponible.

| Seau | Limite | Clé |
|---|---|---|
| `login` | 8 / min | **email + IP**, échecs uniquement |
| `register` | 5 / h | IP |
| `write` | 120 / min | **userId** |
| `import` | 5 / 5 min | userId |
| `ai` | 20 / min | userId |

Deux erreurs corrigées après test réel :

- **Le seau était indexé sur l'IP seule.** Une officine partage une connexion NAT :
  8 erreurs de frappe d'un préparateur bloquaient toute l'équipe. Le seau porte
  désormais sur le couple email+IP.
- **Les connexions réussies consommaient le quota.** `peek()` vérifie sans consommer,
  seul un échec incrémente, et `reset()` vide le seau après authentification.

```
essai 8 (mauvais mdp)  → 401
essai 9                → 429
login demo, même IP    → 200   ✓ l'officine n'est pas bloquée
```

## 4. Migrations versionnées

`db push` convient au prototypage, pas à la production : aucun historique, aucun rollback.

```bash
npm run db:migrate   # prisma migrate dev   — développement
npm run db:deploy    # prisma migrate deploy — CI/CD et production
npm run db:status    # état des migrations
```

Migration initiale générée (607 lignes SQL) et **validée par reconstruction complète
sur une base vierge** : 29 tables créées, seed rejoué, 650 ventes. C'est le seul test
qui prouve qu'un déploiement neuf fonctionnera.

## PWA

`manifest.webmanifest` + `sw.js` déclarés dans le layout, service worker enregistré
côté dashboard. L'application est installable sur l'écran d'accueil et démarre
directement sur `/dashboard`.

## État final

- **0 vulnérabilité** npm · Next 15.5.22
- 21 pages en `200`, 38 routes
- Caisse fonctionnelle sans réseau, synchronisation idempotente
- Import/export CSV bidirectionnel
- Rate limiting distribué, migrations versionnées

### Reste avant la vraie mise en service
- [ ] Provisionner Upstash Redis et renseigner les deux variables
- [ ] Icônes PWA `icon-192.png` / `icon-512.png`
- [ ] Écran de gestion des opérations `failed` (actuellement API seule)
- [ ] Rotation documentée de `ENCRYPTION_KEY` (le préfixe `v1:` la rend possible)
- [ ] Sauvegardes automatiques + test de restauration trimestriel
- [ ] Sentry (erreurs) et supervision de la file hors ligne

---

# Partie 4 — Finalisation

## Icônes et PWA

Icônes générées depuis un SVG maître (`public/icon.svg`) avec `cairosvg` :
`icon-192`, `icon-512`, `icon-maskable-512`, `apple-touch-icon`, `favicon-32`.

Deux points souvent négligés :
- **La variante `maskable`** a un fond bord à bord et un contenu réduit à 62 %.
  Sans elle, Android rogne le logo dans les icônes rondes.
- **Le premier rendu était raté** : l'onde dorée coupait la croix et le vert de marque
  disparaissait. Recomposé — croix remontée, onde descendue, dégradé rééquilibré.

Manifeste enrichi de **raccourcis** (appui long sur l'icône) : Caisse, Stock, Synchronisation.

## Service worker v2

La première version cachait tout de la même façon. Trois stratégies distinctes désormais :

| Ressource | Stratégie | Raison |
|---|---|---|
| `/_next/static`, images, polices | Cache d'abord | Versionnées, donc immuables |
| Pages | Réseau d'abord, cache en repli | Fraîcheur prioritaire, disponibilité garantie |
| `/api/*` | **Jamais de cache** | Un stock ou un CA périmé est pire que pas de donnée |
| POST/PUT/DELETE | Non interceptés | Passent par la file IndexedDB |

Page `/hors-ligne` dédiée en dernier recours, qui renvoie vers la caisse et la file.

## Écran de gestion de la file — `/dashboard/synchronisation`

L'API existait, l'interface manquait. Une vente refusée restait invisible.

L'écran affiche l'état réseau, les compteurs (en attente / échec / synchronisées),
et surtout **une description lisible de chaque opération** — « Vente comptoir ·
2 références · 3 unités · mtn momo · 4 900 FCFA » — parce qu'un pharmacien doit
reconnaître sa vente, pas déchiffrer un UUID.

Sur les échecs :
> Ces ventes ont été refusées par le serveur — le plus souvent parce que le stock avait
> déjà été écoulé entre-temps. **Aucune n'est comptabilisée tant qu'elle figure ici.**

Actions : *Réessayer* (après correction du stock), *Abandonner*, et **export JSON** —
filet de sécurité si un poste doit être réinstallé avec des ventes non synchronisées.

### Test de bout en bout contre le vrai serveur

```
4 ventes encaissées hors ligne (dont 1 sur un produit à stock insuffisant)

Retour réseau      → {"envoyees":3,"doublons":0,"echecs":1,"restantes":1}
Second rejeu       → {"envoyees":0,"doublons":3,"echecs":0,"restantes":1}

sent    TK-89649
sent    TK-89650
sent    TK-89651
failed  —  Stock insuffisant pour Sérum physiologique 5 ml x20 (9 restant).

Stock Amoxicilline : 118 → 114  (−4, exactement les 4 unités vendues)
```

Le second rejeu ne crée **aucune** vente supplémentaire : l'idempotence tient.

## Rotation de la clé de chiffrement

`ENCRYPTION_KEY_OLD` accepte plusieurs anciennes clés (séparées par des virgules).
Le déchiffrement les essaie dans l'ordre ; le chiffrement utilise toujours la clé courante.

```bash
# 1. Nouvelle clé
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# 2. ENCRYPTION_KEY = nouvelle, ENCRYPTION_KEY_OLD = ancienne, puis redéployer
# 3. Simuler, puis appliquer
npm run key:rotate:dry
npm run key:rotate

# 4. À 0 restant : retirer ENCRYPTION_KEY_OLD et redéployer
```

Aucune interruption de service : l'application lit les deux clés pendant toute l'opération.
Le script est interruptible et rejouable (`needsRewrap()` ne réécrit que le nécessaire).

**Note d'architecture** : `lib/crypto.ts` porte `server-only`, ce qui empêchait les scripts
CLI de l'importer. Les primitives ont été isolées dans `lib/crypto-core.ts` ; la façade
protégée les réexporte pour l'application.

### Rotation vérifiée dans les deux sens

```
état initial (clé A)     → +229 97 45 88 12
rotation A → B           → 1 réécrit
  avec B seule           → +229 97 45 88 12   ✓
  avec A seule           → null  ← illisible  ✓ (la donnée est bien re-chiffrée)
  A + B déclarée en OLD  → +229 97 45 88 12   ✓
rejeu du script          → 0 à réécrire       ✓ idempotent
```

## État final

| | |
|---|---|
| Vulnérabilités npm | **0** |
| Pages | 22, toutes en `200` |
| Routes | 39 |
| Base | 29 tables, migrations versionnées |
| Hors ligne | Caisse fonctionnelle, file gérable, rejeu idempotent |
| PWA | Installable, 3 raccourcis, icône maskable |
| Chiffrement | AES-256-GCM, rotation de clé sans coupure |

### Avant la mise en service réelle
- [ ] Provisionner Upstash Redis (`UPSTASH_REDIS_REST_URL` / `_TOKEN`)
- [ ] Sauvegardes automatiques + test de restauration trimestriel documenté
- [ ] Sentry pour les erreurs, alerte si la file dépasse un seuil
- [ ] Test terrain : 30 encaissements réseau coupé, puis resynchronisation
- [ ] Faire valider les modèles de message WhatsApp par Meta
