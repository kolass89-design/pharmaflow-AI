# PharmaFlow AI — Architecture produit & technique

> Plateforme SaaS de gestion d'officine pour l'Afrique francophone (Bénin, Togo, Côte d'Ivoire, Sénégal, Niger, Cameroun).
> Identité, textes, design et contenus 100 % originaux.

---

## 1. Positionnement produit

| Axe | Choix |
|---|---|
| Promesse | « La pharmacie intelligente pour l'Afrique francophone » |
| Différenciateurs | Mode hors ligne réel · agent WhatsApp · IA de réapprovisionnement · Mobile Money multi-pays · français natif |
| Cibles | Officine unique (Starter), officine en croissance (Pro), réseau multi-sites (Enterprise) |
| Utilisateurs | Titulaire, pharmacien, préparateur, caissier, comptable + patient (app publique) |
| Modèle | Abonnement mensuel/annuel en XOF/XAF, 14 jours d'essai sans carte |

### Personas
1. **Dr. titulaire** — veut de la visibilité (marge, trésorerie, ruptures) sans passer ses soirées sur Excel.
2. **Préparateur / caissier** — veut encaisser vite, même quand le réseau tombe.
3. **Comptable externe** — veut un export fiscal propre chaque mois.
4. **Patient** — veut savoir où trouver son médicament, ce soir, maintenant.

---

## 2. Identité visuelle (originale)

- **Couleurs** : vert santé `#128357` (primaire), bleu confiance `#2563eb` (secondaire), or `#d9a441` (accent), fonds `#f8fafc` / encre `#0b1620`.
- **Logo** : croix pharmaceutique stylisée dans un carré arrondi en dégradé vert→bleu, traversée d'une onde dorée (le « flow »).
- **Typographie** : Inter (titres extra-bold serrés, corps régulier).
- **Formes** : cartes `rounded-2xl`, ombres douces, bordures 1 px.
- **Mouvement** : animations légères uniquement (flottement du hero, transitions 150-200 ms). Jamais d'animation sur les écrans de caisse.
- **Modes** : clair par défaut, sombre disponible dans le dashboard (`class="dark"` sur `<html>`).

---

## 3. Architecture technique

```
┌────────────────────────────────────────────────────────────┐
│  Clients                                                   │
│  Web Next.js (site + dashboard)  │  PWA officine  │  App patient │
└──────────────┬───────────────────┴────────┬───────────────┘
               │ HTTPS / JSON               │ Service Worker + IndexedDB
┌──────────────▼────────────────────────────▼───────────────┐
│  Next.js App Router (Vercel)                              │
│  · Pages RSC + composants client                          │
│  · Route Handlers /api/*  (auth, produits, ventes, sync)  │
│  · Middleware : garde de session + en-têtes de sécurité   │
└──────────────┬────────────────────────────────────────────┘
               │ Prisma
┌──────────────▼────────────────────────────────────────────┐
│  PostgreSQL (Neon / Railway / Supabase)                   │
│  25 tables · cloisonnement par pharmacyId                 │
└──────────────┬────────────────────────────────────────────┘
               │
   ┌───────────┼─────────────┬───────────────┬──────────────┐
   ▼           ▼             ▼               ▼              ▼
 S3/Supabase  WhatsApp    Mobile Money    Moteur IA      SMTP/SMS
 (ordonnances) Business API (agrégateur)  (prévisions,   (rappels)
                                           OCR, Q/R)
```

### Stack retenue
- **Frontend** : Next.js 14 (App Router), TypeScript, Tailwind CSS, composants maison façon shadcn/ui, Recharts.
- **Backend** : Route Handlers Next.js pour le MVP → extraction possible vers NestJS quand les traitements asynchrones (OCR, prévisions, webhooks) dépassent la limite serverless.
- **Base** : PostgreSQL + Prisma. Multi-tenant par `pharmacyId` sur chaque table métier (+ RLS Postgres en option Enterprise).
- **Auth** : session signée HMAC-SHA256 en cookie `httpOnly`/`sameSite=lax`/`secure`, mots de passe en `scrypt`, RBAC par matrice de permissions (`lib/auth.ts`).
- **Fichiers** : S3 compatible (ordonnances scannées, factures, exports), URLs signées à durée courte.
- **Mobile** : PWA installable en v1 (même code, coût nul) ; React Native Expo en v2 pour scanner natif et notifications push avancées.

### Découpage en 3 surfaces
1. **Site marketing** — statique/SSG, indexable, ultra-léger.
2. **Dashboard officine** — client-side interactif, protégé par middleware.
3. **Espace patient** — recherche, réservation, pharmacies de garde (partiellement public).

---

## 4. Mode hors ligne (élément critique)

| Couche | Rôle |
|---|---|
| Service Worker (`public/sw.js`) | Cache du shell applicatif et des routes caisse/stock |
| IndexedDB | Catalogue produits répliqué + file d'opérations (ventes, mouvements) |
| `offlineUuid` | UUID généré côté client, contrainte `@unique` en base → idempotence, zéro doublon |
| `POST /api/sync` | Rejoue la file, renvoie `applied` / `duplicate` / `rejected` |
| Résolution de conflits | Le stock est recalculé côté serveur à partir des mouvements ; en cas de stock négatif, alerte d'inventaire plutôt que rejet de la vente |

Règle produit : **une vente n'est jamais bloquée par l'absence de réseau.**

---

## 5. Sécurité

- Transport TLS 1.3 ; en-têtes `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` posés par le middleware.
- Mots de passe : `scrypt` avec sel unique par utilisateur ; comparaison à temps constant.
- Sessions : cookie signé, 8 h, `httpOnly` (immunisé au vol par XSS), rotation à la connexion.
- CSRF : cookies `sameSite=lax` + mutations exclusivement en POST/PUT/DELETE avec vérification d'origine.
- Injections SQL : Prisma paramétré exclusivement, aucun SQL concaténé.
- XSS : React échappe par défaut, aucun `dangerouslySetInnerHTML`.
- Rate limiting : compteur par IP sur la connexion (8 tentatives/minute) → à remplacer par Upstash Redis en production.
- Données patients : téléphone et identifiants chiffrés applicativement (AES-256-GCM, `ENCRYPTION_KEY`), accès journalisé dans `audit_logs`.
- IA : seules des données agrégées et anonymisées sont envoyées au modèle, jamais l'identité d'un patient.
- Conformité : principes RGPD + cadres nationaux (APDP Bénin, CDP Sénégal, ARTCI Côte d'Ivoire) — registre de traitement, minimisation, droit d'export et d'effacement.
- Sauvegardes : quotidiennes chiffrées, restauration point-in-time, test de restauration trimestriel documenté.

---

## 6. Modèle de données (25 tables)

`users`, `pharmacies`, `pharmacy_members`, `roles`, `permissions`, `products`, `product_batches`, `stock_movements`, `suppliers`, `purchase_orders`, `purchase_order_items`, `sales`, `sale_items`, `payments`, `expenses`, `patients`, `prescriptions`, `prescription_items`, `treatment_reminders`, `whatsapp_conversations`, `whatsapp_messages`, `reservations`, `ai_recommendations`, `audit_logs`, `subscriptions`, `invoices`, `guard_schedules`.

Détail complet et contraintes : `prisma/schema.prisma`.

Conventions :
- Montants en **entiers** (le FCFA n'a pas de décimale) — jamais de `float` sur de l'argent.
- Chaque table métier porte `pharmacyId` avec `onDelete: Cascade`.
- Index composites sur les axes de lecture réels (`[pharmacyId, soldAt]`, `[productId, expiryDate]`, `[city, startsAt]`).

---

## 7. API principales

| Méthode | Route | Rôle |
|---|---|---|
| POST | `/api/auth/login` | Connexion, session signée, rate limiting |
| POST | `/api/auth/register` | Création de compte + officine |
| POST | `/api/auth/logout` | Destruction de session |
| GET/POST | `/api/products` | Catalogue, recherche, création (permission `stock.*`) |
| POST | `/api/sales` | Enregistrement d'une vente (permission `pos.sell`) |
| POST | `/api/sync` | Rejeu idempotent de la file hors ligne |
| GET | `/api/ai/recommendations` | Recommandations et suggestions de réappro |
| GET/POST | `/api/whatsapp/webhook` | Vérification Meta + traitement des messages (signature HMAC) |
| GET | `/api/guards` | Pharmacies de garde, filtrables par ville (public) |

À ajouter en v1.1 : `/api/patients`, `/api/prescriptions` (avec OCR asynchrone), `/api/purchase-orders`, `/api/accounting/reports`, `/api/subscriptions/webhook` (Mobile Money).

---

## 8. Feuille de route

| Phase | Contenu | Durée indicative |
|---|---|---|
| **MVP (livré)** | Site vitrine complet, auth, dashboard 10 modules mockés, POS interactif, schéma Prisma, API socle, PWA | fait |
| **V1 — données réelles** | Branchement Postgres, CRUD complet, import Excel, impression ticket, clôture de caisse | 4-6 semaines |
| **V1.5 — canaux** | WhatsApp Business API en production, Mobile Money (agrégateur), SMS de rappel | 3-4 semaines |
| **V2 — intelligence** | Prévision de demande (Prophet/LightGBM), OCR ordonnances, assistant Q/R sur données agrégées | 6-8 semaines |
| **V2.5 — échelle** | Multi-officines consolidé, app patient native Expo, API partenaires, RLS Postgres | 8 semaines |

---

## 9. Arborescence du projet

```
pharmaflow-ai/
├─ app/
│  ├─ layout.tsx · globals.css · page.tsx        # accueil
│  ├─ fonctionnalites/ demo/ tarifs/ contact/
│  ├─ pharmacies-de-garde/ ressources/ blog/[slug]/
│  ├─ connexion/ inscription/
│  ├─ dashboard/
│  │  ├─ page.tsx (accueil)
│  │  └─ ventes/ stock/ ordonnances/ patients/ fournisseurs/
│  │     comptabilite/ ia/ whatsapp/ parametres/
│  └─ api/
│     ├─ auth/{login,register,logout}/
│     └─ products/ sales/ sync/ guards/ ai/recommendations/ whatsapp/webhook/
├─ components/
│  ├─ site/     Header · Footer · Logo · SiteShell · DashboardPreview · RoiCalculator
│  └─ dashboard/Shell (sidebar, topbar, thème, indicateur réseau, Card, Kpi)
├─ lib/         auth.ts (session, RBAC, hachage) · mock.ts · utils.ts
├─ prisma/      schema.prisma
├─ public/      manifest.webmanifest · sw.js
├─ docs/        ARCHITECTURE.md · INSTALLATION.md
├─ middleware.ts
└─ tailwind.config.ts
```
