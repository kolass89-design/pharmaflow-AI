# Installation & déploiement — PharmaFlow AI

## 1. Prérequis
- Node.js 20 ou supérieur
- npm 10+
- PostgreSQL 15+ (local, Neon, Railway ou Supabase) — optionnel pour le MVP mocké

## 2. Installation locale

```bash
cd pharmaflow-ai
npm install
cp .env.example .env
npm run dev          # http://localhost:3000
```

Compte de démonstration : **demo@pharmaflow.ai** / **demo1234**

## 3. Variables d'environnement

| Variable | Rôle |
|---|---|
| `DATABASE_URL` | Chaîne de connexion PostgreSQL |
| `SESSION_SECRET` | Clé HMAC des sessions (32 caractères minimum) |
| `ENCRYPTION_KEY` | Clé AES-256 (64 caractères hex) pour les champs patients |
| `WHATSAPP_VERIFY_TOKEN` / `WHATSAPP_APP_SECRET` / `WHATSAPP_TOKEN` / `WHATSAPP_PHONE_NUMBER_ID` | WhatsApp Business API |
| `S3_*` | Stockage des ordonnances et factures |
| `OPENAI_API_KEY` | Assistant IA et OCR |
| `SMTP_URL` | Emails transactionnels |

Générer des secrets solides :
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"   # SESSION_SECRET
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"         # ENCRYPTION_KEY
```

## 4. Base de données

```bash
npm run db:generate    # génère le client Prisma
npm run db:push        # applique le schéma (dev)
npx prisma migrate dev --name init   # migrations versionnées (recommandé)
npm run db:studio      # explorateur visuel
```

## 5. Build de production

```bash
npm run build
npm run start
```

## 6. Déploiement

### Frontend + API — Vercel
1. Poussez le dépôt sur GitHub.
2. « Import Project » sur Vercel, framework détecté automatiquement.
3. Renseignez toutes les variables d'environnement (Production + Preview).
4. Ajoutez le domaine (`pharmaflow.ai`) et forcez HTTPS.

### Base de données — Neon ou Railway
- Créez l'instance dans la région la plus proche (Europe de l'Ouest offre la meilleure latence vers l'Afrique de l'Ouest).
- Activez les sauvegardes quotidiennes et la restauration point-in-time.
- Copiez la chaîne `postgresql://…?sslmode=require` dans `DATABASE_URL`.

### Traitements longs — Railway / Render / Fly.io
Extraire vers un service séparé : OCR des ordonnances, entraînement des modèles de prévision, envois WhatsApp en masse, génération des exports fiscaux. Ces tâches dépassent les limites d'exécution serverless.

### WhatsApp Business API
1. Créez une application Meta Business, ajoutez le produit WhatsApp.
2. Webhook : `https://votre-domaine/api/whatsapp/webhook`, token de vérification = `WHATSAPP_VERIFY_TOKEN`.
3. Abonnez-vous à l'événement `messages`.
4. Faites valider vos modèles de message (rappels de traitement, confirmation de réservation).

### Mobile Money
Passez par un agrégateur régional couvrant MTN, Moov, Orange, Celtiis et Wave plutôt que par cinq intégrations directes. Exposez un webhook unique `/api/payments/webhook`, vérifiez systématiquement la signature et rendez le traitement idempotent sur la référence du prestataire.

## 7. PWA
Le manifeste et le service worker sont dans `public/`. Pour activer l'installation, enregistrez le worker dans le layout du dashboard :
```ts
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js");
```
Ajoutez `icon-192.png` et `icon-512.png` dans `public/`.

## 7 bis. Exploitation

Sauvegardes, supervision, test terrain et contrôle avant production :
voir `docs/EXPLOITATION.md`.

```bash
npm run preflight -- https://votre-domaine   # contrôle bloquant avant ouverture
npm run backup                                # sauvegarde chiffrée
npm run backup:verify                         # test de restauration
```

Sur un VPS à 2 Go de RAM, le build nécessite un plafond mémoire explicite —
déjà appliqué dans le script `build`.

## 8. Checklist avant mise en production
- [ ] `SESSION_SECRET` et `ENCRYPTION_KEY` uniques et stockés dans un gestionnaire de secrets
- [ ] Rate limiting déporté sur Redis (Upstash) au lieu de la mémoire du processus
- [ ] Sauvegardes automatiques vérifiées par un test de restauration réel
- [ ] Journal d'audit alimenté sur tout accès à un dossier patient
- [ ] MFA activé pour les comptes titulaires
- [ ] Politique de confidentialité et registre de traitement publiés
- [ ] Supervision : Sentry (erreurs) + Vercel Analytics ou Plausible (usage)
- [x] Test terrain du mode hors ligne : `npm run test:terrain` (30 encaissements, validé)
- [x] Test de restauration des sauvegardes : `npm run backup:verify` (validé)
- [ ] `npm run preflight` sans point bloquant sur l'environnement cible
