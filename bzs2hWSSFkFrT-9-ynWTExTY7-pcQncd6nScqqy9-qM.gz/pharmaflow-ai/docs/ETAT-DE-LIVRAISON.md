# État de livraison — ce qui fonctionne, ce qui manque

Document d'honnêteté produit. À lire avant toute promesse commerciale.

## ✅ Opérationnel

| Domaine | Détail |
|---|---|
| Caisse | Encaissement, remise, 7 moyens de paiement enregistrés, **mode hors ligne** avec resynchronisation idempotente |
| Stock | Lots, FEFO, péremptions, seuils, réception, ajustement avec motif, **import/export CSV** |
| Ordonnances | Saisie, statuts (servie / partielle / archivée), **alerte automatique sur allergies** |
| Patients | Dossiers, historique, téléphone **chiffré AES-256**, rappels enregistrés |
| Fournisseurs | Création, bons de commande, génération automatique depuis les alertes |
| Comptabilité | Recettes, dépenses, marges, **export CSV ventes et dépenses** |
| Espace patient | Recherche sans accent, comparaison d'officines, réservation 2 h, suivi |
| Agent WhatsApp | Moteur conversationnel réel, **transfert humain systématique** sur question thérapeutique |
| Administration | Modification de l'officine, horaires, **invitation et suspension de membres** |
| Sécurité | RBAC 5 rôles, journal d'audit, limitation de débit, cloisonnement multi-officines |

## ⚠️ Nécessite une intégration externe

Ces fonctions ne peuvent pas être terminées sans un tiers.

| Fonction | Bloquant | Impact |
|---|---|---|
| **Envoi WhatsApp** | Validation Meta du numéro et des modèles | Le moteur répond et enregistre tout, mais rien n'est transmis tant que `WHATSAPP_TOKEN` est absent |
| **Paiement Mobile Money** | Contrat avec un agrégateur | Le POS enregistre le moyen déclaré ; **aucun débit réel n'est déclenché**. La caisse affiche désormais un avertissement explicite au caissier : *« Paiement NON débité par la plateforme. Vérifiez la réception sur votre téléphone marchand avant de laisser partir le client. »* |
| **Email** | Service SMTP ou Resend | Pas d'email d'invitation ni de réinitialisation de mot de passe |
| **SMS** | Passerelle opérateur | Les rappels sont programmés mais non envoyés |

L'interface **le dit explicitement** à l'utilisateur plutôt que de simuler un succès.

## ❌ Non implémenté

| Fonction | État | Contournement |
|---|---|---|
| **OCR des ordonnances** | Retiré de l'interface et du site | Saisie manuelle, avec contrôle des allergies |
| **Impression de ticket** | Absent | Le récapitulatif de vente reste affiché à l'écran |
| **Scan code-barres** | Bouton retiré | Une douchette USB fonctionne : elle saisit dans le champ de recherche |
| **Double authentification** | Affichée « Non disponible » | Mots de passe `scrypt`, sessions signées 8 h |
| **Mot de passe oublié** | Absent | Le titulaire réinvite le membre |
| **Paiement de l'abonnement en ligne** | Renvoi vers un contact | Facturation manuelle |

### Correction importante
Les paramètres affichaient auparavant « Authentification à deux facteurs : **Activée** ».
**C'était faux.** Une fausse assurance de sécurité est pire que son absence :
la mention est corrigée, et le site public ne promet plus ni MFA ni OCR.

## Verdict

**Utilisable en pilote accompagné, pas en déploiement commercial autonome.**

Une officine peut aujourd'hui tenir sa caisse, son stock, ses ordonnances et ses
patients de bout en bout, y compris sans réseau. Il lui manquera l'impression de
ticket, le débit Mobile Money automatique et les notifications sortantes.

### Avant d'ouvrir le service
1. Faire valider le numéro WhatsApp par Meta (quelques jours)
2. Signer avec un agrégateur Mobile Money couvrant MTN, Moov, Celtiis, Orange, Wave
3. Configurer un service d'email transactionnel
4. Provisionner Upstash Redis (`npm run preflight` le signale)
5. Décider pour l'impression : imprimante réseau ESC/POS ou export PDF
6. **Pilote de deux semaines en double saisie** avec l'ancien système
