# Tests — PharmaFlow AI

Trois niveaux, une seule commande.

```bash
npm test              # tout : unitaires + intégration + terrain (~15 s)
npm run test:unit     # unitaires seuls (~2 s, ni base ni serveur)
npm run test:api      # intégration seule
```

| Niveau | Fichiers | Nombre | Ce qui est couvert |
|---|---|---|---|
| Unitaires | `tests/unit/` | **96** | Parseur CSV, RBAC, chiffrement, sessions, masquage |
| Intégration | `tests/integration/` | **48** | API réelle + PostgreSQL : transactions, FEFO, cloisonnement |
| Terrain | `scripts/test-terrain.mjs` | 1 scénario | 30 encaissements hors ligne puis resynchronisation |

## Principe : tester le vrai code

`tests/helpers/load.mjs` transpile les modules TypeScript de `lib/` avec esbuild
et neutralise `server-only` ainsi que `next/headers`. **Aucune logique n'est
réimplémentée dans les tests** — une réimplémentation testerait la copie, pas le produit.

## Isolation

Les tests d'intégration créent une base jetable (`pharmaflow_test_<pid>`), y
appliquent les migrations, chargent le seed, démarrent un serveur dédié, puis
suppriment tout. **La base de développement n'est jamais touchée.**

## Ce qui est réellement protégé

### Contrôle d'accès
Le comptable ne doit **jamais** accéder aux dossiers patients — il n'a aucune
raison métier de le faire. Le test l'énonce explicitement. Sont aussi couverts :
le débordement de joker (`pos.*` ne doit pas autoriser `postal.envoi`) et le refus
par défaut de toute permission inconnue.

### Chiffrement
Aller-retour, IV aléatoire (deux chiffrements diffèrent), rejet d'une donnée
altérée via l'authentification GCM, illisibilité avec une autre clé, et
**rotation** : l'ancienne clé déclarée en `ENCRYPTION_KEY_OLD` rend la donnée
lisible sans interruption.

### Sessions
Une charge utile modifiée est rejetée. Le test le plus important : une tentative
d'**élévation de privilège** (changer `CASHIER` en `OWNER` en réutilisant la
signature d'origine) échoue.

### Ventes — le cœur métier
- décrément du stock au montant exact ;
- **atomicité** : un panier dont une ligne échoue ne laisse ni vente partielle ni stock décrémenté ;
- remise plafonnée à 50 % (une remise de 500 % viderait la caisse) ;
- chaque vente génère un paiement et des mouvements tracés.

### Idempotence
Trois envois du même `offlineUuid` → une seule vente, et le stock n'est décrémenté
qu'une fois. C'est ce qui rend le mode hors ligne exploitable.

### Cloisonnement
Impossible de lire un patient d'une autre officine, même en connaissant son
identifiant. La liste des produits est strictement limitée à l'officine.

### Intégrité de la base
Aucune ligne de vente orpheline, aucune vente sans paiement, aucun stock négatif,
et le total de chaque vente correspond à la somme de ses lignes.

## Validation par injection de régressions

Une suite qui ne détecte rien ne sert à rien. Deux failles ont été injectées
volontairement pour vérifier qu'elle les attrape :

| Faille injectée | Détection |
|---|---|
| `stock.write` ajouté au rôle caissier | `not ok — Contrôle d'accès par rôle` (96 → 95 réussis) |
| Contrôle d'idempotence retiré de `/api/sales` | `not ok — Idempotence de la synchronisation` (48 → 47) |

Les deux ont été détectées, puis le code a été restauré.

## Intégration continue

`.github/workflows/ci.yml` exécute à chaque commit : audit des dépendances
(**bloquant** au niveau `high`), tests unitaires, migrations sur base vierge,
build, intégration, scénario terrain, et **vérification de restauration de sauvegarde**.

## Pièges rencontrés

| Problème | Cause | Correction |
|---|---|---|
| Comptage de mouvements faux | Fenêtre « 5 dernières minutes » captant les ventes des tests précédents | Mesure d'un delta avant/après |
| `serveur injoignable` | Serveur résiduel pointant sur une base supprimée | Libération du port avant démarrage |
| `pkill` sans effet | `next start` se renomme en `next-server` | Cibler le bon nom de processus |
| `Cannot find module next/headers` | `lib/auth.ts` importe un module du runtime Next | Bouchon injecté par le chargeur |
