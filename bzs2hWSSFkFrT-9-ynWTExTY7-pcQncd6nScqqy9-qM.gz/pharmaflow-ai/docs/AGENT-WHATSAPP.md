# Agent WhatsApp

Point 11 du cahier des charges. Le webhook lisait auparavant des données
factices et ne persistait rien ; il s'appuie désormais sur la base réelle.

## La règle qui prime sur tout

**Le bot traite la logistique. Il ne donne jamais de conseil thérapeutique.**

Un automate qui répondrait à une question de posologie engagerait la
responsabilité du pharmacien titulaire. Sept familles de motifs déclenchent un
transfert humain immédiat :

| Famille | Exemples |
|---|---|
| Posologie | « quelle dose », « combien de comprimés par jour » |
| Grossesse / pédiatrie | « je suis enceinte », « pour un bébé de 3 mois » |
| Effets et tolérance | « effets secondaires », « contre-indications », « allergique à » |
| Danger | « est-ce dangereux », « puis-je prendre » |
| Interactions | « avec mon traitement », « en même temps que » |
| Symptômes | « j'ai mal », « fièvre », « quels symptômes » |
| Ordonnance | « renouveler mon traitement » |

Les motifs sont **volontairement larges** : en cas de doute, c'est le pharmacien
qui répond. Un faux positif coûte une notification ; un faux négatif coûte un
conseil médical rendu par une machine.

En cas de transfert, la conversation passe en `HUMAN_REQUIRED` et la réponse
ne contient aucune indication thérapeutique — c'est vérifié par les tests.

## Ce que le bot sait faire

| Intention | Comportement |
|---|---|
| `salutation` | Accueil au nom de l'officine |
| `recherche` | Disponibilité + prix + jusqu'à 2 alternatives |
| `confirmation` | « oui » réserve le produit précédemment proposé |
| `annulation` | « non » n'engage rien |
| `suivi` | État d'une réservation via sa référence |
| `horaires` / `adresse` | Horaires réels, lien d'itinéraire |
| `humain` | Transfert sur demande explicite |

## Décisions de conception

### L'état vit en base, pas en mémoire
Les instances serverless sont éphémères : une session en RAM disparaîtrait entre
deux messages. Le contexte (« quel produit vient d'être proposé ? ») est
reconstruit depuis les six derniers messages de la conversation.

### Le bot se tait quand un humain a repris la main
Statut `HUMAN` : plus aucune réponse automatique. Rien n'est plus déroutant pour
un patient qu'un robot qui coupe la parole au pharmacien.

### Idempotence des webhooks
Meta rejoue les webhooks non acquittés. Sans garde-fou, un patient recevrait
plusieurs fois la même réponse et pourrait réserver en double. Le `providerId`
du message est donc vérifié avant tout traitement.

### Toujours 200, même en erreur
Un statut d'erreur déclenche des rejeux en boucle chez Meta et, à terme, la
désactivation du webhook. Les incidents partent à la supervision, jamais au client.

### Signature obligatoire en production
Sans `WHATSAPP_APP_SECRET`, le webhook n'accepte les requêtes qu'en développement.
En production, un webhook non signé permettrait d'injecter de faux messages —
et donc de créer de fausses réservations.

### Réservation : mêmes règles que l'espace patient
Pas de décrément de stock, validité 2 heures, médicaments sous ordonnance refusés,
référence `R-ABCD1234` sans I ni O (confusions avec 1 et 0 à l'oral).

## Configuration

```bash
WHATSAPP_VERIFY_TOKEN=""      # vérification initiale du webhook
WHATSAPP_APP_SECRET=""        # signature HMAC — obligatoire en production
WHATSAPP_TOKEN=""             # jeton d'envoi (Graph API)
WHATSAPP_PHONE_NUMBER_ID=""   # identifiant du numéro émetteur
```

Webhook à déclarer chez Meta : `https://votre-domaine/api/whatsapp/webhook`,
événement `messages`.

Sans `WHATSAPP_TOKEN`, le moteur fonctionne et persiste tout, mais n'émet rien :
utile pour tester avant validation Meta.

## Couverture de tests

**45 unitaires** (sans base ni serveur) : classification des intentions,
priorité du conseil médical, extraction du nom de produit.

**32 d'intégration** : vérification du webhook, refus de conseil sur 10 formulations
réelles, recherche sans accent et par DCI, réservation par « oui », idempotence,
format officiel Meta, charge illisible, message non textuel.

### Validation par injection de régression
Motif « posologie » retiré du moteur → **4 tests échouent immédiatement**,
dont « Quelle posologie pour l'amoxicilline ? ». Code restauré ensuite.

## Deux bugs trouvés en écrivant les tests

| Bug | Conséquence |
|---|---|
| `effet secondaire` ne couvrait pas le pluriel | « Quels sont les effets secondaires ? » recevait une réponse automatique au lieu d'un pharmacien |
| La salutation l'emportait sur tout | « Bonjour, avez-vous du paracétamol ? » renvoyait un simple bonjour |

Le second est un défaut d'usage courant : presque personne n'écrit sa demande
sans dire bonjour d'abord.
