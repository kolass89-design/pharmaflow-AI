import type { Metadata } from "next";
import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import RechercheMedicament from "@/components/patient/RechercheMedicament";
import { listerVilles } from "@/lib/patient-queries";

export const metadata: Metadata = {
  title: "Trouver un médicament près de chez vous — PharmaFlow AI",
  description:
    "Recherchez un médicament, vérifiez sa disponibilité dans les pharmacies partenaires, réservez-le 2 heures et récupérez-le au comptoir. Service gratuit, sans compte.",
};

export const dynamic = "force-dynamic";

export default async function Page() {
  let villes: string[] = [];
  try {
    villes = await listerVilles();
  } catch {
    villes = [];   // la page doit rester utilisable même si la base est indisponible
  }

  return (
    <SiteShell>
      <section className="border-b border-slate-200 bg-brand-50/60 py-10 sm:py-14 dark:border-white/10 dark:bg-brand-900/10">
        <div className="container-x">
          <span className="badge">Service gratuit · sans compte</span>
          <h1 className="h2 mt-4">Trouvez votre médicament, maintenant</h1>
          <p className="mt-3 max-w-2xl muted">
            Vérifiez la disponibilité dans les officines partenaires, comparez les prix,
            réservez pendant 2 heures et passez récupérer. Vous payez au comptoir.
          </p>
        </div>
      </section>

      <section className="section !py-10">
        <div className="container-x max-w-3xl">
          <RechercheMedicament villes={villes} />

          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {[
              ["1", "Cherchez", "Par nom commercial ou par molécule. Les accents sont facultatifs."],
              ["2", "Réservez", "Le pharmacien met le produit de côté pendant 2 heures."],
              ["3", "Récupérez", "Donnez votre référence au comptoir et réglez sur place."],
            ].map(([n, titre, texte]) => (
              <div key={n} className="rounded-2xl border border-slate-200 p-4 dark:border-white/10">
                <span className="grid h-8 w-8 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white">{n}</span>
                <p className="mt-3 font-semibold">{titre}</p>
                <p className="mt-1 text-sm muted">{texte}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 rounded-2xl border border-amber-200 bg-amber-50/60 p-4 text-sm dark:border-amber-500/30 dark:bg-amber-500/10">
            <p className="font-semibold text-amber-900 dark:text-amber-300">Avertissement</p>
            <p className="mt-1 text-amber-800 dark:text-amber-300/90">
              Ce service indique une disponibilité, il ne remplace ni une consultation médicale
              ni le conseil du pharmacien. Les médicaments soumis à ordonnance ne sont pas
              réservables en ligne : présentez votre prescription au comptoir.
            </p>
          </div>

          <div className="mt-8 flex flex-wrap justify-center gap-3 text-sm">
            <Link href="/ma-reservation" className="btn-ghost">Suivre une réservation</Link>
            <Link href="/pharmacies-de-garde" className="btn-ghost">Pharmacies de garde</Link>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
