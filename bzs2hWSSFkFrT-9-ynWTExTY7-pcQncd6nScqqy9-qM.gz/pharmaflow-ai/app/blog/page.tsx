import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import { posts } from "@/lib/mock";

export default function Page() {
  return (
    <SiteShell>
      <section className="section">
        <div className="container-x">
          <h1 className="h2">Blog PharmaFlow AI</h1>
          <div className="mt-10 space-y-4">
            {posts.map(p => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card block">
                <span className="badge">{p.tag}</span>
                <h2 className="mt-3 text-lg font-semibold">{p.titre}</h2>
                <p className="mt-2 text-sm muted">{p.extrait}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
