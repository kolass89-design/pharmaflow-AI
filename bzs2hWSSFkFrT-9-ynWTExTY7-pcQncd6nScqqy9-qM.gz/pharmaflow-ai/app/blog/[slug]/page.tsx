import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import { posts } from "@/lib/mock";
import { notFound } from "next/navigation";

export function generateStaticParams() { return posts.map(p => ({ slug: p.slug })); }

const body: Record<string, string[]> = {
  "eviter-ruptures-pharmacie": [
    "Une rupture n'est jamais un hasard : c'est presque toujours un seuil d'alerte fixé une fois pour toutes, puis oublié.",
    "1. Calculez une couverture, pas un seuil fixe. Divisez votre stock par la consommation moyenne des 30 derniers jours, puis comparez au délai réel de votre grossiste.",
    "2. Intégrez la saisonnalité. Antipaludiques et antidiarrhéiques suivent la pluie ; antihistaminiques suivent l'harmattan.",
    "3. Classez en ABC. Vos 20 % de références qui font 80 % du chiffre méritent un suivi quotidien, pas hebdomadaire.",
    "4. Suivez le taux de service. Chaque demande non satisfaite doit être enregistrée : c'est votre meilleur indicateur de rupture invisible.",
    "5. Automatisez la commande. Une suggestion générée chaque matin, validée en deux minutes, vaut mieux qu'un inventaire mensuel parfait.",
  ],
  "digitaliser-officine-benin": [
    "Digitaliser ne commence pas par le logiciel, mais par la qualité de vos données de stock.",
    "Jours 1 à 15 : inventaire physique complet, nettoyage du fichier produits, harmonisation des désignations et des DCI.",
    "Jours 16 à 45 : mise en service de la caisse, formation des préparateurs, impression des étiquettes code-barres pour les 300 références les plus vendues.",
    "Jours 46 à 75 : activation des lots et des dates de péremption, puis des fournisseurs et des bons de commande.",
    "Jours 76 à 90 : ouverture de l'agent WhatsApp et des prévisions IA, une fois que l'historique est suffisamment riche.",
    "Point d'attention : prévoyez un onduleur et un forfait data de secours. Le mode hors ligne couvre le reste.",
  ],
  "whatsapp-pharmacie": [
    "En Afrique francophone, WhatsApp est le premier réflexe du patient avant de se déplacer.",
    "Répondre « disponible / prix / je vous le garde 2 heures » transforme une simple question en vente confirmée.",
    "L'automatisation ne remplace pas le pharmacien : elle filtre les questions logistiques pour lui laisser le conseil.",
    "Trois règles : répondre en moins d'une minute, ne jamais donner de conseil posologique par bot, et tracer chaque réservation dans le logiciel.",
    "Résultat observé chez nos officines pilotes : entre 8 et 15 % de passages supplémentaires au comptoir.",
  ],
  "gerer-dates-expiration": [
    "Les péremptions sont une perte sèche : elles coûtent la marge et le capital immobilisé.",
    "Appliquez le FEFO (First Expired, First Out) au rangement physique, pas seulement dans le logiciel.",
    "Programmez trois alertes : 90 jours (négociation retour fournisseur), 60 jours (mise en avant comptoir), 30 jours (déstockage encadré).",
    "Négociez dès la commande la clause de reprise avec vos grossistes : elle se discute à l'achat, jamais à l'expiration.",
    "Suivez un indicateur unique : valeur du stock expirant à 90 jours, rapportée au stock total. En dessous de 2 %, vous êtes bien géré.",
  ],
};

export default async function Page({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = posts.find(p => p.slug === slug);
  if (!post) notFound();
  return (
    <SiteShell>
      <article className="section">
        <div className="container-x max-w-3xl">
          <span className="badge">{post!.tag}</span>
          <h1 className="h2 mt-4">{post!.titre}</h1>
          <p className="mt-3 text-sm muted">{post!.duree} de lecture · Équipe PharmaFlow AI</p>
          <div className="mt-8 space-y-5 text-[15px] leading-7 muted">
            {(body[slug] ?? []).map((p, i) => <p key={i}>{p}</p>)}
          </div>
          <Link href="/blog" className="btn-ghost mt-10">← Tous les articles</Link>
        </div>
      </article>
    </SiteShell>
  );
}
