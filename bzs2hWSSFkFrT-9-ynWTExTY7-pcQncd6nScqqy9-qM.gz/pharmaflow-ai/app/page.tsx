import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import DashboardPreview from "@/components/site/DashboardPreview";
import RoiCalculator from "@/components/site/RoiCalculator";
import { stats, testimonials, posts, waThread } from "@/lib/mock";

const features = [
  { t: "Stock intelligent", d: "Lots, péremptions FEFO, seuils dynamiques et inventaire tournant sans tableur.", i: "📦" },
  { t: "Caisse POS rapide", d: "Encaissement en 3 clics, code-barres, remises, tickets — même hors connexion.", i: "🧾" },
  { t: "Ordonnances numériques", d: "Saisie assistée, association patient, alerte automatique sur les allergies déclarées, archivage.", i: "📄" },
  { t: "Patients & rappels", d: "Historique d'achats, allergies, pathologies chroniques et rappels de traitement programmables.", i: "🧑‍⚕️" },
  { t: "Fournisseurs & commandes", d: "Bons de commande, suivi livraison, factures et encours par grossiste.", i: "🚚" },
  { t: "Comptabilité & rapports", d: "Recettes, dépenses, marges, statistiques mensuelles et export fiscal.", i: "📊" },
  { t: "IA prédictive", d: "Prévision des ventes, réapprovisionnement suggéré, détection d'anomalies.", i: "✨" },
  { t: "Agent WhatsApp", d: "Disponibilité, prix, réservation et transfert à un humain, 24 h/24.", i: "💬" },
  { t: "Pharmacies de garde", d: "Calendrier de garde publié automatiquement et visible par les patients.", i: "🕒" },
  { t: "App patient mobile", d: "Recherche de médicament, officines proches, réservation et itinéraire.", i: "📱" },
];

export default function Home() {
  return (
    <SiteShell>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-gradient-to-b from-brand-50/70 to-transparent dark:border-white/10 dark:from-brand-900/20">
        <div className="container-x grid gap-12 py-16 sm:py-24 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="badge">Conçu pour l'Afrique francophone · fonctionne hors ligne</span>
            <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl">
              La pharmacie intelligente pour <span className="bg-gradient-to-r from-brand-600 to-trust-600 bg-clip-text text-transparent">l'Afrique francophone</span>
            </h1>
            <p className="mt-5 text-lg muted">
              Pilotez votre officine de bout en bout : stock et lots, caisse rapide, ordonnances,
              dossiers patients, comptabilité, intelligence artificielle et relation client sur WhatsApp —
              en français, en FCFA, avec ou sans connexion.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/inscription" className="btn-primary">Commencer gratuitement</Link>
              <Link href="/demo" className="btn-ghost">Voir la démo</Link>
            </div>
            <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm muted">
              <li>✅ 14 jours gratuits</li>
              <li>✅ Sans carte bancaire</li>
              <li>✅ Support francophone</li>
            </ul>
          </div>
          <div className="relative">
            <div className="animate-floaty"><DashboardPreview /></div>
            <div className="mt-4 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm lg:absolute lg:-bottom-10 lg:-left-8 lg:mt-0 lg:w-64 dark:border-white/10 dark:bg-ink">
              <p className="mb-2 text-xs font-semibold text-brand-600">Agent WhatsApp</p>
              {waThread.slice(0, 2).map((m, i) => (
                <p key={i} className={"mb-2 rounded-xl px-3 py-2 text-xs " + (m.from === "patient" ? "bg-slate-100 dark:bg-white/10" : "bg-brand-600 text-white")}>
                  {m.text}
                </p>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PREUVES */}
      <section className="border-b border-slate-200 py-12 dark:border-white/10">
        <div className="container-x grid grid-cols-2 gap-6 lg:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <p className="text-3xl font-extrabold text-brand-600">{s.value}</p>
              <p className="mt-1 text-sm muted">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="container-x mt-10 flex flex-wrap items-center justify-center gap-4 opacity-70">
          {["Pharmacie Étoile","Officine du Lac","Groupe Santé Plus","Pharmacie Sainte-Rita","Réseau Bien-Être"].map((p) => (
            <span key={p} className="rounded-lg border border-dashed border-slate-300 px-4 py-2 text-xs font-semibold muted dark:border-white/15">{p}</span>
          ))}
        </div>
      </section>

      {/* FONCTIONNALITÉS */}
      <section className="section" id="fonctionnalites">
        <div className="container-x">
          <h2 className="h2">Tout ce dont une officine moderne a besoin</h2>
          <p className="mt-3 max-w-2xl muted">Dix modules intégrés, une seule base de données, aucune ressaisie.</p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f) => (
              <div key={f.t} className="card">
                <div className="text-2xl">{f.i}</div>
                <h3 className="mt-3 font-semibold">{f.t}</h3>
                <p className="mt-2 text-sm muted">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* DEMO */}
      <section className="section bg-white dark:bg-white/5" id="demo">
        <div className="container-x">
          <h2 className="h2">Essayez le tableau de bord</h2>
          <p className="mt-3 max-w-2xl muted">Données de démonstration, navigation réelle. Cliquez sur les onglets.</p>
          <div className="mt-10"><DashboardPreview /></div>
        </div>
      </section>

      {/* IA */}
      <section className="section">
        <div className="container-x grid gap-10 lg:grid-cols-2 lg:items-center">
          <div>
            <span className="badge">Intelligence artificielle</span>
            <h2 className="h2 mt-4">Une IA qui connaît votre officine</h2>
            <ul className="mt-6 space-y-3 text-sm muted">
              {["Prévision des ruptures avant qu'elles n'arrivent",
                "Recommandations d'achat par fournisseur et par délai",
                "Analyse des ventes par famille, saison et quartier",
                "Détection des produits dormants et du surstock",
                "Alertes d'expiration à 90, 60 et 30 jours",
                "Assistant conversationnel pour vos préparateurs"].map((x) => (
                <li key={x} className="flex gap-3"><span className="text-brand-600">◆</span>{x}</li>
              ))}
            </ul>
          </div>
          <div className="card">
            <p className="text-sm font-semibold">Question posée à l'assistant</p>
            <p className="mt-2 rounded-xl bg-slate-100 p-3 text-sm dark:bg-white/10">« Quels antipaludiques dois-je commander cette semaine ? »</p>
            <p className="mt-4 text-sm font-semibold text-brand-600">Réponse</p>
            <p className="mt-2 text-sm muted">
              Sur 30 jours, l'ACT 20/120 progresse de 24 %. Stock actuel : 15 boîtes, couverture 4 jours,
              délai UBIPHARM 48 h. Commande suggérée : 120 boîtes, budget 210 000 FCFA, marge attendue 138 000 FCFA.
            </p>
          </div>
        </div>
      </section>

      {/* WHATSAPP */}
      <section className="section bg-white dark:bg-white/5">
        <div className="container-x grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="mx-auto w-full max-w-sm rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-white/10 dark:bg-ink">
            {waThread.map((m, i) => (
              <div key={i} className={"mb-3 flex " + (m.from === "patient" ? "justify-start" : "justify-end")}>
                <p className={"max-w-[85%] rounded-2xl px-4 py-2 text-sm " + (m.from === "patient" ? "bg-white shadow-sm dark:bg-white/10" : "bg-brand-600 text-white")}>{m.text}</p>
              </div>
            ))}
          </div>
          <div>
            <span className="badge">Agent WhatsApp</span>
            <h2 className="h2 mt-4">Votre comptoir ouvert 24 h/24</h2>
            <p className="mt-4 muted">
              L'agent répond aux demandes de disponibilité et de prix, propose une réservation de 2 heures,
              envoie l'itinéraire et passe la main à un humain dès que la question devient pharmaceutique.
            </p>
            <div className="mt-6 grid gap-3 sm:grid-cols-2 text-sm muted">
              <p>• Réponses en français et langues locales courantes</p>
              <p>• Réservations traçables dans le dashboard</p>
              <p>• Rappels de traitement automatisés</p>
              <p>• Transfert humain en un clic</p>
            </div>
          </div>
        </div>
      </section>

      {/* PATIENT */}
      <section className="section" id="patient">
        <div className="container-x">
          <h2 className="h2">Côté patient : trouver, réserver, y aller</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[["🔎","Recherche de médicament","Par nom commercial ou DCI, avec équivalents génériques."],
              ["📍","Pharmacies proches","Les officines qui ont réellement le produit en stock."],
              ["🎟️","Réservation","Réf. valable 2 heures, sans paiement en ligne obligatoire."],
              ["🧭","Itinéraire","Ouverture directe dans l'application de cartes."],
              ["🌙","Ouvertes / de garde","Calendrier de garde à jour par ville."],
              ["⏰","Rappels de traitement","Notifications WhatsApp aux heures de prise."]].map(([i,t,d]) => (
              <div key={t} className="card"><div className="text-2xl">{i}</div>
                <h3 className="mt-3 font-semibold">{t}</h3><p className="mt-2 text-sm muted">{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* SECURITE */}
      <section className="section bg-white dark:bg-white/5" id="securite">
        <div className="container-x">
          <h2 className="h2">Les données de santé méritent mieux</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[["Chiffrement","TLS 1.3 en transit, AES-256 au repos, champs sensibles chiffrés en base."],
              ["Sauvegardes","Sauvegardes chiffrées AES-256 avec procédure de restauration vérifiée."],
              ["Rôles & permissions","Titulaire, pharmacien, préparateur, caissier, comptable — accès minimal."],
              ["Journal d'audit","Chaque accès à un dossier patient est horodaté et traçable."],
              ["Confidentialité","Principes RGPD et cadres nationaux (APDP Bénin, CDP Sénégal, ARTCI…)."],
              ["Hébergement","Isolation stricte par pharmacie, en-têtes de sécurité, limitation de débit."],
              ["Résilience","Mode hors ligne chiffré, file de synchronisation, anti-doublon."],
              ["Export","Vos données vous appartiennent : export Excel/PDF/CSV à tout moment."]].map(([t,d]) => (
              <div key={t} className="card"><h3 className="font-semibold">{t}</h3><p className="mt-2 text-sm muted">{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      {/* ROI */}
      <section className="section">
        <div className="container-x">
          <h2 className="h2">Combien pouvez-vous économiser ?</h2>
          <p className="mt-3 max-w-2xl muted">Déplacez les curseurs selon votre activité réelle.</p>
          <div className="mt-10"><RoiCalculator /></div>
        </div>
      </section>

      {/* TEMOIGNAGES */}
      <section className="section bg-white dark:bg-white/5">
        <div className="container-x">
          <h2 className="h2">Ils pilotent leur officine avec PharmaFlow AI</h2>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {testimonials.map((t) => (
              <figure key={t.nom} className="card">
                <blockquote className="text-sm">« {t.texte} »</blockquote>
                <figcaption className="mt-4 text-sm">
                  <span className="font-semibold">{t.nom}</span>
                  <span className="block muted">{t.role} — {t.ville}</span>
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
      </section>

      {/* RESSOURCES */}
      <section className="section">
        <div className="container-x">
          <h2 className="h2">Ressources</h2>
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {posts.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card block">
                <span className="badge">{p.tag}</span>
                <h3 className="mt-3 font-semibold">{p.titre}</h3>
                <p className="mt-2 text-sm muted">{p.extrait}</p>
                <p className="mt-3 text-xs muted">{p.duree} de lecture</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section">
        <div className="container-x">
          <div className="rounded-2xl bg-gradient-to-r from-brand-600 to-trust-700 p-10 text-center text-white">
            <h2 className="text-3xl font-bold">Prêt à moderniser votre officine ?</h2>
            <p className="mx-auto mt-3 max-w-xl opacity-90">14 jours d'essai, accompagnement à la reprise de votre stock, sans carte bancaire.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link href="/inscription" className="btn bg-white px-6 py-3 text-brand-700 hover:bg-slate-100">Commencer gratuitement</Link>
              <Link href="/contact" className="btn border border-white/40 px-6 py-3 text-white hover:bg-white/10">Parler à un expert</Link>
            </div>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
