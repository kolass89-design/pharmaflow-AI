import SiteShell from "@/components/site/SiteShell";
import DashboardPreview from "@/components/site/DashboardPreview";
import Link from "next/link";

export default function Page() {
  return (
    <SiteShell>
      <section className="section">
        <div className="container-x">
          <span className="badge">Démo interactive</span>
          <h1 className="h2 mt-4">Le dashboard PharmaFlow AI, en conditions réelles</h1>
          <p className="mt-4 max-w-2xl muted">
            Données fictives d'une officine de Cotonou. Naviguez librement entre les onglets, puis créez
            votre compte pour importer votre propre stock.
          </p>
          <div className="mt-10"><DashboardPreview /></div>
          <div className="mt-10 grid gap-4 sm:grid-cols-3">
            {[["Compte de démonstration","demo@pharmaflow.ai / demo1234"],
              ["Rôle","Pharmacien titulaire (accès complet)"],
              ["Réinitialisation","Les données sont remises à zéro chaque nuit"]].map(([t,d]) => (
              <div key={t} className="card"><p className="font-semibold">{t}</p><p className="mt-2 text-sm muted">{d}</p></div>
            ))}
          </div>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link href="/dashboard" className="btn-primary">Ouvrir le dashboard complet</Link>
            <Link href="/inscription" className="btn-ghost">Créer mon compte</Link>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
