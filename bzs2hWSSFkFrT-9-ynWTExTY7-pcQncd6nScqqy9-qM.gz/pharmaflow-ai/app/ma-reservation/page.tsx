import type { Metadata } from "next";
import SiteShell from "@/components/site/SiteShell";
import SuiviReservation from "@/components/patient/SuiviReservation";

export const metadata: Metadata = {
  title: "Suivre ma réservation — PharmaFlow AI",
  description: "Consultez l'état de votre réservation de médicament avec votre référence.",
};

export default function Page() {
  return (
    <SiteShell>
      <section className="section">
        <div className="container-x max-w-lg">
          <span className="badge">Suivi</span>
          <h1 className="h2 mt-4">Où en est ma réservation ?</h1>
          <p className="mt-3 muted">
            Saisissez la référence reçue lors de votre réservation (format R-ABCD1234).
          </p>
          <div className="mt-8"><SuiviReservation /></div>
        </div>
      </section>
    </SiteShell>
  );
}
