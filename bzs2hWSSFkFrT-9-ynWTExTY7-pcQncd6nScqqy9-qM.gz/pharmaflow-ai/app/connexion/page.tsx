"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Logo from "@/components/site/Logo";

export default function Page() {
  const r = useRouter();
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true); setErr("");
    const fd = new FormData(e.currentTarget);
    const res = await fetch("/api/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: fd.get("email"), password: fd.get("password") }),
    });
    setLoading(false);
    if (res.ok) r.push("/dashboard"); else setErr("Identifiants incorrects. Essayez demo@pharmaflow.ai / demo1234");
  }
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex items-center justify-center p-8">
        <form onSubmit={submit} className="w-full max-w-sm">
          <Link href="/"><Logo /></Link>
          <h1 className="mt-8 text-2xl font-bold">Connexion</h1>
          <p className="mt-2 text-sm muted">Accédez à votre officine.</p>
          {err && <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{err}</p>}
          <label className="mt-6 block"><span className="text-sm font-medium">Email</span>
            <input name="email" type="email" required defaultValue="demo@pharmaflow.ai" className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" /></label>
          <label className="mt-4 block"><span className="text-sm font-medium">Mot de passe</span>
            <input name="password" type="password" required defaultValue="demo1234" className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" /></label>
          <div className="mt-3 text-right"><a href="#" className="text-xs text-brand-600">Mot de passe oublié ?</a></div>
          <button disabled={loading} className="btn-primary mt-6 w-full">{loading ? "Connexion..." : "Se connecter"}</button>
          <p className="mt-6 text-center text-sm muted">Pas encore de compte ? <Link href="/inscription" className="text-brand-600 font-semibold">Créer un compte</Link></p>
        </form>
      </div>
      <div className="hidden bg-gradient-to-br from-brand-600 to-trust-700 p-12 text-white lg:flex lg:flex-col lg:justify-center">
        <h2 className="text-3xl font-bold">Votre officine, sous contrôle.</h2>
        <p className="mt-4 max-w-md opacity-90">Caisse hors ligne, stock par lots, ordonnances, IA de réapprovisionnement et agent WhatsApp — dans une seule interface en français.</p>
        <ul className="mt-8 space-y-2 text-sm opacity-90">
          <li>✓ Données chiffrées et sauvegardées chaque jour</li>
          <li>✓ Support francophone 6 j/7</li>
          <li>✓ 180+ officines en Afrique de l'Ouest et centrale</li>
        </ul>
      </div>
    </div>
  );
}
