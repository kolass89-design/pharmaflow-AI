import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import { posts } from "@/lib/mock";

export default function Page() {
  return (
    <SiteShell>
      <section className="section">
        <div className="container-x">
          <span className="badge">Ressources</span>
          <h1 className="h2 mt-4">Guides pratiques pour l'officine</h1>
          <p className="mt-4 max-w-2xl muted">Méthodes concrètes, adaptées au contexte des pharmacies d'Afrique de l'Ouest et centrale.</p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2">
            {posts.map(p => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="card block">
                <span className="badge">{p.tag}</span>
                <h2 className="mt-3 text-lg font-semibold">{p.titre}</h2>
                <p className="mt-2 text-sm muted">{p.extrait}</p>
                <p className="mt-4 text-xs muted">{p.duree} de lecture · Lire →</p>
              </Link>
            ))}
          </div>
          <div className="mt-12 card">
            <h2 className="text-lg font-semibold">Recevoir les guides par email</h2>
            <p className="mt-2 text-sm muted">Un email utile par mois, jamais de spam.</p>
            <form className="mt-4 flex flex-col gap-3 sm:flex-row">
              <input type="email" required placeholder="vous@officine.bj" className="flex-1 rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />
              <button className="btn-primary">S'abonner</button>
            </form>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
