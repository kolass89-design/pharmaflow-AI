import SiteShell from "@/components/site/SiteShell";
import GuardsList from "@/components/site/GuardsList";
import { getPublicGuards } from "@/lib/queries";
import { guards as fallback } from "@/lib/mock";

export const revalidate = 300;   // régénéré toutes les 5 minutes

export default async function Page() {
  let data: { pharmacie: string; ville: string; quartier: string; tel: string; periode: string }[] = [];
  try {
    data = await getPublicGuards();
  } catch {
    data = [];   // la page publique doit rester disponible même si la base est injoignable
  }
  const rows = data.length ? data : fallback;

  return (
    <SiteShell>
      <section className="border-b border-slate-200 bg-brand-50/60 py-16 dark:border-white/10 dark:bg-brand-900/10">
        <div className="container-x">
          <span className="badge">Service public</span>
          <h1 className="h2 mt-4">Pharmacies de garde</h1>
          <p className="mt-4 max-w-2xl muted">
            Calendrier publié par les officines partenaires, mis à jour en continu.
          </p>
        </div>
      </section>
      <section className="section"><div className="container-x"><GuardsList rows={rows} /></div></section>
    </SiteShell>
  );
}
