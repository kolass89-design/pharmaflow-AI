import { redirect } from "next/navigation";
import Link from "next/link";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import { SalesArea } from "@/components/dashboard/Charts";
import { getSession } from "@/lib/auth";
import { getDashboardData } from "@/lib/queries";
import { fcfa } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const d = await getDashboardData(s.pharmacyId);

  const dateStr = new Intl.DateTimeFormat("fr-FR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }).format(new Date());

  return (
    <Shell title="Tableau de bord" subtitle={`Données réelles · ${dateStr}`}>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Chiffre d'affaires du jour" value={fcfa(d.caToday)}
          delta={`${d.variation >= 0 ? "+" : ""}${d.variation} % vs hier`} />
        <Kpi label="Ventes du jour" value={String(d.salesCount)}
          delta={`Panier moyen ${fcfa(d.avgBasket)}`} tone="trust" />
        <Kpi label="Ordonnances du jour" value={String(d.prescriptionsToday)}
          delta={`${d.pendingPrescriptions} en attente`} tone="trust" />
        <Kpi label="Alertes" value={String(d.lowStock.length + d.expiring.length)}
          delta={`${d.lowStock.length} ruptures · ${d.expiring.length} péremptions`} tone="rose" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Ventes des 7 derniers jours" className="lg:col-span-2">
          {d.salesWeek.length ? <SalesArea data={d.salesWeek} />
            : <p className="text-sm muted">Aucune vente enregistrée sur la période.</p>}
        </Card>
        <Card title="Recommandations IA" action={<Link href="/dashboard/ia" className="text-xs font-semibold text-brand-600">Tout voir</Link>}>
          <ul className="space-y-3">
            {d.recos.map(r => (
              <li key={r.id} className="rounded-xl border border-slate-200 p-3 dark:border-white/10">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold">{r.title}</p>
                  <span className="badge shrink-0">{r.severity}</span>
                </div>
                <p className="mt-1 text-xs muted">{r.detail}</p>
              </li>
            ))}
            {!d.recos.length && <p className="text-sm muted">Aucune recommandation active.</p>}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Presque en rupture" action={<Link href="/dashboard/stock" className="text-xs font-semibold text-brand-600">Stock</Link>}>
          <ul className="space-y-2 text-sm">
            {d.lowStock.map(p => (
              <li key={p.id} className="flex items-center justify-between gap-2 rounded-xl bg-rose-50/70 px-3 py-2 dark:bg-rose-500/10">
                <span>{p.nom}</span>
                <span className="shrink-0 font-semibold text-rose-600">{p.stock} / seuil {p.seuil}</span>
              </li>
            ))}
            {!d.lowStock.length && <p className="text-sm muted">Aucun produit sous le seuil. 👍</p>}
          </ul>
        </Card>
        <Card title="Péremptions sous 90 jours">
          <ul className="space-y-2 text-sm">
            {d.expiring.map(b => (
              <li key={b.id} className="flex items-center justify-between gap-2 rounded-xl bg-amber-50/70 px-3 py-2 dark:bg-amber-500/10">
                <span>{b.nom} · {b.lot}</span>
                <span className="shrink-0 font-semibold text-amber-700">{b.joursRestants} j</span>
              </li>
            ))}
            {!d.expiring.length && <p className="text-sm muted">Aucun lot proche de la péremption.</p>}
          </ul>
        </Card>
      </div>
    </Shell>
  );
}
