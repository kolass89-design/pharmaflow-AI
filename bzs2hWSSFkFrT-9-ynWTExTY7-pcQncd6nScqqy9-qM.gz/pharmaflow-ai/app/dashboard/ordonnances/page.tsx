import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import { getSession } from "@/lib/auth";
import { getPrescriptions, getPatients, getStock } from "@/lib/queries";
import PrescriptionForm from "@/components/dashboard/PrescriptionForm";
import PrescriptionActions from "@/components/dashboard/PrescriptionActions";

export const dynamic = "force-dynamic";

const STATUTS: Record<string, string> = { PENDING: "En attente", PARTIAL: "Partielle", SERVED: "Servie", ARCHIVED: "Archivée" };

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [rows, patients, stock] = await Promise.all([
    getPrescriptions(s.pharmacyId), getPatients(s.pharmacyId), getStock(s.pharmacyId),
  ]);
  const today = new Date().toISOString().slice(0, 10);

  return (
    <Shell title="Ordonnances" subtitle="Saisie, OCR, contrôle des interactions et archivage chiffré">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Total enregistrées" value={String(rows.length)} />
        <Kpi label="Du jour" value={String(rows.filter(r => r.date === today).length)} tone="trust" />
        <Kpi label="En attente" value={String(rows.filter(r => r.statut === "PENDING").length)} tone="amber" />
        <Kpi label="Servies" value={String(rows.filter(r => r.statut === "SERVED").length)} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="File d'ordonnances" className="lg:col-span-2"
          action={<div className="flex gap-2"><PrescriptionForm patients={patients.map(p => ({ id: p.id, nom: p.nom }))} products={stock.map(p => ({ id: p.id, nom: p.nom }))} /></div>}>
          <ul className="space-y-3">
            {rows.map(o => (
              <li key={o.id} className="rounded-xl border border-slate-200 p-4 text-sm dark:border-white/10">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-semibold">{o.patient}</span>
                  <span className="badge">{STATUTS[o.statut] ?? o.statut}</span>
                </div>
                <p className="mt-1 text-xs muted">Prescripteur {o.medecin} · {o.date} · {o.items} ligne{o.items > 1 ? "s" : ""}</p>
                {o.notes && <p className="mt-2 rounded-lg bg-slate-100 p-2 text-xs muted dark:bg-white/5">{o.notes}</p>}
                <div className="mt-3"><PrescriptionActions id={o.id} statut={o.statut} /></div>
              </li>
            ))}
            {!rows.length && <p className="text-sm muted">Aucune ordonnance enregistrée.</p>}
          </ul>
        </Card>
        <Card title="Capture OCR">
          <div className="grid h-32 place-items-center rounded-xl border-2 border-dashed border-slate-300 text-sm muted dark:border-white/15">
            Bientôt disponible
          </div>
          <p className="mt-3 rounded-xl bg-slate-100 p-3 text-xs muted dark:bg-white/5">
            La reconnaissance automatique des ordonnances photographiées est en cours de
            développement. En attendant, saisissez les lignes prescrites via « + Nouvelle » :
            le contrôle des allergies du patient s'applique dès la saisie.
          </p>
        </Card>
      </div>
    </Shell>
  );
}
