import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import ConversationsView from "@/components/dashboard/ConversationsView";
import { getSession } from "@/lib/auth";
import { getConversations, getReservations } from "@/lib/queries";
import ReservationsPanel from "@/components/dashboard/ReservationsPanel";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [convs, pharmacy, listeReservations] = await Promise.all([
    getConversations(s.pharmacyId),
    prisma.pharmacy.findUnique({ where: { id: s.pharmacyId }, select: { whatsappNo: true } }),
    getReservations(s.pharmacyId),
  ]);
  const reservations = listeReservations.length;
  const msgCount = convs.reduce((t, c) => t + c.messages.length, 0);

  return (
    <Shell title="Agent WhatsApp" subtitle={`Numéro connecté : ${pharmacy?.whatsappNo ?? "non configuré"}`}>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Conversations" value={String(convs.length)} />
        <Kpi label="Messages échangés" value={String(msgCount)} tone="trust" />
        <Kpi label="Réservations créées" value={String(reservations)} tone="trust" />
        <Kpi label="Transferts humains requis" value={String(convs.filter(c => c.statut === "HUMAN_REQUIRED").length)} tone="amber" />
      </div>
      <div className="mt-6"><ReservationsPanel reservations={listeReservations} /></div>
      <div className="mt-6"><ConversationsView convs={convs} /></div>
      <Card className="mt-6" title="Réponses automatiques">
        <ul className="space-y-2 text-sm muted">
          <li>• Disponibilité produit → interrogation du stock temps réel puis prix TTC.</li>
          <li>• Réservation → blocage du stock pendant 2 heures avec référence unique.</li>
          <li>• Horaires et adresse → réponse instantanée avec lien d'itinéraire.</li>
          <li>• Question posologique ou pathologie → transfert immédiat à un pharmacien.</li>
        </ul>
      </Card>
    </Shell>
  );
}
