import { redirect } from "next/navigation";
import Shell from "@/components/dashboard/Shell";
import SettingsView from "@/components/dashboard/SettingsView";
import { getSession } from "@/lib/auth";
import { getSettings } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const d = await getSettings(s.pharmacyId);

  return (
    <Shell title="Paramètres" subtitle="Configuration de l'officine, des accès et de la sécurité">
      <SettingsView
        pharmacy={{
          name: d.pharmacy?.name ?? "", city: d.pharmacy?.city ?? "",
          district: d.pharmacy?.district ?? "", country: d.pharmacy?.country ?? "BJ",
          licenseNo: d.pharmacy?.licenseNo ?? "", phone: d.pharmacy?.phone ?? "",
          currency: d.pharmacy?.currency ?? "XOF",
          openingHours: (d.pharmacy?.openingHours as Record<string, string>) ?? {},
        }}
        members={d.members}
        audit={d.audit}
        subscription={d.subscription ? {
          plan: d.subscription.plan, status: d.subscription.status, amount: d.subscription.amount,
          trialEndsAt: d.subscription.trialEndsAt?.toISOString().slice(0, 10) ?? null,
        } : null}
      />
    </Shell>
  );
}
