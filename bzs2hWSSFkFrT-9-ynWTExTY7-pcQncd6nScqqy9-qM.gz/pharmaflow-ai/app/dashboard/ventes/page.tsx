import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import Pos from "@/components/dashboard/Pos";
import { getSession } from "@/lib/auth";
import { getPosProducts, getSalesSummary } from "@/lib/queries";
import { fcfa } from "@/lib/utils";

export const dynamic = "force-dynamic";

const LABELS: Record<string, string> = {
  CASH: "Espèces", MTN_MOMO: "MTN MoMo", MOOV_MONEY: "Moov Money",
  ORANGE_MONEY: "Orange Money", CELTIIS_CASH: "Celtiis Cash", WAVE: "Wave",
  CARD: "Carte", BANK_TRANSFER: "Virement", INSURANCE: "Assurance",
};

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [products, sum] = await Promise.all([getPosProducts(s.pharmacyId), getSalesSummary(s.pharmacyId)]);

  return (
    <Shell title="Caisse / Ventes" subtitle={`Caissier : ${s.name} · les ventes sont enregistrées en base`}>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Encaissé aujourd'hui" value={fcfa(sum.encaisse)} delta={`${sum.tickets} tickets`} />
        <Kpi label="Espèces" value={fcfa(sum.cash)} tone="trust" />
        <Kpi label="Mobile Money" value={fcfa(sum.mobile)} tone="trust" />
        <Kpi label="Références disponibles" value={String(products.length)} tone="amber" />
      </div>

      <div className="mt-6"><Pos products={products} /></div>

      <Card className="mt-6" title="Derniers tickets">
        <ul className="space-y-2 text-sm">
          {sum.derniers.map(t => (
            <li key={t.reference} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 dark:border-white/5">
              <span className="font-medium">{t.reference}</span>
              <span className="muted">{t.heure} · {LABELS[t.method] ?? t.method}</span>
              <span className="font-semibold">{fcfa(t.total)}</span>
            </li>
          ))}
          {!sum.derniers.length && <p className="text-sm muted">Aucune vente enregistrée.</p>}
        </ul>
      </Card>
    </Shell>
  );
}
