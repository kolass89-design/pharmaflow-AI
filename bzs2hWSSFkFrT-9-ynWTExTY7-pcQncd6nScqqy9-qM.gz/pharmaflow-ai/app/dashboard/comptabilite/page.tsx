import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import { RevenueBars } from "@/components/dashboard/Charts";
import { getSession } from "@/lib/auth";
import { getAccounting } from "@/lib/queries";
import { fcfa } from "@/lib/utils";

export const dynamic = "force-dynamic";

const LABELS: Record<string, string> = {
  CASH: "Espèces", MTN_MOMO: "MTN MoMo", MOOV_MONEY: "Moov Money",
  ORANGE_MONEY: "Orange Money", CELTIIS_CASH: "Celtiis Cash", WAVE: "Wave",
  CARD: "Carte", BANK_TRANSFER: "Virement", INSURANCE: "Assurance",
};

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const a = await getAccounting(s.pharmacyId);

  return (
    <Shell title="Comptabilité" subtitle="Recettes, dépenses, marges et exports — calculés sur les ventes réelles">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Recettes du mois" value={fcfa(a.recettesMois)} />
        <Kpi label="Dépenses saisies" value={fcfa(a.depensesMois)} tone="amber" />
        <Kpi label="Résultat" value={fcfa(a.benefice)} tone={a.benefice >= 0 ? "brand" : "rose"} />
        <Kpi label="Marge" value={`${a.marge} %`} tone="trust" />
      </div>

      <Card className="mt-6" title="Recettes par mois"
        action={<div className="flex gap-2">
          <a href="/api/accounting/export?type=ventes" className="btn-ghost !py-2 !text-xs">Export ventes</a>
          <a href="/api/accounting/export?type=depenses" className="btn-ghost !py-2 !text-xs">Export dépenses</a>
        </div>}>
        {a.serie.length ? <RevenueBars data={a.serie} /> : <p className="text-sm muted">Pas encore de données.</p>}
      </Card>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Dépenses par catégorie">
          <ul className="space-y-2 text-sm">
            {a.depenses.map(d => (
              <li key={d.categorie} className="flex justify-between border-b border-slate-100 pb-2 dark:border-white/5">
                <span className="muted">{d.categorie}</span><span className="font-medium">{fcfa(d.montant)}</span>
              </li>
            ))}
            {!a.depenses.length && <p className="text-sm muted">Aucune dépense saisie.</p>}
          </ul>
        </Card>
        <Card title="Encaissements par moyen de paiement">
          <ul className="space-y-2 text-sm">
            {a.paiements.map(p => (
              <li key={p.method} className="flex items-center gap-3">
                <span className="w-28 shrink-0 muted">{LABELS[p.method] ?? p.method}</span>
                <span className="h-2 flex-1 rounded-full bg-slate-100 dark:bg-white/10">
                  <span className="block h-2 rounded-full bg-brand-600" style={{ width: `${p.part}%` }} />
                </span>
                <span className="w-12 shrink-0 text-right font-medium">{p.part} %</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </Shell>
  );
}
