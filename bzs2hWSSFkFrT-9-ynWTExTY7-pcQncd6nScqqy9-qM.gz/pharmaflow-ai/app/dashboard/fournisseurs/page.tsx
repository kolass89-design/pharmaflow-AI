import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import { getSession } from "@/lib/auth";
import { getSuppliers, getPurchaseOrders } from "@/lib/queries";
import { fcfa } from "@/lib/utils";
import AutoOrderButton from "@/components/dashboard/AutoOrderButton";
import SupplierForm from "@/components/dashboard/SupplierForm";

export const dynamic = "force-dynamic";

const PO: Record<string, string> = {
  DRAFT: "Brouillon", SENT: "Envoyée", PREPARING: "En préparation",
  IN_TRANSIT: "En transit", PARTIAL: "Partielle", RECEIVED: "Livrée", CANCELLED: "Annulée",
};

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [suppliers, orders] = await Promise.all([getSuppliers(s.pharmacyId), getPurchaseOrders(s.pharmacyId)]);
  const encours = suppliers.reduce((t, x) => t + x.encours, 0);
  const enCours = orders.filter(o => !["RECEIVED", "CANCELLED"].includes(o.statut)).length;

  return (
    <Shell title="Fournisseurs" subtitle="Grossistes, bons de commande, livraisons et factures">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Fournisseurs actifs" value={String(suppliers.filter(x => x.statut === "Actif").length)} />
        <Kpi label="Commandes en cours" value={String(enCours)} tone="trust" />
        <Kpi label="Encours total" value={fcfa(encours)} tone="amber" />
        <Kpi label="Références sourcées" value={String(suppliers.reduce((t, x) => t + x.references, 0))} tone="trust" />
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Grossistes" action={<SupplierForm />}>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="text-xs uppercase muted"><tr><th className="py-2">Nom</th><th>Pays</th><th>Délai</th><th>Réf.</th><th>Encours</th></tr></thead>
              <tbody>
                {suppliers.map(x => (
                  <tr key={x.id} className="border-t border-slate-100 dark:border-white/5">
                    <td className="py-2.5 font-medium">{x.nom}</td><td className="muted">{x.pays}</td>
                    <td className="muted">{x.delai}</td><td className="muted">{x.references}</td>
                    <td>{fcfa(x.encours)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
        <Card title="Bons de commande" action={<AutoOrderButton />}>
          <ul className="space-y-2 text-sm">
            {orders.map(o => (
              <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-slate-200 p-3 dark:border-white/10">
                <span className="font-medium">{o.id} · {o.fournisseur}</span>
                <span className="text-xs muted">{o.date} · {fcfa(o.montant)}</span>
                <span className="badge">{PO[o.statut] ?? o.statut}</span>
              </li>
            ))}
            {!orders.length && <p className="text-sm muted">Aucune commande.</p>}
          </ul>
        </Card>
      </div>
    </Shell>
  );
}
