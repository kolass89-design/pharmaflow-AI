import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import { ForecastLines } from "@/components/dashboard/Charts";
import AiAssistant from "@/components/dashboard/AiAssistant";
import { getSession } from "@/lib/auth";
import { getAiData, getLowStockProducts, getExpiringBatches } from "@/lib/queries";
import { fcfa } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [d, low, exp] = await Promise.all([
    getAiData(s.pharmacyId), getLowStockProducts(s.pharmacyId), getExpiringBatches(s.pharmacyId, 90),
  ]);

  return (
    <Shell title="Intelligence artificielle" subtitle="Prévisions et analyses calculées sur vos ventes réelles">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Recommandations actives" value={String(d.recos.length)} />
        <Kpi label="Réappro. à déclencher" value={String(low.length)} tone="rose" />
        <Kpi label="Lots à écouler (90 j)" value={String(exp.length)} tone="amber" />
        <Kpi label="Semaines d'historique" value={String(d.forecast.filter(f => f.reel).length)} tone="trust" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card title="Prévision de chiffre d'affaires hebdomadaire" className="lg:col-span-2">
          <ForecastLines data={d.forecast} />
          <p className="mt-2 text-xs muted">
            Modèle actuel : moyenne mobile + tendance linéaire sur l'historique réel.
            À remplacer par un modèle saisonnier (Prophet/LightGBM) dès 6 mois de données.
          </p>
        </Card>
        <Card title="Recommandations">
          <ul className="space-y-3">
            {d.recos.map(r => (
              <li key={r.id} className="rounded-xl border border-slate-200 p-3 dark:border-white/10">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-semibold">{r.title}</p>
                  <span className="badge shrink-0">{r.severity}</span>
                </div>
                <p className="mt-1 text-xs muted">{r.detail}</p>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card title="Produits les plus rentables (marge réelle générée)">
          <ul className="space-y-2 text-sm">
            {d.topProduits.map(p => (
              <li key={p.nom} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 dark:border-white/5">
                <span className="font-medium">{p.nom}</span>
                <span className="text-xs muted">{p.qte} unités</span>
                <span className="font-semibold text-brand-600">{fcfa(p.marge)}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Suggestions de réapprovisionnement">
          <ul className="space-y-2 text-sm">
            {low.map(p => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-rose-50/70 px-3 py-2 dark:bg-rose-500/10">
                <span>{p.nom}</span>
                <span className="text-xs muted">{p.fournisseur}</span>
                <span className="font-semibold text-rose-600">commander {Math.max(p.seuil * 3 - p.stock, 20)}</span>
              </li>
            ))}
            {!low.length && <p className="text-sm muted">Aucun réapprovisionnement urgent.</p>}
          </ul>
        </Card>
      </div>

      <div className="mt-6"><AiAssistant /></div>
    </Shell>
  );
}
