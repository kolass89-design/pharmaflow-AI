import { redirect } from "next/navigation";
import Shell, { Card, Kpi } from "@/components/dashboard/Shell";
import StockTable from "@/components/dashboard/StockTable";
import { getSession } from "@/lib/auth";
import { getStock, getStockSummary, getRecentMovements, getSuppliers } from "@/lib/queries";
import StockActions from "@/components/dashboard/StockActions";
import { fcfa } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const [rows, sum, moves, suppliers] = await Promise.all([
    getStock(s.pharmacyId), getStockSummary(s.pharmacyId), getRecentMovements(s.pharmacyId), getSuppliers(s.pharmacyId),
  ]);
  const actions = (
    <StockActions
      suppliers={suppliers.map(x => ({ id: x.id, nom: x.nom }))}
      products={rows.map(r => ({ id: r.id, nom: r.nom, stock: r.stock }))}
    />
  );

  return (
    <Shell title="Stock" subtitle="Produits, lots, péremptions et mouvements — données réelles">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Références actives" value={String(sum.references)} />
        <Kpi label="Valeur du stock (prix d'achat)" value={fcfa(sum.valeur)} tone="trust" />
        <Kpi label="Sous le seuil" value={String(sum.sousSeuil)} tone="rose" />
        <Kpi label="Expirent sous 90 jours" value={String(sum.expirant)} tone="amber" />
      </div>

      <div className="mt-6"><StockTable rows={rows} actions={actions} /></div>

      <Card className="mt-6" title="Derniers mouvements">
        <ul className="space-y-2 text-sm">
          {moves.map(m => (
            <li key={m.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2 dark:border-white/5">
              <span className="muted">{m.date}</span>
              <span className="font-medium">{m.produit}</span>
              <span className={m.type === "IN" ? "text-brand-600" : "text-rose-600"}>
                {m.type === "IN" ? "+" : "−"}{Math.abs(m.quantite)}
              </span>
              <span className="text-xs muted">{m.motif}</span>
            </li>
          ))}
          {!moves.length && <p className="text-sm muted">Aucun mouvement enregistré.</p>}
        </ul>
      </Card>
    </Shell>
  );
}
