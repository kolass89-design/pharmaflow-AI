import { redirect } from "next/navigation";
import Shell, { Kpi } from "@/components/dashboard/Shell";
import PatientsView from "@/components/dashboard/PatientsView";
import { getSession } from "@/lib/auth";
import { getPatients } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  const patients = await getPatients(s.pharmacyId);

  return (
    <Shell title="Patients" subtitle="Dossiers, allergies, historique et rappels de traitement">
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Patients enregistrés" value={String(patients.length)} />
        <Kpi label="Suivis chroniques" value={String(patients.filter(p => p.chroniques !== "—").length)} tone="trust" />
        <Kpi label="Allergies déclarées" value={String(patients.filter(p => p.allergies !== "—").length)} tone="amber" />
        <Kpi label="Ordonnances liées" value={String(patients.reduce((s2, p) => s2 + p.ordonnances, 0))} tone="trust" />
      </div>
      <div className="mt-6"><PatientsView patients={patients} /></div>
    </Shell>
  );
}
