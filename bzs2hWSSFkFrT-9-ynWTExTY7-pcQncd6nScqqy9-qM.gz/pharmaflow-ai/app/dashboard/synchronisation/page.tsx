import { redirect } from "next/navigation";
import Shell from "@/components/dashboard/Shell";
import QueueManager from "@/components/dashboard/QueueManager";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function Page() {
  const s = await getSession();
  if (!s) redirect("/connexion");
  return (
    <Shell title="Synchronisation" subtitle="File des opérations réalisées hors connexion">
      <QueueManager />
    </Shell>
  );
}
