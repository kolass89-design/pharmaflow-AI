"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import Logo from "@/components/site/Logo";

export default function Page() {
  const r = useRouter();
  const [step, setStep] = useState(1);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [f, setF] = useState({
    fullName: "", email: "", password: "",
    pharmacyName: "", city: "", country: "BJ", whatsapp: "",
  });
  const set = (k: string, v: string) => setF(s => ({ ...s, [k]: v }));

  function next() {
    setErr("");
    if (step === 1) {
      if (!f.fullName.trim()) return setErr("Indiquez le nom du pharmacien titulaire.");
      if (!f.email.includes("@")) return setErr("Adresse email invalide.");
      if (f.password.length < 8) return setErr("Le mot de passe doit contenir au moins 8 caractères.");
    }
    if (step === 2) {
      if (!f.pharmacyName.trim()) return setErr("Indiquez le nom de la pharmacie.");
      if (!f.city.trim()) return setErr("Indiquez la ville.");
    }
    setStep(step + 1);
  }

  async function finish() {
    setBusy(true); setErr("");
    const res = await fetch("/api/auth/register", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f),
    });
    const d = await res.json();
    setBusy(false);
    if (!res.ok) return setErr(d.error ?? "Erreur lors de la création du compte.");
    r.push("/dashboard");
  }

  return (
    <div className="mx-auto flex min-h-screen max-w-lg flex-col justify-center p-6">
      <Link href="/"><Logo /></Link>
      <div className="mt-6 flex gap-2">
        {[1, 2, 3].map(s => <div key={s} className={"h-1.5 flex-1 rounded-full " + (s <= step ? "bg-brand-600" : "bg-slate-200 dark:bg-white/10")} />)}
      </div>
      <h1 className="mt-6 text-2xl font-bold">Créer votre compte</h1>
      <p className="mt-2 text-sm muted">14 jours gratuits · sans carte bancaire · étape {step}/3</p>
      {err && <p className="mt-4 rounded-xl bg-rose-50 p-3 text-sm text-rose-700">{err}</p>}

      <div className="mt-8 space-y-4">
        {step === 1 && <>
          <In label="Nom du pharmacien titulaire" v={f.fullName} on={v => set("fullName", v)} ph="Dr. Prénom Nom" />
          <In label="Email professionnel" type="email" v={f.email} on={v => set("email", v)} ph="vous@officine.bj" />
          <In label="Mot de passe" type="password" v={f.password} on={v => set("password", v)} ph="8 caractères minimum" />
        </>}
        {step === 2 && <>
          <In label="Nom de la pharmacie" v={f.pharmacyName} on={v => set("pharmacyName", v)} ph="Pharmacie Étoile" />
          <In label="Ville" v={f.city} on={v => set("city", v)} ph="Cotonou" />
          <label className="block"><span className="text-sm font-medium">Pays</span>
            <select value={f.country} onChange={e => set("country", e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent">
              {[["BJ", "Bénin"], ["TG", "Togo"], ["CI", "Côte d'Ivoire"], ["SN", "Sénégal"], ["NE", "Niger"], ["CM", "Cameroun"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select></label>
          <In label="Numéro WhatsApp de l'officine" type="tel" v={f.whatsapp} on={v => set("whatsapp", v)} ph="+229 ..." />
        </>}
        {step === 3 && <>
          <div className="rounded-xl border border-slate-200 p-4 text-sm dark:border-white/10">
            <p className="font-semibold">Récapitulatif</p>
            <ul className="mt-3 space-y-1 muted">
              <li>Titulaire : {f.fullName}</li>
              <li>Email : {f.email}</li>
              <li>Pharmacie : {f.pharmacyName}, {f.city}</li>
              <li>Formule : Starter — essai gratuit 14 jours</li>
            </ul>
          </div>
          <label className="flex gap-3 text-xs muted"><input type="checkbox" defaultChecked className="mt-0.5" />
            J'accepte les conditions d'utilisation et la politique de confidentialité des données patients.</label>
        </>}
      </div>

      <div className="mt-8 flex gap-3">
        {step > 1 && <button onClick={() => setStep(step - 1)} className="btn-ghost flex-1">Retour</button>}
        {step < 3
          ? <button onClick={next} className="btn-primary flex-1">Continuer</button>
          : <button onClick={finish} disabled={busy} className="btn-primary flex-1 disabled:opacity-50">{busy ? "Création…" : "Créer mon officine"}</button>}
      </div>
      <p className="mt-6 text-center text-sm muted">Déjà inscrit ? <Link href="/connexion" className="font-semibold text-brand-600">Se connecter</Link></p>
    </div>
  );
}

function In({ label, v, on, type = "text", ph }: { label: string; v: string; on: (v: string) => void; type?: string; ph?: string }) {
  return <label className="block"><span className="text-sm font-medium">{label}</span>
    <input type={type} value={v} placeholder={ph} onChange={e => on(e.target.value)}
      className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" /></label>;
}
