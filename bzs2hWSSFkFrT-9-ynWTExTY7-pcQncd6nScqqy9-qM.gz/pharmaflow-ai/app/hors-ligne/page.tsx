import Link from "next/link";
import Logo from "@/components/site/Logo";

export const metadata = { title: "Hors ligne — PharmaFlow AI" };

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-6 text-center">
      <Logo />
      <div className="mt-8 max-w-md">
        <p className="text-5xl">📴</p>
        <h1 className="mt-4 text-2xl font-bold">Pas de connexion</h1>
        <p className="mt-3 muted">
          Cette page n'a pas encore été consultée sur cet appareil, elle n'est donc pas
          disponible hors ligne. La caisse et le stock, eux, restent utilisables.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link href="/dashboard/ventes" className="btn-primary">Aller à la caisse</Link>
          <Link href="/dashboard/synchronisation" className="btn-ghost">Voir la file d'attente</Link>
        </div>
        <p className="mt-8 text-xs muted">
          Vos ventes réalisées hors connexion sont conservées sur cet appareil et seront
          envoyées automatiquement dès le retour du réseau.
        </p>
      </div>
    </div>
  );
}
