import "./globals.css";
import type { Metadata, Viewport } from "next";

export const metadata: Metadata = {
  title: "PharmaFlow AI — La pharmacie intelligente pour l'Afrique francophone",
  description:
    "Logiciel SaaS de gestion d'officine : caisse POS hors ligne, stock et lots, ordonnances, patients, comptabilité, IA prédictive et agent WhatsApp. Bénin, Togo, Côte d'Ivoire, Sénégal, Niger, Cameroun.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "PharmaFlow AI", statusBarStyle: "default" },
  icons: {
    icon: [
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#128357" },
    { media: "(prefers-color-scheme: dark)", color: "#0b1620" },
  ],
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}
