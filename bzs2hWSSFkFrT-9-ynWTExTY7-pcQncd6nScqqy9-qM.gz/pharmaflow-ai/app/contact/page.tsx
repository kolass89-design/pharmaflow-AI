import SiteShell from "@/components/site/SiteShell";

export default function Page() {
  return (
    <SiteShell>
      <section className="section">
        <div className="container-x grid gap-10 lg:grid-cols-2">
          <div>
            <span className="badge">Contact</span>
            <h1 className="h2 mt-4">Parlons de votre officine</h1>
            <p className="mt-4 muted">Réponse sous 24 h ouvrées, en français.</p>
            <div className="mt-8 space-y-4 text-sm">
              <p><strong>WhatsApp :</strong> <a className="text-brand-600" href="https://wa.me/22900000000">+229 00 00 00 00</a></p>
              <p><strong>Email :</strong> <a className="text-brand-600" href="mailto:bonjour@pharmaflow.ai">bonjour@pharmaflow.ai</a></p>
              <p><strong>Bureaux :</strong> Cotonou (Bénin) · Abidjan (Côte d'Ivoire)</p>
              <p><strong>Horaires :</strong> lundi – samedi, 8 h – 19 h GMT+1</p>
            </div>
            <div id="mentions" className="mt-12 space-y-6 text-sm muted">
              <div><h2 className="font-semibold text-ink dark:text-slate-100">Mentions légales</h2>
                <p className="mt-2">PharmaFlow AI — éditeur de logiciel de gestion d'officine. Société en cours d'immatriculation, Cotonou, Bénin. Directeur de la publication : la direction de PharmaFlow AI.</p></div>
              <div id="confidentialite"><h2 className="font-semibold text-ink dark:text-slate-100">Confidentialité</h2>
                <p className="mt-2">Les données de santé sont traitées pour le seul compte de la pharmacie responsable de traitement. Chiffrement en transit et au repos, cloisonnement par établissement, journal d'audit, suppression ou export sur demande.</p></div>
              <div id="cgu"><h2 className="font-semibold text-ink dark:text-slate-100">Conditions d'utilisation</h2>
                <p className="mt-2">Abonnement sans engagement, disponibilité cible 99,9 %, sauvegardes quotidiennes. Le logiciel est un outil de gestion et ne se substitue pas au jugement professionnel du pharmacien.</p></div>
            </div>
          </div>
          <form className="card h-fit space-y-4">
            {[["Nom complet","text","Dr. Prénom Nom"],["Email professionnel","email","vous@officine.bj"],["Téléphone / WhatsApp","tel","+229 ..."],["Nom de la pharmacie","text","Pharmacie ..."]].map(([l,t,ph]) => (
              <label key={l} className="block">
                <span className="text-sm font-medium">{l}</span>
                <input type={t} placeholder={ph} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />
              </label>
            ))}
            <label className="block">
              <span className="text-sm font-medium">Pays</span>
              <select className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent">
                {["Bénin","Togo","Côte d'Ivoire","Sénégal","Niger","Cameroun","Autre"].map(p => <option key={p}>{p}</option>)}
              </select>
            </label>
            <label className="block">
              <span className="text-sm font-medium">Votre message</span>
              <textarea rows={4} className="mt-1 w-full rounded-xl border border-slate-300 px-4 py-3 text-sm dark:border-white/15 dark:bg-transparent" />
            </label>
            <button className="btn-primary w-full">Envoyer</button>
          </form>
        </div>
      </section>
    </SiteShell>
  );
}
