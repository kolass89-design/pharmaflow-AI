import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, int, date, assertOwnership, ApiError, throttle } from "@/lib/api";

/**
 * Réception de marchandise : crée un lot, incrémente le stock et trace le mouvement.
 * Peut être rattachée à un bon de commande (réception totale ou partielle).
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("stock.move");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const productId = await assertOwnership("product", str(b.productId, "Produit")!, s.pharmacyId);
    const quantity = int(b.quantity, "Quantité", { min: 1 })!;
    const expiryDate = date(b.expiryDate, "Date de péremption")!;
    if (expiryDate.getTime() < Date.now()) throw new ApiError(422, "La date de péremption est déjà dépassée.");
    const batchNo = str(b.batchNo, "Numéro de lot")!;
    const costPrice = int(b.costPrice, "Prix d'achat unitaire", { optional: true });

    const result = await prisma.$transaction(async (tx) => {
      // Un même lot reçu deux fois est cumulé plutôt que dupliqué.
      const existing = await tx.productBatch.findFirst({ where: { productId, batchNo } });
      const batch = existing
        ? await tx.productBatch.update({ where: { id: existing.id }, data: { quantity: { increment: quantity } } })
        : await tx.productBatch.create({ data: { productId, batchNo, quantity, expiryDate, costPrice } });

      await tx.stockMovement.create({
        data: {
          pharmacyId: s.pharmacyId, productId, batchId: batch.id, type: "IN", quantity,
          reason: str(b.reason, "Motif", { optional: true }) ?? "Réception fournisseur",
          reference: str(b.reference, "Référence", { optional: true }),
          userId: s.userId,
        },
      });

      if (b.purchaseOrderId) {
        const po = await tx.purchaseOrder.findFirst({
          where: { id: String(b.purchaseOrderId), pharmacyId: s.pharmacyId }, include: { items: true },
        });
        if (po) {
          const item = po.items.find(i => i.productId === productId);
          if (item) {
            await tx.purchaseOrderItem.update({
              where: { id: item.id }, data: { received: Math.min(item.quantity, item.received + quantity) },
            });
          }
          const items = await tx.purchaseOrderItem.findMany({ where: { orderId: po.id } });
          const complete = items.every(i => i.received >= i.quantity);
          const started = items.some(i => i.received > 0);
          await tx.purchaseOrder.update({
            where: { id: po.id },
            data: { status: complete ? "RECEIVED" : started ? "PARTIAL" : po.status, receivedAt: complete ? new Date() : null },
          });
        }
      }

      const total = await tx.productBatch.aggregate({ where: { productId }, _sum: { quantity: true } });
      return { batchId: batch.id, stock: total._sum.quantity ?? 0 };
    });

    await audit(s, "STOCK_RECEIVE", "Product", productId, { quantity, batchNo });
    return result;
  });
}
