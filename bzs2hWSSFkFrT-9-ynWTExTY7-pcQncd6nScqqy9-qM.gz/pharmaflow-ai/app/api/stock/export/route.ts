import { NextResponse } from "next/server";
import { requirePermission } from "@/lib/api";
import { getStock } from "@/lib/queries";

/** Échappe une cellule CSV (guillemets doublés si le contenu en contient). */
const cell = (v: unknown) => {
  const s = String(v ?? "");
  return /[";\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/**
 * Export du stock au format CSV.
 * Le même format que l'import : ce qui sort peut être réimporté après correction
 * dans Excel — c'est le mode opératoire réel des officines.
 */
export async function GET() {
  let s;
  try { s = await requirePermission("stock.read"); }
  catch (e: any) { return NextResponse.json({ error: e.message ?? "Accès refusé" }, { status: e.status ?? 403 }); }
  const rows = await getStock(s.pharmacyId);

  const head = ["Nom", "DCI", "Lot", "Peremption", "Quantite", "Seuil", "Prix achat", "Prix vente", "Marge %", "Fournisseur"];
  const lines = rows.map(r => [
    r.nom, r.dci, r.lot, r.expiration, r.stock, r.seuil, r.achat, r.vente, r.marge, r.fournisseur,
  ].map(cell).join(";"));

  const csv = "\uFEFF" + [head.join(";"), ...lines].join("\r\n");
  const date = new Date().toISOString().slice(0, 10);

  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="stock-pharmaflow-${date}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
