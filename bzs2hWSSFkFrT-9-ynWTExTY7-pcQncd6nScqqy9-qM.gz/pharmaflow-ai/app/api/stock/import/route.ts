import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, ApiError, throttle } from "@/lib/api";
import { parseCatalogCsv, templateCsv } from "@/lib/import";

const MAX_BYTES = 2 * 1024 * 1024;   // 2 Mo : largement au-delà d'un catalogue d'officine

/** Modèle CSV à télécharger. */
export async function GET() {
  try { await requirePermission("stock.read"); }
  catch (e: any) { return NextResponse.json({ error: e.message ?? "Accès refusé" }, { status: e.status ?? 403 }); }
  return new NextResponse(templateCsv(), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="modele-catalogue-pharmaflow.csv"',
    },
  });
}

/**
 * Import du catalogue.
 * Deux temps : `dryRun` renvoie une prévisualisation et les anomalies,
 * puis la confirmation applique réellement. On n'écrase jamais un catalogue
 * de plusieurs centaines de références sans que le pharmacien ait vu le résultat.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("stock.write");
    await throttle(s, "import");

    const form = await req.formData().catch(() => null);
    if (!form) throw new ApiError(422, "Envoi invalide : un fichier est attendu.");
    const file = form.get("file");
    if (!(file instanceof File)) throw new ApiError(422, "Aucun fichier reçu.");
    if (file.size > MAX_BYTES) throw new ApiError(413, "Fichier trop volumineux (2 Mo maximum).");
    if (file.size === 0) throw new ApiError(422, "Le fichier est vide.");

    const dryRun = form.get("dryRun") === "true";
    const mode = String(form.get("mode") ?? "create");   // create | upsert

    const parsed = parseCatalogCsv(await file.text());
    if (!parsed.rows.length) {
      throw new ApiError(422, parsed.issues[0]?.message ?? "Aucune ligne exploitable dans ce fichier.");
    }

    if (dryRun) {
      // Croisement avec l'existant pour annoncer créations vs mises à jour.
      const barcodes = parsed.rows.map(r => r.barcode).filter(Boolean) as string[];
      const noms = parsed.rows.map(r => r.name);
      const existants = await prisma.product.findMany({
        where: { pharmacyId: s.pharmacyId, OR: [{ barcode: { in: barcodes } }, { name: { in: noms } }] },
        select: { name: true, barcode: true },
      });
      const cles = new Set(existants.flatMap(e => [e.barcode, e.name.toLowerCase()].filter(Boolean) as string[]));
      const dejaLa = parsed.rows.filter(r => cles.has(r.barcode ?? "") || cles.has(r.name.toLowerCase())).length;

      return {
        dryRun: true,
        resume: {
          lignesLues: parsed.totalLignes,
          valides: parsed.rows.length,
          aCreer: parsed.rows.length - dejaLa,
          aMettreAJour: dejaLa,
          anomalies: parsed.issues.length,
          avecStock: parsed.rows.filter(r => r.quantity > 0).length,
          valeurStock: parsed.rows.reduce((t, r) => t + r.purchasePrice * r.quantity, 0),
        },
        colonnesReconnues: parsed.colonnesReconnues,
        apercu: parsed.rows.slice(0, 10),
        anomalies: parsed.issues.slice(0, 50),
      };
    }

    // ── Application réelle ──
    const fournisseurs = await prisma.supplier.findMany({
      where: { pharmacyId: s.pharmacyId }, select: { id: true, name: true },
    });
    const parNom = new Map(fournisseurs.map(f => [f.name.toLowerCase(), f.id]));

    let crees = 0, majs = 0, lots = 0, ignores = 0;

    // Traitement par paquets : une transaction unique de 5 000 lignes bloquerait la base.
    const CHUNK = 100;
    for (let i = 0; i < parsed.rows.length; i += CHUNK) {
      const chunk = parsed.rows.slice(i, i + CHUNK);
      await prisma.$transaction(async (tx) => {
        for (const r of chunk) {
          let supplierId: string | null = null;
          if (r.supplierName) {
            const key = r.supplierName.toLowerCase();
            supplierId = parNom.get(key) ?? null;
            if (!supplierId) {
              const cree = await tx.supplier.create({ data: { pharmacyId: s.pharmacyId, name: r.supplierName } });
              parNom.set(key, cree.id);
              supplierId = cree.id;
            }
          }

          const existant = await tx.product.findFirst({
            where: {
              pharmacyId: s.pharmacyId,
              OR: [...(r.barcode ? [{ barcode: r.barcode }] : []), { name: r.name }],
            },
          });

          let productId: string;
          if (existant) {
            if (mode !== "upsert") { ignores++; continue; }
            await tx.product.update({
              where: { id: existant.id },
              data: {
                dci: r.dci ?? existant.dci, category: r.category ?? existant.category,
                purchasePrice: r.purchasePrice, salePrice: r.salePrice,
                alertThreshold: r.alertThreshold, supplierId: supplierId ?? existant.supplierId,
                isActive: true,
              },
            });
            productId = existant.id;
            majs++;
          } else {
            const cree = await tx.product.create({
              data: {
                pharmacyId: s.pharmacyId, name: r.name, dci: r.dci, barcode: r.barcode,
                category: r.category, purchasePrice: r.purchasePrice, salePrice: r.salePrice,
                alertThreshold: r.alertThreshold, supplierId,
              },
            });
            productId = cree.id;
            crees++;
          }

          if (r.quantity > 0 && r.expiryDate) {
            const batchNo = r.batchNo ?? `IMPORT-${new Date().toISOString().slice(0, 10)}`;
            const dejaLot = await tx.productBatch.findFirst({ where: { productId, batchNo } });
            const batch = dejaLot
              ? await tx.productBatch.update({ where: { id: dejaLot.id }, data: { quantity: { increment: r.quantity } } })
              : await tx.productBatch.create({
                  data: { productId, batchNo, quantity: r.quantity, expiryDate: new Date(r.expiryDate), costPrice: r.purchasePrice },
                });
            await tx.stockMovement.create({
              data: {
                pharmacyId: s.pharmacyId, productId, batchId: batch.id, type: "IN",
                quantity: r.quantity, reason: "Import catalogue", reference: `IMPORT-L${r.ligne}`, userId: s.userId,
              },
            });
            lots++;
          }
        }
      }, { timeout: 30_000 });
    }

    await audit(s, "CATALOG_IMPORT", "Product", undefined, { crees, majs, lots, ignores, fichier: file.name });
    return {
      resultat: { crees, misAJour: majs, lotsCrees: lots, ignores, anomalies: parsed.issues.length },
      anomalies: parsed.issues.slice(0, 50),
    };
  });
}
