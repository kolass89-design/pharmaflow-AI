import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, int, oneOf, assertOwnership, ApiError, throttle } from "@/lib/api";

const TYPES = ["ADJUSTMENT", "LOSS", "RETURN"] as const;

/**
 * Ajustement d'inventaire : casse, péremption, vol, correction de comptage.
 * `delta` peut être négatif. Chaque ajustement exige un motif — c'est une exigence
 * de traçabilité pharmaceutique, pas un confort.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("stock.move");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const productId = await assertOwnership("product", str(b.productId, "Produit")!, s.pharmacyId);
    const delta = int(b.delta, "Écart", { min: -100000, max: 100000 })!;
    if (delta === 0) throw new ApiError(422, "L'écart ne peut pas être nul.");
    const reason = str(b.reason, "Motif", { min: 3 })!;
    const type = oneOf(b.type, "Type", TYPES, "ADJUSTMENT");

    const result = await prisma.$transaction(async (tx) => {
      const batches = await tx.productBatch.findMany({
        where: { productId, ...(delta < 0 ? { quantity: { gt: 0 } } : {}) },
        orderBy: { expiryDate: "asc" },
      });
      if (!batches.length) throw new ApiError(409, "Aucun lot disponible pour ce produit.");

      if (delta < 0) {
        const dispo = batches.reduce((t, x) => t + x.quantity, 0);
        if (dispo < Math.abs(delta)) throw new ApiError(409, `Stock insuffisant : ${dispo} unité(s) disponible(s).`);
        let reste = Math.abs(delta);
        for (const bt of batches) {
          if (reste <= 0) break;
          const pris = Math.min(bt.quantity, reste);
          await tx.productBatch.update({ where: { id: bt.id }, data: { quantity: { decrement: pris } } });
          reste -= pris;
        }
      } else {
        await tx.productBatch.update({ where: { id: batches[0].id }, data: { quantity: { increment: delta } } });
      }

      await tx.stockMovement.create({
        data: {
          pharmacyId: s.pharmacyId, productId, type, quantity: Math.abs(delta),
          reason: `${reason} (${delta > 0 ? "+" : "−"}${Math.abs(delta)})`, userId: s.userId,
        },
      });

      const total = await tx.productBatch.aggregate({ where: { productId }, _sum: { quantity: true } });
      return { stock: total._sum.quantity ?? 0 };
    });

    await audit(s, "STOCK_ADJUST", "Product", productId, { delta, reason, type });
    return result;
  });
}
