import { NextResponse } from "next/server";
import { guards } from "@/lib/mock";

export async function GET(req: Request) {
  const ville = new URL(req.url).searchParams.get("ville");
  const data = ville ? guards.filter(g => g.ville.toLowerCase() === ville.toLowerCase()) : guards;
  return NextResponse.json({ data, updatedAt: new Date().toISOString() });
}
