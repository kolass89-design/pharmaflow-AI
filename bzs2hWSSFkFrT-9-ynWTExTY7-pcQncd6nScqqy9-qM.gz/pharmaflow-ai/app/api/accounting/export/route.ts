import { NextResponse } from "next/server";
import { requirePermission } from "@/lib/api";
import { prisma } from "@/lib/db";

const cell = (v: unknown) => {
  const s = String(v ?? "");
  return /[";\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** Export comptable : ventes et dépenses, format CSV lisible par tout tableur. */
export async function GET(req: Request) {
  let s;
  try { s = await requirePermission("accounting.read"); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: e.status ?? 403 }); }

  const type = new URL(req.url).searchParams.get("type") ?? "ventes";
  const date = new Date().toISOString().slice(0, 10);
  let head: string[]; let lignes: string[];

  if (type === "depenses") {
    const rows = await prisma.expense.findMany({ where: { pharmacyId: s.pharmacyId }, orderBy: { spentAt: "desc" } });
    head = ["Date", "Categorie", "Libelle", "Montant FCFA"];
    lignes = rows.map(r => [r.spentAt.toISOString().slice(0, 10), r.category, r.label, r.amount].map(cell).join(";"));
  } else {
    const rows = await prisma.sale.findMany({
      where: { pharmacyId: s.pharmacyId }, orderBy: { soldAt: "desc" }, take: 5000,
      include: { payments: true, items: { include: { product: { select: { name: true } } } } },
    });
    head = ["Date", "Heure", "Reference", "Articles", "Sous-total", "Remise", "Total", "Paiement"];
    lignes = rows.map(r => [
      r.soldAt.toISOString().slice(0, 10), r.soldAt.toISOString().slice(11, 16), r.reference,
      r.items.map(i => `${i.product.name} x${i.quantity}`).join(", "),
      r.subtotal, r.discount, r.total, r.payments[0]?.method ?? "",
    ].map(cell).join(";"));
  }

  const csv = "\uFEFF" + [head.join(";"), ...lignes].join("\r\n");
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${type}-pharmaflow-${date}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
