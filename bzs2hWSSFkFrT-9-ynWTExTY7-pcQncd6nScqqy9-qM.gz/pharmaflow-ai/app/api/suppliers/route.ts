import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, int, oneOf } from "@/lib/api";
import { getSuppliers } from "@/lib/queries";

const PAYS = ["BJ", "TG", "CI", "SN", "NE", "CM", "OTHER"] as const;

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "suppliers.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  return NextResponse.json({ data: await getSuppliers(s.pharmacyId) });
}

export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("suppliers.write");
    const b = await req.json().catch(() => ({}));
    const supplier = await prisma.supplier.create({
      data: {
        pharmacyId: s.pharmacyId,
        name: str(b.name, "Nom du fournisseur", { min: 2 })!,
        country: oneOf(b.country, "Pays", PAYS, "BJ"),
        contact: str(b.contact, "Contact", { optional: true }),
        email: str(b.email, "Email", { optional: true }),
        phone: str(b.phone, "Téléphone", { optional: true }),
        leadTimeHours: int(b.leadTimeHours, "Délai de livraison", { min: 1, max: 2000, optional: true }) ?? 72,
      },
    });
    await audit(s, "SUPPLIER_CREATE", "Supplier", supplier.id, { name: supplier.name });
    return { supplier: { id: supplier.id, nom: supplier.name } };
  });
}
