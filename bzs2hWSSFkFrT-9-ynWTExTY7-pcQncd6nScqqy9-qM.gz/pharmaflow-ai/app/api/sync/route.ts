import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";

// Réception de la file d'opérations accumulées hors ligne (caisse + mouvements de stock).
export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const { operations = [] } = await req.json().catch(() => ({ operations: [] }));
  const seen = new Set<string>();
  const results = operations.map((op: any) => {
    if (!op.offlineUuid) return { status: "rejected", reason: "offlineUuid manquant" };
    if (seen.has(op.offlineUuid)) return { offlineUuid: op.offlineUuid, status: "duplicate" };
    seen.add(op.offlineUuid);
    return { offlineUuid: op.offlineUuid, status: "applied" };
  });
  return NextResponse.json({ applied: results.filter((r: any) => r.status === "applied").length, results });
}
