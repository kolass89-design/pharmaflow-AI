import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Tâche horaire : clôture les réservations dépassées.
 *
 * Sans elle, une réservation non retirée resterait « active » indéfiniment et
 * fausserait le décompte des unités réservées, bloquant le stock à tort.
 *
 * Protégée par CRON_SECRET : sur Vercel, l'en-tête Authorization est ajouté
 * automatiquement aux tâches planifiées.
 */
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const fourni = req.headers.get("authorization");
    if (fourni !== `Bearer ${secret}`) {
      return NextResponse.json({ error: "Non autorisé" }, { status: 401 });
    }
  }

  const r = await prisma.reservation.updateMany({
    where: { status: "ACTIVE", expiresAt: { lt: new Date() } },
    data: { status: "EXPIRED" },
  });

  return NextResponse.json({ ok: true, expirees: r.count, at: new Date().toISOString() });
}
