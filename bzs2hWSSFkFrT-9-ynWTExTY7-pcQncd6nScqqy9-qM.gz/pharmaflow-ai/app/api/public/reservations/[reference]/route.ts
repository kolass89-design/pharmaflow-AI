import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

/**
 * Suivi d'une réservation par sa référence.
 * La référence tient lieu de secret : on ne renvoie donc aucune donnée
 * personnelle (ni nom, ni téléphone), seulement l'état et le lieu de retrait.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ reference: string }> }) {
  const { reference } = await params;

  const r = await prisma.reservation.findUnique({
    where: { reference: reference.toUpperCase().slice(0, 20) },
    include: { pharmacy: { select: { name: true, city: true, district: true, phone: true } } },
  });
  if (!r) return NextResponse.json({ error: "Référence introuvable." }, { status: 404 });

  const expiree = r.expiresAt < new Date() && r.status === "ACTIVE";
  return NextResponse.json({
    reference: r.reference,
    produit: r.productLabel,
    quantite: r.quantity,
    total: (r.unitPrice ?? 0) * r.quantity,
    statut: expiree ? "EXPIRED" : r.status,
    expireLe: r.expiresAt.toISOString(),
    pharmacie: {
      nom: r.pharmacy.name,
      ville: r.pharmacy.city,
      quartier: r.pharmacy.district,
      telephone: r.pharmacy.phone,
    },
  });
}
