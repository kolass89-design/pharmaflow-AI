import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { encrypt } from "@/lib/crypto";
import { rateLimit, clientIp } from "@/lib/ratelimit";

/**
 * Réservation d'un médicament par un patient, sans compte.
 *
 * Choix structurants :
 *  - le stock N'EST PAS décrémenté. Une réservation n'est pas une vente : si on
 *    décrémentait, un plaisantin pourrait vider le stock affiché d'une officine.
 *    Le pharmacien met le produit de côté physiquement, la vente reste au comptoir.
 *  - validité 2 heures : au-delà, le produit doit redevenir disponible.
 *  - les médicaments soumis à ordonnance sont refusés : la délivrance exige un
 *    contrôle du pharmacien, qu'aucun formulaire web ne peut remplacer.
 */
const DUREE_MS = 2 * 60 * 60 * 1000;

function reference() {
  const lettres = "ABCDEFGHJKLMNPQRSTUVWXYZ";   // sans I ni O : dictées au téléphone
  let s = "";
  for (let i = 0; i < 4; i++) s += lettres[Math.floor(Math.random() * lettres.length)];
  return `R-${s}${Math.floor(1000 + Math.random() * 9000)}`;
}

export async function POST(req: Request) {
  const ip = clientIp(req);
  const b = await req.json().catch(() => ({}));
  const productId = String(b?.productId ?? "");
  const nom = String(b?.nom ?? "").trim().slice(0, 120);
  const telephone = String(b?.telephone ?? "").trim().slice(0, 30);
  const quantite = Math.min(Math.max(Math.floor(Number(b?.quantite ?? 1)), 1), 5);

  if (!productId) return NextResponse.json({ error: "Produit non précisé." }, { status: 422 });
  if (nom.length < 3) return NextResponse.json({ error: "Indiquez votre nom complet." }, { status: 422 });
  if (!/^\+?[\d\s.-]{8,}$/.test(telephone)) {
    return NextResponse.json({ error: "Numéro de téléphone invalide." }, { status: 422 });
  }

  // Le quota n'est consommé qu'une fois la demande jugée recevable : une faute
  // de frappe ne doit pas priver le patient d'une de ses réservations horaires.
  const rl = await rateLimit(`reservation:${ip}`, 5, 3_600_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de réservations depuis cette connexion. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } },
    );
  }

  const produit = await prisma.product.findFirst({
    where: { id: productId, isActive: true, isPublic: true },
    include: {
      batches: { where: { quantity: { gt: 0 }, expiryDate: { gt: new Date() } } },
      pharmacy: { select: { id: true, name: true, city: true, district: true, phone: true } },
    },
  });
  if (!produit) return NextResponse.json({ error: "Ce produit n'est plus proposé." }, { status: 404 });

  if (produit.requiresPrescription) {
    return NextResponse.json(
      { error: "Ce médicament est soumis à ordonnance : présentez-vous au comptoir avec votre prescription." },
      { status: 403 },
    );
  }

  const stock = produit.batches.reduce((t, x) => t + x.quantity, 0);
  if (stock < quantite) {
    return NextResponse.json({ error: "Stock insuffisant pour cette quantité." }, { status: 409 });
  }

  // Les réservations actives en cours ne doivent pas dépasser le stock réel.
  const dejaReserve = await prisma.reservation.aggregate({
    where: { productId, status: "ACTIVE", expiresAt: { gt: new Date() } },
    _sum: { quantity: true },
  });
  if ((dejaReserve._sum.quantity ?? 0) + quantite > stock) {
    return NextResponse.json(
      { error: "Toutes les unités disponibles sont déjà réservées. Contactez l'officine par téléphone." },
      { status: 409 },
    );
  }

  const expiresAt = new Date(Date.now() + DUREE_MS);
  const reservation = await prisma.reservation.create({
    data: {
      pharmacyId: produit.pharmacy.id,
      productId,
      quantity: quantite,
      reference: reference(),
      expiresAt,
      source: "WEB",
      customerName: nom,
      customerPhoneEnc: encrypt(telephone),   // donnée personnelle : chiffrée au repos
      productLabel: produit.name,
      unitPrice: produit.salePrice,
    },
  });

  await prisma.auditLog.create({
    data: {
      pharmacyId: produit.pharmacy.id,
      action: "RESERVATION_WEB",
      entity: "Reservation",
      entityId: reservation.id,
      ip,
      metadata: { produit: produit.name, quantite },
    },
  });

  return NextResponse.json({
    ok: true,
    reservation: {
      reference: reservation.reference,
      produit: produit.name,
      quantite,
      prixUnitaire: produit.salePrice,
      total: produit.salePrice * quantite,
      expireLe: expiresAt.toISOString(),
      pharmacie: {
        nom: produit.pharmacy.name,
        ville: produit.pharmacy.city,
        quartier: produit.pharmacy.district,
        telephone: produit.pharmacy.phone,
      },
    },
  }, { status: 201 });
}
