import { NextResponse } from "next/server";
import { rechercherMedicament, listerVilles } from "@/lib/patient-queries";
import { rateLimit, clientIp } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

/**
 * Recherche publique de médicament. Aucune authentification : c'est le point
 * d'entrée grand public. Le débit est donc limité par IP pour éviter qu'un robot
 * ne moissonne les prix et disponibilités de toutes les officines.
 */
export async function GET(req: Request) {
  const rl = await rateLimit(`recherche:${clientIp(req)}`, 30, 60_000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de recherches. Patientez quelques instants." },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } },
    );
  }

  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").slice(0, 80);
  const ville = url.searchParams.get("ville")?.slice(0, 60) || undefined;
  const lat = Number(url.searchParams.get("lat"));
  const lon = Number(url.searchParams.get("lon"));
  const position = Number.isFinite(lat) && Number.isFinite(lon) ? { lat, lon } : undefined;

  if (q.trim().length < 2) {
    return NextResponse.json({ resultats: [], villes: await listerVilles(), message: "Saisissez au moins 2 caractères." });
  }

  const resultats = await rechercherMedicament(q, { ville, position });
  return NextResponse.json(
    { resultats, villes: await listerVilles(), total: resultats.length },
    { headers: { "Cache-Control": "no-store" } },
  );
}
