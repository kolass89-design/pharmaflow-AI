import { NextResponse } from "next/server";
import { listerPharmacies, listerVilles } from "@/lib/patient-queries";

export const revalidate = 300;

export async function GET(req: Request) {
  const ville = new URL(req.url).searchParams.get("ville")?.slice(0, 60) || undefined;
  return NextResponse.json({ pharmacies: await listerPharmacies(ville), villes: await listerVilles() });
}
