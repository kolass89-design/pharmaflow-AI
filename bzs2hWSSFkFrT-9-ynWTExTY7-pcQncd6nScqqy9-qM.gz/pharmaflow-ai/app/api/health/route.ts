import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { usingRedis } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

/**
 * Sonde de santé — à brancher sur un moniteur externe (UptimeRobot, Better Stack…).
 * Volontairement publique mais sans aucune donnée métier : uniquement des états.
 */
export async function GET() {
  const debut = Date.now();
  const checks: Record<string, { ok: boolean; detail?: string; ms?: number }> = {};

  // Base de données
  try {
    const t = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    checks.database = { ok: true, ms: Date.now() - t };
  } catch (e: any) {
    checks.database = { ok: false, detail: e?.code ?? "injoignable" };
  }

  // Migrations appliquées
  try {
    const rows = await prisma.$queryRaw<{ n: bigint }[]>`
      SELECT COUNT(*)::bigint AS n FROM "_prisma_migrations" WHERE finished_at IS NOT NULL`;
    checks.migrations = { ok: Number(rows[0]?.n ?? 0) > 0, detail: `${Number(rows[0]?.n ?? 0)} appliquée(s)` };
  } catch {
    checks.migrations = { ok: false, detail: "table absente" };
  }

  // Configuration critique : sans ces clés, sessions et données patients sont en péril.
  const cle = process.env.ENCRYPTION_KEY;
  checks.encryption = {
    ok: Boolean(cle && /^[0-9a-fA-F]{64}$/.test(cle)),
    detail: cle ? undefined : "ENCRYPTION_KEY absente",
  };
  checks.session = {
    ok: Boolean(process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 32),
    detail: process.env.SESSION_SECRET ? undefined : "SESSION_SECRET absente",
  };
  checks.rateLimit = {
    ok: true,
    detail: usingRedis ? "Redis distribué" : "mémoire (instance unique uniquement)",
  };

  const degrade = !checks.rateLimit.detail?.startsWith("Redis");
  const enPanne = Object.values(checks).some(c => !c.ok);
  const statut = enPanne ? "down" : degrade ? "degraded" : "ok";

  return NextResponse.json(
    { status: statut, checks, ms: Date.now() - debut, at: new Date().toISOString() },
    { status: enPanne ? 503 : 200, headers: { "Cache-Control": "no-store" } },
  );
}
