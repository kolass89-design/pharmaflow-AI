import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, date, throttle } from "@/lib/api";
import { encrypt, decrypt, maskPhone } from "@/lib/crypto";

export async function GET(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "patients.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });

  const q = new URL(req.url).searchParams.get("q") ?? "";
  const rows = await prisma.patient.findMany({
    where: { pharmacyId: s.pharmacyId, ...(q ? { fullName: { contains: q, mode: "insensitive" } } : {}) },
    orderBy: { fullName: "asc" }, take: 50,
  });

  // En liste, le téléphone est masqué : l'accès en clair exige l'ouverture de la fiche.
  return NextResponse.json({
    data: rows.map(p => ({
      id: p.id, nom: p.fullName, ville: p.city, allergies: p.allergies,
      telephone: maskPhone(decrypt(p.phoneEnc)),
    })),
  });
}

export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("patients.write");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const fullName = str(b.fullName, "Nom du patient", { min: 2 })!;
    const patient = await prisma.patient.create({
      data: {
        pharmacyId: s.pharmacyId, fullName,
        phoneEnc: encrypt(str(b.phone, "Téléphone", { optional: true })),
        birthDate: date(b.birthDate, "Date de naissance", { optional: true }),
        gender: str(b.gender, "Sexe", { optional: true }),
        city: str(b.city, "Ville", { optional: true }),
        allergies: str(b.allergies, "Allergies", { max: 1000, optional: true }),
        chronicConditions: str(b.chronicConditions, "Pathologies chroniques", { max: 1000, optional: true }),
        // Le consentement est horodaté : exigence de conformité sur les données de santé.
        consentAt: b.consent ? new Date() : null,
      },
    });

    await audit(s, "PATIENT_CREATE", "Patient", patient.id);
    return { patient: { id: patient.id, nom: patient.fullName } };
  });
}
