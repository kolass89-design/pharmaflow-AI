import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, assertOwnership, ApiError } from "@/lib/api";
import { encrypt, decrypt } from "@/lib/crypto";

/** Lecture d'une fiche complète : le téléphone est déchiffré ET l'accès est journalisé. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("patients.read");
    await assertOwnership("patient", id, s.pharmacyId);

    const p = await prisma.patient.findUnique({
      where: { id: id },
      include: {
        sales: { orderBy: { soldAt: "desc" }, take: 10, include: { items: { include: { product: { select: { name: true } } } } } },
        prescriptions: { orderBy: { issuedAt: "desc" }, take: 10 },
        reminders: true,
      },
    });
    if (!p) throw new ApiError(404, "Patient introuvable.");

    await audit(s, "PATIENT_VIEW", "Patient", p.id);
    return {
      patient: {
        id: p.id, nom: p.fullName, telephone: decrypt(p.phoneEnc), ville: p.city,
        allergies: p.allergies, chroniques: p.chronicConditions,
        consentement: p.consentAt?.toISOString().slice(0, 10) ?? null,
        achats: p.sales.map(v => ({
          date: v.soldAt.toISOString().slice(0, 10), total: v.total,
          libelle: v.items.map(i => i.product.name).join(", "),
        })),
        ordonnances: p.prescriptions.length,
        rappels: p.reminders.map(r => ({ label: r.label, canal: r.channel, actif: r.isActive })),
      },
    };
  });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("patients.write");
    await assertOwnership("patient", id, s.pharmacyId);
    const b = await req.json().catch(() => ({}));

    const data: Record<string, unknown> = {};
    if (b.fullName !== undefined) data.fullName = str(b.fullName, "Nom du patient", { min: 2 });
    if (b.phone !== undefined) data.phoneEnc = encrypt(str(b.phone, "Téléphone", { optional: true }));
    if (b.city !== undefined) data.city = str(b.city, "Ville", { optional: true });
    if (b.allergies !== undefined) data.allergies = str(b.allergies, "Allergies", { max: 1000, optional: true });
    if (b.chronicConditions !== undefined) data.chronicConditions = str(b.chronicConditions, "Pathologies", { max: 1000, optional: true });
    if (!Object.keys(data).length) throw new ApiError(422, "Aucune modification fournie.");

    await prisma.patient.update({ where: { id: id }, data });
    await audit(s, "PATIENT_UPDATE", "Patient", id, { champs: Object.keys(data) });
    return { updated: true };
  });
}
