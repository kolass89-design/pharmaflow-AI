import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, int, date } from "@/lib/api";

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "accounting.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  const data = await prisma.expense.findMany({
    where: { pharmacyId: s.pharmacyId }, orderBy: { spentAt: "desc" }, take: 100,
  });
  return NextResponse.json({ data });
}

export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("accounting.write");
    const b = await req.json().catch(() => ({}));
    const expense = await prisma.expense.create({
      data: {
        pharmacyId: s.pharmacyId,
        category: str(b.category, "Catégorie", { min: 2 })!,
        label: str(b.label, "Libellé", { min: 2 })!,
        amount: int(b.amount, "Montant", { min: 1 })!,
        spentAt: date(b.spentAt, "Date", { optional: true }) ?? new Date(),
        receiptUrl: str(b.receiptUrl, "Justificatif", { optional: true }),
      },
    });
    await audit(s, "EXPENSE_CREATE", "Expense", expense.id, { amount: expense.amount });
    return { expense };
  });
}
