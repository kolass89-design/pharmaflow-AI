import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { throttle } from "@/lib/api";
import { captureError } from "@/lib/monitoring";
import type { PaymentMethod } from "@prisma/client";

type Line = { productId: string; quantity: number };

/**
 * Enregistrement d'une vente réelle.
 * Garanties :
 *  - transaction atomique (vente + lignes + paiement + décrément des lots + mouvements)
 *  - décrément FEFO (First Expired, First Out) sur les lots
 *  - idempotence via offlineUuid pour la resynchronisation du mode hors ligne
 */
export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "pos.sell")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  try { await throttle(s, "write"); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: 429 }); }

  const body = await req.json().catch(() => null);
  const items: Line[] = Array.isArray(body?.items) ? body.items : [];
  if (!items.length) return NextResponse.json({ error: "Panier vide" }, { status: 422 });

  const discountPercent = Math.min(Math.max(Number(body?.discountPercent ?? 0), 0), 50);
  const method = (body?.method ?? "CASH") as PaymentMethod;
  const offlineUuid: string | undefined = body?.offlineUuid;

  // Idempotence : une vente déjà synchronisée n'est jamais dupliquée.
  if (offlineUuid) {
    const existing = await prisma.sale.findUnique({ where: { offlineUuid } });
    if (existing) return NextResponse.json({ ok: true, duplicate: true, sale: existing });
  }

  try {
    const sale = await prisma.$transaction(async (tx) => {
      const products = await tx.product.findMany({
        where: { id: { in: items.map(i => i.productId) }, pharmacyId: s.pharmacyId },
        include: { batches: { where: { quantity: { gt: 0 } }, orderBy: { expiryDate: "asc" } } },
      });
      if (products.length !== items.length) throw new Error("PRODUIT_INTROUVABLE");

      const saleItems = [];
      const movements: { productId: string; batchId: string; quantity: number }[] = [];

      for (const line of items) {
        const p = products.find(x => x.id === line.productId)!;
        const qty = Math.max(1, Math.floor(line.quantity));
        const dispo = p.batches.reduce((t, b) => t + b.quantity, 0);
        if (dispo < qty) throw new Error(`STOCK_INSUFFISANT:${p.name}:${dispo}`);

        // FEFO : on puise d'abord dans le lot qui expire le plus tôt.
        let reste = qty;
        for (const b of p.batches) {
          if (reste <= 0) break;
          const pris = Math.min(b.quantity, reste);
          await tx.productBatch.update({ where: { id: b.id }, data: { quantity: { decrement: pris } } });
          movements.push({ productId: p.id, batchId: b.id, quantity: pris });
          reste -= pris;
        }

        saleItems.push({
          productId: p.id, quantity: qty, unitPrice: p.salePrice,
          discount: 0, lineTotal: p.salePrice * qty,
        });
      }

      const subtotal = saleItems.reduce((t, i) => t + i.lineTotal, 0);
      const discount = Math.round((subtotal * discountPercent) / 100);
      const total = subtotal - discount;

      // Référence séquentielle par pharmacie.
      const count = await tx.sale.count({ where: { pharmacyId: s.pharmacyId } });
      const reference = "TK-" + String(89000 + count + 1);

      const created = await tx.sale.create({
        data: {
          pharmacyId: s.pharmacyId, userId: s.userId, reference, offlineUuid: offlineUuid ?? null,
          subtotal, discount, total,
          patientId: body?.patientId ?? null,
          items: { create: saleItems },
          payments: { create: { method, amount: total } },
        },
        include: { items: true },
      });

      for (const m of movements) {
        await tx.stockMovement.create({
          data: {
            pharmacyId: s.pharmacyId, productId: m.productId, batchId: m.batchId,
            type: "OUT", quantity: m.quantity, reason: "Vente comptoir",
            reference: created.reference, userId: s.userId,
          },
        });
      }

      await tx.auditLog.create({
        data: { pharmacyId: s.pharmacyId, userId: s.userId, action: "SALE_CREATE", entity: "Sale", entityId: created.id },
      });

      return created;
    });

    const MOBILE = ["MTN_MOMO", "MOOV_MONEY", "ORANGE_MONEY", "CELTIIS_CASH", "WAVE"];
    const encaissementNonAutomatique = MOBILE.includes(method) && !process.env.PAYMENT_PROVIDER_KEY;

    return NextResponse.json({
      ok: true,
      sale,
      // Sans agrégateur configuré, la plateforme n'a débité personne : elle a
      // seulement enregistré le moyen déclaré. Le taire ferait croire au
      // caissier que l'argent est arrivé.
      encaissementNonAutomatique,
      avertissement: encaissementNonAutomatique
        ? "Paiement NON débité par la plateforme. Vérifiez la réception sur votre téléphone marchand avant de laisser partir le client."
        : undefined,
    }, { status: 201 });
  } catch (e: any) {
    const msg = String(e.message ?? "");
    if (msg.startsWith("STOCK_INSUFFISANT")) {
      const [, nom, dispo] = msg.split(":");
      return NextResponse.json({ error: `Stock insuffisant pour ${nom} (${dispo} restant).` }, { status: 409 });
    }
    if (msg === "PRODUIT_INTROUVABLE")
      return NextResponse.json({ error: "Un produit du panier est introuvable." }, { status: 404 });
    await captureError(e, { origine: "vente", pharmacyId: s.pharmacyId });
    return NextResponse.json({ error: "Erreur lors de l'enregistrement de la vente." }, { status: 500 });
  }
}

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const sales = await prisma.sale.findMany({
    where: { pharmacyId: s.pharmacyId }, orderBy: { soldAt: "desc" }, take: 20,
    include: { items: { include: { product: { select: { name: true } } } }, payments: true },
  });
  return NextResponse.json({ data: sales });
}
