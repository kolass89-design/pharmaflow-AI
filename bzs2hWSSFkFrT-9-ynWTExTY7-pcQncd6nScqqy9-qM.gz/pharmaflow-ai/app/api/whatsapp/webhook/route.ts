import { NextResponse } from "next/server";
import crypto from "crypto";
import { prisma } from "@/lib/db";
import { traiterMessage } from "@/lib/whatsapp/moteur";
import { captureError } from "@/lib/monitoring";

/**
 * Webhook WhatsApp Business API (Meta Cloud API).
 *
 * Contraintes imposées par la plateforme :
 *  - répondre en moins de 20 s, sinon Meta considère l'appel en échec ;
 *  - renvoyer systématiquement 200, même en cas d'erreur interne : un statut
 *    d'erreur déclenche des rejeux en boucle et, à terme, la désactivation
 *    du webhook. Les incidents partent donc à la supervision, pas au client.
 */

export const dynamic = "force-dynamic";
export const maxDuration = 20;

/* ─────────── Vérification initiale du webhook ─────────── */
export async function GET(req: Request) {
  const u = new URL(req.url);
  const attendu = process.env.WHATSAPP_VERIFY_TOKEN;
  const fourni = u.searchParams.get("hub.verify_token");

  if (!attendu) {
    return NextResponse.json({ error: "WHATSAPP_VERIFY_TOKEN non configuré." }, { status: 503 });
  }
  if (u.searchParams.get("hub.mode") !== "subscribe" || !fourni || !egales(fourni, attendu)) {
    return NextResponse.json({ error: "Vérification refusée." }, { status: 403 });
  }
  return new Response(u.searchParams.get("hub.challenge") ?? "", {
    status: 200, headers: { "Content-Type": "text/plain" },
  });
}

/** Comparaison à temps constant, robuste aux longueurs différentes. */
function egales(a: string, b: string): boolean {
  const ha = crypto.createHash("sha256").update(a).digest();
  const hb = crypto.createHash("sha256").update(b).digest();
  return crypto.timingSafeEqual(ha, hb);
}

function signatureValide(brut: string, entete: string | null): boolean {
  const secret = process.env.WHATSAPP_APP_SECRET;
  // Sans secret configuré, on n'accepte que le développement : en production,
  // un webhook non signé est une porte ouverte à l'injection de faux messages.
  if (!secret) return process.env.NODE_ENV !== "production";
  if (!entete) return false;
  const attendu = "sha256=" + crypto.createHmac("sha256", secret).update(brut).digest("hex");
  return egales(entete, attendu);
}

/* ─────────── Extraction du format Meta ─────────── */

type MessageEntrant = { telephone: string; texte: string; messageId: string; numeroDestinataire: string };

function extraireMessages(charge: any): MessageEntrant[] {
  const sortie: MessageEntrant[] = [];

  // Format officiel Meta : entry[].changes[].value.messages[]
  for (const entry of charge?.entry ?? []) {
    for (const change of entry?.changes ?? []) {
      const value = change?.value;
      const numeroDestinataire = value?.metadata?.phone_number_id ?? "";
      for (const m of value?.messages ?? []) {
        if (m?.type !== "text") continue;   // images, audio : hors périmètre du bot
        sortie.push({
          telephone: String(m.from ?? ""),
          texte: String(m.text?.body ?? ""),
          messageId: String(m.id ?? ""),
          numeroDestinataire,
        });
      }
    }
  }

  // Format simplifié, utilisé par les tests et la démonstration.
  if (!sortie.length && charge?.message?.text) {
    sortie.push({
      telephone: String(charge.message.from ?? charge.from ?? "+22900000000"),
      texte: String(charge.message.text),
      messageId: String(charge.message.id ?? `local-${Date.now()}`),
      numeroDestinataire: String(charge.to ?? ""),
    });
  }

  return sortie;
}

/** Retrouve l'officine destinataire à partir du numéro WhatsApp appelé. */
async function resoudrePharmacie(numeroDestinataire: string) {
  if (numeroDestinataire) {
    const parId = await prisma.pharmacy.findFirst({
      where: { whatsappNo: { contains: numeroDestinataire } },
      select: { id: true },
    });
    if (parId) return parId.id;
  }
  // Repli mono-officine : la première pharmacie ayant un numéro configuré.
  const defaut = await prisma.pharmacy.findFirst({
    where: { whatsappNo: { not: null } }, select: { id: true }, orderBy: { createdAt: "asc" },
  });
  return defaut?.id ?? null;
}

/* ─────────── Envoi de la réponse ─────────── */

async function envoyer(destinataire: string, texte: string) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneId) return { envoye: false, raison: "non configuré" };

  try {
    const r = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        messaging_product: "whatsapp", to: destinataire,
        type: "text", text: { preview_url: false, body: texte.slice(0, 4096) },
      }),
      signal: AbortSignal.timeout(8000),
    });
    return { envoye: r.ok, raison: r.ok ? undefined : `HTTP ${r.status}` };
  } catch (e: any) {
    return { envoye: false, raison: e?.message ?? "réseau" };
  }
}

/* ─────────── Réception ─────────── */

export async function POST(req: Request) {
  const brut = await req.text();

  if (!signatureValide(brut, req.headers.get("x-hub-signature-256"))) {
    return NextResponse.json({ error: "Signature invalide." }, { status: 401 });
  }

  let charge: any;
  try {
    charge = JSON.parse(brut || "{}");
  } catch {
    return NextResponse.json({ ok: true, ignore: "charge illisible" });
  }

  const messages = extraireMessages(charge);
  if (!messages.length) return NextResponse.json({ ok: true, traites: 0 });

  const resultats = [];
  for (const m of messages) {
    try {
      // Meta rejoue les webhooks non acquittés : sans ce garde-fou, un patient
      // recevrait plusieurs fois la même réponse et pourrait réserver en double.
      if (m.messageId) {
        const deja = await prisma.whatsappMessage.findFirst({ where: { providerId: m.messageId } });
        if (deja) { resultats.push({ messageId: m.messageId, statut: "doublon" }); continue; }
      }

      const pharmacyId = await resoudrePharmacie(m.numeroDestinataire);
      if (!pharmacyId) {
        resultats.push({ messageId: m.messageId, statut: "aucune officine configurée" });
        continue;
      }

      const reponse = await traiterMessage({ pharmacyId, telephone: m.telephone, message: m.texte });

      if (m.messageId) {
        await prisma.whatsappMessage.updateMany({
          where: { conversation: { pharmacyId, phone: m.telephone }, body: m.texte.slice(0, 4000), providerId: null },
          data: { providerId: m.messageId },
        });
      }

      if (reponse.texte) await envoyer(m.telephone, reponse.texte);

      resultats.push({
        messageId: m.messageId,
        intention: reponse.intention,
        handoff: reponse.handoff,
        reply: reponse.texte,
        reservation: reponse.reservation,
      });
    } catch (e) {
      await captureError(e, { origine: "whatsapp", telephone: m.telephone.slice(0, 6) + "…" });
      resultats.push({ messageId: m.messageId, statut: "erreur" });
    }
  }

  // Toujours 200 : un statut d'erreur ferait rejouer Meta en boucle.
  return NextResponse.json({ ok: true, traites: resultats.length, resultats });
}
