import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, oneOf, throttle, ApiError } from "@/lib/api";
import { hashPassword } from "@/lib/auth";
import crypto from "crypto";

const ROLES = ["PHARMACIST", "TECHNICIAN", "CASHIER", "ACCOUNTANT"] as const;

/**
 * Invitation d'un membre de l'équipe.
 *
 * Aucun email n'étant encore branché, le mot de passe provisoire est renvoyé
 * une seule fois au titulaire, qui le transmet de vive voix. C'est volontaire :
 * mieux vaut un secret remis en main propre qu'un lien d'activation qui n'arrive jamais.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("users.manage");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const email = str(b.email, "Email", { min: 5 }).toLowerCase();
    if (!email.includes("@")) throw new ApiError(422, "Adresse email invalide.");
    const fullName = str(b.fullName, "Nom complet", { min: 3 });
    const roleName = oneOf(b.role, "Rôle", ROLES);

    if (await prisma.user.findUnique({ where: { email } })) {
      throw new ApiError(409, "Un compte existe déjà avec cet email.");
    }
    const role = await prisma.role.findUnique({ where: { name: roleName } });
    if (!role) throw new ApiError(500, "Rôles non initialisés.");

    const provisoire = crypto.randomBytes(6).toString("base64url");
    const user = await prisma.user.create({
      data: {
        email, fullName, passwordHash: hashPassword(provisoire),
        memberships: { create: { pharmacyId: s.pharmacyId, roleId: role.id } },
      },
    });

    await audit(s, "MEMBER_INVITE", "User", user.id, { email, role: roleName });
    return {
      membre: { id: user.id, nom: fullName, email, role: roleName },
      motDePasseProvisoire: provisoire,
      consigne: "Communiquez ce mot de passe de vive voix. Il ne sera plus affiché.",
    };
  });
}
