import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, throttle, ApiError } from "@/lib/api";

/** Suspension ou réactivation d'un membre. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("users.manage");
    await throttle(s, "write");

    if (id === s.userId) throw new ApiError(409, "Vous ne pouvez pas suspendre votre propre compte.");

    const membre = await prisma.pharmacyMember.findFirst({
      where: { userId: id, pharmacyId: s.pharmacyId }, include: { role: true },
    });
    if (!membre) throw new ApiError(404, "Ce membre n'appartient pas à votre officine.");

    // Une officine sans titulaire actif deviendrait ingérable.
    if (membre.role.name === "OWNER") {
      const titulaires = await prisma.pharmacyMember.count({
        where: { pharmacyId: s.pharmacyId, isActive: true, role: { name: "OWNER" } },
      });
      if (titulaires <= 1) throw new ApiError(409, "Impossible de suspendre le dernier titulaire.");
    }

    const b = await req.json().catch(() => ({}));
    const actif = Boolean(b.isActive);

    await prisma.pharmacyMember.update({ where: { id: membre.id }, data: { isActive: actif } });
    await prisma.user.update({ where: { id }, data: { isActive: actif } });
    await audit(s, actif ? "MEMBER_ENABLE" : "MEMBER_SUSPEND", "User", id);
    return { actif };
  });
}
