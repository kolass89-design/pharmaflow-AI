import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { throttle } from "@/lib/api";
import { getAiData, getLowStockProducts, getAccounting, getExpiringBatches } from "@/lib/queries";
import { fcfa } from "@/lib/utils";

/**
 * Assistant sur données agrégées.
 * MVP : routage par intention sur des agrégats réels (aucune donnée patient exposée).
 * Évolution : passer ces mêmes agrégats en contexte à un LLM pour une réponse rédigée.
 */
export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  try { await throttle(s, "ai"); }
  catch (e: any) { return NextResponse.json({ error: e.message }, { status: 429 }); }

  const { question } = await req.json().catch(() => ({ question: "" }));
  const q = String(question ?? "").toLowerCase();

  if (/rentab|marge|meilleur/.test(q)) {
    const { topProduits } = await getAiData(s.pharmacyId);
    if (!topProduits.length) return NextResponse.json({ answer: "Pas encore assez de ventes pour calculer la rentabilité." });
    const total = topProduits.reduce((t, p) => t + p.marge, 0);
    return NextResponse.json({
      answer: `Vos 5 produits les plus rentables ont généré ${fcfa(total)} de marge :\n`
        + topProduits.map((p, i) => `${i + 1}. ${p.nom} — ${fcfa(p.marge)} (${p.qte} unités)`).join("\n"),
    });
  }

  if (/command|réappro|reappro|acheter|rupture/.test(q)) {
    const low = await getLowStockProducts(s.pharmacyId);
    if (!low.length) return NextResponse.json({ answer: "Aucun produit sous son seuil d'alerte. Rien d'urgent à commander." });
    const budget = low.reduce((t, p) => t + p.achat * Math.max(p.seuil * 3 - p.stock, 20), 0);
    return NextResponse.json({
      answer: `${low.length} produit(s) à commander, budget estimé ${fcfa(budget)} :\n`
        + low.map(p => `• ${p.nom} — stock ${p.stock}/${p.seuil}, commander ${Math.max(p.seuil * 3 - p.stock, 20)} chez ${p.fournisseur}`).join("\n"),
    });
  }

  if (/expir|péremp|peremp/.test(q)) {
    const exp = await getExpiringBatches(s.pharmacyId, 90);
    if (!exp.length) return NextResponse.json({ answer: "Aucun lot n'expire dans les 90 prochains jours." });
    return NextResponse.json({
      answer: `${exp.length} lot(s) à surveiller :\n`
        + exp.map(b => `• ${b.nom} (${b.lot}) — ${b.quantite} unités, expire dans ${b.joursRestants} jours`).join("\n"),
    });
  }

  if (/chiffre|ca |recette|vente|résultat|resultat/.test(q)) {
    const a = await getAccounting(s.pharmacyId);
    return NextResponse.json({
      answer: `Recettes du mois en cours : ${fcfa(a.recettesMois)}. Dépenses saisies : ${fcfa(a.depensesMois)}. `
        + `Résultat : ${fcfa(a.benefice)} (marge ${a.marge} %).\n`
        + `Répartition des encaissements : ${a.paiements.slice(0, 3).map(p => `${p.method} ${p.part} %`).join(", ")}.`,
    });
  }

  return NextResponse.json({
    answer: "Je peux répondre sur : la rentabilité des produits, les réapprovisionnements à passer, "
      + "les lots proches de péremption et votre chiffre d'affaires. Reformulez votre question avec l'un de ces thèmes.",
  });
}
