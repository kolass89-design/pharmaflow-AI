import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { aiRecos, products } from "@/lib/mock";

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const restock = products.filter(p => p.stock < p.seuil).map(p => ({
    type: "RESTOCK", severity: "HIGH", product: p.nom,
    suggestedQty: Math.max(p.seuil * 3 - p.stock, 20),
    supplier: p.fournisseur,
  }));
  return NextResponse.json({ recommendations: aiRecos, restock });
}
