import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, int, assertOwnership, ApiError } from "@/lib/api";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("stock.write");
    await assertOwnership("product", id, s.pharmacyId);
    const b = await req.json().catch(() => ({}));

    const data: Record<string, unknown> = {};
    if (b.name !== undefined) data.name = str(b.name, "Nom du produit", { min: 2 });
    if (b.dci !== undefined) data.dci = str(b.dci, "DCI", { optional: true });
    if (b.purchasePrice !== undefined) data.purchasePrice = int(b.purchasePrice, "Prix d'achat");
    if (b.salePrice !== undefined) data.salePrice = int(b.salePrice, "Prix de vente");
    if (b.alertThreshold !== undefined) data.alertThreshold = int(b.alertThreshold, "Seuil d'alerte");
    if (b.isActive !== undefined) data.isActive = Boolean(b.isActive);
    if (!Object.keys(data).length) throw new ApiError(422, "Aucune modification fournie.");

    const before = await prisma.product.findUnique({ where: { id: id } });
    const pa = (data.purchasePrice as number) ?? before!.purchasePrice;
    const pv = (data.salePrice as number) ?? before!.salePrice;
    if (pv < pa) throw new ApiError(422, "Le prix de vente ne peut pas être inférieur au prix d'achat.");

    const product = await prisma.product.update({ where: { id: id }, data });
    await audit(s, "PRODUCT_UPDATE", "Product", product.id, { champs: Object.keys(data) });
    return { product };
  });
}

/** Désactivation logique : on ne supprime jamais un produit qui a un historique de ventes. */
export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("stock.write");
    await assertOwnership("product", id, s.pharmacyId);
    const sold = await prisma.saleItem.count({ where: { productId: id } });
    if (sold > 0) {
      await prisma.product.update({ where: { id: id }, data: { isActive: false } });
      await audit(s, "PRODUCT_DEACTIVATE", "Product", id);
      return { deactivated: true, message: "Produit désactivé (historique de ventes conservé)." };
    }
    await prisma.product.delete({ where: { id: id } });
    await audit(s, "PRODUCT_DELETE", "Product", id);
    return { deleted: true };
  });
}
