import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, int, date, assertOwnership, throttle } from "@/lib/api";
import { getStock } from "@/lib/queries";

export async function GET(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "stock.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });

  const q = new URL(req.url).searchParams.get("q")?.toLowerCase() ?? "";
  const rows = await getStock(s.pharmacyId);
  const data = q ? rows.filter(r => (r.nom + r.dci + r.fournisseur).toLowerCase().includes(q)) : rows;
  return NextResponse.json({ data, count: data.length });
}

/** Création d'un produit, avec lot initial optionnel. */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("stock.write");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const name = str(b.name, "Nom du produit", { min: 2 });
    const purchasePrice = int(b.purchasePrice, "Prix d'achat")!;
    const salePrice = int(b.salePrice, "Prix de vente")!;
    if (salePrice < purchasePrice) throw new (await import("@/lib/api")).ApiError(422, "Le prix de vente ne peut pas être inférieur au prix d'achat.");

    const supplierId = b.supplierId ? await assertOwnership("supplier", String(b.supplierId), s.pharmacyId) : null;
    const initialQty = int(b.initialQuantity, "Quantité initiale", { optional: true }) ?? 0;
    const expiry = date(b.expiryDate, "Date de péremption", { optional: true });
    if (initialQty > 0 && !expiry) throw new (await import("@/lib/api")).ApiError(422, "Une date de péremption est requise pour le lot initial.");

    const product = await prisma.$transaction(async (tx) => {
      const p = await tx.product.create({
        data: {
          pharmacyId: s.pharmacyId, name,
          dci: str(b.dci, "DCI", { optional: true }),
          form: str(b.form, "Forme", { optional: true }),
          dosage: str(b.dosage, "Dosage", { optional: true }),
          barcode: str(b.barcode, "Code-barres", { optional: true }),
          category: str(b.category, "Catégorie", { optional: true }),
          purchasePrice, salePrice,
          alertThreshold: int(b.alertThreshold, "Seuil d'alerte", { optional: true }) ?? 10,
          supplierId,
        },
      });

      if (initialQty > 0 && expiry) {
        const batch = await tx.productBatch.create({
          data: {
            productId: p.id, batchNo: str(b.batchNo, "Numéro de lot", { optional: true }) ?? "LOT-INIT",
            quantity: initialQty, expiryDate: expiry, costPrice: purchasePrice,
          },
        });
        await tx.stockMovement.create({
          data: {
            pharmacyId: s.pharmacyId, productId: p.id, batchId: batch.id, type: "IN",
            quantity: initialQty, reason: "Création produit — stock initial", userId: s.userId,
          },
        });
      }
      return p;
    });

    await audit(s, "PRODUCT_CREATE", "Product", product.id, { name });
    return { product };
  });
}
