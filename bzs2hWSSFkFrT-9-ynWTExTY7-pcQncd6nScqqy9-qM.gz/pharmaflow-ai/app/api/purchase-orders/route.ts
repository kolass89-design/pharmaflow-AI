import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, int, date, assertOwnership, ApiError } from "@/lib/api";
import { getPurchaseOrders, getLowStockProducts } from "@/lib/queries";

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "suppliers.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  return NextResponse.json({ data: await getPurchaseOrders(s.pharmacyId) });
}

/**
 * Création d'un bon de commande.
 * Mode "auto" : génère la commande à partir des produits sous leur seuil,
 * regroupés par fournisseur — c'est la matérialisation des recommandations IA.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("suppliers.write");
    const b = await req.json().catch(() => ({}));

    if (b.auto) {
      const low = await getLowStockProducts(s.pharmacyId);
      if (!low.length) throw new ApiError(409, "Aucun produit sous son seuil : rien à commander.");

      const products = await prisma.product.findMany({
        where: { id: { in: low.map(l => l.id) } }, select: { id: true, supplierId: true, purchasePrice: true, alertThreshold: true },
      });
      const parFournisseur = new Map<string, { productId: string; quantity: number; unitCost: number }[]>();
      for (const p of products) {
        if (!p.supplierId) continue;
        const l = low.find(x => x.id === p.id)!;
        const qty = Math.max(p.alertThreshold * 3 - l.stock, 20);
        const arr = parFournisseur.get(p.supplierId) ?? [];
        arr.push({ productId: p.id, quantity: qty, unitCost: p.purchasePrice });
        parFournisseur.set(p.supplierId, arr);
      }
      if (!parFournisseur.size) throw new ApiError(409, "Les produits en alerte n'ont pas de fournisseur assigné.");

      const created: { reference: string; lignes: number; montant: number }[] = [];
      for (const [supplierId, items] of parFournisseur) {
        const count = await prisma.purchaseOrder.count({ where: { pharmacyId: s.pharmacyId } });
        const po = await prisma.purchaseOrder.create({
          data: {
            pharmacyId: s.pharmacyId, supplierId, reference: `BC-${1200 + count + created.length}`,
            status: "DRAFT", totalAmount: items.reduce((t, i) => t + i.unitCost * i.quantity, 0),
            items: { create: items },
          },
        });
        created.push({ reference: po.reference, lignes: items.length, montant: po.totalAmount });
      }
      await audit(s, "PO_AUTO_CREATE", "PurchaseOrder", undefined, { bons: created.length });
      return { auto: true, commandes: created };
    }

    const supplierId = await assertOwnership("supplier", str(b.supplierId, "Fournisseur")!, s.pharmacyId);
    const items = Array.isArray(b.items) ? b.items : [];
    if (!items.length) throw new ApiError(422, "La commande doit contenir au moins une ligne.");

    const lignes = [];
    for (const it of items) {
      const productId = await assertOwnership("product", str(it.productId, "Produit")!, s.pharmacyId);
      lignes.push({
        productId,
        quantity: int(it.quantity, "Quantité", { min: 1 })!,
        unitCost: int(it.unitCost, "Coût unitaire", { min: 0 })!,
      });
    }

    const count = await prisma.purchaseOrder.count({ where: { pharmacyId: s.pharmacyId } });
    const po = await prisma.purchaseOrder.create({
      data: {
        pharmacyId: s.pharmacyId, supplierId, reference: `BC-${1200 + count}`, status: "SENT",
        totalAmount: lignes.reduce((t, i) => t + i.unitCost * i.quantity, 0),
        expectedAt: date(b.expectedAt, "Date attendue", { optional: true }),
        items: { create: lignes },
      },
    });
    await audit(s, "PO_CREATE", "PurchaseOrder", po.id, { reference: po.reference });
    return { commande: { id: po.id, reference: po.reference, montant: po.totalAmount } };
  });
}
