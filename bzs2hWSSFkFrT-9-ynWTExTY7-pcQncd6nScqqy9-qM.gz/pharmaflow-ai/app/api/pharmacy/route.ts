import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, throttle, ApiError } from "@/lib/api";

/** Mise à jour de l'identité et des horaires de l'officine. */
export async function PATCH(req: Request) {
  return handle(async () => {
    const s = await requirePermission("settings.write");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const data: Record<string, unknown> = {};
    if (b.name !== undefined) data.name = str(b.name, "Nom de la pharmacie", { min: 2 });
    if (b.city !== undefined) data.city = str(b.city, "Ville", { min: 2 });
    if (b.district !== undefined) data.district = str(b.district, "Quartier", { optional: true });
    if (b.licenseNo !== undefined) data.licenseNo = str(b.licenseNo, "Numéro d'ordre", { optional: true });
    if (b.phone !== undefined) data.phone = str(b.phone, "Téléphone", { optional: true });
    if (b.whatsappNo !== undefined) data.whatsappNo = str(b.whatsappNo, "Numéro WhatsApp", { optional: true });

    if (b.openingHours !== undefined) {
      const h = b.openingHours;
      if (typeof h !== "object" || h === null) throw new ApiError(422, "Horaires invalides.");
      // Format attendu « 08:00-20:00 » ou « fermé » : c'est ce que lit estOuverte().
      for (const [jour, plage] of Object.entries(h as Record<string, string>)) {
        if (typeof plage !== "string") throw new ApiError(422, `Horaire invalide pour ${jour}.`);
        if (plage && !/^(ferm|\d{1,2}:\d{2}\s*[-–]\s*\d{1,2}:\d{2})/i.test(plage)) {
          throw new ApiError(422, `Format attendu pour ${jour} : « 08:00-20:00 » ou « fermé ».`);
        }
      }
      data.openingHours = h;
    }

    if (!Object.keys(data).length) throw new ApiError(422, "Aucune modification fournie.");

    const pharmacy = await prisma.pharmacy.update({ where: { id: s.pharmacyId }, data });
    await audit(s, "PHARMACY_UPDATE", "Pharmacy", s.pharmacyId, { champs: Object.keys(data) });
    return { pharmacy: { nom: pharmacy.name, ville: pharmacy.city } };
  });
}
