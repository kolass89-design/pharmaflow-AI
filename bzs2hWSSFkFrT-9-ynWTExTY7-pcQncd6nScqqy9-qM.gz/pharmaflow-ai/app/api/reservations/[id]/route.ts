import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, oneOf, throttle, ApiError } from "@/lib/api";

const STATUTS = ["COLLECTED", "CANCELLED"] as const;

/**
 * Traitement d'une réservation par l'officine : retirée ou annulée.
 * Le stock n'a jamais été décrémenté à la réservation ; il le sera par la vente
 * normale au comptoir. On ne fait donc ici que clore le suivi.
 */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("pos.sell");
    await throttle(s, "write");

    const reservation = await prisma.reservation.findFirst({ where: { id, pharmacyId: s.pharmacyId } });
    if (!reservation) throw new ApiError(404, "Réservation introuvable dans votre officine.");
    if (reservation.status !== "ACTIVE") throw new ApiError(409, "Cette réservation est déjà clôturée.");

    const b = await req.json().catch(() => ({}));
    const status = oneOf(b.status, "Statut", STATUTS);

    await prisma.reservation.update({ where: { id }, data: { status } });
    await audit(s, `RESERVATION_${status}`, "Reservation", id, { reference: reservation.reference });
    return { status };
  });
}
