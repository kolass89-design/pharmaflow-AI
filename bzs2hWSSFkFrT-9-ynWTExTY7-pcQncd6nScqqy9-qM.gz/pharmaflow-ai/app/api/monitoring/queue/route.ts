import { NextResponse } from "next/server";
import { getSession } from "@/lib/auth";
import { checkFileHorsLigne } from "@/lib/monitoring";

/**
 * Remontée de l'état de la file locale d'un poste.
 *
 * Le serveur ne peut pas deviner qu'un poste accumule des ventes non
 * synchronisées : c'est le navigateur qui doit le signaler. Sans cela,
 * une caisse peut encaisser dans le vide pendant des heures.
 */
export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });

  const b = await req.json().catch(() => ({}));
  const enAttente = Math.max(0, Math.min(Number(b?.enAttente ?? 0), 10_000));
  const echecs = Math.max(0, Math.min(Number(b?.echecs ?? 0), 10_000));
  const plusAncienneMs = b?.plusAncienneMs != null ? Math.max(0, Number(b.plusAncienneMs)) : null;

  await checkFileHorsLigne({ pharmacyId: s.pharmacyId, enAttente, echecs, plusAncienneMs });
  return NextResponse.json({ ok: true });
}
