import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { encodeSession, verifyPassword, type Role } from "@/lib/auth";
import { rateLimit, peek, reset, clientIp, POLICIES } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const ip = clientIp(req);

  const { email, password } = await req.json().catch(() => ({}));
  if (typeof email !== "string" || typeof password !== "string")
    return NextResponse.json({ error: "Requête invalide" }, { status: 422 });

  // Le seau est indexé sur le compte visé, pas seulement sur l'IP : une officine
  // partage souvent une unique connexion, punir l'IP punirait toute l'équipe.
  const bucket = `login:${email.toLowerCase().trim()}:${ip}`;
  const rl = await peek(bucket, POLICIES.login.limit, POLICIES.login.windowMs);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `Trop de tentatives sur ce compte. Réessayez dans ${rl.retryAfter} seconde(s).` },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } },
    );
  }

  const user = await prisma.user.findUnique({
    where: { email: email.toLowerCase().trim() },
    include: { memberships: { include: { role: true, pharmacy: true } } },
  });

  const membership = user?.memberships[0];
  const ok = user && user.isActive && membership && safeVerify(password, user.passwordHash);

  if (!ok) {
    // Seuls les échecs consomment le quota : une connexion réussie ne pénalise personne.
    await rateLimit(bucket, POLICIES.login.limit, POLICIES.login.windowMs);
    // Message volontairement générique : ne jamais révéler si l'email existe.
    return NextResponse.json({ error: "Identifiants invalides" }, { status: 401 });
  }
  await reset(bucket);

  await prisma.user.update({ where: { id: user!.id }, data: { lastLoginAt: new Date() } });
  await prisma.auditLog.create({
    data: {
      pharmacyId: membership!.pharmacyId, userId: user!.id, action: "LOGIN_SUCCESS",
      ip, userAgent: req.headers.get("user-agent") ?? undefined,
    },
  });

  const token = encodeSession({
    userId: user!.id, email: user!.email, role: membership!.role.name as Role,
    pharmacyId: membership!.pharmacyId, name: user!.fullName,
  });
  const res = NextResponse.json({ ok: true });
  res.cookies.set("pf_session", token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production",
    path: "/", maxAge: 60 * 60 * 8,
  });
  return res;
}

function safeVerify(pw: string, hash: string) {
  try { return verifyPassword(pw, hash); } catch { return false; }
}
