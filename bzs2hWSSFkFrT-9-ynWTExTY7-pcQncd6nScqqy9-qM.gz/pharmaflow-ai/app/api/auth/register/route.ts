import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { encodeSession, hashPassword } from "@/lib/auth";
import { rateLimit, clientIp, POLICIES } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const rl = await rateLimit(`register:${clientIp(req)}`, POLICIES.register.limit, POLICIES.register.windowMs);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Trop de créations de compte depuis cette connexion. Réessayez plus tard." },
      { status: 429, headers: { "Retry-After": String(rl.retryAfter) } },
    );
  }
  const b = await req.json().catch(() => ({}));
  const email = String(b.email ?? "").toLowerCase().trim();
  const password = String(b.password ?? "");
  const fullName = String(b.fullName ?? "").trim();
  const pharmacyName = String(b.pharmacyName ?? "").trim();

  if (!email.includes("@") || password.length < 8 || !fullName || !pharmacyName)
    return NextResponse.json({ error: "Champs manquants ou mot de passe trop court (8 caractères minimum)." }, { status: 422 });

  if (await prisma.user.findUnique({ where: { email } }))
    return NextResponse.json({ error: "Un compte existe déjà avec cet email." }, { status: 409 });

  const ownerRole = await prisma.role.findUnique({ where: { name: "OWNER" } });
  if (!ownerRole) return NextResponse.json({ error: "Rôles non initialisés (lancez npm run db:seed)." }, { status: 500 });

  const pharmacy = await prisma.pharmacy.create({
    data: {
      name: pharmacyName,
      city: String(b.city ?? "Cotonou"),
      country: (b.country ?? "BJ") as any,
      whatsappNo: b.whatsapp ?? null,
      subscription: { create: { plan: "STARTER", status: "TRIALING", trialEndsAt: new Date(Date.now() + 14 * 864e5) } },
    },
  });

  const user = await prisma.user.create({
    data: {
      email, fullName, passwordHash: hashPassword(password),
      memberships: { create: { pharmacyId: pharmacy.id, roleId: ownerRole.id } },
    },
  });

  await prisma.auditLog.create({
    data: { pharmacyId: pharmacy.id, userId: user.id, action: "PHARMACY_CREATED", entity: "Pharmacy", entityId: pharmacy.id },
  });

  const token = encodeSession({
    userId: user.id, email, role: "OWNER", pharmacyId: pharmacy.id, name: fullName,
  });
  const res = NextResponse.json({ ok: true }, { status: 201 });
  res.cookies.set("pf_session", token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 8,
  });
  return res;
}
