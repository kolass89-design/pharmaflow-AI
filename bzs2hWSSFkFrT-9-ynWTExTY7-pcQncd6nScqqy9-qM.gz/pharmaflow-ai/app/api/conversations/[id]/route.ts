import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, oneOf, str, throttle, ApiError } from "@/lib/api";

const STATUTS = ["BOT", "HUMAN", "CLOSED"] as const;

/** Reprise en main par un pharmacien, ou clôture de la conversation. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("whatsapp.write");
    await throttle(s, "write");

    const conv = await prisma.whatsappConversation.findFirst({ where: { id, pharmacyId: s.pharmacyId } });
    if (!conv) throw new ApiError(404, "Conversation introuvable dans votre officine.");

    const b = await req.json().catch(() => ({}));
    const status = oneOf(b.status, "Statut", STATUTS);

    await prisma.whatsappConversation.update({ where: { id }, data: { status } });
    await audit(s, `CONVERSATION_${status}`, "WhatsappConversation", id);
    return { status };
  });
}

/**
 * Réponse manuelle du pharmacien.
 * Le message est enregistré et la conversation passe en HUMAN : le bot se tait
 * ensuite, pour ne pas couper la parole au professionnel.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("whatsapp.write");
    await throttle(s, "write");

    const conv = await prisma.whatsappConversation.findFirst({ where: { id, pharmacyId: s.pharmacyId } });
    if (!conv) throw new ApiError(404, "Conversation introuvable.");

    const b = await req.json().catch(() => ({}));
    const texte = str(b.message, "Message", { min: 1, max: 4000 });

    await prisma.whatsappMessage.create({
      data: { conversationId: id, direction: "OUT", sender: "STAFF", body: texte },
    });
    await prisma.whatsappConversation.update({
      where: { id }, data: { status: "HUMAN", lastMessageAt: new Date() },
    });

    // L'émission réelle exige WHATSAPP_TOKEN ; sans lui, le message est
    // conservé mais non transmis. On le dit plutôt que de le masquer.
    const token = process.env.WHATSAPP_TOKEN;
    const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
    let envoye = false;
    if (token && phoneId) {
      try {
        const r = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            messaging_product: "whatsapp", to: conv.phone,
            type: "text", text: { preview_url: false, body: texte },
          }),
          signal: AbortSignal.timeout(8000),
        });
        envoye = r.ok;
      } catch { envoye = false; }
    }

    await audit(s, "WHATSAPP_REPLY", "WhatsappConversation", id, { envoye });
    return {
      envoye,
      avertissement: envoye ? undefined
        : "Message enregistré mais non transmis : le numéro WhatsApp Business n'est pas encore configuré.",
    };
  });
}
