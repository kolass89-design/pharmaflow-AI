import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getSession, can } from "@/lib/auth";
import { requirePermission, handle, audit, str, int, date, assertOwnership, ApiError, throttle } from "@/lib/api";
import { getPrescriptions } from "@/lib/queries";

export async function GET() {
  const s = await getSession();
  if (!s) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!can(s.role, "prescriptions.read")) return NextResponse.json({ error: "Accès refusé" }, { status: 403 });
  return NextResponse.json({ data: await getPrescriptions(s.pharmacyId) });
}

/**
 * Création d'une ordonnance.
 * Contrôle métier : croisement automatique des produits prescrits avec les allergies
 * déclarées du patient. Les alertes sont renvoyées au pharmacien, qui reste décisionnaire.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("prescriptions.write");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const patientId = await assertOwnership("patient", str(b.patientId, "Patient")!, s.pharmacyId);
    const items = Array.isArray(b.items) ? b.items : [];
    if (!items.length) throw new ApiError(422, "L'ordonnance doit contenir au moins une ligne.");
    if (items.length > 30) throw new ApiError(422, "Trop de lignes prescrites (30 maximum).");

    const patient = await prisma.patient.findUnique({ where: { id: patientId } });
    const allergies = (patient?.allergies ?? "").toLowerCase();

    const lignes = [];
    const alertes: string[] = [];
    for (const it of items) {
      const label = str(it.label, "Libellé de la ligne", { min: 2 })!;
      const productId = it.productId ? await assertOwnership("product", String(it.productId), s.pharmacyId) : null;

      if (allergies && allergies !== "—") {
        const produit = productId
          ? await prisma.product.findUnique({ where: { id: productId }, select: { name: true, dci: true } })
          : null;
        const cibles = [label, produit?.name, produit?.dci].filter(Boolean).join(" ").toLowerCase();
        for (const a of allergies.split(/[,;]/).map(x => x.trim()).filter(x => x.length > 3)) {
          if (cibles.includes(a)) alertes.push(`⚠️ ${label} — allergie déclarée : ${a}`);
        }
      }

      lignes.push({
        label, productId,
        dosage: str(it.dosage, "Posologie", { optional: true }),
        duration: str(it.duration, "Durée", { optional: true }),
        quantity: int(it.quantity, "Quantité", { min: 1, optional: true }) ?? 1,
      });
    }

    const presc = await prisma.prescription.create({
      data: {
        pharmacyId: s.pharmacyId, patientId,
        prescriber: str(b.prescriber, "Prescripteur", { optional: true }),
        issuedAt: date(b.issuedAt, "Date de prescription", { optional: true }) ?? new Date(),
        notes: str(b.notes, "Notes", { max: 2000, optional: true }),
        imageUrl: str(b.imageUrl, "Image", { optional: true }),
        ocrText: str(b.ocrText, "Texte OCR", { max: 10000, optional: true }),
        status: "PENDING",
        items: { create: lignes },
      },
      include: { items: true },
    });

    await audit(s, "PRESCRIPTION_CREATE", "Prescription", presc.id, { lignes: lignes.length, alertes: alertes.length });
    return { prescription: { id: presc.id, lignes: presc.items.length }, alertes };
  });
}
