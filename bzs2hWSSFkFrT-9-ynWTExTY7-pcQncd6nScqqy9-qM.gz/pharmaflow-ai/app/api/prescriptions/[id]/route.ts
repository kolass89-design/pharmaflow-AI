import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, oneOf, assertOwnership } from "@/lib/api";

const STATUTS = ["PENDING", "PARTIAL", "SERVED", "ARCHIVED"] as const;

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { id } = await params;
    const s = await requirePermission("prescriptions.write");
    await assertOwnership("prescription", id, s.pharmacyId);
    const b = await req.json().catch(() => ({}));
    const status = oneOf(b.status, "Statut", STATUTS);

    await prisma.prescription.update({ where: { id: id }, data: { status } });
    await audit(s, "PRESCRIPTION_STATUS", "Prescription", id, { status });
    return { status };
  });
}
