import { prisma } from "@/lib/db";
import { requirePermission, handle, audit, str, oneOf, throttle, assertOwnership } from "@/lib/api";

const CANAUX = ["WHATSAPP", "SMS"] as const;

/**
 * Rappel de traitement.
 *
 * L'envoi effectif n'est pas encore branché (WhatsApp Business API en cours de
 * validation Meta) : le rappel est enregistré et affiché, mais aucun message ne
 * part. L'interface le dit explicitement plutôt que de laisser croire le contraire.
 */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await requirePermission("patients.write");
    await throttle(s, "write");
    const b = await req.json().catch(() => ({}));

    const patientId = await assertOwnership("patient", str(b.patientId, "Patient"), s.pharmacyId);
    const rappel = await prisma.treatmentReminder.create({
      data: {
        patientId,
        label: str(b.label, "Libellé du rappel", { min: 3 }),
        schedule: str(b.schedule, "Fréquence", { min: 2 }),
        channel: oneOf(b.channel, "Canal", CANAUX, "WHATSAPP"),
      },
    });

    await audit(s, "REMINDER_CREATE", "TreatmentReminder", rappel.id);
    return {
      rappel: { id: rappel.id, label: rappel.label },
      avertissement: "Rappel enregistré. L'envoi automatique sera actif après validation du numéro WhatsApp par Meta.",
    };
  });
}
