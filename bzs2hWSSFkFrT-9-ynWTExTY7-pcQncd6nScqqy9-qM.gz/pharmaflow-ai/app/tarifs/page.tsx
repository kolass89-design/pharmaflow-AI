"use client";
import { useState } from "react";
import Link from "next/link";
import SiteShell from "@/components/site/SiteShell";
import { plans } from "@/lib/mock";
import { fcfa } from "@/lib/utils";

const faq = [
  ["Y a-t-il un engagement ?", "Non. L'abonnement mensuel est sans engagement et résiliable à tout moment. L'annuel offre deux mois gratuits."],
  ["Comment payer depuis le Bénin ou le Togo ?", "Par MTN MoMo, Moov Money, Celtiis Cash, Orange Money, Wave selon le pays, par virement ou par carte."],
  ["Que se passe-t-il après les 14 jours d'essai ?", "Votre compte passe en lecture seule. Aucune donnée n'est supprimée avant 90 jours et l'export reste disponible."],
  ["La reprise de mon stock existant est-elle incluse ?", "Oui : import Excel guidé inclus dans tous les plans, accompagnement téléphonique inclus en Pro et Enterprise."],
  ["Le prix dépend-il du nombre de ventes ?", "Non. Le prix dépend du plan et du nombre d'utilisateurs, jamais de votre chiffre d'affaires."],
  ["Puis-je gérer plusieurs officines ?", "Oui, avec le plan Enterprise : tableau consolidé, transferts de stock inter-sites et droits par établissement."],
];

export default function Page() {
  const [annuel, setAnnuel] = useState(false);
  return (
    <SiteShell>
      <section className="border-b border-slate-200 bg-brand-50/60 py-16 text-center dark:border-white/10 dark:bg-brand-900/10">
        <div className="container-x">
          <span className="badge">Tarifs</span>
          <h1 className="h2 mt-4">Des prix clairs, en FCFA</h1>
          <p className="mx-auto mt-4 max-w-xl muted">14 jours d'essai gratuit sur tous les plans, sans carte bancaire.</p>
          <div className="mt-8 inline-flex rounded-xl border border-slate-300 bg-white p-1 dark:border-white/15 dark:bg-white/5">
            <button onClick={() => setAnnuel(false)} className={"rounded-lg px-4 py-2 text-sm font-semibold " + (!annuel ? "bg-brand-600 text-white" : "muted")}>Mensuel</button>
            <button onClick={() => setAnnuel(true)} className={"rounded-lg px-4 py-2 text-sm font-semibold " + (annuel ? "bg-brand-600 text-white" : "muted")}>Annuel · 2 mois offerts</button>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container-x grid gap-6 lg:grid-cols-3">
          {plans.map((p) => (
            <div key={p.nom} className={"card flex flex-col " + (p.populaire ? "ring-2 ring-brand-600" : "")}>
              {p.populaire && <span className="badge mb-3 w-fit">Le plus choisi</span>}
              <h2 className="text-xl font-bold">{p.nom}</h2>
              <p className="mt-1 text-sm muted">{p.cible}</p>
              <p className="mt-6 text-3xl font-extrabold">
                {p.mensuel === 0 ? "Sur devis" : fcfa(annuel ? p.annuel : p.mensuel)}
                {p.mensuel !== 0 && <span className="text-sm font-normal muted">/{annuel ? "an" : "mois"}</span>}
              </p>
              <ul className="mt-6 flex-1 space-y-2 text-sm muted">
                {p.features.map((f) => <li key={f} className="flex gap-2"><span className="text-brand-600">✓</span>{f}</li>)}
              </ul>
              <Link href={p.mensuel === 0 ? "/contact" : "/inscription"} className={"mt-8 " + (p.populaire ? "btn-primary" : "btn-ghost")}>
                {p.mensuel === 0 ? "Demander un devis" : "Démarrer l'essai"}
              </Link>
            </div>
          ))}
        </div>
        <div className="container-x mt-8 text-center text-sm muted">
          Paiement accepté : MTN MoMo · Moov Money · Orange Money · Celtiis Cash · Wave · Virement · Carte
        </div>
      </section>

      <section className="section bg-white dark:bg-white/5">
        <div className="container-x">
          <h2 className="h2">Questions fréquentes sur les tarifs</h2>
          <div className="mt-8 grid gap-4 lg:grid-cols-2">
            {faq.map(([q, a]) => (
              <details key={q} className="card">
                <summary className="cursor-pointer font-semibold">{q}</summary>
                <p className="mt-3 text-sm muted">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
