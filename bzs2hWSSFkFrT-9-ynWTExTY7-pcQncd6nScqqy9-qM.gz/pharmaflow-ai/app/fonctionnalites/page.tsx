import SiteShell from "@/components/site/SiteShell";
import Link from "next/link";

const modules = [
  { t: "Caisse POS", d: "Encaissement clavier/code-barres, remises ligne ou ticket, multi-paiement (espèces, MTN MoMo, Moov Money, Orange Money, Celtiis Cash, Wave, carte), retours, clôture de caisse avec écart constaté.", p: ["Mode hors ligne complet","Ticket 58/80 mm","Clôture par caissier"] },
  { t: "Stock & lots", d: "Fiche produit avec DCI, forme, dosage, lots, dates de péremption, seuils d'alerte, prix d'achat, prix de vente et marge calculée. Historique complet des mouvements.", p: ["Import Excel","Export Excel/PDF","Inventaire tournant"] },
  { t: "Ordonnances", d: "Création assistée, rattachement au patient, lignes prescrites, posologies, notes du pharmacien et croisement automatique avec les allergies déclarées.", p: ["Alerte allergies","Suivi du statut","Archivage"] },
  { t: "Patients", d: "Fiche patient, historique d'achats, allergies, pathologies chroniques, documents médicaux et rappels de traitement envoyés par WhatsApp ou SMS.", p: ["Consentement tracé","Rappels automatiques","Accès restreint"] },
  { t: "Fournisseurs", d: "Répertoire des grossistes, bons de commande générés depuis les suggestions IA, suivi des livraisons, réception partielle, factures et encours.", p: ["Réception partielle","Encours par grossiste","Délais suivis"] },
  { t: "Comptabilité", d: "Recettes, dépenses, bénéfice, marge brute par famille, rapports mensuels, export fiscal et rapprochement des paiements Mobile Money.", p: ["Export fiscal","Marge par famille","Rapprochement MoMo"] },
  { t: "Intelligence artificielle", d: "Prévision de la demande, suggestions de réapprovisionnement, détection d'anomalies de caisse, produits dormants, produits les plus rentables et questions/réponses sur vos données.", p: ["Prévision 30 j","Anomalies caisse","Assistant Q/R"] },
  { t: "Agent WhatsApp", d: "Numéro professionnel connecté, réponses automatiques sur la disponibilité et les prix, réservations, transfert humain systématique dès qu'une question devient thérapeutique.", p: ["WhatsApp Business API","Réservation 2 h","Transfert humain"] },
  { t: "Mobile & PWA", d: "Application installable pour le comptoir mobile et application patient : recherche de médicament, officines proches, réservation, itinéraire et pharmacies de garde.", p: ["Installable","Hors ligne","Notifications push"] },
  { t: "Paramètres & sécurité", d: "Utilisateurs, rôles et permissions fines, horaires d'ouverture, moyens de paiement acceptés, sauvegardes chiffrées, journal d'audit et gestion de l'abonnement.", p: ["5 rôles","Journal d'audit","Sauvegardes"] },
];

export default function Page() {
  return (
    <SiteShell>
      <section className="border-b border-slate-200 bg-brand-50/60 py-16 dark:border-white/10 dark:bg-brand-900/10">
        <div className="container-x">
          <span className="badge">Fonctionnalités</span>
          <h1 className="h2 mt-4">Une plateforme, dix modules connectés</h1>
          <p className="mt-4 max-w-2xl muted">Chaque vente met à jour le stock, la comptabilité et les modèles de prévision. Aucune double saisie.</p>
        </div>
      </section>
      <section className="section">
        <div className="container-x grid gap-6 lg:grid-cols-2">
          {modules.map((m) => (
            <div key={m.t} className="card" id={m.t.toLowerCase().split(" ")[0]}>
              <h2 className="text-xl font-bold">{m.t}</h2>
              <p className="mt-3 text-sm muted">{m.d}</p>
              <div className="mt-4 flex flex-wrap gap-2">{m.p.map((x) => <span key={x} className="badge">{x}</span>)}</div>
            </div>
          ))}
        </div>
        <div className="container-x mt-12 text-center">
          <Link href="/demo" className="btn-primary">Explorer la démo interactive</Link>
        </div>
      </section>
    </SiteShell>
  );
}
