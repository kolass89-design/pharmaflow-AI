-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "isPublic" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "requiresPrescription" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "Reservation" ADD COLUMN     "customerName" TEXT,
ADD COLUMN     "customerPhoneEnc" TEXT,
ADD COLUMN     "productLabel" TEXT,
ADD COLUMN     "source" TEXT NOT NULL DEFAULT 'WHATSAPP',
ADD COLUMN     "unitPrice" INTEGER;

-- CreateIndex
CREATE INDEX "Reservation_pharmacyId_status_idx" ON "Reservation"("pharmacyId", "status");

-- AddForeignKey
ALTER TABLE "Reservation" ADD CONSTRAINT "Reservation_pharmacyId_fkey" FOREIGN KEY ("pharmacyId") REFERENCES "Pharmacy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
