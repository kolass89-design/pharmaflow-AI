-- Recherche insensible aux accents pour l'espace patient
CREATE EXTENSION IF NOT EXISTS unaccent;
