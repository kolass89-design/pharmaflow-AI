/**
 * Rotation de la clé de chiffrement des données patients.
 *
 * Procédure sans interruption de service :
 *   1. Générer une nouvelle clé   : node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
 *   2. ENCRYPTION_KEY_OLD = ancienne clé   (le déchiffrement accepte les deux)
 *      ENCRYPTION_KEY     = nouvelle clé   (les écritures utilisent déjà la nouvelle)
 *   3. Redéployer — l'application fonctionne avec les deux clés.
 *   4. Lancer ce script : npx tsx prisma/rotate-key.ts
 *   5. Une fois à 0 restant, retirer ENCRYPTION_KEY_OLD et redéployer.
 *
 * Le script est interruptible et rejouable : il ne réécrit que ce qui doit l'être.
 */
import { PrismaClient } from "@prisma/client";
import { encrypt, decrypt, needsRewrap } from "../lib/crypto-core";

const prisma = new PrismaClient();
const DRY = process.argv.includes("--dry-run");

async function main() {
  if (!process.env.ENCRYPTION_KEY) throw new Error("ENCRYPTION_KEY absente.");
  console.log(DRY ? "→ Simulation (aucune écriture)\n" : "→ Rotation en cours\n");

  const patients = await prisma.patient.findMany({ select: { id: true, fullName: true, phoneEnc: true } });
  let aReecrire = 0, reecrits = 0, illisibles = 0, vides = 0;

  for (const p of patients) {
    if (!p.phoneEnc) { vides++; continue; }
    if (!needsRewrap(p.phoneEnc)) continue;

    aReecrire++;
    const clair = decrypt(p.phoneEnc);
    if (clair === null) {
      illisibles++;
      console.warn(`  ⚠️  ${p.fullName} (${p.id}) : illisible avec les clés fournies — vérifiez ENCRYPTION_KEY_OLD.`);
      continue;
    }
    if (!DRY) {
      await prisma.patient.update({ where: { id: p.id }, data: { phoneEnc: encrypt(clair) } });
      reecrits++;
    }
  }

  console.log(`\nPatients        : ${patients.length}`);
  console.log(`Sans téléphone  : ${vides}`);
  console.log(`À réécrire      : ${aReecrire}`);
  console.log(DRY ? `Simulés         : ${aReecrire - illisibles}` : `Réécrits        : ${reecrits}`);
  if (illisibles) {
    console.error(`\n❌ ${illisibles} enregistrement(s) illisible(s). N'ôtez PAS ENCRYPTION_KEY_OLD.`);
    process.exit(1);
  }
  console.log("\n✅ Rotation terminée. ENCRYPTION_KEY_OLD peut être retirée après redéploiement.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
