/**
 * Seed PharmaFlow AI — jeu de données réaliste pour une officine de Cotonou.
 * Exécution : npm run db:seed
 */
import { PrismaClient, RoleName, Country, Currency, MovementType, PaymentMethod, PoStatus, PrescriptionStatus, ConversationStatus, PlanTier, SubStatus } from "@prisma/client";
import crypto from "crypto";

const prisma = new PrismaClient();

function hashPassword(pw: string, salt = crypto.randomBytes(16).toString("hex")) {
  const h = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `scrypt$${salt}$${h}`;
}

const PERMISSIONS: [string, string][] = [
  ["pos.sell", "Encaisser une vente"],
  ["pos.refund", "Rembourser une vente"],
  ["pos.close", "Clôturer la caisse"],
  ["stock.read", "Consulter le stock"],
  ["stock.write", "Créer et modifier des produits"],
  ["stock.move", "Enregistrer un mouvement de stock"],
  ["prescriptions.read", "Consulter les ordonnances"],
  ["prescriptions.write", "Créer et servir des ordonnances"],
  ["patients.read", "Consulter les dossiers patients"],
  ["patients.write", "Modifier les dossiers patients"],
  ["suppliers.read", "Consulter les fournisseurs"],
  ["suppliers.write", "Gérer commandes et fournisseurs"],
  ["accounting.read", "Consulter la comptabilité"],
  ["accounting.write", "Saisir dépenses et exports"],
  ["ai.read", "Consulter les recommandations IA"],
  ["whatsapp.read", "Lire les conversations"],
  ["whatsapp.write", "Répondre aux patients"],
  ["settings.write", "Modifier les paramètres"],
  ["users.manage", "Gérer les utilisateurs"],
];

const ROLE_PERMS: Record<RoleName, string[] | "ALL"> = {
  OWNER: "ALL",
  PHARMACIST: ["pos.sell","pos.refund","pos.close","stock.read","stock.write","stock.move","prescriptions.read","prescriptions.write","patients.read","patients.write","suppliers.read","suppliers.write","ai.read","whatsapp.read","whatsapp.write"],
  TECHNICIAN: ["pos.sell","stock.read","stock.move","prescriptions.read","patients.read"],
  CASHIER: ["pos.sell","pos.close","stock.read"],
  ACCOUNTANT: ["accounting.read","accounting.write","suppliers.read","stock.read"],
};

async function main() {
  console.log("→ Nettoyage…");
  // Ordre inverse des dépendances ; les cascades font le reste.
  // Ordre imposé par les clés étrangères : SaleItem et StockMovement pointent
  // vers Product sans cascade, la suppression de Pharmacy échouerait sinon.
  await prisma.payment.deleteMany();
  await prisma.saleItem.deleteMany();
  await prisma.sale.deleteMany();
  await prisma.stockMovement.deleteMany();
  await prisma.purchaseOrderItem.deleteMany();
  await prisma.purchaseOrder.deleteMany();
  await prisma.prescriptionItem.deleteMany();
  await prisma.prescription.deleteMany();
  await prisma.treatmentReminder.deleteMany();
  await prisma.reservation.deleteMany();
  await prisma.whatsappMessage.deleteMany();
  await prisma.whatsappConversation.deleteMany();
  await prisma.productBatch.deleteMany();
  await prisma.product.deleteMany();
  await prisma.patient.deleteMany();
  await prisma.supplier.deleteMany();
  await prisma.expense.deleteMany();
  await prisma.aiRecommendation.deleteMany();
  await prisma.guardSchedule.deleteMany();
  await prisma.auditLog.deleteMany();
  await prisma.invoice.deleteMany();
  await prisma.subscription.deleteMany();
  await prisma.pharmacyMember.deleteMany();
  await prisma.pharmacy.deleteMany();
  await prisma.user.deleteMany();
  await prisma.role.deleteMany();
  await prisma.permission.deleteMany();

  console.log("→ Permissions & rôles…");
  await prisma.permission.createMany({
    data: PERMISSIONS.map(([code, label]) => ({ code, label })),
  });
  const allPerms = await prisma.permission.findMany();

  const roleLabels: Record<RoleName, string> = {
    OWNER: "Pharmacien titulaire",
    PHARMACIST: "Pharmacien",
    TECHNICIAN: "Préparateur",
    CASHIER: "Caissier",
    ACCOUNTANT: "Comptable",
  };

  const roles: Record<string, string> = {};
  for (const name of Object.keys(ROLE_PERMS) as RoleName[]) {
    const wanted = ROLE_PERMS[name];
    const perms = wanted === "ALL" ? allPerms : allPerms.filter(p => wanted.includes(p.code));
    const r = await prisma.role.create({
      data: { name, label: roleLabels[name], permissions: { connect: perms.map(p => ({ id: p.id })) } },
    });
    roles[name] = r.id;
  }

  console.log("→ Pharmacie & équipe…");
  const pharmacy = await prisma.pharmacy.create({
    data: {
      name: "Pharmacie Étoile",
      city: "Cotonou",
      district: "Gbégamey",
      country: Country.BJ,
      currency: Currency.XOF,
      licenseNo: "BJ-PH-2019-0447",
      phone: "+229 21 30 44 12",
      whatsappNo: "+229 97 00 00 00",
      latitude: 6.3703,
      longitude: 2.3912,
      openingHours: {
        lun_ven: "07:30-21:00", sam: "08:00-20:00", dim: "09:00-13:00",
      },
    },
  });

  const team: [string, string, RoleName][] = [
    ["demo@pharmaflow.ai", "Dr. Léonie Ahouansou", RoleName.OWNER],
    ["marc.dossou@pharmaflow.ai", "Marc Dossou", RoleName.PHARMACIST],
    ["grace.todjinou@pharmaflow.ai", "Grace Todjinou", RoleName.TECHNICIAN],
    ["ismael.koudjo@pharmaflow.ai", "Ismaël Koudjo", RoleName.CASHIER],
    ["cabinet.yekpon@pharmaflow.ai", "Cabinet Yèkpon", RoleName.ACCOUNTANT],
  ];

  const users: Record<string, string> = {};
  for (const [email, fullName, role] of team) {
    const u = await prisma.user.create({
      data: {
        email, fullName,
        passwordHash: hashPassword("demo1234"),
        memberships: { create: { pharmacyId: pharmacy.id, roleId: roles[role] } },
      },
    });
    users[role] = u.id;
  }

  console.log("→ Abonnement…");
  await prisma.subscription.create({
    data: {
      pharmacyId: pharmacy.id, plan: PlanTier.PRO, status: SubStatus.TRIALING,
      amount: 39000, currency: Currency.XOF,
      trialEndsAt: new Date(Date.now() + 11 * 864e5),
    },
  });

  console.log("→ Officine partenaire (comparaison des disponibilités)…");
  const partenaire = await prisma.pharmacy.create({
    data: {
      name: "Pharmacie Sainte-Rita", city: "Cotonou", district: "Akpakpa",
      country: Country.BJ, currency: Currency.XOF,
      phone: "+229 21 33 08 45", whatsappNo: "+229 96 55 22 11",
      latitude: 6.3612, longitude: 2.4501,
      openingHours: { lun_ven: "08:00-20:00", sam: "08:00-19:00", dim: "fermé" },
      subscription: { create: { plan: PlanTier.STARTER, status: SubStatus.ACTIVE, amount: 19000 } },
    },
  });

  console.log("→ Fournisseurs…");
  const suppliersData = [
    { name: "UBIPHARM", country: Country.BJ, leadTimeHours: 48, balance: 2_450_000, phone: "+229 21 33 10 00" },
    { name: "CAMEG", country: Country.TG, leadTimeHours: 72, balance: 890_000, phone: "+228 22 21 40 00" },
    { name: "LABOREX", country: Country.CI, leadTimeHours: 96, balance: 1_120_000, phone: "+225 27 21 75 00" },
  ];
  const suppliers = [];
  for (const s of suppliersData) {
    suppliers.push(await prisma.supplier.create({ data: { ...s, pharmacyId: pharmacy.id } }));
  }
  const [ubipharm, cameg, laborex] = suppliers;

  console.log("→ Catalogue produits & lots…");
  const productsData = [
    { name: "Amoxicilline 500 mg (12 gél.)", dci: "Amoxicilline", form: "Gélule", dosage: "500 mg", barcode: "6001234500011", category: "Antibiotique", purchasePrice: 1600, salePrice: 2500, alertThreshold: 40, supplier: ubipharm, qty: 126, batch: "LOT-A231", exp: "2027-03-31" },
    { name: "Paracétamol 1 g (8 cp.)", dci: "Paracétamol", form: "Comprimé", dosage: "1 g", barcode: "6001234500028", category: "Antalgique", purchasePrice: 420, salePrice: 700, alertThreshold: 60, supplier: cameg, qty: 28, batch: "LOT-P118", exp: "2026-11-30" },
    { name: "Artéméther/Luméfantrine 20/120", dci: "Artéméther + Luméfantrine", form: "Comprimé", dosage: "20/120 mg", barcode: "6001234500035", category: "Antipaludique", purchasePrice: 1750, salePrice: 2900, alertThreshold: 35, supplier: ubipharm, qty: 15, batch: "LOT-M442", exp: "2026-09-15" },
    { name: "Metformine 850 mg (30 cp.)", dci: "Metformine", form: "Comprimé", dosage: "850 mg", barcode: "6001234500042", category: "Antidiabétique", purchasePrice: 1200, salePrice: 2100, alertThreshold: 25, supplier: laborex, qty: 74, batch: "LOT-D907", exp: "2028-01-31" },
    { name: "Sérum physiologique 5 ml x20", dci: "Chlorure de sodium 0,9 %", form: "Unidose", dosage: "5 ml", barcode: "6001234500059", category: "Dispositif", purchasePrice: 900, salePrice: 1500, alertThreshold: 30, supplier: cameg, qty: 9, batch: "LOT-S330", exp: "2026-08-20" },
    { name: "Amlodipine 5 mg (30 cp.)", dci: "Amlodipine", form: "Comprimé", dosage: "5 mg", barcode: "6001234500066", category: "Antihypertenseur", purchasePrice: 1050, salePrice: 1800, alertThreshold: 20, supplier: laborex, qty: 58, batch: "LOT-C551", exp: "2027-06-30" },
    { name: "Ibuprofène 400 mg (20 cp.)", dci: "Ibuprofène", form: "Comprimé", dosage: "400 mg", barcode: "6001234500073", category: "Anti-inflammatoire", purchasePrice: 650, salePrice: 1100, alertThreshold: 40, supplier: ubipharm, qty: 92, batch: "LOT-I204", exp: "2027-10-31" },
    { name: "Oméprazole 20 mg (14 gél.)", dci: "Oméprazole", form: "Gélule", dosage: "20 mg", barcode: "6001234500080", category: "Anti-ulcéreux", purchasePrice: 1350, salePrice: 2300, alertThreshold: 25, supplier: laborex, qty: 47, batch: "LOT-O615", exp: "2027-12-31" },
    { name: "Sels de réhydratation orale (sachet)", dci: "SRO", form: "Poudre", dosage: "20,5 g", barcode: "6001234500097", category: "Pédiatrie", purchasePrice: 180, salePrice: 350, alertThreshold: 100, supplier: cameg, qty: 240, batch: "LOT-R881", exp: "2028-04-30" },
    { name: "Vitamine B12 injectable (5 amp.)", dci: "Cyanocobalamine", form: "Ampoule", dosage: "1000 µg", barcode: "6001234500103", category: "Vitamine", purchasePrice: 2100, salePrice: 3400, alertThreshold: 10, supplier: ubipharm, qty: 33, batch: "LOT-V119", exp: "2027-02-28" },
  ];

  // Les médicaments soumis à ordonnance ne sont pas réservables librement
  // depuis l'espace public : le patient doit passer au comptoir.
  const SOUS_ORDONNANCE = ["Amoxicilline", "Ceftriaxone", "Metformine", "Amlodipine", "Oméprazole"];

  const products = [];
  for (const p of productsData) {
    const created = await prisma.product.create({
      data: {
        pharmacyId: pharmacy.id, name: p.name, dci: p.dci, form: p.form, dosage: p.dosage,
        barcode: p.barcode, category: p.category, purchasePrice: p.purchasePrice,
        salePrice: p.salePrice, alertThreshold: p.alertThreshold, supplierId: p.supplier.id,
        requiresPrescription: SOUS_ORDONNANCE.some(d => (p.dci + " " + p.name).includes(d)),
        batches: {
          create: { batchNo: p.batch, quantity: p.qty, expiryDate: new Date(p.exp), costPrice: p.purchasePrice },
        },
      },
      include: { batches: true },
    });
    products.push(created);
    await prisma.stockMovement.create({
      data: {
        pharmacyId: pharmacy.id, productId: created.id, batchId: created.batches[0].id,
        type: MovementType.IN, quantity: p.qty, reason: "Stock initial (inventaire d'ouverture)",
        userId: users.OWNER,
      },
    });
  }

  console.log("→ Catalogue de l'officine partenaire…");
  const cataloguePartenaire = [
    { name: "Paracétamol 1 g (8 cp.)", dci: "Paracétamol", pa: 400, pv: 650, qty: 140, lot: "LOT-SR01", exp: "2027-05-31" },
    { name: "Artéméther/Luméfantrine 20/120", dci: "Artéméther + Luméfantrine", pa: 1700, pv: 2750, qty: 95, lot: "LOT-SR02", exp: "2027-08-31" },
    { name: "Sels de réhydratation orale (sachet)", dci: "SRO", pa: 175, pv: 300, qty: 320, lot: "LOT-SR03", exp: "2028-06-30" },
    { name: "Ibuprofène 400 mg (20 cp.)", dci: "Ibuprofène", pa: 630, pv: 1000, qty: 110, lot: "LOT-SR04", exp: "2027-11-30" },
  ];
  for (const c of cataloguePartenaire) {
    await prisma.product.create({
      data: {
        pharmacyId: partenaire.id, name: c.name, dci: c.dci, category: "Général",
        purchasePrice: c.pa, salePrice: c.pv, alertThreshold: 25,
        batches: { create: { batchNo: c.lot, quantity: c.qty, expiryDate: new Date(c.exp), costPrice: c.pa } },
      },
    });
  }

  console.log("→ Patients…");
  const patientsData = [
    { fullName: "Adjovi Sènou", city: "Cotonou", allergies: "Pénicilline", chronicConditions: "Hypertension" },
    { fullName: "Kouassi N'Guessan", city: "Cotonou", allergies: null, chronicConditions: null },
    { fullName: "Fatou Mbaye", city: "Cotonou", allergies: "Sulfamides", chronicConditions: "Diabète type 2" },
    { fullName: "Ibrahim Salou", city: "Porto-Novo", allergies: null, chronicConditions: null },
    { fullName: "Bernadette Agbo", city: "Cotonou", allergies: "Aspirine", chronicConditions: "Asthme" },
  ];
  const patients = [];
  for (const p of patientsData) {
    patients.push(await prisma.patient.create({
      data: { ...p, pharmacyId: pharmacy.id, consentAt: new Date() },
    }));
  }

  console.log("→ Ordonnances…");
  await prisma.prescription.create({
    data: {
      pharmacyId: pharmacy.id, patientId: patients[0].id, prescriber: "Dr. Hounkpatin",
      issuedAt: new Date(Date.now() - 1 * 864e5), status: PrescriptionStatus.SERVED,
      notes: "Traitement de 7 jours, contrôle tensionnel dans 2 semaines.",
      items: {
        create: [
          { label: "Amoxicilline 500 mg", productId: products[0].id, dosage: "1 gél. x3/jour", duration: "7 jours", quantity: 2, served: 2 },
          { label: "Paracétamol 1 g", productId: products[1].id, dosage: "1 cp. si douleur", duration: "5 jours", quantity: 1, served: 1 },
          { label: "Amlodipine 5 mg", productId: products[5].id, dosage: "1 cp. le matin", duration: "30 jours", quantity: 1, served: 1 },
        ],
      },
    },
  });
  await prisma.prescription.create({
    data: {
      pharmacyId: pharmacy.id, patientId: patients[2].id, prescriber: "Dr. Diop",
      issuedAt: new Date(), status: PrescriptionStatus.PENDING,
      items: {
        create: [
          { label: "Metformine 850 mg", productId: products[3].id, dosage: "1 cp. matin et soir", duration: "30 jours", quantity: 2 },
          { label: "Oméprazole 20 mg", productId: products[7].id, dosage: "1 gél. à jeun", duration: "14 jours", quantity: 1 },
        ],
      },
    },
  });

  console.log("→ Historique de ventes (60 jours)…");
  const methods = [PaymentMethod.CASH, PaymentMethod.MTN_MOMO, PaymentMethod.MOOV_MONEY, PaymentMethod.CELTIIS_CASH, PaymentMethod.WAVE, PaymentMethod.CARD];
  let ref = 89000;
  for (let d = 59; d >= 0; d--) {
    const day = new Date(); day.setDate(day.getDate() - d); day.setHours(9, 0, 0, 0);
    const isWeekend = day.getDay() === 0;
    const nSales = isWeekend ? 4 + Math.floor(Math.random() * 4) : 8 + Math.floor(Math.random() * 8);
    for (let i = 0; i < nSales; i++) {
      const nItems = 1 + Math.floor(Math.random() * 3);
      const picked = [...products].sort(() => Math.random() - 0.5).slice(0, nItems);
      const items = picked.map(p => {
        const quantity = 1 + Math.floor(Math.random() * 2);
        return { productId: p.id, quantity, unitPrice: p.salePrice, discount: 0, lineTotal: p.salePrice * quantity };
      });
      const subtotal = items.reduce((s, it) => s + it.lineTotal, 0);
      const soldAt = new Date(day); soldAt.setMinutes(soldAt.getMinutes() + i * 37);
      const method = methods[Math.floor(Math.random() * methods.length)];
      await prisma.sale.create({
        data: {
          pharmacyId: pharmacy.id, userId: users.CASHIER,
          patientId: Math.random() > 0.6 ? patients[Math.floor(Math.random() * patients.length)].id : null,
          reference: "TK-" + (++ref), subtotal, discount: 0, total: subtotal, soldAt,
          items: { create: items },
          payments: { create: { method, amount: subtotal } },
        },
      });
    }
  }

  console.log("→ Dépenses…");
  const expenses = [
    ["Achats", "Facture UBIPHARM juillet", 6_950_000],
    ["Salaires", "Masse salariale juillet", 980_000],
    ["Loyer", "Loyer local commercial", 250_000],
    ["Énergie", "SBEE + carburant groupe", 180_000],
    ["Logiciel", "Abonnement PharmaFlow AI", 39_000],
    ["Divers", "Entretien et fournitures", 141_000],
  ] as const;
  for (const [category, label, amount] of expenses) {
    await prisma.expense.create({ data: { pharmacyId: pharmacy.id, category, label, amount } });
  }

  console.log("→ Commandes fournisseurs…");
  await prisma.purchaseOrder.create({
    data: {
      pharmacyId: pharmacy.id, supplierId: ubipharm.id, reference: "BC-1187",
      status: PoStatus.RECEIVED, totalAmount: 1_240_000, receivedAt: new Date(Date.now() - 2 * 864e5),
      items: { create: [{ productId: products[0].id, quantity: 100, unitCost: 1600, received: 100 }] },
    },
  });
  await prisma.purchaseOrder.create({
    data: {
      pharmacyId: pharmacy.id, supplierId: cameg.id, reference: "BC-1188",
      status: PoStatus.IN_TRANSIT, totalAmount: 430_000, expectedAt: new Date(Date.now() + 864e5),
      items: { create: [{ productId: products[1].id, quantity: 200, unitCost: 420 }] },
    },
  });

  console.log("→ WhatsApp…");
  const conv = await prisma.whatsappConversation.create({
    data: {
      pharmacyId: pharmacy.id, phone: "+229 97 12 34 56", status: ConversationStatus.BOT,
      messages: {
        create: [
          { direction: "IN", sender: "PATIENT", body: "Bonjour, avez-vous de l'Amoxicilline 500 mg ?" },
          { direction: "OUT", sender: "BOT", body: "Bonjour 👋 Oui, disponible. Prix : 2 500 FCFA la boîte de 12 gélules. Souhaitez-vous réserver ?" },
          { direction: "IN", sender: "PATIENT", body: "Oui" },
          { direction: "OUT", sender: "BOT", body: "Réservation confirmée ✅ Référence R-8842, valable 2 heures à la Pharmacie Étoile, Gbégamey." },
        ],
      },
    },
  });
  await prisma.reservation.create({
    data: {
      conversationId: conv.id, pharmacyId: pharmacy.id, productId: products[0].id,
      reference: "R-8842", expiresAt: new Date(Date.now() + 2 * 3600e3),
    },
  });

  console.log("→ Recommandations IA…");
  await prisma.aiRecommendation.createMany({
    data: [
      { pharmacyId: pharmacy.id, type: "RESTOCK", severity: "URGENT", title: "Rupture prévue sous 6 jours", detail: "Paracétamol 1 g — commander 180 boîtes (saison des pluies, +24 % de demande)." },
      { pharmacyId: pharmacy.id, type: "DORMANT", severity: "INFO", title: "Produit dormant", detail: "Vitamine B12 injectable — 0 vente en 45 jours. Envisager un retour fournisseur." },
      { pharmacyId: pharmacy.id, type: "EXPIRY", severity: "WARNING", title: "Expiration proche", detail: "LOT-S330 (Sérum physiologique) expire dans 25 jours — promotion suggérée." },
      { pharmacyId: pharmacy.id, type: "PRICING", severity: "INFO", title: "Marge optimisable", detail: "Amlodipine 5 mg : marge 41 %, hausse de 5 % possible sans perte de volume." },
    ],
  });

  console.log("→ Pharmacies de garde…");
  await prisma.guardSchedule.create({
    data: {
      pharmacyId: pharmacy.id, city: "Cotonou", isPublished: true,
      startsAt: new Date("2026-07-25T08:00:00Z"), endsAt: new Date("2026-07-31T20:00:00Z"),
    },
  });

  await prisma.guardSchedule.create({
    data: {
      pharmacyId: partenaire.id, city: "Cotonou", isPublished: true,
      startsAt: new Date("2026-08-01T08:00:00Z"), endsAt: new Date("2026-08-07T20:00:00Z"),
    },
  });

  console.log("→ Journal d'audit…");
  await prisma.auditLog.createMany({
    data: [
      { pharmacyId: pharmacy.id, userId: users.OWNER, action: "PATIENT_VIEW", entity: "Patient", entityId: patients[0].id },
      { pharmacyId: pharmacy.id, userId: users.CASHIER, action: "SALE_CREATE", entity: "Sale" },
      { pharmacyId: pharmacy.id, userId: users.TECHNICIAN, action: "STOCK_RECEIVE", entity: "PurchaseOrder" },
      { pharmacyId: pharmacy.id, action: "BACKUP_SUCCESS", entity: "System" },
    ],
  });

  const counts = {
    produits: await prisma.product.count(),
    ventes: await prisma.sale.count(),
    lignes: await prisma.saleItem.count(),
    patients: await prisma.patient.count(),
  };
  console.log("\n✅ Seed terminé :", counts);
  console.log("   Connexion : demo@pharmaflow.ai / demo1234");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
