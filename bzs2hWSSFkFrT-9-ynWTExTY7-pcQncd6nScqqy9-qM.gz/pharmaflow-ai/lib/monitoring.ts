import "server-only";

/**
 * Supervision applicative.
 *
 * Sentry n'est pas imposé comme dépendance : sur un déploiement modeste, une
 * webhook (Slack, Discord, e-mail via un relais) suffit et n'ajoute aucun paquet.
 * L'interface reste la même, ce qui permet de brancher Sentry plus tard sans
 * toucher au code applicatif.
 */

export type Severity = "info" | "warning" | "error" | "critical";

type Event = {
  severity: Severity;
  message: string;
  context?: Record<string, unknown>;
  pharmacyId?: string;
  userId?: string;
};

const WEBHOOK = process.env.MONITORING_WEBHOOK_URL;
const ENV = process.env.NODE_ENV ?? "development";

/** Champs à ne jamais transmettre à un service tiers. */
const INTERDITS = ["password", "passwordhash", "phone", "phoneenc", "token", "secret", "authorization", "cookie", "allergies", "fullname", "patientid"];

/**
 * Retire les données personnelles ou sensibles avant tout envoi externe.
 * Une supervision ne doit jamais devenir un canal de fuite de données de santé.
 */
export function scrub(input: unknown, profondeur = 0): unknown {
  if (profondeur > 4) return "[trop profond]";
  if (input === null || typeof input !== "object") return input;
  if (Array.isArray(input)) return input.slice(0, 20).map(v => scrub(v, profondeur + 1));

  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(input as Record<string, unknown>)) {
    if (INTERDITS.some(i => k.toLowerCase().includes(i))) { out[k] = "[masqué]"; continue; }
    out[k] = scrub(v, profondeur + 1);
  }
  return out;
}

const EMOJI: Record<Severity, string> = { info: "ℹ️", warning: "⚠️", error: "🔴", critical: "🚨" };

/** Signale un évènement. Ne lève jamais : la supervision ne doit pas casser la requête. */
export async function report(e: Event): Promise<void> {
  const ligne = `${EMOJI[e.severity]} [${ENV}] ${e.message}`;
  const contexte = e.context ? scrub(e.context) : undefined;

  // Toujours dans les logs de la plateforme (Vercel, Railway…).
  if (e.severity === "error" || e.severity === "critical") console.error(ligne, contexte ?? "");
  else if (e.severity === "warning") console.warn(ligne, contexte ?? "");
  else console.info(ligne, contexte ?? "");

  if (!WEBHOOK || ENV === "development") return;

  try {
    await fetch(WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: ligne,
        severity: e.severity,
        pharmacyId: e.pharmacyId,
        userId: e.userId,
        context: contexte,
        at: new Date().toISOString(),
      }),
      signal: AbortSignal.timeout(3000),   // jamais de blocage sur la supervision
    });
  } catch {
    // Silence volontaire : un échec de notification ne doit pas remonter à l'utilisateur.
  }
}

/** Capture une exception avec son contexte. */
export async function captureError(err: unknown, contexte?: Record<string, unknown>) {
  const e = err instanceof Error ? err : new Error(String(err));
  await report({
    severity: "error",
    message: `${e.name}: ${e.message}`,
    context: { ...contexte, stack: e.stack?.split("\n").slice(0, 5).join("\n") },
  });
}

/* ─────────── Seuils métier ─────────── */

export const SEUILS = {
  fileHorsLigne: 25,          // opérations en attente sur un poste
  ageFileMinutes: 120,        // ancienneté de la plus vieille opération
  echecsSynchro: 5,           // opérations définitivement refusées
  tauxErreur5xx: 10,          // erreurs serveur par tranche de 5 minutes
} as const;

/**
 * Alerte si une file hors ligne dérive.
 * Signal fort : une file qui grossit sans se vider signifie qu'un poste
 * encaisse dans le vide — le stock affiché ailleurs est faux.
 */
export async function checkFileHorsLigne(
  params: { pharmacyId: string; enAttente: number; echecs: number; plusAncienneMs: number | null },
) {
  const { pharmacyId, enAttente, echecs, plusAncienneMs } = params;
  const ageMin = plusAncienneMs ? Math.round(plusAncienneMs / 60000) : 0;

  if (echecs >= SEUILS.echecsSynchro) {
    await report({
      severity: "critical", pharmacyId,
      message: `${echecs} vente(s) refusée(s) non traitée(s) — chiffre d'affaires potentiellement sous-évalué.`,
      context: { echecs, enAttente },
    });
    return;
  }
  if (enAttente >= SEUILS.fileHorsLigne || ageMin >= SEUILS.ageFileMinutes) {
    await report({
      severity: "warning", pharmacyId,
      message: `File hors ligne préoccupante : ${enAttente} opération(s), la plus ancienne depuis ${ageMin} min.`,
      context: { enAttente, ageMin },
    });
  }
}
