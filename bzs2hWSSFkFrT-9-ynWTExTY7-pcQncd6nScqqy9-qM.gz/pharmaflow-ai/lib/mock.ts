export const stats = [
  { label: "Pharmacies connectées", value: "180+" },
  { label: "Temps gagné / jour", value: "2 h 15" },
  { label: "Ruptures évitées", value: "-38 %" },
  { label: "Disponibilité service", value: "99,9 %" },
];

export const salesWeek = [
  { jour: "Lun", ventes: 412000, ordonnances: 21 },
  { jour: "Mar", ventes: 388500, ordonnances: 18 },
  { jour: "Mer", ventes: 501200, ordonnances: 27 },
  { jour: "Jeu", ventes: 465800, ordonnances: 24 },
  { jour: "Ven", ventes: 612400, ordonnances: 33 },
  { jour: "Sam", ventes: 704900, ordonnances: 41 },
  { jour: "Dim", ventes: 259300, ordonnances: 12 },
];

export type Product = {
  id: string; nom: string; dci: string; lot: string; expiration: string;
  stock: number; seuil: number; achat: number; vente: number; fournisseur: string;
};

export const products: Product[] = [
  { id:"P-1001", nom:"Amoxicilline 500 mg (12 gél.)", dci:"Amoxicilline", lot:"LOT-A231", expiration:"2027-03-31", stock:126, seuil:40, achat:1600, vente:2500, fournisseur:"UBIPHARM" },
  { id:"P-1002", nom:"Paracétamol 1 g (8 cp.)", dci:"Paracétamol", lot:"LOT-P118", expiration:"2026-11-30", stock:28, seuil:60, achat:420, vente:700, fournisseur:"CAMEG" },
  { id:"P-1003", nom:"Artéméther/Luméfantrine 20/120", dci:"ACT", lot:"LOT-M442", expiration:"2026-09-15", stock:15, seuil:35, achat:1750, vente:2900, fournisseur:"UBIPHARM" },
  { id:"P-1004", nom:"Metformine 850 mg (30 cp.)", dci:"Metformine", lot:"LOT-D907", expiration:"2028-01-31", stock:74, seuil:25, achat:1200, vente:2100, fournisseur:"LABOREX" },
  { id:"P-1005", nom:"Sérum physiologique 5 ml x20", dci:"NaCl 0,9 %", lot:"LOT-S330", expiration:"2026-08-20", stock:9, seuil:30, achat:900, vente:1500, fournisseur:"CAMEG" },
  { id:"P-1006", nom:"Amlodipine 5 mg (30 cp.)", dci:"Amlodipine", lot:"LOT-C551", expiration:"2027-06-30", stock:58, seuil:20, achat:1050, vente:1800, fournisseur:"LABOREX" },
];

export const patients = [
  { id:"PT-201", nom:"Adjovi Sènou", ville:"Cotonou", tel:"+229 97 12 34 56", allergies:"Pénicilline", dernier:"2026-07-21" },
  { id:"PT-202", nom:"Kouassi N'Guessan", ville:"Abidjan", tel:"+225 07 88 21 44", allergies:"—", dernier:"2026-07-24" },
  { id:"PT-203", nom:"Fatou Mbaye", ville:"Dakar", tel:"+221 77 401 22 90", allergies:"Sulfamides", dernier:"2026-07-25" },
  { id:"PT-204", nom:"Ibrahim Salou", ville:"Niamey", tel:"+227 90 55 18 03", allergies:"—", dernier:"2026-07-19" },
];

export const prescriptions = [
  { id:"ORD-4412", patient:"Adjovi Sènou", medecin:"Dr. Hounkpatin", date:"2026-07-25", items:3, statut:"Servie" },
  { id:"ORD-4413", patient:"Fatou Mbaye", medecin:"Dr. Diop", date:"2026-07-25", items:2, statut:"En attente" },
  { id:"ORD-4414", patient:"Kouassi N'Guessan", medecin:"Dr. Aka", date:"2026-07-24", items:5, statut:"Partielle" },
];

export const suppliers = [
  { id:"F-01", nom:"UBIPHARM", pays:"Bénin", delai:"48 h", encours:"2 450 000 FCFA", statut:"Actif" },
  { id:"F-02", nom:"CAMEG", pays:"Togo", delai:"72 h", encours:"890 000 FCFA", statut:"Actif" },
  { id:"F-03", nom:"LABOREX", pays:"Côte d'Ivoire", delai:"96 h", encours:"1 120 000 FCFA", statut:"En négociation" },
];

export const aiRecos = [
  { titre:"Rupture prévue sous 6 jours", detail:"Paracétamol 1 g — commander 180 boîtes (saison des pluies, +24 % de demande).", niveau:"Urgent" },
  { titre:"Produit dormant", detail:"Vitamine B12 injectable — 0 vente en 45 jours. Envisager un retour fournisseur.", niveau:"Info" },
  { titre:"Expiration proche", detail:"LOT-S330 (Sérum physiologique) expire dans 25 jours — promotion suggérée.", niveau:"Attention" },
  { titre:"Marge optimisable", detail:"Amlodipine 5 mg : marge 41 %, hausse de 5 % possible sans perte de volume.", niveau:"Info" },
];

export const waThread = [
  { from:"patient", text:"Bonjour, avez-vous de l'Amoxicilline 500 mg ?" },
  { from:"bot", text:"Bonjour 👋 Oui, disponible. Prix : 2 500 FCFA la boîte de 12 gélules. Souhaitez-vous réserver ?" },
  { from:"patient", text:"Oui" },
  { from:"bot", text:"Réservation confirmée ✅ Votre réf. R-8842 est valable 2 heures à la Pharmacie Étoile, Cotonou." },
];

export const testimonials = [
  { nom:"Dr. Léonie Ahouansou", role:"Pharmacienne titulaire", ville:"Cotonou, Bénin", texte:"La clôture de caisse prenait 45 minutes, elle prend maintenant 5 minutes. Les alertes de rupture nous ont évité de perdre nos clients chroniques." },
  { nom:"Kossi Amegan", role:"Gérant d'officine", ville:"Lomé, Togo", texte:"Le mode hors ligne est décisif : quand le réseau coupe, la caisse continue et tout se synchronise ensuite." },
  { nom:"Dr. Aminata Fall", role:"Pharmacienne", ville:"Dakar, Sénégal", texte:"L'agent WhatsApp répond aux disponibilités la nuit. Nos réservations ont augmenté sans embaucher." },
  { nom:"Dr. Serge Nkoulou", role:"Directeur réseau 4 officines", ville:"Douala, Cameroun", texte:"Le pilotage multi-sites et les rapports consolidés nous donnent enfin une vision unique de la trésorerie." },
  { nom:"Mariam Traoré", role:"Responsable stock", ville:"Abidjan, Côte d'Ivoire", texte:"Le suivi des lots et des péremptions a réduit nos pertes de près d'un tiers en un semestre." },
  { nom:"Dr. Hamidou Issa", role:"Pharmacien titulaire", ville:"Niamey, Niger", texte:"L'interface est simple : mes préparateurs ont été autonomes en deux jours, en français." },
];

export const guards = [
  { pharmacie:"Pharmacie Étoile", ville:"Cotonou", quartier:"Gbégamey", tel:"+229 21 30 44 12", periode:"25 – 31 juillet 2026" },
  { pharmacie:"Pharmacie du Lac", ville:"Cotonou", quartier:"Fidjrossè", tel:"+229 21 35 90 07", periode:"25 – 31 juillet 2026" },
  { pharmacie:"Pharmacie Sainte-Rita", ville:"Porto-Novo", quartier:"Djègan-Kpèvi", tel:"+229 20 21 55 31", periode:"25 – 31 juillet 2026" },
  { pharmacie:"Pharmacie Espoir", ville:"Lomé", quartier:"Bè-Kpota", tel:"+228 22 51 18 44", periode:"25 – 31 juillet 2026" },
  { pharmacie:"Pharmacie Plateau", ville:"Abidjan", quartier:"Plateau", tel:"+225 27 20 32 11", periode:"25 – 31 juillet 2026" },
];

export const posts = [
  { slug:"eviter-ruptures-pharmacie", titre:"Comment éviter les ruptures de stock en pharmacie ?", extrait:"Seuils dynamiques, saisonnalité et délais fournisseurs : la méthode en 5 étapes.", tag:"Stock", duree:"6 min" },
  { slug:"digitaliser-officine-benin", titre:"Digitaliser une officine au Bénin : par où commencer ?", extrait:"Inventaire, codes-barres, caisse, puis IA : un plan réaliste sur 90 jours.", tag:"Transformation", duree:"8 min" },
  { slug:"whatsapp-pharmacie", titre:"Pourquoi connecter WhatsApp à sa pharmacie ?", extrait:"Le canal n°1 en Afrique francophone devient un vrai comptoir virtuel.", tag:"Relation client", duree:"5 min" },
  { slug:"gerer-dates-expiration", titre:"Mieux gérer les dates d'expiration et réduire les pertes", extrait:"FEFO, alertes à 90/60/30 jours et négociation des retours fournisseurs.", tag:"Qualité", duree:"7 min" },
];

export const plans = [
  { nom:"Starter", cible:"Officine unique, 1 à 3 postes", mensuel:19000, annuel:190000,
    features:["Caisse POS + mode hors ligne","Stock, lots & péremptions","2 utilisateurs","Rapports essentiels","Support WhatsApp"] },
  { nom:"Pro", cible:"Pharmacie en croissance", mensuel:39000, annuel:390000, populaire:true,
    features:["Tout Starter","Patients & ordonnances (OCR)","Agent WhatsApp","IA prévision & réappro","10 utilisateurs","Comptabilité & export fiscal"] },
  { nom:"Enterprise", cible:"Réseau multi-officines", mensuel:0, annuel:0,
    features:["Tout Pro","Multi-pharmacies consolidé","Rôles & permissions avancés","Journal d'audit étendu","API & intégrations","Accompagnement dédié"] },
];
