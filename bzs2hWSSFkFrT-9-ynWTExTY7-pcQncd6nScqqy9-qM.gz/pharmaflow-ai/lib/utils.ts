export const cn = (...c: (string | false | undefined | null)[]) => c.filter(Boolean).join(" ");
export const fcfa = (n: number) =>
  new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(n) + " FCFA";
