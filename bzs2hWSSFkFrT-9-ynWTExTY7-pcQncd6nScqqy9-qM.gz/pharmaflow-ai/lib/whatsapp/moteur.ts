import "server-only";
import { prisma } from "../db";
import { encrypt } from "../crypto";

/**
 * Moteur conversationnel de l'agent WhatsApp.
 *
 * Principe directeur : le bot traite la logistique (disponibilité, prix,
 * horaires, réservation) et passe la main dès que la question devient
 * pharmaceutique. Un automate ne donne jamais de conseil thérapeutique.
 *
 * L'état de la conversation vit en base (WhatsappConversation.status) : il n'y
 * a pas de session en mémoire, car les instances serverless sont éphémères.
 */

export type Reponse = {
  texte: string;
  handoff: boolean;              // transfert à un pharmacien
  intention: Intention;
  reservation?: { reference: string; expireLe: string };
};

export type Intention =
  | "salutation" | "recherche" | "reservation" | "confirmation" | "annulation"
  | "horaires" | "adresse" | "suivi" | "conseil_medical" | "humain" | "inconnu";

/* ─────────────── Détection d'intention ─────────────── */

const norm = (s: string) =>
  s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();

/**
 * Motifs déclenchant un transfert humain immédiat.
 * Volontairement larges : en cas de doute, c'est le pharmacien qui répond.
 */
const CONSEIL_MEDICAL = [
  /posologie|dosage|combien de (comprime|gelule|fois)|quelle dose/,
  /enceinte|grossesse|allaite|nourrisson|bebe de/,
  /effets? secondaires?|effets? indesirables?|contre.?indication|allergi|tolerance/,
  /puis.?je prendre|est.?ce que je peux prendre|dangereux|risque/,
  /interaction|avec mon traitement|en meme temps que/,
  /symptome|j'ai mal|je souffre|fievre|douleur|maladie|diagnostic/,
  /ordonnance|prescription|renouveler mon traitement/,
];

const MOTIFS: [Intention, RegExp[]][] = [
  ["conseil_medical", CONSEIL_MEDICAL],
  ["humain", [/parler a (un|une) (pharmacien|humain|personne)|un humain|quelqu'un|conseiller/]],
  ["confirmation", [/^(oui|ok|d'accord|daccord|yes|je confirme|c'est bon|vas.?y)\b/]],
  ["annulation", [/^(non|annuler|annule|laisse tomber|stop)\b/]],
  ["suivi", [/ma reservation|mon code|ou en est|reference r-|statut/]],
  ["horaires", [/horaire|ouvert|fermez|fermeture|quelle heure|de garde|nuit|dimanche/]],
  ["adresse", [/adresse|ou etes.?vous|ou se trouve|situe|localisation|itineraire|comment venir/]],
  ["reservation", [/reserv|mettre de cote|garder|bloquer/]],
  // La salutation ne l'emporte que si elle constitue tout le message :
  // « Bonjour, avez-vous du paracétamol ? » est une recherche, pas un bonjour.
  ["salutation", [/^(bonjour|bonsoir|salut|hello|slt|cc|bjr|bsr|coucou)[\s,!.?]*$/]],
];

export function detecterIntention(message: string): Intention {
  const t = norm(message);
  if (!t) return "salutation";
  for (const [intention, motifs] of MOTIFS) {
    if (motifs.some((m) => m.test(t))) return intention;
  }
  // Un message court et alphabétique est probablement un nom de médicament.
  if (t.length >= 3) return "recherche";
  return "inconnu";
}

/** Extrait le terme de recherche en retirant les formules de politesse. */
export function extraireProduit(message: string): string {
  return norm(message)
    .replace(/^(bonjour|bonsoir|salut|hello|bjr|bsr)[\s,!.]*/g, "")
    .replace(/(est.?ce que vous avez|avez.?vous|vous avez|je cherche|je voudrais|je veux|il me faut|auriez.?vous)/g, "")
    .replace(/\b(du|de la|de l'|des|le|la|les|un|une|svp|s'il vous plait|merci|please)\b/g, "")
    .replace(/[?!.,;]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/* ─────────────── Formatage ─────────────── */

const fcfa = (n: number) => new Intl.NumberFormat("fr-FR").format(n) + " FCFA";

function reference() {
  const lettres = "ABCDEFGHJKLMNPQRSTUVWXYZ";   // ni I ni O : dictées au téléphone
  let s = "";
  for (let i = 0; i < 4; i++) s += lettres[Math.floor(Math.random() * lettres.length)];
  return `R-${s}${Math.floor(1000 + Math.random() * 9000)}`;
}

function horairesLisibles(h: unknown): string {
  if (!h || typeof h !== "object") return "Contactez-nous pour connaître nos horaires.";
  const o = h as Record<string, string>;
  const lignes = [
    o.lun_ven && `Lundi – vendredi : ${o.lun_ven}`,
    o.sam && `Samedi : ${o.sam}`,
    o.dim && `Dimanche : ${o.dim}`,
  ].filter(Boolean);
  return lignes.join("\n");
}

/* ─────────────── Traitement d'un message ─────────────── */

const DUREE_RESERVATION_MS = 2 * 60 * 60 * 1000;

export async function traiterMessage(params: {
  pharmacyId: string;
  telephone: string;
  message: string;
}): Promise<Reponse> {
  const { pharmacyId, telephone, message } = params;

  const pharmacie = await prisma.pharmacy.findUnique({ where: { id: pharmacyId } });
  if (!pharmacie) return { texte: "Service momentanément indisponible.", handoff: true, intention: "inconnu" };

  // La conversation porte l'état : le dernier produit proposé permet de
  // comprendre « oui » comme « oui, je réserve ce produit-là ».
  const conversation = await prisma.whatsappConversation.upsert({
    where: { id: (await trouverConversation(pharmacyId, telephone)) ?? "___nouvelle___" },
    update: { lastMessageAt: new Date() },
    create: { pharmacyId, phone: telephone, status: "BOT" },
    include: { messages: { orderBy: { createdAt: "desc" }, take: 6 } },
  });

  await prisma.whatsappMessage.create({
    data: { conversationId: conversation.id, direction: "IN", sender: "PATIENT", body: message.slice(0, 4000) },
  });

  // Si un humain a repris la main, le bot se tait : rien n'est plus déroutant
  // qu'un automate qui coupe la parole au pharmacien.
  if (conversation.status === "HUMAN") {
    return { texte: "", handoff: true, intention: "humain" };
  }

  const intention = detecterIntention(message);
  const reponse = await construireReponse({ intention, message, pharmacie, conversation });

  if (reponse.texte) {
    await prisma.whatsappMessage.create({
      data: {
        conversationId: conversation.id, direction: "OUT",
        sender: reponse.handoff ? "BOT" : "BOT", body: reponse.texte,
      },
    });
  }

  if (reponse.handoff && conversation.status !== "HUMAN_REQUIRED") {
    await prisma.whatsappConversation.update({
      where: { id: conversation.id }, data: { status: "HUMAN_REQUIRED" },
    });
  }

  return reponse;
}

async function trouverConversation(pharmacyId: string, telephone: string) {
  const c = await prisma.whatsappConversation.findFirst({
    where: { pharmacyId, phone: telephone, status: { not: "CLOSED" } },
    orderBy: { lastMessageAt: "desc" },
  });
  return c?.id ?? null;
}

/** Retrouve le dernier produit proposé par le bot dans l'historique récent. */
async function dernierProduitPropose(pharmacyId: string, messages: { body: string; sender: string }[]) {
  const propositions = messages.filter((m) => m.sender === "BOT" && m.body.includes("FCFA"));
  if (!propositions.length) return null;
  const nom = propositions[0].body.match(/^(?:Oui, )?(.+?) est disponible/)?.[1]
    ?? propositions[0].body.split("\n")[0];
  if (!nom) return null;
  return prisma.product.findFirst({
    where: { pharmacyId, name: nom.trim(), isActive: true },
    include: { batches: { where: { quantity: { gt: 0 }, expiryDate: { gt: new Date() } } } },
  });
}

async function construireReponse(ctx: {
  intention: Intention;
  message: string;
  pharmacie: { id: string; name: string; city: string; district: string | null; phone: string | null; openingHours: unknown };
  conversation: { id: string; messages: { body: string; sender: string }[] };
}): Promise<Reponse> {
  const { intention, message, pharmacie, conversation } = ctx;

  switch (intention) {
    case "conseil_medical":
      return {
        intention, handoff: true,
        texte:
          "Votre question demande l'avis d'un professionnel. Je transmets à notre pharmacien, " +
          `qui vous répondra en personne dans quelques instants.\n\nSi c'est urgent : ${pharmacie.phone ?? "appelez l'officine"}.`,
      };

    case "humain":
      return {
        intention, handoff: true,
        texte: "Bien sûr, je transmets à un pharmacien de l'équipe. Merci de patienter quelques instants.",
      };

    case "salutation":
      return {
        intention, handoff: false,
        texte:
          `Bonjour 👋 Bienvenue à la ${pharmacie.name}.\n\n` +
          "Je peux vérifier la disponibilité d'un médicament, vous donner son prix et le mettre de côté 2 heures.\n\n" +
          "Quel produit recherchez-vous ?",
      };

    case "horaires":
      return {
        intention, handoff: false,
        texte: `Nos horaires — ${pharmacie.name} :\n${horairesLisibles(pharmacie.openingHours)}\n\n` +
          `Téléphone : ${pharmacie.phone ?? "—"}`,
      };

    case "adresse":
      return {
        intention, handoff: false,
        texte:
          `${pharmacie.name}\n${pharmacie.district ? pharmacie.district + ", " : ""}${pharmacie.city}\n` +
          `${pharmacie.phone ?? ""}\n\nItinéraire : https://maps.google.com/?q=${encodeURIComponent(pharmacie.name + " " + pharmacie.city)}`,
      };

    case "suivi": {
      const ref = message.toUpperCase().match(/R-[A-Z0-9]{8}/)?.[0];
      if (!ref) {
        return { intention, handoff: false, texte: "Indiquez votre référence de réservation, au format R-ABCD1234." };
      }
      const r = await prisma.reservation.findUnique({ where: { reference: ref } });
      if (!r || r.pharmacyId !== pharmacie.id) {
        return { intention, handoff: false, texte: `Aucune réservation ne correspond à ${ref}. Vérifiez la référence.` };
      }
      const expiree = r.expiresAt < new Date();
      return {
        intention, handoff: false,
        texte: expiree
          ? `Votre réservation ${ref} a expiré (validité 2 heures). Souhaitez-vous réserver à nouveau ?`
          : `Réservation ${ref} — ${r.productLabel} × ${r.quantity}, à retirer avant ` +
            `${r.expiresAt.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}.`,
      };
    }

    case "confirmation": {
      const produit = await dernierProduitPropose(pharmacie.id, conversation.messages);
      if (!produit) {
        return { intention, handoff: false, texte: "Quel produit souhaitez-vous réserver ?" };
      }
      if (produit.requiresPrescription) {
        return {
          intention, handoff: true,
          texte: "Ce médicament est soumis à ordonnance : il ne peut pas être réservé par message. " +
            "Présentez-vous au comptoir avec votre prescription.",
        };
      }
      const stock = produit.batches.reduce((t, b) => t + b.quantity, 0);
      if (stock < 1) {
        return { intention, handoff: false, texte: "Ce produit vient d'être épuisé. Souhaitez-vous que je vous prévienne à son retour ?" };
      }

      const expiresAt = new Date(Date.now() + DUREE_RESERVATION_MS);
      const res = await prisma.reservation.create({
        data: {
          pharmacyId: pharmacie.id, productId: produit.id, quantity: 1,
          reference: reference(), expiresAt, source: "WHATSAPP",
          conversationId: conversation.id,
          productLabel: produit.name, unitPrice: produit.salePrice,
        },
      });
      await prisma.auditLog.create({
        data: {
          pharmacyId: pharmacie.id, action: "RESERVATION_WHATSAPP",
          entity: "Reservation", entityId: res.id, metadata: { produit: produit.name },
        },
      });

      return {
        intention, handoff: false,
        reservation: { reference: res.reference, expireLe: expiresAt.toISOString() },
        texte:
          `Réservation confirmée ✅\n\nRéférence : ${res.reference}\n${produit.name}\n` +
          `${fcfa(produit.salePrice)} — paiement au comptoir\n\n` +
          `Valable 2 heures, jusqu'à ${expiresAt.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}.\n` +
          `${pharmacie.name}, ${pharmacie.district ? pharmacie.district + ", " : ""}${pharmacie.city}`,
      };
    }

    case "annulation":
      return { intention, handoff: false, texte: "Entendu, rien n'est réservé. Puis-je vous aider pour autre chose ?" };

    case "recherche":
    case "reservation":
    default: {
      const terme = extraireProduit(message);
      if (terme.length < 3) {
        return { intention: "inconnu", handoff: false, texte: "Quel médicament recherchez-vous ? Indiquez son nom ou sa molécule." };
      }

      const produits = await rechercher(pharmacie.id, terme);
      if (!produits.length) {
        return {
          intention: "recherche", handoff: false,
          texte:
            `Je ne trouve pas « ${terme} » dans notre stock actuel.\n\n` +
            "Vérifiez l'orthographe ou indiquez la molécule (par exemple « paracétamol »). " +
            "Je peux aussi transmettre votre demande à un pharmacien.",
        };
      }

      const p = produits[0];
      const stock = p.batches.reduce((t, b) => t + b.quantity, 0);

      if (stock <= 0) {
        return {
          intention: "recherche", handoff: false,
          texte: `${p.name} est momentanément épuisé. Souhaitez-vous que je vous prévienne dès son retour ?`,
        };
      }
      if (p.requiresPrescription) {
        return {
          intention: "recherche", handoff: false,
          texte:
            `${p.name} est disponible — ${fcfa(p.salePrice)}.\n\n` +
            "⚠️ Ce médicament est soumis à ordonnance : il ne peut pas être réservé par message. " +
            "Présentez-vous au comptoir avec votre prescription.",
        };
      }

      const autres = produits.slice(1, 3)
        .map((x) => `• ${x.name} — ${fcfa(x.salePrice)}`)
        .join("\n");

      return {
        intention: "recherche", handoff: false,
        texte:
          `Oui, ${p.name} est disponible.\nPrix : ${fcfa(p.salePrice)}\n\n` +
          (autres ? `Également en stock :\n${autres}\n\n` : "") +
          "Souhaitez-vous que je le mette de côté 2 heures ? Répondez « oui ».",
      };
    }
  }
}

/** Recherche insensible aux accents, avec repli si l'extension unaccent manque. */
async function rechercher(pharmacyId: string, terme: string) {
  let ids: string[] | null = null;
  try {
    const rows = await prisma.$queryRaw<{ id: string }[]>`
      SELECT id FROM "Product"
      WHERE "pharmacyId" = ${pharmacyId} AND "isActive" = true
        AND (unaccent(lower(name)) LIKE unaccent(lower(${"%" + terme + "%"}))
          OR unaccent(lower(coalesce(dci, ''))) LIKE unaccent(lower(${"%" + terme + "%"})))
      LIMIT 5`;
    ids = rows.map((r) => r.id);
    if (!ids.length) return [];
  } catch {
    ids = null;
  }

  return prisma.product.findMany({
    where: {
      pharmacyId, isActive: true,
      ...(ids ? { id: { in: ids } } : {
        OR: [
          { name: { contains: terme, mode: "insensitive" } },
          { dci: { contains: terme, mode: "insensitive" } },
        ],
      }),
    },
    include: { batches: { where: { quantity: { gt: 0 }, expiryDate: { gt: new Date() } } } },
    take: 5,
  });
}
