import { PrismaClient } from "@prisma/client";

// Singleton : en développement, Next.js recharge les modules à chaque édition.
// Sans ce cache global, chaque rechargement ouvrirait un nouveau pool de connexions
// et saturerait PostgreSQL ("too many clients already").
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
