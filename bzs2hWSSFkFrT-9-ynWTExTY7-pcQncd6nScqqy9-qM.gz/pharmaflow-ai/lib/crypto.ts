import "server-only";

/**
 * Façade serveur du chiffrement patients.
 * Les primitives vivent dans crypto-core.ts pour rester accessibles
 * aux scripts CLI (npm run key:rotate).
 */
export { encrypt, decrypt, maskPhone, needsRewrap } from "./crypto-core";
