import { cookies } from "next/headers";
import crypto from "crypto";

const SECRET = process.env.SESSION_SECRET ?? "dev-secret-change-me";
export type Session = { userId: string; email: string; role: Role; pharmacyId: string; name: string };
export type Role = "OWNER" | "PHARMACIST" | "TECHNICIAN" | "CASHIER" | "ACCOUNTANT";

export const PERMISSIONS: Record<Role, string[]> = {
  OWNER: ["*"],
  PHARMACIST: ["pos.*", "stock.*", "prescriptions.*", "patients.*", "ai.read", "reports.read", "whatsapp.*"],
  TECHNICIAN: ["pos.sell", "stock.read", "stock.move", "prescriptions.read", "patients.read"],
  CASHIER: ["pos.sell", "pos.close", "stock.read"],
  ACCOUNTANT: ["accounting.*", "reports.read", "suppliers.read"],
};

export function can(role: Role, perm: string) {
  return PERMISSIONS[role].some(p => p === "*" || p === perm || (p.endsWith(".*") && perm.startsWith(p.slice(0, -1))));
}

function sign(payload: string) {
  return crypto.createHmac("sha256", SECRET).update(payload).digest("base64url");
}
export function encodeSession(s: Session) {
  const body = Buffer.from(JSON.stringify(s)).toString("base64url");
  return `${body}.${sign(body)}`;
}
export function decodeSession(token?: string): Session | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = sign(body);
  if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  try { return JSON.parse(Buffer.from(body, "base64url").toString()); } catch { return null; }
}
export async function getSession(): Promise<Session | null> {
  const store = await cookies();
  return decodeSession(store.get("pf_session")?.value);
}
export function hashPassword(pw: string, salt = crypto.randomBytes(16).toString("hex")) {
  const h = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `scrypt$${salt}$${h}`;
}
export function verifyPassword(pw: string, stored: string) {
  const [, salt, h] = stored.split("$");
  const candidate = crypto.scryptSync(pw, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(candidate, "hex"), Buffer.from(h, "hex"));
}
