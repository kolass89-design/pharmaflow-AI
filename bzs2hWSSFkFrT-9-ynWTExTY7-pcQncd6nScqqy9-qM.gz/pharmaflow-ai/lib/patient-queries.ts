import "server-only";
import { prisma } from "./db";

/**
 * Requêtes de l'espace patient (public, sans authentification).
 *
 * Règles de confidentialité appliquées ici, une fois pour toutes :
 *  - on ne divulgue JAMAIS la quantité exacte en stock (information commerciale
 *    sensible, et un stock précis facilite les détournements) ;
 *  - on n'expose que trois états : disponible, stock limité, indisponible ;
 *  - les médicaments soumis à ordonnance sont signalés et non réservables.
 */

export type Disponibilite = "disponible" | "limite" | "indisponible";

export type ResultatRecherche = {
  produitId: string;
  nom: string;
  dci: string | null;
  prix: number;
  surOrdonnance: boolean;
  disponibilite: Disponibilite;
  pharmacie: {
    id: string;
    nom: string;
    ville: string;
    quartier: string | null;
    telephone: string | null;
    whatsapp: string | null;
    latitude: number | null;
    longitude: number | null;
    ouverteMaintenant: boolean | null;
    deGarde: boolean;
  };
};

/** Trois paliers plutôt qu'un nombre : suffisant pour décider de se déplacer. */
function paliers(stock: number, seuil: number): Disponibilite {
  if (stock <= 0) return "indisponible";
  if (stock <= Math.max(seuil, 5)) return "limite";
  return "disponible";
}

/** Distance à vol d'oiseau (formule de haversine), en kilomètres. */
export function distanceKm(
  a: { lat: number; lon: number },
  b: { lat: number; lon: number },
): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLon = ((b.lon - a.lon) * Math.PI) / 180;
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(x)) * 10) / 10;
}

/** Lit les horaires JSON de la pharmacie pour dire si elle est ouverte à l'instant T. */
export function estOuverte(horaires: unknown, maintenant = new Date()): boolean | null {
  if (!horaires || typeof horaires !== "object") return null;
  const h = horaires as Record<string, string>;
  const jour = maintenant.getDay();
  const plage = jour === 0 ? h.dim : jour === 6 ? h.sam : h.lun_ven;
  if (!plage || /ferm/i.test(plage)) return false;
  const m = plage.match(/(\d{1,2}):(\d{2})\s*[-–]\s*(\d{1,2}):(\d{2})/);
  if (!m) return null;
  const minutes = maintenant.getHours() * 60 + maintenant.getMinutes();
  return minutes >= +m[1] * 60 + +m[2] && minutes <= +m[3] * 60 + +m[4];
}

/**
 * Recherche un médicament dans toutes les officines partenaires.
 * Le tri place d'abord ce qui est réellement disponible, puis le prix le plus bas.
 */
export async function rechercherMedicament(
  terme: string,
  options: { ville?: string; position?: { lat: number; lon: number } } = {},
): Promise<(ResultatRecherche & { distanceKm?: number })[]> {
  const q = terme.trim();
  if (q.length < 2) return [];

  // « paracetamol » doit trouver « Paracétamol » : les patients tapent rarement
  // les accents sur un clavier de téléphone. L'extension unaccent normalise des
  // deux côtés ; en son absence, on retombe sur une recherche accent-sensible.
  let ids: string[] | null = null;
  try {
    const rows = await prisma.$queryRaw<{ id: string }[]>`
      SELECT id FROM "Product"
      WHERE "isActive" = true AND "isPublic" = true
        AND (unaccent(lower(name)) LIKE unaccent(lower(${"%" + q + "%"}))
          OR unaccent(lower(coalesce(dci, ''))) LIKE unaccent(lower(${"%" + q + "%"})))
      LIMIT 60`;
    ids = rows.map(r => r.id);
    if (ids.length === 0) return [];
  } catch {
    ids = null;
  }

  const produits = await prisma.product.findMany({
    where: {
      isActive: true,
      isPublic: true,
      ...(ids
        ? { id: { in: ids } }
        : {
            OR: [
              { name: { contains: q, mode: "insensitive" } },
              { dci: { contains: q, mode: "insensitive" } },
            ],
          }),
      ...(options.ville ? { pharmacy: { city: { equals: options.ville, mode: "insensitive" } } } : {}),
    },
    include: {
      batches: { where: { quantity: { gt: 0 }, expiryDate: { gt: new Date() } } },
      pharmacy: {
        include: {
          guardSchedules: {
            where: { isPublished: true, startsAt: { lte: new Date() }, endsAt: { gte: new Date() } },
          },
        },
      },
    },
    take: 60,
  });

  const maintenant = new Date();

  return produits
    .map((p) => {
      const stock = p.batches.reduce((t, b) => t + b.quantity, 0);
      const ph = p.pharmacy;
      const resultat: ResultatRecherche & { distanceKm?: number } = {
        produitId: p.id,
        nom: p.name,
        dci: p.dci,
        prix: p.salePrice,
        surOrdonnance: p.requiresPrescription,
        disponibilite: paliers(stock, p.alertThreshold),
        pharmacie: {
          id: ph.id,
          nom: ph.name,
          ville: ph.city,
          quartier: ph.district,
          telephone: ph.phone,
          whatsapp: ph.whatsappNo,
          latitude: ph.latitude,
          longitude: ph.longitude,
          ouverteMaintenant: estOuverte(ph.openingHours, maintenant),
          deGarde: ph.guardSchedules.length > 0,
        },
      };
      if (options.position && ph.latitude != null && ph.longitude != null) {
        resultat.distanceKm = distanceKm(options.position, { lat: ph.latitude, lon: ph.longitude });
      }
      return resultat;
    })
    .sort((a, b) => {
      const rang = { disponible: 0, limite: 1, indisponible: 2 } as const;
      if (rang[a.disponibilite] !== rang[b.disponibilite]) return rang[a.disponibilite] - rang[b.disponibilite];
      if (a.distanceKm != null && b.distanceKm != null && a.distanceKm !== b.distanceKm) {
        return a.distanceKm - b.distanceKm;
      }
      return a.prix - b.prix;
    });
}

/** Officines partenaires d'une ville, avec état d'ouverture et de garde. */
export async function listerPharmacies(ville?: string) {
  const pharmacies = await prisma.pharmacy.findMany({
    where: ville ? { city: { equals: ville, mode: "insensitive" } } : {},
    include: {
      guardSchedules: {
        where: { isPublished: true, startsAt: { lte: new Date() }, endsAt: { gte: new Date() } },
      },
    },
    orderBy: { name: "asc" },
  });

  return pharmacies.map((p) => ({
    id: p.id,
    nom: p.name,
    ville: p.city,
    quartier: p.district,
    telephone: p.phone,
    whatsapp: p.whatsappNo,
    latitude: p.latitude,
    longitude: p.longitude,
    horaires: (p.openingHours as Record<string, string> | null) ?? null,
    ouverteMaintenant: estOuverte(p.openingHours),
    deGarde: p.guardSchedules.length > 0,
  }));
}

/** Villes couvertes, pour alimenter le filtre de recherche. */
export async function listerVilles(): Promise<string[]> {
  const rows = await prisma.pharmacy.findMany({ select: { city: true }, distinct: ["city"], orderBy: { city: "asc" } });
  return rows.map((r) => r.city);
}
