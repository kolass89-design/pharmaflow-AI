import crypto from "crypto";

/**
 * Primitives de chiffrement AES-256-GCM (données patients sensibles).
 *
 * Ce module est volontairement SANS `server-only` : les scripts de maintenance
 * (rotation de clé) doivent pouvoir l'exécuter hors du runtime Next.js.
 * L'accès applicatif passe par lib/crypto.ts, qui, lui, est protégé.
 * Même si la base est exfiltrée, les téléphones restent illisibles sans ENCRYPTION_KEY.
 * Format stocké : v1:<iv base64url>:<tag base64url>:<données base64url>
 */
function parseKey(hex: string | undefined, nom: string): Buffer | null {
  if (!hex) return null;
  if (!/^[0-9a-fA-F]{64}$/.test(hex)) {
    throw new Error(`${nom} invalide : 64 caractères hexadécimaux attendus.`);
  }
  return Buffer.from(hex, "hex");
}

/** Clé courante : sert au chiffrement de toute nouvelle donnée. */
function key(): Buffer {
  const k = parseKey(process.env.ENCRYPTION_KEY, "ENCRYPTION_KEY");
  if (!k) throw new Error("ENCRYPTION_KEY manquante.");
  return k;
}

/**
 * Clés de déchiffrement acceptées, dans l'ordre d'essai.
 * Pendant une rotation, l'ancienne clé reste listée dans ENCRYPTION_KEY_OLD
 * (séparées par des virgules) : les données existantes restent lisibles
 * pendant que les nouvelles écritures utilisent déjà la clé courante.
 */
function decryptionKeys(): Buffer[] {
  const keys = [key()];
  for (const old of (process.env.ENCRYPTION_KEY_OLD ?? "").split(",").map(x => x.trim()).filter(Boolean)) {
    const k = parseKey(old, "ENCRYPTION_KEY_OLD");
    if (k) keys.push(k);
  }
  return keys;
}

export function encrypt(plain: string | null | undefined): string | null {
  if (!plain) return null;
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", key(), iv);
  const data = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return `v1:${iv.toString("base64url")}:${c.getAuthTag().toString("base64url")}:${data.toString("base64url")}`;
}

export function decrypt(payload: string | null | undefined): string | null {
  if (!payload) return null;
  const parts = payload.split(":");
  if (parts[0] !== "v1" || parts.length !== 4) return payload; // valeur héritée non chiffrée

  // On essaie la clé courante puis les anciennes : une rotation ne casse rien.
  for (const k of decryptionKeys()) {
    try {
      const d = crypto.createDecipheriv("aes-256-gcm", k, Buffer.from(parts[1], "base64url"));
      d.setAuthTag(Buffer.from(parts[2], "base64url"));
      return Buffer.concat([d.update(Buffer.from(parts[3], "base64url")), d.final()]).toString("utf8");
    } catch { /* clé suivante */ }
  }
  return null; // aucune clé ne convient : donnée altérée ou clé perdue
}

/** Indique si une valeur doit être réécrite avec la clé courante. */
export function needsRewrap(payload: string | null | undefined): boolean {
  if (!payload) return false;
  const parts = payload.split(":");
  if (parts[0] !== "v1" || parts.length !== 4) return true;   // clair hérité → à chiffrer
  try {
    const d = crypto.createDecipheriv("aes-256-gcm", key(), Buffer.from(parts[1], "base64url"));
    d.setAuthTag(Buffer.from(parts[2], "base64url"));
    Buffer.concat([d.update(Buffer.from(parts[3], "base64url")), d.final()]);
    return false;                                              // déjà sous la clé courante
  } catch {
    return true;
  }
}

/** Masque un numéro pour l'affichage en liste : +229 97 •• •• 56 */
export function maskPhone(phone: string | null): string {
  if (!phone) return "—";
  const s = phone.replace(/\s+/g, "");
  if (s.length < 6) return "••";
  return `${s.slice(0, 6)} •• •• ${s.slice(-2)}`;
}
