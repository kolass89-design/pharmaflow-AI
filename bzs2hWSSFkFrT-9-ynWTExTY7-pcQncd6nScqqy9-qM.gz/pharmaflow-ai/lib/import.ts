import "server-only";

/**
 * Parseur CSV et prévisualisation d'import du catalogue produits.
 *
 * Choix : aucune dépendance externe. Les bibliothèques XLSX du registre npm
 * (xlsx, exceljs) traînent des vulnérabilités connues — prototype pollution,
 * ReDoS, chaînes archiver/glob non corrigées. Pour un logiciel qui manipule
 * des données de santé, importer 40 paquets transitifs pour lire un tableau
 * n'est pas un compromis acceptable.
 *
 * Le format pivot est donc le CSV (export universel depuis Excel, LibreOffice,
 * Google Sheets et la plupart des logiciels d'officine).
 */

export type ImportRow = {
  ligne: number;
  name: string;
  dci: string | null;
  barcode: string | null;
  category: string | null;
  purchasePrice: number;
  salePrice: number;
  alertThreshold: number;
  quantity: number;
  batchNo: string | null;
  expiryDate: string | null;
  supplierName: string | null;
};

export type ImportIssue = { ligne: number; champ: string; message: string };

/** Découpe une ligne CSV en respectant les guillemets et les séparateurs échappés. */
function splitLine(line: string, sep: string): string[] {
  const out: string[] = [];
  let cur = "";
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quoted) {
      if (c === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; }   // guillemet échappé ""
        else quoted = false;
      } else cur += c;
    } else if (c === '"') quoted = true;
    else if (c === sep) { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur);
  return out.map(x => x.trim());
}

/** Détecte le séparateur réel : le point-virgule domine sur les Excel francophones. */
function detectSeparator(header: string): string {
  const counts = [";", ",", "\t", "|"].map(s => [s, header.split(s).length] as const);
  return counts.sort((a, b) => b[1] - a[1])[0][1] > 1 ? counts.sort((a, b) => b[1] - a[1])[0][0] : ";";
}

/** Normalise un en-tête : minuscules, sans accent ni ponctuation. */
function norm(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
}

/** Synonymes acceptés pour chaque colonne — les officines n'ont pas toutes le même modèle. */
const ALIASES: Record<string, string[]> = {
  name: ["nom", "produit", "designation", "libelle", "article", "nomcommercial", "name"],
  dci: ["dci", "moleculedci", "molecule", "principeactif", "substance"],
  barcode: ["codebarre", "codebarres", "ean", "gencod", "barcode", "code"],
  category: ["categorie", "famille", "rayon", "classe", "category"],
  purchasePrice: ["prixachat", "pa", "pachat", "prixdachat", "cout", "purchaseprice"],
  salePrice: ["prixvente", "pv", "pvente", "prixdevente", "prixpublic", "ppv", "saleprice"],
  alertThreshold: ["seuil", "seuilalerte", "stockmini", "stockminimum", "minimum", "alerte"],
  quantity: ["quantite", "qte", "stock", "stockactuel", "quantity"],
  batchNo: ["lot", "numerolot", "nlot", "batch", "batchno"],
  expiryDate: ["peremption", "datepetemption", "dateperemption", "expiration", "dateexpiration", "exp", "expiry", "expirydate"],
  supplierName: ["fournisseur", "grossiste", "supplier", "laboratoire"],
};

function mapHeaders(headers: string[]): Record<string, number> {
  const map: Record<string, number> = {};
  headers.forEach((h, i) => {
    const n = norm(h);
    for (const [field, aliases] of Object.entries(ALIASES)) {
      if (map[field] === undefined && aliases.includes(n)) map[field] = i;
    }
  });
  return map;
}

/** Accepte "2 500", "2500,50", "2 500,00 FCFA" → 2500 (entier, le FCFA n'a pas de décimale). */
function parseAmount(raw: string): number | null {
  if (!raw) return null;
  const cleaned = raw.replace(/[^\d,.\-]/g, "").replace(/\s/g, "");
  if (!cleaned) return null;
  // "1.234,56" (fr) vs "1,234.56" (en) : le dernier séparateur est le décimal
  const lastComma = cleaned.lastIndexOf(",");
  const lastDot = cleaned.lastIndexOf(".");
  let normalized = cleaned;
  if (lastComma > lastDot) normalized = cleaned.replace(/\./g, "").replace(",", ".");
  else if (lastDot > lastComma) normalized = cleaned.replace(/,/g, "");
  const n = Number(normalized);
  return Number.isFinite(n) ? Math.round(n) : null;
}

/** Accepte 31/12/2027, 2027-12-31, 31-12-2027, 12/2027 (fin de mois). */
function parseDate(raw: string): string | null {
  if (!raw) return null;
  const s = raw.trim();
  let m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) return iso(+m[1], +m[2], +m[3]);
  m = s.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{2,4})$/);
  if (m) {
    const year = +m[3] < 100 ? 2000 + +m[3] : +m[3];
    return iso(year, +m[2], +m[1]);
  }
  m = s.match(/^(\d{1,2})[\/\-.](\d{4})$/);          // MM/AAAA → dernier jour du mois
  if (m) return iso(+m[2], +m[1], new Date(+m[2], +m[1], 0).getDate());
  return null;
}

function iso(y: number, mo: number, d: number): string | null {
  if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if (dt.getUTCMonth() !== mo - 1) return null;
  return dt.toISOString().slice(0, 10);
}

export type ParseResult = {
  rows: ImportRow[];
  issues: ImportIssue[];
  colonnesReconnues: string[];
  colonnesManquantes: string[];
  totalLignes: number;
};

const REQUIRED = ["name", "purchasePrice", "salePrice"];
const MAX_ROWS = 5000;

export function parseCatalogCsv(content: string): ParseResult {
  // Retire le BOM UTF-8 qu'Excel ajoute systématiquement.
  const text = content.replace(/^\uFEFF/, "");
  const lines = text.split(/\r?\n/).filter(l => l.trim().length);
  if (!lines.length) {
    return { rows: [], issues: [{ ligne: 0, champ: "fichier", message: "Le fichier est vide." }], colonnesReconnues: [], colonnesManquantes: REQUIRED, totalLignes: 0 };
  }

  const sep = detectSeparator(lines[0]);
  const headers = splitLine(lines[0], sep);
  const map = mapHeaders(headers);
  const manquantes = REQUIRED.filter(f => map[f] === undefined);
  const reconnues = Object.keys(map);

  const rows: ImportRow[] = [];
  const issues: ImportIssue[] = [];

  if (manquantes.length) {
    return { rows: [], issues: [{ ligne: 1, champ: "en-têtes", message: `Colonnes obligatoires introuvables : ${manquantes.join(", ")}. En-têtes détectés : ${headers.join(" | ")}` }], colonnesReconnues: reconnues, colonnesManquantes: manquantes, totalLignes: lines.length - 1 };
  }

  const dataLines = lines.slice(1, MAX_ROWS + 1);
  const vus = new Set<string>();

  dataLines.forEach((line, idx) => {
    const ligne = idx + 2;                       // +2 : en-tête + index base 1
    const cells = splitLine(line, sep);
    const get = (f: string) => (map[f] !== undefined ? (cells[map[f]] ?? "").trim() : "");

    const name = get("name");
    if (!name) { issues.push({ ligne, champ: "nom", message: "Nom du produit manquant — ligne ignorée." }); return; }

    const pa = parseAmount(get("purchasePrice"));
    const pv = parseAmount(get("salePrice"));
    if (pa === null) { issues.push({ ligne, champ: "prix d'achat", message: `Prix d'achat illisible : « ${get("purchasePrice")} »` }); return; }
    if (pv === null) { issues.push({ ligne, champ: "prix de vente", message: `Prix de vente illisible : « ${get("salePrice")} »` }); return; }
    if (pv < pa) issues.push({ ligne, champ: "prix", message: `Prix de vente (${pv}) inférieur au prix d'achat (${pa}) — à vérifier.` });

    const qty = parseAmount(get("quantity")) ?? 0;
    const expiry = parseDate(get("expiryDate"));
    if (qty > 0 && !expiry) {
      issues.push({ ligne, champ: "péremption", message: `Quantité ${qty} sans date de péremption valide — le stock ne sera pas créé.` });
    }
    if (expiry && expiry < new Date().toISOString().slice(0, 10)) {
      issues.push({ ligne, champ: "péremption", message: `Lot déjà périmé (${expiry}) — stock ignoré.` });
    }

    const barcode = get("barcode") || null;
    const cle = (barcode ?? name).toLowerCase();
    if (vus.has(cle)) { issues.push({ ligne, champ: "doublon", message: `« ${name} » apparaît plusieurs fois dans le fichier — seule la première occurrence est conservée.` }); return; }
    vus.add(cle);

    rows.push({
      ligne, name,
      dci: get("dci") || null,
      barcode,
      category: get("category") || null,
      purchasePrice: pa,
      salePrice: pv,
      alertThreshold: parseAmount(get("alertThreshold")) ?? 10,
      quantity: qty > 0 && expiry && expiry >= new Date().toISOString().slice(0, 10) ? qty : 0,
      batchNo: get("batchNo") || null,
      expiryDate: expiry,
      supplierName: get("supplierName") || null,
    });
  });

  if (lines.length - 1 > MAX_ROWS) {
    issues.push({ ligne: 0, champ: "fichier", message: `Fichier tronqué : ${MAX_ROWS} lignes maximum par import (${lines.length - 1} détectées).` });
  }

  return { rows, issues, colonnesReconnues: reconnues, colonnesManquantes: [], totalLignes: lines.length - 1 };
}

/** Modèle CSV téléchargeable, pré-rempli d'exemples réalistes. */
export function templateCsv(): string {
  const head = "Nom;DCI;Code-barres;Categorie;Prix achat;Prix vente;Seuil;Quantite;Lot;Peremption;Fournisseur";
  const rows = [
    "Amoxicilline 500 mg (12 gél.);Amoxicilline;6001234500011;Antibiotique;1600;2500;40;120;LOT-A231;31/03/2027;UBIPHARM",
    "Paracétamol 1 g (8 cp.);Paracétamol;6001234500028;Antalgique;420;700;60;250;LOT-P118;30/11/2026;CAMEG",
    "Artéméther/Luméfantrine 20/120;ACT;6001234500035;Antipaludique;1750;2900;35;80;LOT-M442;15/09/2027;UBIPHARM",
  ];
  return "\uFEFF" + [head, ...rows].join("\r\n");   // BOM pour qu'Excel ouvre en UTF-8
}
