"use client";

/**
 * File d'opérations hors ligne (IndexedDB).
 *
 * Principe : la caisse ne doit JAMAIS être bloquée par l'absence de réseau.
 * Une vente est d'abord écrite localement, puis rejouée vers le serveur dès
 * que la connexion revient. L'idempotence est garantie par un UUID généré
 * côté client et contraint en base (colonne offlineUuid @unique).
 *
 * Aucune dépendance : l'API IndexedDB native suffit.
 */

const DB_NAME = "pharmaflow";
const DB_VERSION = 1;
const STORE_QUEUE = "queue";
const STORE_CACHE = "catalogue";

export type QueuedOp = {
  uuid: string;
  endpoint: string;
  payload: unknown;
  createdAt: number;
  tries: number;
  lastError?: string;
  status: "pending" | "sent" | "failed";
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_QUEUE)) {
        const store = db.createObjectStore(STORE_QUEUE, { keyPath: "uuid" });
        store.createIndex("status", "status");
        store.createIndex("createdAt", "createdAt");
      }
      if (!db.objectStoreNames.contains(STORE_CACHE)) {
        db.createObjectStore(STORE_CACHE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(db => new Promise<T>((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    t.oncomplete = () => db.close();
  }));
}

export const isSupported = () => typeof indexedDB !== "undefined";

/** Met une opération en file. Retourne l'UUID qui servira à l'idempotence. */
export async function enqueue(endpoint: string, payload: Record<string, unknown>): Promise<string> {
  const uuid = crypto.randomUUID();
  const op: QueuedOp = {
    uuid, endpoint,
    payload: { ...payload, offlineUuid: uuid },
    createdAt: Date.now(), tries: 0, status: "pending",
  };
  await tx(STORE_QUEUE, "readwrite", s => s.put(op));
  return uuid;
}

export async function listQueue(): Promise<QueuedOp[]> {
  const all = await tx<QueuedOp[]>(STORE_QUEUE, "readonly", s => s.getAll() as IDBRequest<QueuedOp[]>);
  return all.sort((a, b) => a.createdAt - b.createdAt);
}

export async function pendingCount(): Promise<number> {
  const all = await listQueue();
  return all.filter(o => o.status !== "sent").length;
}

async function update(op: QueuedOp) {
  await tx(STORE_QUEUE, "readwrite", s => s.put(op));
}

async function remove(uuid: string) {
  await tx(STORE_QUEUE, "readwrite", s => s.delete(uuid));
}

/** Purge les opérations confirmées de plus de 24 h (l'historique vit côté serveur). */
export async function purgeOld() {
  const all = await listQueue();
  const limite = Date.now() - 24 * 3600e3;
  for (const op of all) if (op.status === "sent" && op.createdAt < limite) await remove(op.uuid);
}

export type SyncResult = { envoyees: number; doublons: number; echecs: number; restantes: number };

/**
 * Rejoue la file dans l'ordre chronologique.
 * Un 409 (stock insuffisant) ou 422 est définitif : inutile de réessayer indéfiniment,
 * l'opération est marquée `failed` et signalée au pharmacien.
 * Une erreur réseau ou 5xx reste `pending` : elle sera retentée.
 */
export async function flushQueue(): Promise<SyncResult> {
  if (!isSupported() || !navigator.onLine) {
    return { envoyees: 0, doublons: 0, echecs: 0, restantes: await pendingCount() };
  }

  const ops = (await listQueue()).filter(o => o.status === "pending");
  let envoyees = 0, doublons = 0, echecs = 0;

  for (const op of ops) {
    try {
      const res = await fetch(op.endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(op.payload),
      });

      if (res.ok) {
        const data = await res.json().catch(() => ({}));
        if (data?.duplicate) doublons++; else envoyees++;
        op.status = "sent";
        await update(op);
      } else if (res.status >= 400 && res.status < 500 && res.status !== 429) {
        const data = await res.json().catch(() => ({}));
        op.status = "failed";
        op.lastError = data?.error ?? `Erreur ${res.status}`;
        echecs++;
        await update(op);
      } else {
        op.tries++;
        op.lastError = `Erreur serveur ${res.status}`;
        await update(op);
      }
    } catch (e: any) {
      op.tries++;
      op.lastError = e?.message ?? "Réseau indisponible";
      await update(op);
      break;   // réseau coupé : inutile de poursuivre la boucle
    }
  }

  await purgeOld();
  return { envoyees, doublons, echecs, restantes: await pendingCount() };
}

/** Supprime une opération définitivement échouée, après décision du pharmacien. */
export async function discard(uuid: string) {
  await remove(uuid);
}

/** Remet une opération échouée en file (après correction du stock, par exemple). */
export async function retry(uuid: string) {
  const all = await listQueue();
  const op = all.find(o => o.uuid === uuid);
  if (!op) return;
  op.status = "pending";
  op.tries = 0;
  op.lastError = undefined;
  await update(op);
}

/** Vide toutes les opérations confirmées. */
export async function clearSent() {
  for (const op of await listQueue()) if (op.status === "sent") await remove(op.uuid);
}

/**
 * Export JSON de la file — filet de sécurité : si un poste doit être réinstallé
 * alors que des ventes n'ont pas été synchronisées, elles ne sont pas perdues.
 */
export async function exportQueue(): Promise<string> {
  return JSON.stringify({ exporteLe: new Date().toISOString(), operations: await listQueue() }, null, 2);
}

/* ─────────── Cache du catalogue (permet de vendre hors ligne) ─────────── */

export type CachedProduct = { id: string; nom: string; dci: string; lot: string; expiration: string; stock: number; vente: number };

export async function cacheCatalog(products: CachedProduct[]) {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const t = db.transaction(STORE_CACHE, "readwrite");
    const store = t.objectStore(STORE_CACHE);
    store.clear();
    for (const p of products) store.put(p);
    t.oncomplete = () => { db.close(); resolve(); };
    t.onerror = () => reject(t.error);
  });
}

export async function readCatalog(): Promise<CachedProduct[]> {
  try {
    return await tx<CachedProduct[]>(STORE_CACHE, "readonly", s => s.getAll() as IDBRequest<CachedProduct[]>);
  } catch {
    return [];
  }
}
