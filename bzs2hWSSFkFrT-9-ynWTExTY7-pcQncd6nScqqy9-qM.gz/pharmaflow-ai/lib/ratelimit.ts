import "server-only";

/**
 * Limitation de débit à fenêtre glissante.
 *
 * En production sur Vercel, chaque instance serverless a sa propre mémoire :
 * un compteur en RAM ne limite donc rien du tout. On s'appuie sur Upstash Redis
 * (REST, compatible edge) dès que les variables sont présentes, avec repli
 * automatique sur la mémoire en développement.
 */

type Verdict = { allowed: boolean; remaining: number; retryAfter: number };

const URL_REST = process.env.UPSTASH_REDIS_REST_URL;
const TOKEN_REST = process.env.UPSTASH_REDIS_REST_TOKEN;
export const usingRedis = Boolean(URL_REST && TOKEN_REST);

/* ─────────── Repli mémoire (développement / instance unique) ─────────── */
const memory = new Map<string, number[]>();

function memoryLimit(key: string, limit: number, windowMs: number): Verdict {
  const now = Date.now();
  const hits = (memory.get(key) ?? []).filter(t => now - t < windowMs);
  if (hits.length >= limit) {
    const retryAfter = Math.ceil((windowMs - (now - hits[0])) / 1000);
    memory.set(key, hits);
    return { allowed: false, remaining: 0, retryAfter };
  }
  hits.push(now);
  memory.set(key, hits);
  // Purge opportuniste pour éviter que la Map ne grossisse indéfiniment.
  if (memory.size > 5000) {
    for (const [k, v] of memory) if (!v.some(t => now - t < windowMs)) memory.delete(k);
  }
  return { allowed: true, remaining: limit - hits.length, retryAfter: 0 };
}

/* ─────────── Upstash Redis ─────────── */
async function redisPipeline(commands: unknown[][]): Promise<any[]> {
  const res = await fetch(`${URL_REST}/pipeline`, {
    method: "POST",
    headers: { Authorization: `Bearer ${TOKEN_REST}`, "Content-Type": "application/json" },
    body: JSON.stringify(commands),
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`Upstash ${res.status}`);
  return res.json();
}

async function redisLimit(key: string, limit: number, windowMs: number): Promise<Verdict> {
  const now = Date.now();
  const member = `${now}-${Math.random().toString(36).slice(2, 8)}`;
  // Fenêtre glissante via sorted set : purge, comptage, ajout, expiration.
  const out = await redisPipeline([
    ["ZREMRANGEBYSCORE", key, 0, now - windowMs],
    ["ZCARD", key],
    ["ZADD", key, now, member],
    ["PEXPIRE", key, windowMs],
  ]);
  const count = Number(out[1]?.result ?? 0);
  if (count >= limit) {
    await redisPipeline([["ZREM", key, member]]);   // la tentative refusée ne compte pas
    return { allowed: false, remaining: 0, retryAfter: Math.ceil(windowMs / 1000) };
  }
  return { allowed: true, remaining: limit - count - 1, retryAfter: 0 };
}

/**
 * @param key    identifiant du seau (ex. "login:1.2.3.4")
 * @param limit  nombre de requêtes autorisées
 * @param windowMs durée de la fenêtre en millisecondes
 */
export async function rateLimit(key: string, limit: number, windowMs: number): Promise<Verdict> {
  if (!usingRedis) return memoryLimit(key, limit, windowMs);
  try {
    return await redisLimit(key, limit, windowMs);
  } catch (e) {
    // Redis indisponible : on dégrade en mémoire plutôt que de bloquer l'officine.
    console.error("[ratelimit] Redis injoignable, repli mémoire", e);
    return memoryLimit(key, limit, windowMs);
  }
}

/** Consulte l'état du seau SANS consommer de jeton. */
export async function peek(key: string, limit: number, windowMs: number): Promise<Verdict> {
  if (!usingRedis) {
    const now = Date.now();
    const hits = (memory.get(key) ?? []).filter(t => now - t < windowMs);
    if (hits.length >= limit) {
      return { allowed: false, remaining: 0, retryAfter: Math.ceil((windowMs - (now - hits[0])) / 1000) };
    }
    return { allowed: true, remaining: limit - hits.length, retryAfter: 0 };
  }
  try {
    const now = Date.now();
    const out = await redisPipeline([
      ["ZREMRANGEBYSCORE", key, 0, now - windowMs],
      ["ZCARD", key],
    ]);
    const count = Number(out[1]?.result ?? 0);
    return count >= limit
      ? { allowed: false, remaining: 0, retryAfter: Math.ceil(windowMs / 1000) }
      : { allowed: true, remaining: limit - count, retryAfter: 0 };
  } catch {
    return { allowed: true, remaining: limit, retryAfter: 0 };
  }
}

/** Vide un seau (ex. après une authentification réussie). */
export async function reset(key: string): Promise<void> {
  if (!usingRedis) { memory.delete(key); return; }
  try { await redisPipeline([["DEL", key]]); } catch { memory.delete(key); }
}

/** Extrait une IP exploitable derrière les proxys Vercel / Cloudflare. */
export function clientIp(req: Request): string {
  const h = req.headers;
  return (
    h.get("cf-connecting-ip") ??
    h.get("x-real-ip") ??
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "local"
  );
}

/** Politiques par usage — pensées pour un réseau mobile africain, souvent partagé en NAT. */
export const POLICIES = {
  login: { limit: 8, windowMs: 60_000 },        // 8 tentatives / minute / IP
  register: { limit: 5, windowMs: 3_600_000 },  // 5 créations d'officine / heure / IP
  write: { limit: 120, windowMs: 60_000 },      // écritures métier : généreux, un comptoir est rapide
  import: { limit: 5, windowMs: 300_000 },      // imports catalogue : coûteux en base
  ai: { limit: 20, windowMs: 60_000 },
} as const;
