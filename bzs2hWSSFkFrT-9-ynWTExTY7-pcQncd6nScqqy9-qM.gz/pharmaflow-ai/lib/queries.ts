import "server-only";
import { prisma } from "./db";

/**
 * Couche d'accès aux données.
 * Règle absolue : chaque requête est filtrée par pharmacyId (cloisonnement multi-tenant).
 */

const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const daysAgo = (n: number) => { const d = new Date(); d.setDate(d.getDate() - n); d.setHours(0, 0, 0, 0); return d; };

/* ─────────── Tableau de bord ─────────── */
export async function getDashboardData(pharmacyId: string) {
  const today = startOfToday();
  const yesterday = daysAgo(1);

  const [todayAgg, yesterdayAgg, prescriptionsToday, pendingPrescriptions, recos] = await Promise.all([
    prisma.sale.aggregate({
      where: { pharmacyId, soldAt: { gte: today } },
      _sum: { total: true }, _count: true,
    }),
    prisma.sale.aggregate({
      where: { pharmacyId, soldAt: { gte: yesterday, lt: today } },
      _sum: { total: true },
    }),
    prisma.prescription.count({ where: { pharmacyId, issuedAt: { gte: today } } }),
    prisma.prescription.count({ where: { pharmacyId, status: "PENDING" } }),
    prisma.aiRecommendation.findMany({
      where: { pharmacyId, isDismissed: false }, orderBy: { createdAt: "desc" }, take: 4,
    }),
  ]);

  // Ventes des 7 derniers jours, agrégées en SQL (une seule requête, pas 7).
  const weekRows = await prisma.$queryRaw<{ day: Date; total: bigint; n: bigint }[]>`
    SELECT date_trunc('day', "soldAt") AS day, SUM(total)::bigint AS total, COUNT(*)::bigint AS n
    FROM "Sale"
    WHERE "pharmacyId" = ${pharmacyId} AND "soldAt" >= ${daysAgo(6)}
    GROUP BY 1 ORDER BY 1 ASC`;

  const jours = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
  const salesWeek = weekRows.map(r => ({
    jour: jours[new Date(r.day).getDay()],
    ventes: Number(r.total),
    tickets: Number(r.n),
  }));

  const lowStock = await getLowStockProducts(pharmacyId);
  const expiring = await getExpiringBatches(pharmacyId, 90);

  const caToday = todayAgg._sum.total ?? 0;
  const caYesterday = yesterdayAgg._sum.total ?? 0;

  return {
    caToday,
    salesCount: todayAgg._count,
    avgBasket: todayAgg._count ? Math.round(caToday / todayAgg._count) : 0,
    variation: caYesterday ? Math.round(((caToday - caYesterday) / caYesterday) * 1000) / 10 : 0,
    prescriptionsToday,
    pendingPrescriptions,
    recos,
    salesWeek,
    lowStock,
    expiring,
  };
}

/* ─────────── Stock ─────────── */
export type StockRow = Awaited<ReturnType<typeof getStock>>[number];

export async function getStock(pharmacyId: string) {
  const products = await prisma.product.findMany({
    where: { pharmacyId, isActive: true },
    include: {
      batches: { orderBy: { expiryDate: "asc" } },
      supplier: { select: { name: true } },
    },
    orderBy: { name: "asc" },
  });

  return products.map(p => {
    const stock = p.batches.reduce((s, b) => s + b.quantity, 0);
    const next = p.batches.find(b => b.quantity > 0);
    return {
      id: p.id,
      nom: p.name,
      dci: p.dci ?? "—",
      lot: next?.batchNo ?? "—",
      expiration: next ? next.expiryDate.toISOString().slice(0, 10) : "—",
      stock,
      seuil: p.alertThreshold,
      achat: p.purchasePrice,
      vente: p.salePrice,
      marge: p.salePrice ? Math.round(((p.salePrice - p.purchasePrice) / p.salePrice) * 100) : 0,
      fournisseur: p.supplier?.name ?? "—",
      sousSeuil: stock < p.alertThreshold,
    };
  });
}

export async function getStockSummary(pharmacyId: string) {
  const rows = await getStock(pharmacyId);
  return {
    references: rows.length,
    valeur: rows.reduce((s, r) => s + r.achat * r.stock, 0),
    sousSeuil: rows.filter(r => r.sousSeuil).length,
    expirant: (await getExpiringBatches(pharmacyId, 90)).length,
  };
}

export async function getLowStockProducts(pharmacyId: string) {
  const rows = await getStock(pharmacyId);
  return rows.filter(r => r.sousSeuil);
}

export async function getExpiringBatches(pharmacyId: string, days: number) {
  const limit = new Date(Date.now() + days * 864e5);
  const batches = await prisma.productBatch.findMany({
    where: { product: { pharmacyId }, quantity: { gt: 0 }, expiryDate: { lte: limit } },
    include: { product: { select: { name: true } } },
    orderBy: { expiryDate: "asc" },
  });
  return batches.map(b => ({
    id: b.id, nom: b.product.name, lot: b.batchNo,
    expiration: b.expiryDate.toISOString().slice(0, 10), quantite: b.quantity,
    joursRestants: Math.ceil((b.expiryDate.getTime() - Date.now()) / 864e5),
  }));
}

export async function getRecentMovements(pharmacyId: string, take = 10) {
  const moves = await prisma.stockMovement.findMany({
    where: { pharmacyId }, include: { product: { select: { name: true } } },
    orderBy: { createdAt: "desc" }, take,
  });
  return moves.map(m => ({
    id: m.id, produit: m.product.name, type: m.type, quantite: m.quantity,
    motif: m.reason ?? "—", date: m.createdAt.toISOString().slice(0, 16).replace("T", " "),
  }));
}

/* ─────────── Ventes / caisse ─────────── */
export async function getPosProducts(pharmacyId: string) {
  const rows = await getStock(pharmacyId);
  return rows.filter(r => r.stock > 0);
}

export async function getSalesSummary(pharmacyId: string) {
  const today = startOfToday();
  const [agg, byMethod, last] = await Promise.all([
    prisma.sale.aggregate({ where: { pharmacyId, soldAt: { gte: today } }, _sum: { total: true }, _count: true }),
    prisma.payment.groupBy({
      by: ["method"], where: { sale: { pharmacyId, soldAt: { gte: today } } }, _sum: { amount: true },
    }),
    prisma.sale.findMany({
      where: { pharmacyId }, orderBy: { soldAt: "desc" }, take: 8,
      include: { payments: { select: { method: true } } },
    }),
  ]);

  const cash = byMethod.find(m => m.method === "CASH")?._sum.amount ?? 0;
  const mobile = byMethod.filter(m => ["MTN_MOMO", "MOOV_MONEY", "ORANGE_MONEY", "CELTIIS_CASH", "WAVE"].includes(m.method))
    .reduce((s, m) => s + (m._sum.amount ?? 0), 0);

  return {
    encaisse: agg._sum.total ?? 0,
    tickets: agg._count,
    cash,
    mobile,
    derniers: last.map(s => ({
      reference: s.reference, total: s.total,
      method: s.payments[0]?.method ?? "CASH",
      heure: s.soldAt.toISOString().slice(11, 16),
    })),
  };
}

/* ─────────── Patients / ordonnances / fournisseurs ─────────── */
export async function getPatients(pharmacyId: string) {
  const rows = await prisma.patient.findMany({
    where: { pharmacyId },
    include: {
      sales: { orderBy: { soldAt: "desc" }, take: 5, include: { items: { include: { product: { select: { name: true } } } } } },
      reminders: true,
      _count: { select: { prescriptions: true } },
    },
    orderBy: { fullName: "asc" },
  });
  return rows.map(p => ({
    id: p.id, nom: p.fullName, ville: p.city ?? "—",
    allergies: p.allergies ?? "—", chroniques: p.chronicConditions ?? "—",
    dernier: p.sales[0]?.soldAt.toISOString().slice(0, 10) ?? "—",
    ordonnances: p._count.prescriptions,
    achats: p.sales.map(s => ({
      date: s.soldAt.toISOString().slice(0, 10), total: s.total,
      libelle: s.items.map(i => i.product.name).join(", "),
    })),
    rappels: p.reminders.map(r => ({ label: r.label, schedule: r.schedule, channel: r.channel, actif: r.isActive })),
  }));
}

export async function getPrescriptions(pharmacyId: string) {
  const rows = await prisma.prescription.findMany({
    where: { pharmacyId },
    include: { patient: { select: { fullName: true } }, items: true },
    orderBy: { issuedAt: "desc" }, take: 25,
  });
  return rows.map(o => ({
    id: o.id, patient: o.patient.fullName, medecin: o.prescriber ?? "—",
    date: o.issuedAt.toISOString().slice(0, 10), items: o.items.length,
    statut: o.status, notes: o.notes ?? "",
  }));
}

export async function getSuppliers(pharmacyId: string) {
  const rows = await prisma.supplier.findMany({
    where: { pharmacyId }, include: { _count: { select: { products: true } } }, orderBy: { name: "asc" },
  });
  return rows.map(s => ({
    id: s.id, nom: s.name, pays: s.country, delai: `${s.leadTimeHours} h`,
    encours: s.balance, references: s._count.products, statut: s.isActive ? "Actif" : "Inactif",
  }));
}

export async function getPurchaseOrders(pharmacyId: string) {
  const rows = await prisma.purchaseOrder.findMany({
    where: { pharmacyId }, include: { supplier: { select: { name: true } }, items: true },
    orderBy: { createdAt: "desc" }, take: 15,
  });
  return rows.map(o => ({
    id: o.reference, fournisseur: o.supplier.name, statut: o.status,
    montant: o.totalAmount, date: o.createdAt.toISOString().slice(0, 10), lignes: o.items.length,
  }));
}

/* ─────────── Comptabilité ─────────── */
export async function getAccounting(pharmacyId: string) {
  const rows = await prisma.$queryRaw<{ mois: Date; recettes: bigint }[]>`
    SELECT date_trunc('month', "soldAt") AS mois, SUM(total)::bigint AS recettes
    FROM "Sale" WHERE "pharmacyId" = ${pharmacyId}
    GROUP BY 1 ORDER BY 1 ASC`;

  const depenses = await prisma.expense.groupBy({
    by: ["category"], where: { pharmacyId }, _sum: { amount: true },
  });
  const totalDepenses = depenses.reduce((s, d) => s + (d._sum.amount ?? 0), 0);

  const moisLabels = ["Jan", "Fév", "Mar", "Avr", "Mai", "Juin", "Juil", "Août", "Sep", "Oct", "Nov", "Déc"];
  const serie = rows.map(r => ({
    m: moisLabels[new Date(r.mois).getMonth()],
    recettes: Number(r.recettes),
    depenses: Math.round(Number(r.recettes) * 0.68), // approximation tant que les achats ne sont pas tous saisis
  }));

  const recettesMois = serie.at(-1)?.recettes ?? 0;
  const byMethod = await prisma.payment.groupBy({
    by: ["method"], where: { sale: { pharmacyId } }, _sum: { amount: true },
  });
  const totalPaie = byMethod.reduce((s, m) => s + (m._sum.amount ?? 0), 0) || 1;

  return {
    serie,
    recettesMois,
    depensesMois: totalDepenses,
    benefice: recettesMois - totalDepenses,
    marge: recettesMois ? Math.round(((recettesMois - totalDepenses) / recettesMois) * 100) : 0,
    depenses: depenses.map(d => ({ categorie: d.category, montant: d._sum.amount ?? 0 }))
      .sort((a, b) => b.montant - a.montant),
    paiements: byMethod.map(m => ({
      method: m.method, montant: m._sum.amount ?? 0,
      part: Math.round(((m._sum.amount ?? 0) / totalPaie) * 100),
    })).sort((a, b) => b.montant - a.montant),
  };
}

/* ─────────── IA ─────────── */
export async function getAiData(pharmacyId: string) {
  const recos = await prisma.aiRecommendation.findMany({
    where: { pharmacyId, isDismissed: false }, orderBy: { createdAt: "desc" },
  });

  // Prévision naïve : moyenne mobile sur 4 semaines + tendance linéaire.
  const rows = await prisma.$queryRaw<{ semaine: Date; total: bigint }[]>`
    SELECT date_trunc('week', "soldAt") AS semaine, SUM(total)::bigint AS total
    FROM "Sale" WHERE "pharmacyId" = ${pharmacyId}
    GROUP BY 1 ORDER BY 1 ASC`;

  type Point = { j: string; reel?: number; prevu?: number };
  const last6 = rows.slice(-6);
  const hist: Point[] = last6.map((r, i) => ({ j: `S-${last6.length - i}`, reel: Number(r.total) }));
  const vals = hist.map(h => h.reel ?? 0);
  const n = vals.length || 1;
  const moy = vals.reduce((a, b) => a + b, 0) / n;
  const tendance = n > 1 ? (vals[n - 1] - vals[0]) / (n - 1) : 0;
  const prevu: Point[] = [1, 2, 3].map(k => ({ j: `S+${k}`, prevu: Math.max(0, Math.round(moy + tendance * (n / 2 + k))) }));

  // Top rentabilité réelle (marge = (PV - PA) × quantité vendue).
  const top = await prisma.$queryRaw<{ name: string; marge: bigint; qte: bigint }[]>`
    SELECT p.name,
           SUM((si."unitPrice" - p."purchasePrice") * si.quantity)::bigint AS marge,
           SUM(si.quantity)::bigint AS qte
    FROM "SaleItem" si
    JOIN "Product" p ON p.id = si."productId"
    JOIN "Sale" s ON s.id = si."saleId"
    WHERE s."pharmacyId" = ${pharmacyId}
    GROUP BY p.name ORDER BY marge DESC LIMIT 5`;

  return {
    recos,
    forecast: [...hist, ...prevu] as Point[],
    topProduits: top.map(t => ({ nom: t.name, marge: Number(t.marge), qte: Number(t.qte) })),
  };
}

/* ─────────── WhatsApp ─────────── */
export async function getConversations(pharmacyId: string) {
  const rows = await prisma.whatsappConversation.findMany({
    where: { pharmacyId },
    include: { messages: { orderBy: { createdAt: "asc" } } },
    orderBy: { lastMessageAt: "desc" }, take: 20,
  });
  return rows.map(c => ({
    id: c.id, phone: c.phone, statut: c.status,
    heure: c.lastMessageAt.toISOString().slice(11, 16),
    dernier: c.messages.at(-1)?.body ?? "",
    messages: c.messages.map(m => ({ from: m.sender === "PATIENT" ? "patient" : "bot", text: m.body })),
  }));
}

/* ─────────── Réservations patients ─────────── */
export async function getReservations(pharmacyId: string) {
  const maintenant = new Date();
  const rows = await prisma.reservation.findMany({
    where: { pharmacyId },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    take: 40,
  });
  return rows.map(r => ({
    id: r.id,
    reference: r.reference,
    produit: r.productLabel ?? "—",
    quantite: r.quantity,
    total: (r.unitPrice ?? 0) * r.quantity,
    client: r.customerName ?? "Via WhatsApp",
    source: r.source,
    statut: r.status === "ACTIVE" && r.expiresAt < maintenant ? "EXPIRED" : r.status,
    expireLe: r.expiresAt.toISOString(),
    minutesRestantes: Math.max(0, Math.round((r.expiresAt.getTime() - maintenant.getTime()) / 60000)),
  }));
}

/* ─────────── Paramètres ─────────── */
export async function getSettings(pharmacyId: string) {
  const [pharmacy, members, audit, subscription] = await Promise.all([
    prisma.pharmacy.findUnique({ where: { id: pharmacyId } }),
    prisma.pharmacyMember.findMany({
      where: { pharmacyId },
      include: { user: { select: { fullName: true, email: true, isActive: true } }, role: true },
    }),
    prisma.auditLog.findMany({
      where: { pharmacyId }, include: { user: { select: { fullName: true } } },
      orderBy: { createdAt: "desc" }, take: 10,
    }),
    prisma.subscription.findUnique({ where: { pharmacyId }, include: { invoices: true } }),
  ]);
  return {
    pharmacy,
    members: members.map(m => ({
      id: m.userId, nom: m.user.fullName, email: m.user.email, role: m.role.label,
      statut: m.isActive ? "Actif" : "Suspendu",
    })),
    audit: audit.map(a => ({
      date: a.createdAt.toISOString().slice(0, 16).replace("T", " "),
      qui: a.user?.fullName ?? "système", action: a.action, entite: a.entity ?? "",
    })),
    subscription,
  };
}

/* ─────────── Public (site vitrine) ─────────── */
export async function getPublicGuards(city?: string) {
  const now = new Date();
  const rows = await prisma.guardSchedule.findMany({
    where: { isPublished: true, endsAt: { gte: now }, ...(city ? { city } : {}) },
    include: { pharmacy: true }, orderBy: { startsAt: "asc" },
  });
  return rows.map(g => ({
    pharmacie: g.pharmacy.name, ville: g.city, quartier: g.pharmacy.district ?? "",
    tel: g.pharmacy.phone ?? "", 
    periode: `${g.startsAt.toISOString().slice(0, 10)} → ${g.endsAt.toISOString().slice(0, 10)}`,
  }));
}
