import "server-only";
import { NextResponse } from "next/server";
import { prisma } from "./db";
import { getSession, can, type Session } from "./auth";
import { rateLimit, clientIp, POLICIES } from "./ratelimit";
import { captureError } from "./monitoring";

/**
 * Socle commun des routes d'écriture.
 * Objectif : garantir que chaque mutation est authentifiée, autorisée,
 * validée et tracée — sans répéter ce code dans chaque route.
 */

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export const bad = (msg: string) => new ApiError(422, msg);
export const notFound = (msg = "Ressource introuvable") => new ApiError(404, msg);
export const conflict = (msg: string) => new ApiError(409, msg);

/** Vérifie la session et la permission ; lève une ApiError sinon. */
export async function requirePermission(perm: string): Promise<Session> {
  const s = await getSession();
  if (!s) throw new ApiError(401, "Non authentifié");
  if (!can(s.role, perm)) throw new ApiError(403, "Votre rôle ne permet pas cette action.");
  return s;
}

/**
 * Limite le débit d'écriture par utilisateur (et non par IP : une officine
 * partage souvent une seule connexion NAT, punir l'IP punirait toute l'équipe).
 */
export async function throttle(s: Session, bucket: keyof typeof POLICIES = "write") {
  const p = POLICIES[bucket];
  const r = await rateLimit(`${bucket}:${s.userId}`, p.limit, p.windowMs);
  if (!r.allowed) throw new ApiError(429, `Trop de requêtes. Réessayez dans ${r.retryAfter} seconde(s).`);
}

/** Enveloppe une route : convertit les ApiError en réponses HTTP propres. */
export async function handle<T>(fn: () => Promise<T>) {
  try {
    return NextResponse.json({ ok: true, ...(fn ? await fn() : {}) } as any);
  } catch (e: any) {
    if (e instanceof ApiError) return NextResponse.json({ error: e.message }, { status: e.status });
    // Contraintes Prisma traduites en messages métier.
    if (e?.code === "P2002") return NextResponse.json({ error: "Cette valeur existe déjà (doublon)." }, { status: 409 });
    if (e?.code === "P2025") return NextResponse.json({ error: "Ressource introuvable." }, { status: 404 });
    // Erreur non prévue : on la remonte à la supervision, jamais au client.
    await captureError(e, { origine: "api" });
    return NextResponse.json({ error: "Erreur interne du serveur." }, { status: 500 });
  }
}

/** Journalise une action sensible. Jamais bloquant pour la requête. */
export async function audit(
  s: Session,
  action: string,
  entity?: string,
  entityId?: string,
  metadata?: Record<string, unknown>,
) {
  try {
    await prisma.auditLog.create({
      data: { pharmacyId: s.pharmacyId, userId: s.userId, action, entity, entityId, metadata: metadata as any },
    });
  } catch (e) {
    console.error("[audit] échec", e);
  }
}

/* ─────────── Validation (sans dépendance externe) ─────────── */

export function str(v: unknown, field: string, opts?: { min?: number; max?: number; optional?: false }): string;
export function str(v: unknown, field: string, opts: { min?: number; max?: number; optional: true }): string | null;
export function str(v: unknown, field: string, { min = 1, max = 300, optional = false }: { min?: number; max?: number; optional?: boolean } = {}) {
  if (v == null || v === "") {
    if (optional) return null;
    throw bad(`Le champ « ${field} » est requis.`);
  }
  const s = String(v).trim();
  if (s.length < min) throw bad(`« ${field} » doit contenir au moins ${min} caractères.`);
  if (s.length > max) throw bad(`« ${field} » ne peut pas dépasser ${max} caractères.`);
  return s;
}

export function int(v: unknown, field: string, opts?: { min?: number; max?: number; optional?: false }): number;
export function int(v: unknown, field: string, opts: { min?: number; max?: number; optional: true }): number | null;
export function int(v: unknown, field: string, { min = 0, max = 1_000_000_000, optional = false }: { min?: number; max?: number; optional?: boolean } = {}) {
  if (v == null || v === "") {
    if (optional) return null;
    throw bad(`Le champ « ${field} » est requis.`);
  }
  const n = Number(v);
  if (!Number.isFinite(n)) throw bad(`« ${field} » doit être un nombre.`);
  const i = Math.round(n);
  if (i < min) throw bad(`« ${field} » ne peut pas être inférieur à ${min}.`);
  if (i > max) throw bad(`« ${field} » est trop grand.`);
  return i;
}

export function date(v: unknown, field: string, opts?: { optional?: false }): Date;
export function date(v: unknown, field: string, opts: { optional: true }): Date | null;
export function date(v: unknown, field: string, { optional = false }: { optional?: boolean } = {}) {
  if (v == null || v === "") {
    if (optional) return null;
    throw bad(`Le champ « ${field} » est requis.`);
  }
  const d = new Date(String(v));
  if (Number.isNaN(d.getTime())) throw bad(`« ${field} » n'est pas une date valide.`);
  return d;
}

export function oneOf<T extends string>(v: unknown, field: string, values: readonly T[], fallback?: T): T {
  const s = String(v ?? "");
  if (values.includes(s as T)) return s as T;
  if (fallback !== undefined) return fallback;
  throw bad(`« ${field} » doit être l'une des valeurs : ${values.join(", ")}.`);
}

/** Vérifie qu'une entité appartient bien à la pharmacie de la session (anti-IDOR). */
export async function assertOwnership(
  model: "product" | "patient" | "supplier" | "prescription" | "purchaseOrder",
  id: string,
  pharmacyId: string,
) {
  const found = await (prisma[model] as any).findFirst({ where: { id, pharmacyId }, select: { id: true } });
  if (!found) throw notFound("Cette ressource n'appartient pas à votre officine.");
  return found.id as string;
}
